import React from 'react';
import ChildMenu from './MobileChildMenu';
import UrlSet from '../UrlSet';


class ParentNav extends React.Component {
  state = {
    showChild: false
  }
  childMenuUl = childrenMenu => {
    const { nav,setOpenNav,curIndex,openNavIndex } = this.props;
    const showChild = openNavIndex === curIndex ? true : false;
    if(!showChild){
      return null
    }
    return (
      <div className='child-menu'>
        <ul className='child-ul'>
          {childrenMenu.map((nav, index) => {
            return <ChildMenu nav={nav} index={index} key={`${index}`} />
          })
          }
        </ul>
      </div>
    )
  }
  dropSubMenu = e => {
    this.setState({ showChild: !this.state.showChild });
  }
  render() {
    const { nav,setOpenNav,curIndex,openNavIndex } = this.props;
    
    const childrenMenu = nav.subMenu;

    const showChild = openNavIndex === curIndex ? true : false;
    let reactLink;
    if (process.env.NODE_ENV === 'development') {
      reactLink = nav.reactLink;
    } else {
      reactLink = false;
    }

    return (
      <li className={childrenMenu ? ('li has-child') : ('li')}>
        <div className="link">
          
          <UrlSet href={nav.url} reactNav={reactLink}>
            <span className="menu-item-title">{nav.title}</span>
          </UrlSet>
          {childrenMenu ? (<span className='icon-wrap' onClick={()=>setOpenNav(curIndex)} >
            {showChild ? <i className="arrowIcon up" /> : <i className="arrowIcon down" />}</span>) : null 
          }
        </div>
        {childrenMenu ? (this.childMenuUl(childrenMenu)) : null}
      </li>
    )
  }
}
export default ParentNav;