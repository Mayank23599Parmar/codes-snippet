import React from 'react';
import UrlSet from '../UrlSet';
import HtmlParser from "react-html-parser";


class ChildMenu extends React.Component {
  
  childMenuUl = (childrenMenu,nav) => {
    if(childrenMenu.length > 3 && nav.handle != "use-case"){
      childrenMenu = childrenMenu.slice(0,3)
    }
    
    return (
      <ul className='child-menu third-menu'>
        {childrenMenu.map((child,index) => {
          
          return <li className="lastmenu" key={index}>
            <div className="link third-menu-link">
                <UrlSet 
                title={child.title} 
                href={child.url}>
                  {child.image && 
                  <div className="image">
                    <img src={child.image} alt={child.title} />
                    { (child.handle==='support' && this.props.index > 0) && <img src={child.image} alt={child.title} />}
                  </div>}
                <p>{HtmlParser(child.title)}</p>
              </UrlSet>  
              {child.tag.includes("nav_new_tag") &&
              <div className="new-tag-wrapper">
                <span>NEW</span>
              </div>
              }
            </div>
          </li>
        })}
    </ul>
    )
  }
  // dropSubMenu = e => {
  //   this.setState({ showChild: !this.state.showChild });
  // }
  render() {
    const { nav } = this.props;
    const childrenMenu = nav.subMenu;
    //let navHandle =`child-li ${nav.handle}`;
    //const showChild = this.state.showChild;
    let reactLink;
    if (process.env.NODE_ENV === 'development') {
      reactLink = nav.reactLink;
    } else {
      let arr = nav.url.replace(window.location.origin, '').split('/');
      if (arr[1] === "" || arr[1] === "collections" || arr[1] === "products") {
        reactLink = true;
      } else {
        reactLink = false;
      }
    }
    return (
      <li className={`child-li ${nav.handle}`}>
      {/* <li className={childrenMenu ? ("child-li ") : ("child-li lastmenu") `${nav.handle}`}> */}
        <div className="link">
          <UrlSet href={nav.url} reactNav={reactLink}>
              {/* {nav.image && 
              <div className="image">
                <img src={nav.image} alt={nav.title} />
              </div>} */}
            <span className="menu-item-title">{nav.title}</span>
          </UrlSet>
          
          {/* {childrenMenu ? (<span className='icon-wrap' onClick={this.dropSubMenu} >
            {showChild ? <img src={pwa.icons.arrowUp} alt="hide SubMenu" /> : <img src={pwa.icons.arrowDown} alt="show SubMenu"/>}</span>) : null 
          } */}
        </div>
        {childrenMenu ? (this.childMenuUl(childrenMenu , nav)) : null}
        {childrenMenu.length > 3 &&
          <div className="view-all-wrap">
              <UrlSet href={nav.url} reactNav={reactLink}>
                <span className="menu-item-title">View all</span>
            </UrlSet>
          </div>
           
          }
      </li>
    )
  }
}
export default ChildMenu;