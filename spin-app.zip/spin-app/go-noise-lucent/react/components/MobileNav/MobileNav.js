import React from 'react';
import ParentNav from './MobileParentNav';
import { setMobileNavToggle } from '../../redux/mobile-nav-reducer/MobileNavAction';
import { connect } from 'react-redux';
import SearchContainer from '../header/SearchContainer';
import MediaQuery from '../MediaQuery'
class MobileNav extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      openNavIndex : 0
    }
  }
  setOpenNav = index =>{
    if(index === this.state.openNavIndex){
      this.setState({openNavIndex:0})
    }else{
      this.setState({openNavIndex:index})
    }
  }
  render() {
    let mainMenu = pwa.mainMenu;
    //console.log(mainMenu)
    if (!mainMenu) {
      return null;
    }
    let topBarHeight = 0,HeaderHeight = 0;

    if(document.getElementById('Topbar')){
      topBarHeight = document.getElementById('Topbar').clientHeight;
    }
    if(document.getElementById('mainHeader')){
      HeaderHeight = document.getElementById('mainHeader').clientHeight;
    }
    let Style = {
      top: HeaderHeight + topBarHeight,
      height: `calc(100vh - ${HeaderHeight + topBarHeight}px)`
    }
    return (
      <div id="mobile-drawer-main" style={Style}>
        <div className="mobbile-drawer-wrapper">
        <ul className="ul nav clearfix">
          <MediaQuery query="phone">
            <li className="searchBox hide">
              <SearchContainer />
            </li>
          </MediaQuery>
          {mainMenu.map((nav, index) => {
            return <ParentNav nav={nav} openNavIndex={this.state.openNavIndex} setOpenNav={this.setOpenNav} curIndex={index+1} key={index} />
          })}
          <MediaQuery query="phone">
            {simply.customerLoggedin ? <>
            <li className="li border-less">
              <a href="/account">Account</a>
            </li>
            <li className="li border-less">
              <a href="/account/logout">Log out</a>
            </li>
            </> : <>
            <li className="li border-less">
              <a href="/account/register">Sign up</a>
            </li>
            <li className="li border-less">
              <a href="/account/login">Log in</a>
            </li>
            </>}
          </MediaQuery>
        </ul>
        </div>
      </div>
    )
  }
}
const mapDispatchToProps = dispatch => ({
  openNav: item => dispatch(setMobileNavToggle(item))
})
export default connect(null, mapDispatchToProps)(MobileNav);