import React from 'react';
import Srcset from './SrcSet';
import HtmlParser from 'react-html-parser'
const TrustBatches = (props) =>{
    const {trustBatches} = window.pwa;
    if(trustBatches.blocks.length <= 0){
        return null
    }
    return(
        <div className="home-trust-batches" id={`section_${trustBatches.sectionId}`}>
            <div className={trustBatches.full ? '' :'container'}>
                <ul className="flex-view-xs space-between">
                    {trustBatches.blocks.map((item,index)=>{
                        return(
                        <li key={`item.title${index}`}>
                            <div className="block-content ">
                                <div className='image-area'>
                                    <div className="img">
                                        <Srcset src={item.image} />
                                    </div>
                                </div>
                                <div className='text-area '>
                                    <h5 className="title">{item.title}</h5>
                                    <div className="desc">{HtmlParser(item.text)}</div>
                                </div>
                            </div>
                        </li> 
                        )
                    })}
                </ul>
            </div>
        </div>
    )
}
export default TrustBatches;