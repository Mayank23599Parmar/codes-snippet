import React from 'react';
import HtmlParser from 'react-html-parser';

class CategoryContent extends React.Component {
    render() {
        const { categorycontent } = window.pwa;
        const { collectionInfo } = this.props.collectionData;
        if (!collectionInfo.info) {
            return false;
        }
        const { info } = collectionInfo;
        let title = '', text = ''
        if (info.title == 'Wireless Earbuds') {
            title = categorycontent.wireless_earbuds_title
            text = categorycontent.wireless_earbuds_text
        }
        else if (info.title == 'Headphones') {
            title = categorycontent.headphones_title
            text = categorycontent.headphones_text
        }
        else if (info.title == 'Speakers') {
            title = categorycontent.speakers_title
            text = categorycontent.speakers_text
        }
        else if (info.title == 'Smart Wearables') {
            title = categorycontent.smart_wearables_title
            text = categorycontent.smart_wearables_text
        }
        else if (info.title == 'Smart Watches') {
            title = categorycontent.smart_wearables_title
            text = categorycontent.smart_wearables_text
        }
        else if (info.title == 'Bluetooth Earphones') {
            title = categorycontent.bluetooth_neckbands_title
            text = categorycontent.bluetooth_neckbands_text
        }
        else if (info.title == 'Wireless Audio') {
            title = categorycontent.audio_title
            text = categorycontent.audio_text
        }
        return (
            <div className="category-content" id={`section_${categorycontent.sectionId}`}>
                <div className="container">
                    {title ? <h2 className="title">{title}</h2> : null}
                    <div className="desc-wrapper">
                        <div className="desc">{HtmlParser(text)}</div>
                    </div>
                </div>
            </div>
        )
    }
}
export default CategoryContent;