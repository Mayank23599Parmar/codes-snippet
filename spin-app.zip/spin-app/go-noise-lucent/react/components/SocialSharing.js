export const FacebookShare = url =>{
    let fullUrl =`https://www.facebook.com/sharer/sharer.php?u=${url}`
    window.open(fullUrl, '_blank');
}
export const PinterestShare = (url,title,image) =>{
    let fullUrl  = `//pinterest.com/pin/create/button/?url=${url}&description=${title}&media=https:${image}`;
    window.open(fullUrl, '_blank');
}
export const TwitterShare = (url,title) =>{
    let fullUrl = `https://twitter.com/intent/tweet?description=${title}&url=${url}`;
    window.open(fullUrl, '_blank');
}
export const GoogleShare = url =>{
    let fullUrl = `https://plus.google.com/share?url=${url}`;
    window.open(fullUrl, '_blank');
}