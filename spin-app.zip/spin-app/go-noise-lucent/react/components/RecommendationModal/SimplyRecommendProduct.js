import React, { Component } from 'react'
import { connect } from "react-redux";
import { formatMoney, AddItems, discountCalculator, fetchProductTitle } from '../Helper';
import HtmlParser from 'react-html-parser';
import VariantSelector from '../VariantSelector';
import UrlSet from '../UrlSet';
import { showProductDetailPopup, setProductDetailPopupContent, setVariant, setCartQuantityForPopupProducts } from "../../redux/product/productAction";
import { showCollectionProductPopup,setCollectionProductPopupDetail } from "../../redux/collection/collectionAction";
import { addToCart, updateCart } from "../../redux/cart/cartAction";
export class SimplyRecommendProduct extends Component {

	constructor(props) {
		super(props)
		this.cartQuantityRef = React.createRef();
		this.state = {
			selectedVariant: null,
			showModal: false,
			productVariants: null,
			showUpdateButton: 0,

		}
		this.customStyles = {
			overlay: {
				zIndex: 100,
				backgroundColor: "rgb(202 202 202 / 33%)",
				position: "fixed"
			},
			content: {
				top: "50%",
				left: "50%",
				right: "auto",
				bottom: "auto",
				marginRight: "-50%",
				transform: "translate(-50%, -50%)",
				position: "absolute",
				maxWidth: '800px',
				padding: '30px',
				width: "calc(100% - 20px)",
				borderRadius: "10px",
				height: 'auto'
			},
		};
	}
	handleCloseModal = () => {
		this.setState({
			showModal: false

		});
	}
	initSetDefaultVariant = () =>{
		const { productData, extraProducts,cart } = this.props;
		const { product } = productData;
		const productVariants = product.variants;
		const variants = product.variants;
		let selectedVariant = product.selected_or_first_available_variant ? product.selected_or_first_available_variant : product.variants[0];
		for(let i = 0; i< cart.items.length;i++){
            let itemFound = false;
            let item = this.props.cart.items[i];
            for(let j = 0; j< variants.length;j++){
                let newVariant = variants[j];
                if(newVariant.id == item.item.id){
                    itemFound =true;
                    selectedVariant = newVariant;
                    break;
                }
            }
            if(itemFound){
                break;
            }
        }
		this.setState({ selectedVariant, productVariants: productVariants })
	}
	componentWillMount() {
		const { productData, extraProducts,cart } = this.props
		const { product } = productData;

		if (!product) {
			return null;
		}
		this.initSetDefaultVariant();
	}
	componentDidUpdate(prevProps, prevState) {
		if(JSON.stringify(prevProps.cart) !== JSON.stringify(this.props.cart)){
			this.initSetDefaultVariant();
		}
	}
	setSelectedVariant = (variant) => {
		this.props.setVariant(variant);
		this.setState({ selectedVariant: variant })
	}
	viewProductButton = (variantQuantity) => {
		const { productData, extraProducts } = this.props;
		const { product } = productData;
		let reactpopup = document.querySelector('.ReactModal__Overlay');
		reactpopup.style.zIndex = "120";
		this.props.setCartQuantityForPopupProducts(variantQuantity)
		this.props.showProductDetailPopup(true);
		this.props.showCollectionProductPopup(true)
		this.props.setProductDetailPopupContent(product)
		this.props.setCollectionProductPopupDetailAction(product)
		
		// this.props.setVariant(product.variants[0]);
		// console.log(product.variants[0], 'mywarianr');
		this.setState({ showUpdateButton: 1 })

	}
	updatedVariantModal = (cartedVariant, variantQuantity) => {
		const { productData, extraProducts } = this.props;
		const { product } = productData;
		let reactpopup = document.querySelector('.ReactModal__Overlay');
		reactpopup.style.zIndex = "120";
		this.props.showProductDetailPopup(true);
		this.props.showCollectionProductPopup(true)
		this.props.setProductDetailPopupContent(product);
		this.props.setCollectionProductPopupDetailAction(product)
		// this.props.setCartQuantityForPopupProducts(variantQuantity)
		// this.props.setVariant(cartedVariant);
	}
	minusPopupProductQauntity = async (cartValue, variantId) => {
		if (cartValue == 1) {
			return
		}
		const form = { [variantId]: cartValue - 1 };

		this.props.updateCart(form);

	}
	addPopupProductQuantity = (cartValue, variantId) => {
		let cartQuantityValue = parseInt(this.cartQuantityRef.current.value) + 1
		const form = { id: parseInt(variantId), quantity: cartQuantityValue - parseInt(cartValue) }
		let data = {}
		data = {
			"type": "cart",
			form
		}
		this.props.addToCart(data);

		this.cartQuantityRef.current.value = cartQuantityValue
	}
	render() {
		let check = 0;
		const { productData, checkCart, cart } = this.props;
		const { selectedVariant } = this.state;
		const { product, avgRating, swatchImages, discountText } = productData;
		let { swatchTitleShow } = false;
		if (!product || !selectedVariant) {
			return null;
		}

		const { variants, options } = product;
		let actual_title = product.title;
		let tagTitle = fetchProductTitle(product.tags);
		if (tagTitle) {
			actual_title = tagTitle;
		}
		let hasSalePrice = product.tags.find((tag) => tag.includes('sale_'));
		let vclass = '';
		let itemAddedFound = false;
		let addedItem=null
		this.props.cart.items.map((cv, i) => {
			if (this.state.productVariants.find(e => e.id === cv.item.id)) {
				itemAddedFound = true;
				addedItem=cv

			}
		})
		return (
			<>
				<div className='product'>
					<div className='img-part'>
						<div className='img'>
							<img src={selectedVariant.featured_image.src} />
						</div>
					</div>
					<div className='content-part'>
						<h2 className='title'>
							<UrlSet className="product-link" href={`/products/${product.handle}`}>
								<span className="product-title" >{actual_title}</span>
							</UrlSet>
						</h2>
						<div className="product-content-discription">
							<div className="product-price ">
								<h5 className="price">{hasSalePrice && salePrice > 0 ? formatMoney(salePrice * 100) : formatMoney(parseInt(selectedVariant.price))}</h5>
								<div className="discout-price-ewapper">
									{selectedVariant.compare_at_price && selectedVariant.compare_at_price > selectedVariant.price &&
										<p className="compare">
											{formatMoney(parseInt(selectedVariant.compare_at_price)).substring(1)}
										</p>}
									<div className="discount-percentage offer2-active"><p>Save {discountCalculator(selectedVariant.price, selectedVariant.compare_at_price)}</p></div>
								</div>

							</div>
							<div className='btn-wrapper'>
								{itemAddedFound?<button onClick={() => this.updatedVariantModal(addedItem.item,addedItem.item.quantity)}>Update</button>:<button onClick={() => this.viewProductButton(1)}>+ Add</button>}
							</div>
						</div>

					</div>

				</div>

			</>
		)
	}
}
const mapStateToProps = (state) => ({
	cart: state.cart.cart,
	checkCart: state.product.checkCart,
	product: state.product.product,
	cartQuantity: state.product.cartQuantity,
	product: state.product.product,
	selectedVarintForPopUp:state.product.selectedVarintForPopUp,
});
const mapDispatchToProps = (dispatch) => ({
	showProductDetailPopup: (data) => dispatch(showProductDetailPopup(data)),
	showCollectionProductPopup: (data) => dispatch(showCollectionProductPopup(data)),
	setProductDetailPopupContent: (data) => dispatch(setProductDetailPopupContent(data)),
	setVariant: (data) => dispatch(setVariant(data)),
	addToCart: (data) => dispatch(addToCart(data)),
	updateCart: qtyArray => dispatch(updateCart(qtyArray)),
	setCartQuantityForPopupProducts: (data) => dispatch(setCartQuantityForPopupProducts(data)),
	setCollectionProductPopupDetailAction: (data) => dispatch(setCollectionProductPopupDetail(data))
});
export default connect(mapStateToProps, mapDispatchToProps)(SimplyRecommendProduct);
