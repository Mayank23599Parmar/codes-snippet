import React, { Component } from "react";
import { connect } from "react-redux";
import { addToCart } from "../../redux/cart/cartAction";
import { showRecommendationProducts } from "../../redux/product/productAction";
import { showRecommendationCollectionProducts } from "../../redux/collection/collectionAction";
import { formatMoney, discountCalculator } from "../Helper";
import SimplyRecommendProduct from "./SimplyRecommendProduct";
import SrcSet from "../SrcSet";
import UrlSet from "../UrlSet";
export class RecommendationModal extends Component {
  constructor(props) {
    super(props);
    this.SubQuantity = 1;
    this.state = {
      anySelected: false,
      extraProducts: {},
      extraProductsCount: 0,
      extraProductsPrice: 0,
      extraProductsComparePrice: 0,
      codeActiveClass: "",
      copyCodeTooltip: "Copy to clipboard",
    };
  }

  componentDidUpdate() {
    console.log(this.props);
  }

  extraProductsChange = (productID, selectedVariant) => {
    let variantID = selectedVariant.id;
    let {
      extraProductsCount,
      extraProductsPrice,
      extraProductsComparePrice,
      extraProducts,
      anySelected,
    } = this.state;
    if (!extraProducts[productID]) {
      extraProducts[productID] = [];
      extraProducts[productID].push(variantID);
      extraProductsCount = extraProductsCount + 1;
      extraProductsPrice = extraProductsPrice + selectedVariant.price;
      extraProductsComparePrice =
        selectedVariant.compare_at_price + extraProductsComparePrice;
    } else {
      if (extraProducts[productID].includes(variantID)) {
        extraProducts[productID].splice(
          extraProducts[productID].indexOf(variantID),
          1
        );
        if (extraProducts[productID].length === 0) {
          delete extraProducts[productID];
          extraProductsCount = extraProductsCount - 1;
          extraProductsPrice = extraProductsPrice - selectedVariant.price;
          extraProductsComparePrice =
            extraProductsComparePrice - selectedVariant.compare_at_price;
        }
      } else {
        extraProducts[productID].push(variantID);
        extraProductsCount = extraProductsCount + 1;
        extraProductsPrice = extraProductsPrice + selectedVariant.price;
        extraProductsComparePrice =
          selectedVariant.compare_at_price + extraProductsComparePrice;
      }
    }
    if (Object.keys(extraProducts).length > 0) {
      anySelected = true;
    } else {
      anySelected = false;
    }
    this.setState({
      extraProducts,
      anySelected,
      extraProductsCount,
      extraProductsPrice,
      extraProductsComparePrice,
    });
  };
  handleCart = () => {
    const { anySelected, extraProducts } = this.state;
    const { productsList, masterProductVariant } = this.props;
    let masterProductVariantId = masterProductVariant.id;
    if (anySelected) {
      const items = [{ id: parseInt(masterProductVariantId), quantity: 1 }];
      Object.values(extraProducts).map((ids) => {
        ids.forEach((id) => {
          items.push({
            id: parseInt(id),
            quantity: 1,
          });
        });
      });
      let data = {
        type: "cart",
        form: { items: items },
      };
      this.props.addToCart(data);

      window.location.href = "/cart";
    } else {
      const form = { id: parseInt(masterProductVariantId), quantity: 1 };
      let data = {
        type: "cart",
        form,
      };
      this.props.addToCart(data);
      window.location.href = "/cart";
    }
  };
  payWithCreditCardButtonHandler = () => {
    window.location = "/checkout";
  };
  closePopup = () => {
    var root = document.getElementsByTagName("html")[0];
    document.body.classList.remove("overflow-hidden");
    root.classList.remove("overflow-hidden");
    document.body.style.height = "auto";
    root.style.height = "auto";
    this.props.showRecommendationProductsAction(false);
    this.props.showRecommendationCollectionProducts(false);
  };
  copyCodeHandler = () => {
    this.setState({ copyCodeTooltip: `Copied !` });
    navigator.clipboard.writeText(this.props.frequntlyContent.code);
    this.setState({ codeActiveClass: "active" });
  };
  proceedToCheckoutButton = () => {
    window.location.href = "/checkout";
  };
  render() {
    if (document.getElementById("product-cart-quantity")) {
      this.SubQuantity = parseInt(
        document.getElementById("product-cart-quantity").value
      );
    }
    const {
      anySelected,
      extraProducts,
      extraProductsCount,
      extraProductsPrice,
      extraProductsComparePrice,
    } = this.state;
    const {
      productsList,
      masterProductVariant,
      masterProductTitle,
      frequntlyContent,
      masterProductImg
    } = this.props;
    let masterProductVariantId = masterProductVariant.id;
    let totalPrice = masterProductVariant.price + extraProductsPrice;
    let totalComparePrice =
      masterProductVariant.compare_at_price + extraProductsComparePrice;
    let checkProductExistOrNot = false;
    const masterProductVariantDetail = masterProductVariant.name;
    let productsListHtml = productsList.map((x, i) => {
      //add condition if same product aa available 		if (x.product.available && x.product.variants[0].name != masterProductVariant.name) {
      return (
        <SimplyRecommendProduct
          key={i}
          productData={x}
          extraProducts={extraProducts}
          extraProductsChange={this.extraProductsChange}
        />
      );
    });
    let masterImg = '';
    if(masterProductImg){
      masterImg = masterProductImg;
    }
    if(masterProductVariant.featured_image){
      masterImg = masterProductVariant.featured_image.src;
    }
    return (
      <>
        <div className="recommedation-wrapper">
          <div className="buttons-wrapper">
            <div className="recomendation-warpper-header">
              <div className="cart-icon">
                <UrlSet href={`/cart`}>
                  <div className="icon-wrapper">
                    <svg
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M9 22C9.55228 22 10 21.5523 10 21C10 20.4477 9.55228 20 9 20C8.44772 20 8 20.4477 8 21C8 21.5523 8.44772 22 9 22Z"
                        stroke="#5C5C5C"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                      <path
                        d="M20 22C20.5523 22 21 21.5523 21 21C21 20.4477 20.5523 20 20 20C19.4477 20 19 20.4477 19 21C19 21.5523 19.4477 22 20 22Z"
                        stroke="#5C5C5C"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                      <path
                        d="M1 1H5L7.68 14.39C7.77144 14.8504 8.02191 15.264 8.38755 15.5583C8.75318 15.8526 9.2107 16.009 9.68 16H19.4C19.8693 16.009 20.3268 15.8526 20.6925 15.5583C21.0581 15.264 21.3086 14.8504 21.4 14.39L23 6H6"
                        stroke="#5C5C5C"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                    </svg>

                    <p>Go to bag</p>
                  </div>
                </UrlSet>
              </div>
              <div className="cross-sign" onClick={this.closePopup}>
                &#10005;
              </div>
            </div>

            <div className="added-products-details">
              <div className="product-detail">
                <div className="product-image">
                  <SrcSet
                    src={masterImg}
                    alt={masterProductTitle}
                  />
                </div>
                <div className="product-price">
                  <h5 className="product-variant-title">✓ Added to cart</h5>
                  <div className="product-sub-details">
                    <span className="product-bag-subtotal">
                      Cart Subtotal (
                      {this.props.cart.cart.item_count
                        ? this.props.cart.cart.item_count > 1
                          ? `${this.props.cart.cart.item_count} Items`
                          : `${this.props.cart.cart.item_count} Item`
                        : "no Item"}
                      ):
                    </span>
                    <span className="price">
                      {formatMoney(this.props.cart.cart.total_price)}
                    </span>
                  </div>
                </div>
              </div>
              {/* <div className="price-wrap">
							<h5 className="price">{formatMoney(totalPrice)}</h5>
							<h5 className="compare-price">{formatMoney(totalComparePrice)}</h5>
							<h5 className="save-price">Saved {discountCalculator(totalPrice,totalComparePrice)}</h5>
						</div>
						<span className="title">
							{masterProductTitle} 
						</span>
						<span className="ptoduct-count">{extraProductsCount > 0 && `+ ${extraProductsCount} Products` }</span> */}
            </div>
            <div className="buy-now-wrapper">
              <div className="gokwik-container btn-right">
                <button className="gokwikpay shop-btn btn" data-type="cod" data-theme='{"primaryClr":"#505AF0"}' >
                  <span>
                    <span className="btn-text">
                      <span>Pay via UPI/COD</span>
                    </span>
                  </span>
                </button>
              </div>
			  <button className="btn pay-with-credit-cart-button" onClick={this.payWithCreditCardButtonHandler}>
                Pay via Card/Wallet
              </button>
            </div>
          </div>
          <div className={`products-list ${this.state.codeActiveClass}`}>
            {frequntlyContent ? (
              frequntlyContent.code && frequntlyContent.code ? (
                <div className="coupon-section-wrapper">
                  <div className="coupon-text-warpper">
                    <h5 className="coupon-text">{frequntlyContent.text}</h5>
                  </div>
                  <div className={`coupon-code-tooltip`}>
                    <span className="tooltiptext" id="myTooltip">
                      {this.state.copyCodeTooltip}
                    </span>
                    <div
                      className={`coupon-code-wrapper ${this.state.codeActiveClass}`}
                      onClick={this.copyCodeHandler}
                    >
                      <h5
                        className={`coupon-code ${this.state.codeActiveClass}`}
                      >
                        {frequntlyContent.code}
                      </h5>
                      <img src="https://img.icons8.com/material-outlined/24/000000/copy.png" />
                    </div>
                  </div>
                </div>
              ) : (
                <h5 className="product-list-title">
                  {frequntlyContent.frequently_text}
                </h5>
              )
            ) : (
              <h5 className="product-list-title">
                {frequntlyContent.frequently_text}
              </h5>
            )}
            {productsListHtml}
          </div>
          <div className="recommedation-checkout-button-wrapper">
            <div className="gokwik-container btn-right">
              <button className="gokwikpay shop-btn btn" data-type="cod" data-theme='{"primaryClr":"#505AF0"}'>
                <span>
                  <span className="btn-text">
                    <span>Pay via UPI/COD</span>
                  </span>
                </span>
              </button>
            </div>
            <button className="btn pay-with-credit-cart-button" onClick={this.payWithCreditCardButtonHandler}>
              Pay via Card/Wallet
            </button>
          </div>
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  cart: state.cart,
});
const mapDispatchToProps = (dispatch) => ({
  addToCart: (data) => dispatch(addToCart(data)),
  showRecommendationProductsAction: (data) =>
    dispatch(showRecommendationProducts(data)),
  showRecommendationCollectionProducts: (data) =>
    dispatch(showRecommendationCollectionProducts(data)),
});
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(RecommendationModal);
