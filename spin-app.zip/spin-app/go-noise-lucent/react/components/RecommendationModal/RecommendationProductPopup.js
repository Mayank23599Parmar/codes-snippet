
import React, { Component } from "react";
import VariantSelector from "../VariantSelector";
import UrlSet from "../UrlSet";
import { formatMoney, fetchProductTitle, discountCalculator, saveCalculator } from "../Helper";
import { connect } from "react-redux";
import {  showProductDetailPopup} from "../../redux/product/productAction";
import { addToCart, updateCart } from "../../redux/cart/cartAction";
import { showCollectionProductPopup} from "../../redux/collection/collectionAction";
class RecommendationProductPopup extends Component  {
    constructor(props){
        super(props);
        this.state = {
            variant: null,
            qtyError: false,
            qty: 1
        }
    }
    componentDidMount(){
        let variants = [...this.props.product.variants];
        let variant ;
        if(variants){
          variant = variants[0];
          let qty = 1;
        variants.map((item)=>{
            if(item.available){
                variant = item;
            }
        });
        
        let firstAvailableVariant = variants.find((item)=> item.available == true);
        if(firstAvailableVariant){
            variant =firstAvailableVariant;
        };
        for(let i = 0; i< this.props.cart.items.length;i++){
            let itemFound = false;
            let item = this.props.cart.items[i];
            for(let j = 0; j< variants.length;j++){
                let newVariant = variants[j];
                if(newVariant.id == item.item.id){
                    itemFound =true;
                    variant = newVariant;
                    qty = item.item.quantity
                    break;
                }
            }
            if(itemFound){
                break;
            }
        }
        this.setState({qty,variant});
        }
        
    }
    
    popupUpdateVariant=(variant)=>{
        let qty=1
        this.props.cart.items.map((cv,i)=>{
            if(cv.item.id===variant.id){
                qty=cv.item.quantity
            }
        })
        this.setState({qty,variant,qtyError:false});
    }
    addPopupProductQuantity = (type) =>{
        let qty = this.state.qty;
        if(type == 'plus'){
            qty = qty + 1;
        }else{
            if(qty > 1){
                qty = qty - 1;
            }
        }
        if(qty > 5)
        {
          this.setState({qtyError:true});
        }else{
          this.handleChange(qty);
        }
    }
    cartPopupProduct = async () => {
        const { variant } = this.state;
        let alreadyExist=false
        const form = { id: parseInt(variant.id), quantity: this.state.qty }
        let data = {}
        data = {
          "type": "cart",
          form
        }
        this.props.cart.items.map((cv,i)=>{
          if(cv.item.id===variant.id){
            alreadyExist=true
          }
        })
    
        if(alreadyExist){
          let vid=parseInt(variant.id)
          await this.props.updateCart({ [vid]: this.state.qty})
        }
        else{
          await this.props.addToCart(data);
        }
        this.props.showProductDetailPopup(false);
        this.props.showCollectionProductPopup(false)
    }
    handleChange = (qty) =>{
      if(qty > 0){
        this.setState({qty,qtyError:false})
      }
    }
    render(){
        if(!this.state.variant){
            return null;
        }
        const variant = this.state.variant;
        const product = this.props.product;
        let defaultVariant = false;
        if (product.variants.length === 1) {
          if (product.variants[0].title == 'Default Title') {
            defaultVariant = true;
          }
        }
        const {featured_image} = variant;
        let src = product.featured_image;
        if(featured_image){
        src = featured_image.src;
        }
        let qtyError = this.state.qtyError;
        return(
            <div className="product-detail-popup">
                <div className="product-detail-inner-warpper">
                  <div className="main-wrapper">
                    <div className="product-detail-inner">
                      <div className="master-product-wrapper">
                        <div className="master-product-detail">
                          <div className="master-product-detail-wrapper">
                            <div className="master-product-image-wraper">
                              <img src={src} alt={product.title} />
  
                            </div>
                            <div className="master-product-description">
                              <div className="master-product-title">
                                <h5>{fetchProductTitle(product.tags)}</h5>
                              </div>
                              <div className="master-product-price-wrapper">
                                <div className="master-product-original-price">
                                  <span>{formatMoney(variant.price)}</span>
                                </div>
                                <div className="master-product-compare-price">
                                  <span>{formatMoney(variant.compare_at_price)}</span>
                                </div>
                                <p className="discount-percentage offer2-active">Save {discountCalculator(variant.price, variant.compare_at_price)}</p>
                              </div>
                            </div>
                          </div>
                          <div className="close-button" onClick={this.props.closeProductPopup}>
                            <span>✕</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="variants-wrapper">
                    <div className="variant-selector-wrapper">
                      <div className="select-color-wrapper">
                        <p>Select Color</p>
                      </div>
                      <div className="varinat-title-wrapper">
                        <p className="variant-title"> {variant.title} </p>
                      </div>
                    </div>
  
  
                    {product.options.map((option, index) => {
                      return (
                        <ul key={index} className={`swatch-wrap ${defaultVariant ? ' hide-swatch-wrap' : ''}`}>
                          {product.variants.map((variant) => {
                            // if(variant.inventory_quantity>0)
                            {console.log(variant.title)}
                            return <VariantSelector
                                  key={variant.id}
                                  option={option}
                                  selectedVariant={this.state.variant}
                                  variant={variant}
                                  variantImages={[]}
                                  setSelectedVariant={this.popupUpdateVariant}
                                  changeUrl={false}
                                />
  
                          })}
                        </ul>
                      );
                    })}
                  </div>
                  <div className="quantity-wrapper">
                    <div className="quantity-text">
                      <p>Quantity</p>
                    </div>
                    <div className="quantity-button-wrapper">
                      <div className="variant-cart-quantity-wrapper">
                        <div className='variant-cart-quantity'>
  
  
                          <div className="quantity-spinner">
                            <div className={`cart-spinner-button ${this.state.qty == 1  ? 'active' : ""}`} onClick={(e) => this.addPopupProductQuantity('minus')}>
                              -
                            </div>
                            <span className="qty-show">{this.state.qty}</span>
                            <div className="cart-spinner-button" onClick={(e) => this.addPopupProductQuantity('plus')}>
                              +
                            </div>
                          </div>
  
                        </div>
                      </div>
                    </div>
                    {qtyError && <p className="qty-error">Maximum cart limit is 5 units</p>}
                  </div>
                  <div className="popup-buy-button-wrapper">
                    <UrlSet className="view-product-button btn" href={`https://www.gonoise.com/products/${product.handle}`}>
                        view product details
                    </UrlSet>
  
                    <button className="select-variant-button btn" onClick={this.cartPopupProduct}>
                      Select
                    </button>
                  </div>
  
                </div>
  
              </div>
        )
    }
}



const mapStateToProps = (state) => ({
    cart: state.cart.cart
});
const mapDispatchToProps = (dispatch) => ({
    addToCart: (data) => dispatch(addToCart(data)),
    updateCart: (data) => dispatch(updateCart(data)),
    showProductDetailPopup: (data) => dispatch(showProductDetailPopup(data)),
    showCollectionProductPopup: (data) => dispatch(showCollectionProductPopup(data)),
});
  export default connect(mapStateToProps, mapDispatchToProps)(RecommendationProductPopup);