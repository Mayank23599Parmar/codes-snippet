import React from 'react';
import UrlSet from '../UrlSet';

class SideCartCheckoutBtn extends React.Component {
 check = e => {
  window.location = '/checkout';
 };

 render() {
  return (
   <div className='side-cart-checkout-btn'>
    {/* <UrlSet className="side-cart-btn" href="/checkout">Checkout</UrlSet> */}
    <button className='side-cart-btn' onClick={() => this.check(this)}>
     Checkout
    </button>
    {/* <UrlSet className="side-cart-btn-home" href="/">Continue Shopping</UrlSet> */}
   </div>
  );
 }
}

export default SideCartCheckoutBtn;
