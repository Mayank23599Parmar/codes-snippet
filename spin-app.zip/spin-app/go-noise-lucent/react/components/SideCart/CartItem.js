import React, { Component } from 'react';
import { Link } from "react-router-dom";
import { connect } from 'react-redux';
// import { updateCart } from '../../shopify/CartApi';
import { formatMoney, fetchProductTitle } from '../Helper';
import { Spinner } from '../Form';
import Srcset from '../SrcSet';
import { updateCart } from '../../redux/cart/cartAction'
class CartItem extends Component {
  getQtyArray = (qty) => {
    const { index } = this.props;
    // debugger
    let cartData = this.props.cart;
    let items = cartData.cart.items;
    let qtyArray = items.map((item, item_index) => {
      if (item_index === index) {
        return qty
      }
      return item.item.quantity;
    })
    return qtyArray;
  }
  removeItem = () => {
    const qtyArray = this.getQtyArray(0);
    this.props.updateCart(qtyArray);
  }
  changeQty = qty => {
    if (qty === 0) {
      const qtyArray = this.getQtyArray(0);
      this.props.updateCart(qtyArray);
    } else {
      const qtyArray = this.getQtyArray(qty);
      this.props.updateCart(qtyArray);
    }
  }
  render() {
    const { item, tags } = this.props.item;
    let { key, variant_id, url, image, line_price, quantity } = item;
    let actual_title = item.title;
    let tagTitle = fetchProductTitle(tags);
    if (tagTitle) {
      actual_title = tagTitle;
    }
    let showSpinner = true;

    return (
      <div data-vid={variant_id} className="cart-items " data-product-type={item.product_type}>
        <div className="flex-view-xs middle space">
          <div className="col-xs-4">
            <div className="cart-item-image img">
              <Link to={url} className="cart-image">
                <img alt={actual_title} src={image} className='lazyload' />
              </Link>
            </div>
            <br />
          </div>

          <div className="col-xs-8">
            <div>
              <div className="text-wrap">

                <div className="cart-item-name">
                  <div className="flex-view-xs space-between">
                    <Link to={url} >
                      {actual_title}
                    </Link>
                    <p className="product-price original-price">
                      {item.product_type === "Free sample" ? formatMoney(0) : formatMoney(line_price)}
                    </p>
                  </div>
                </div>
                {item.variant_title && <span className="variant-title">{item.variant_title}</span>}

                <div className='qty-part'>
                  {showSpinner && (
                    <div className="qty-label">
                      <p>
                        Quantity
                      </p>
                      <div className='text-left qty'>
                        <Spinner id={`updates-${key}`}
                          label='Quantity'
                          name="updates[]"
                          value={quantity}
                          callbackFun={this.changeQty}
                        />
                        <p className="item-remove" onClick={this.removeItem}>
                          Remove
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    cart: state.cart
  }
};
const mapDispatchToProps = dispatch => {
  return {
    setCartStart: () => dispatch(setCartStart()),
    updateCart: qtyArray => dispatch(updateCart(qtyArray))
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(CartItem);
