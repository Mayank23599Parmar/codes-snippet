import React from "react";
import { formatMoney } from "../Helper";
import SideCartCheckoutBtn from "./sidecartCheckoutBtn";

class SideCartFooter extends React.Component {
  comparePrice = items =>{
    let price = 0;
    items.map((data) => {
      let item = data.item;
      price = price + (data.compare_at_price - item.price); 
    })
    return price;
  }
  render() {
    const { cartData } = this.props;
    let total_price = 0;
    let original_total_price = 0;
    if (cartData.total_price) {
      total_price = cartData.total_price;
      original_total_price = cartData.original_total_price;
    }
    let shipping_msg = "";
    try {
      shipping_msg = window.pwaSettings.cart.shipping_msg;
    } catch (e) {
    }
    if (window.reactMode) {
      shipping_msg = "Free shipping on orders above Rs.500 on a cart";
    }
    return (
      <div className="footer">
        {/* <p className="cart--subtotal">
          <div className='flex-view-xs space-between'>
            <span className="label">
            Item Subtotal
            </span>
            <span className="value">
              {formatMoney(original_total_price + this.comparePrice(cartData.items))}
            </span>
          </div>
        </p> */}
        {/* <p className="saved-price">
          <div className='flex-view-xs space-between'>
            <span className="label">
            You Saved
            </span>
            <span className="value extra">
            -{formatMoney(this.comparePrice(cartData.items))}
            </span>
          </div>
        </p> */}
        
        <div className='cart-total'>
          <div className='flex-view-xs space-between'>
            <h5 className="price-label">
              Total
            </h5>
            <h5 className='price'>{formatMoney(total_price)}</h5>
          </div>
        </div>
        <p className="shipping">
            <span className="label">
              *Free shipping & gst inclusive prices
            </span>
        </p>
        <SideCartCheckoutBtn />
      </div>
    );
  }
}

export default SideCartFooter;
