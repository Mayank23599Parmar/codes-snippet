import React, { Component } from 'react';

import CartItem from './CartItem';
import Loader from '../loader/loader';
import SidecartMessage from './sidecartMessage';
import {cart_addition} from '../../clever-tap-events/CartEvent'

class SideCartBodyContent extends Component {
 render() {
  const { cartData } = this.props;
  const loading = cartData.loading;
  const cartItems = cartData.cart;
  if (loading) {
      
   return <Loader />;
  }
  cart_addition(cartData.cart)
  if (cartItems.item_count === 0) {
   return (
    <div className='mini-cart-data'>
     <div className='empty-cart-msg'>Your cart is empty</div>
    </div>
   );
  }
  return (
   <div className='mini-cart-data'>
    {cartData.freesample && <SidecartMessage cartData={cartData} />}
    <form>
     <input type='hidden' name='update' value='' />
     <div className='cart-data'>
      {cartItems.items.map((item, index) => (
       <CartItem item={item} key={item.id} index={index} />
      ))}
     </div>
    </form>
   </div>
  );
 }
}

export default SideCartBodyContent;
