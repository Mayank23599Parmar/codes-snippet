import React from 'react';
import { connect } from 'react-redux';
import SideCartHeader from './sidecartHeader';
import SideCartBodyContent from './sidecartBodyContent';
import SideCartFooter from './sidecartFooter';
import Loader from '../loader/loader';
//import {cart_addition} from '../../clever-tap-events/CartEvent'


class SideCart extends React.Component {
  render() {
    const {cartData} = this.props;
    //cart_addition(cartData.cart)
    var active = this.props.isactive ? "active" : "";
    return (
      <div className={"side-cart-wrap" + active}>
        {/* <SideCartHeader /> */}
        {cartData.cart ? (
          <>
          {/* <SideCartBodyContent cartData={cartData}/>
          <SideCartFooter cartData={cartData.cart}/> */}
          </>
        ):(<Loader/>)}
        
      </div>
    )
  }
}

const mapStateToProps = state => (
  {
    cartData: state.cart
  }
)
// export default connect(mapStateToProps)(SideCart);