import React from 'react'
import { Link } from 'react-router-dom'

const SidecartMessage = props => {
  let { eligible } = props.cartData.freesample;
  let { cartCount, freeCount } = props.cartData.cart

  if (true) { //to disable free sample. Remove this if you want to enable it again 
    return null
  }
  if (!eligible && cartCount === 1) {
    return (
      <div className="free-sample-text-wrapper">
        <h4 className="free-sample-text">Add one more item to your cart to get complimentary miniature!</h4>
      </div>
    )
  } else if (eligible && freeCount === 1) {
    return (
      <div className="free-sample-text-wrapper">
        <h4 className="free-sample-text">You can add one more complimentary miniature. <Link className="free_sample_link" to="/collections/free-sample">Click here</Link>.</h4>
      </div>
    )
  } else if (eligible && freeCount === 0) {
    return (
      <div className="free-sample-text-wrapper">
        <h4 className="free-sample-text">Get 2 Complimentary miniatures of your choice! <Link className="free_sample_link" to="/collections/free-sample">Click here</Link>.</h4>
      </div>
    )
  } else {
    return null
  }
}

export default SidecartMessage;