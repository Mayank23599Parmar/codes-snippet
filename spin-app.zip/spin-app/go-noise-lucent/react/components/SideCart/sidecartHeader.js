import React from 'react';
import UrlSet from '../UrlSet';
import {closeSideCart} from '../Helper'

class SideCartHeader extends React.Component {
  render() {
    let { closeCart } = this.props;
    return (
      <div className="side-cart-header">
        <h5>
          <UrlSet className='side-cart-title' href='/cart'>
          Shopping Cart
          </UrlSet>
        </h5>
        
        <span className="close-icon" onClick={closeSideCart}>
          <img src={pwa.icons.close} alt="close cart"/>
        </span>
      </div>
    )
  }
}

export default SideCartHeader;