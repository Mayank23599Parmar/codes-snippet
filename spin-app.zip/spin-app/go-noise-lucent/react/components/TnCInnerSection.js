import React, { Component } from "react";
import HtmlParser from "react-html-parser";

export class TnCInnerSection extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showDropDown: false,
    };
  }

  render() {
    const { title, eleArr } = this.props;
    const { showDropDown } = this.state;
    let liElements =
      eleArr &&
      eleArr.map((content, index) => {
        if(cn(content)){
          return null;
        }
        let contArray = content.split(" subtitle#");
        let subtitle = contArray[0];
        if(!cn(contArray[1])){
          contArray = contArray[1].split(" text#");
        }
        let text = contArray[0];
        return (
          <li key={index} className="inner-spec color-white">
            <span className="bullet-point"><p className='color-white'><b>{subtitle ? subtitle : ""}</b></p></span>
            <span className="text-detail"><p className='color-white'>{text ? HtmlParser(text) : ""}</p></span>
          </li>
        );
      });

    return (
      <li className="main-spec"
        onClick={(e) => {
          this.setState({ showDropDown: !showDropDown });
        }}
      >
        <p className={`color-white add-sign ${showDropDown ? "active" : ""}`}>{title}</p>
        <ul className="specifications-inner">{showDropDown && liElements}</ul>
      </li>
    );
  }
}

export default TnCInnerSection;
