import React from 'react';
const loader = () => (
  <div className="loader main-noise-loader">
    <img src={pwa.reactNoiseLoader} alt="Noise loader" />
    {/* <div className="inner one"></div>
    <div className="inner two"></div>
    <div className="inner three"></div> */}
  </div>
)
export default loader;