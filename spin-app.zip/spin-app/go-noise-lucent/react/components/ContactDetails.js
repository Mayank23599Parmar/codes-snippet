import React from 'react';

export default () => {
const {contactDetails} = pwa;
let{contact_call_number,contact_call_number_text,contact_call_title,contact_get_back_to_you_text,contact_help_text,contact_help_title,contact_time_text,contact_time_title,contact_support_btn_text,contact_support_btn_link} =contactDetails;
 return (
  <div className='contact-details'>
   <div className='container'>
    <div className='flex-view-xs space-between'>
     <div className='col-sm-8 col-xs-12'>
      <div className='help-detail'>
       <h3>{contact_help_title}</h3>
       <p className='need-help-content'>
        {contact_help_text}
       </p>
      </div>
     </div>
     <div className='col-sm-4 col-xs-12'>
      <div className='contact-detail'>
       <div className='flex-view-xs space-between time'>
        <div className='half'>
         <span className='bold'>{contact_call_title}</span>
         <span><a href={`tel:${contact_call_number}`}>{contact_call_number_text}</a></span>
        </div>
        <div className='half'>
         <span>{contact_time_title}</span>
         <span>{contact_time_text}</span>
        </div>
       </div>
       <p>{contact_get_back_to_you_text}</p>
       <a className='visit-support-btn btn' href={contact_support_btn_link}>{contact_support_btn_text}</a>
      </div>
     </div>
    </div>
   </div>
  </div>
 );
};
