import React from 'react';
import SubscribeForm from '../components/SubscribeForm';
import HtmlParser from 'react-html-parser';
import MediaQuery from './MediaQuery';
class NewsLetter extends React.Component {
    render(){
        const {newsletter} = window.pwa;
        console.log('newsletter---->',newsletter)
        let texts_show = false;
        if(newsletter.left_text != '' || newsletter.right_text != ''){
            texts_show = true;
        }
        let marquee_show_text = false;
        if(newsletter.marquee_show == true && newsletter.marquee_text != ''){
            marquee_show_text = true;
        }
        let successMsg = '';
        let actualForm = document.querySelector('.footer-newsletter-form')
        if(actualForm.querySelector('.note.form-success')){
            successMsg = actualForm.querySelector('.note.form-success').innerText;
        }
        return(
            <div className="home-newsletter" id={`section_${newsletter.sectionId}`}>
                <div className="container">
                    <div className="home-newsletter-form">
                    <h2 className="title">{newsletter.title}</h2>
                    <div className="form-wrapper">
                        <div className="desc">{HtmlParser(newsletter.text)}</div>
                        {successMsg != '' && <p className="success-msg">{successMsg}</p> }
                        <SubscribeForm 
                        btn_text={newsletter.btn_text} 
                        placeholder={newsletter.input_placeholder} />
                        </div>
                        {marquee_show_text && 
                        <div className="marquee-section">
                            <MediaQuery query="tablet-and-up"><marquee behavior="scroll" direction="left" scrollamount="10" loop="infinite"><p>{newsletter.marquee_text}</p></marquee></MediaQuery>
                            <MediaQuery query="phone"><marquee behavior="scroll" direction="left" scrollamount="7" loop="infinite"><p>{newsletter.marquee_text}</p></marquee></MediaQuery>

                        </div>
                        }
                    </div>
                    {texts_show && <div className="text-part">
                    <h2 className="title">{newsletter.seo_title}</h2>
                        <ul className="flex-view-xs space">
                            {newsletter.left_text && <li className="col-sm-12 col-xs-12">
                                {HtmlParser(newsletter.left_text)}
                            </li>}
                        </ul>
                    </div>}
                </div>
            </div>
        )
    }
}
export default NewsLetter;