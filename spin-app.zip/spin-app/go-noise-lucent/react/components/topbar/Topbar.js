import React, { Component } from 'react';
import UrlSet from '../UrlSet';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
class Topbar extends Component {
  render() {
    let topbar = pwa.topbar;
    if (!topbar.enable || cn(topbar.text)) {
      return null
    }
    return (
      <div className="topbar" id="Topbar">
        <div className="annoucement">
        <UrlSet href={topbar.link}>
          {ReactHtmlParser(topbar.text)}
        </UrlSet>
        </div>
      </div>
    );
  }
}

export default Topbar;