import React, { Component } from "react";
import {connect} from 'react-redux';
import {submitNewsLetter} from '../redux/account/accountActions';
import {emailValidate} from '../components/Helper'
class SubscribeForm extends Component {
  state = {
    input_val: "",
    loading: false,
    msg: "",
    error:""
  }
  handleChange = e => {
    const { value } = e.target;
    this.setState({ input_val: value,msg:"",error:"" });
    let elm = document.getElementById('mail');
    if(elm){
        elm.value = value;
    }
  }
  closeButtonLoading = res =>{
    if (res.status === '200') {
      this.setState({loading:false,error:"",msg:"Thanks for subscribing!",input_val:""})
    }else if (res.status === '401'){
      this.setState({loading:false,error:"",msg:"Already Subscribed!",input_val:""})
    }
    else{
      let error = res.message;
      this.setState({loading:false,error,msg:"",input_val:""})
    }
  }
  handleSubmit = e => {
    e.preventDefault();
    if(cn(this.state.input_val)){
      this.setState({error:"Please fill email!",msg:""})
    }
    else if(!emailValidate(this.state.input_val)){
      this.setState({error:"Please enter valid email!",msg:""})
    }
    else{
      this.setState({loading:true},()=>{
        this.props.submitNewsLetter({
          email:this.state.input_val,
          callback: this.closeButtonLoading
        })
      })
    }
    
    // if (this.state.input_val.trim() !== null && this.state.input_val.trim() !== '') {
    //   // alert(this.state.input_val, this.state.input_val.trim() !== null);
    //   let form = document.getElementById('contact_form');
    //   form.submit();
    // }
  }
  render() {
    let {placeholder,btn_text} = this.props;
    return (
      <div className="subscribe_form_wrap">
        <form
          method="post"
          action="/contact#contact_form"
          acceptCharset="UTF-8"
          className="contact_form flex_view_xs middle"
          onSubmit={e => this.handleSubmit(e)}
        >
          {this.state.error && <p className="error">{this.state.error}</p>}
          {this.state.msg && <p className="success">{this.state.msg}</p>}
          <input
            type="email"
            required=""
            value={this.state.input_val}
            id="mail_form"
            name="contact[email]"
            className="input_email"
            aria-label="Join our mailing list"
            placeholder={placeholder}
            onChange={e => this.handleChange(e)}
          />
          <input type="hidden" name="contact[tags]" value="newsletter" className="active"></input>
          <button type="submit" className={`btn subscribe_btn ${this.state.loading === true ? 'loading':''}`} name="subscribe">{btn_text}</button>
        </form>
      </div>
    );
  }
}


const mapDispatchToProps = dispatch =>({
  submitNewsLetter: data => dispatch(submitNewsLetter(data))
})
export default connect(null,mapDispatchToProps)(SubscribeForm);
