export default {
  baseUrl: "https://pre-order.gonoise.in/",
  postUrl: "https://pre-order.gonoise.in/account/",
  newsLetter: "newsletter",
  register: "register",
  generateOTP: "register/otp",
  verifyOTP: "register/verify",
  address: "address",
  getOrders: "order",
  updateProfile: "profile",
  key: "0329b8ad3bce0bcfdda8ca65c37143c3ccc1e8ae0545da19898ca08bba8ed1a5",
  preOrder: "pre-orders",
  preOrderPayment:"pre-orders/payment",
  getPreorderData: "pre/order",
  preOrderOTPSend:"pre/booking/otp",
  preOrderOTPVerify:"pre/booking/verify"
};
