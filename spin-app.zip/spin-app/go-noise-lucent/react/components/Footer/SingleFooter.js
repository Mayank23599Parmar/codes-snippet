import React, { Component } from "react";

/* Plugin imports */
// import Srcset from "../../components/SrcSet";
import UrlSet from "../../components/UrlSet";
import {footerClickEvent} from "../../clever-tap-events/FooterEvent";

export class SingleFooter extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isActive: false,
    };
  }

  render() {
    const { link } = this.props;
    const { isActive } = this.state;
    return (
      <div className={`menu ${isActive ? "active" : ""}`}>
        <h3
          className="link"
          onClick={() => {
            this.setState({ isActive: !isActive });
          }}
        >
          {link.title} <span className="arrow down"></span>
        </h3>
        <ul className={`submenu`}>
          {link.subMenu.map((sublink) => {
            return (
              <li
                key={sublink.handle}
                onClick={() => footerClickEvent(sublink.title, sublink.url)}
              >
                <UrlSet href={sublink.url}>{sublink.title}</UrlSet>
              </li>
            );
          })}
        </ul>
      </div>
    );
  }
}

export default SingleFooter;
