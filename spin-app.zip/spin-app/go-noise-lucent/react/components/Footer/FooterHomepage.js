import React, { Component } from "react";

/* Plugin imports */
import Srcset from "../../components/SrcSet";
import UrlSet from "../../components/UrlSet";

/* Comp imports */
// import SubscribeInfoForm from "./SubscribeInfoForm";
// import FooterSocialLinks from "./FooterSocialLinks";
import SingleFooter from './SingleFooter';
import FooterContent from '../FooterContent';

/*Clevertap Event*/
import {footerClickEvent} from "../../clever-tap-events/FooterEvent";



class FooterHomepage extends Component {
  render() {
    const { footer } = pwa;
    if(!footer){
      return null;
    }
    const { section } = footer;
    const { settings, blocks } = section;
    if (!settings) {
      return null;
    }
    const list = section.settings.menu.map((link,index)=>{
      return <SingleFooter key={link.handle} link={link} />
    })
    return (
      <div id="footer" className={`section_${section.settings.sectionId}`}>
        <div className={section.settings.full ? "" : "container"}>
          <div className="footer_wrapper">
            {this.props.isHome ? <FooterContent /> : null}
          </div>
        </div>
      </div>
    );
  }
}

export default FooterHomepage;
