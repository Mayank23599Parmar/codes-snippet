import React, { Component } from "react";

class SubscribeInfoForm extends Component {
  state = {
    input_val: ""
  }
  handleChange = e => {
    const { value } = e.target;
    this.setState({ input_val: value });
    let elm = document.getElementById('mail');
    elm.value = value;
  }

  handleSubmit = e => {
    e.preventDefault();
    if (this.state.input_val.trim() !== null && this.state.input_val.trim() !== '') {
      let form = document.getElementById('contact_form');
      form.submit();
    }
  }
  render() {
    return (
      <div className="subscribe_form_wrap">
        <form
          method="post"
          action="/contact#contact_form"
          acceptCharset="UTF-8"
          className="contact_form flex_view_xs middle"
          onSubmit={e => this.handleSubmit(e)}
        >
          <input
            type="email"
            required=""
            value={this.state.input_val}
            id="mail_form"
            name="contact[email]"
            className="input-box"
            aria-label="Join our mailing list"
            placeholder="Email Address"
            onChange={e => this.handleChange(e)}
          />
          <input type="hidden" name="contact[tags]" value="newsletter" className="active"></input>
          <input
            type="submit"
            className="btn"
            name="subscribe"
            value="SIGN UP!"
          />
        </form>
      </div>
    );
  }
}

export default SubscribeInfoForm;
