import React, { Component } from "react";
import UrlSet from "../UrlSet";
// import Srcset from '../../components/SrcSet';

class FooterSocialLinks extends Component {
  render() {
    const {socialIcon}= pwa;
    return (
      <div className="social-icons">
        <ul>
          {socialIcon.map((item, index) => {
            return (
              <li className="social_links_li" key={index}>
                {item.url && item.icon && 
                <UrlSet href={item.url}>
                  <img src={item.icon} />
                </UrlSet>}
              </li>
            );
          })}
        </ul>
      </div>
    );
  }
}

export default FooterSocialLinks;
