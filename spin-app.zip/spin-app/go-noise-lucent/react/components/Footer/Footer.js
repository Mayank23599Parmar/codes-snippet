import React, { Component } from "react";

/* Plugin imports */
import Srcset from "../../components/SrcSet";
import UrlSet from "../../components/UrlSet";

/* Comp imports */
// import SubscribeInfoForm from "./SubscribeInfoForm";
// import FooterSocialLinks from "./FooterSocialLinks";
import SingleFooter from './SingleFooter';
import FooterContent from '../FooterContent';

/*Clevertap Event*/
import {footerClickEvent} from "../../clever-tap-events/FooterEvent";
import {footerFollowClickEvent} from "../../clever-tap-events/FollowEvent";

class Footer extends Component {
  render() {
    const { footer } = pwa;
    if(!footer){
      return null;
    }
    const { section } = footer;
    const { settings, blocks } = section;
    if (!settings) {
      return null;
    }
    const list = section.settings.menu.map((link,index)=>{
      return <SingleFooter key={link.handle} link={link} />
    })
    return (
      <div id="footer" className={`section_${section.settings.sectionId}`}>
        <div className={section.settings.full ? "" : "container"}>
          <div className="footer_wrapper">
            <div className="logo-img">
              <UrlSet href="/">
                <Srcset src={settings.logo} />
              </UrlSet>
            </div>
            <div className="flex-view-xs space">
              <div className="col-sm-9 col-xs-12">
                <div className="menu-part">
                  {list}
                </div>
              </div>
              <div className="col-sm-3 col-xs-12">
                {section.blocks.length > 0 &&
                  <div className="social-login">
                    <h3>
                      {section.settings.follow_us_title}
                    </h3>
                    <ul className=''>
                      {blocks.map((item)=>{
                        return <li key={item.text}>
                          <UrlSet href={item.social_link} target="_blank" onClick={()=>footerFollowClickEvent(item.social_link)}>
                          <img src={item.icon_img}/>
                          <span className="text">{item.text}</span>
                          </UrlSet>
                        </li>
                      })}
                    </ul>
                  </div>
                }
              </div>
            </div>
            {this.props.isHome ? <FooterContent /> : null}
            <div className="copyright_wrapper">
              {section.settings.copyright_text}
              {section.settings.site_map_link && section.settings.site_map_text && 
                <span className='copyright_bar' > | <UrlSet href={section.settings.site_map_link} >
                    {section.settings.site_map_text}
                  </UrlSet> 
                </span>
              }
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Footer;
