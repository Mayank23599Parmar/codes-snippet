import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import CampusFaqInner from "./CampusFaqInner";
class CampusNoisemakerFaq extends Component {
    constructor(props) {
        super(props);
      }
  render() {
    const { specifications } = this.props;
    
    if(cn(specifications.details)){
      return null;
    }
    let sepcArr = specifications.details.split("<>");
    let specificationDetails = sepcArr.map((ele, index) => {
      let eleArr = ele.split(" title#");
      let title = eleArr[0];
      eleArr = eleArr[1].split("$$");
      return (
        <CampusFaqInner key={index} title={title} eleArr={eleArr} />
      );
    });

    return (
      <div>
        <div className="box-section">
          <div className="container">
            <div className="flex-view-xs space product_detail_wrap">
                <h2>FAQs</h2>
                <p>We've got answers.</p>
              <div className="specification-wrap">
                <h2 className="header-title">{ HtmlParser(specifications.title)}</h2>
                <ul className="specifications">{specificationDetails}</ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CampusNoisemakerFaq;
