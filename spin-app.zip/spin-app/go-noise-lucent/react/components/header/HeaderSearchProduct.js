import React, { Component } from "react";
/* Plugins */
import { Link } from 'react-router-dom';
import HtmlParser from "react-html-parser";
import { goToCheckout, productAddCallback } from '../Helper';
import Srcset from '../SrcSet';
// import UrlSet from "../UrlSet";



class HeaderSearchProduct extends Component {
  constructor(props) {
    super(props);
    this.hideVariant = false;
    const { product } = this.props;
    this.availability = product.available ? true : false;
    this.state = {
      variant: product.variants[0],
      soldout: !this.availability,
    };

  }
  componentDidMount() {
    this.availableVariant();
  }
  AddtoCart = (e, checkout) => {
    // debugger;
    const { variant } = this.state;
    const { product } = this.props;

    // let callbackFun = openCartCallback;
    let callbackFun =  productAddCallback;
    if (checkout) {
      callbackFun = goToCheckout;
    }

    AddToCartButtonAction({
      e: e,
      variant: variant,
      qty: 1,
      callback: callbackFun,
      product: product
    });

  }
  availableVariant = () => {
    //check aviablilty of variant and set soldout product
    let { product } = this.props;
    let variant = product.variants.find(variant => variant.available);
    if (variant) this.setState({ variant: variant })
  }

  renderStars = (count) => {
    let i = Math.floor(count);
    let r = (count - i).toFixed(2);
    let html ="";
    for (let index = 0; index < i; index++) {
      html = html + `<i className="stamped-fa stamped-fa-star" aria-hidden="true"></i>`
    }
    if (r > 0.1) {
      html = html + `<i className="stamped-fa stamped-fa-star-half-o" aria-hidden="true"></i>`
    }
    return HtmlParser(html);
  }

  render() {
    let { product, type, from } = this.props;
    if(cn(product.image) || product.title.includes('Test')){
      return null;
    }
    let { variant, soldout } = this.state;
    if (!variant) {
      this.hideVariant = true;
    }
    let img = product.featured_image || product.image.src;
    if (img) {
      if (img.url) {
        img = img.url;
      }
    }
    
    let product_price = product.price_min || product.discounted_price;
    let product_compare_price = product.compare_at_price_min || product.price;
    let hideVariant = this.hideVariant

    if (product.tags && product.tags.includes('free-sample')) {
      return false
    }

    let isSearchTap = from && from == "searchtap";

    return (
      <li ref={this.myRef}>
        <div>
          <div className={"product_main detail_" + product.id}>


            <div className="image">
              <div className="relative img_cell">
                <div className="img">
                  <Link className="product_link" to={`/products/${product.handle}`}>
                    <Srcset alt={product.title} src={img} />
                  </Link>
                </div>
              </div>
            </div>


          <div className="text">
            {type === "listing" && (
              <div className="text-left top-description">
                <Link to={`/products/${product.handle}`} className="product_link" tabIndex={-1}>
                  <span className="product_title" title={product.title} >{product.title}</span>
                </Link>
                {isSearchTap && (product.reviews_count != null || product.reviews_count != undefined) && (
                  <div>
                    <span className="stamped-starrating stamped-badge-starrating">
                      {this.renderStars(product.reviews_average)}
                    </span>
                    ({`${product.reviews_count} ${parseInt(product.reviews_count) > 1 ? 'reviews': 'review'}`})
                  </div>
                )}
              </div>
            )}
              <div className="text_wrapper">
                {type !== "listing" && (
                  <>
                    <Link to={`/products/${product.handle}`} className="product_link" tabIndex={-1}>
                      <span className="product_title" title="{value.title}" >{product.title}</span>
                    </Link>
                    <p className="meta_subtitle">
                    </p>
                  </>
                )}
                {/* <div className="productprice flex_view middle" price={product_price}>
                  <span className="product_price">
                    MRP Rs. {parseInt(product_compare_price) || parseInt(product_price)}
                  </span>
                  {product_compare_price && parseInt(product_compare_price) > parseInt(product_price) && (
                    <span className="compare">
                      OFFER PRICE Rs. {parseInt(product_price)}
                    </span>
                  )}
                </div> */}
                {/* {soldout ? (
                  <div className="product_addtocart_wrap flex_view center middle">
                    <button className="btn soldout disabled">Sold Out</button>
                  </div>
                ) : (
                    (hideVariant ? (
                      <div className="product_addtocart_wrap flex_view_xs middle">
                        <UrlSet href={`/products/${product.handle}`} reactNav={true} className="btn see_details collection_addCart">See details</UrlSet>
                      </div>
                    ) : (
                        <div className="product_addtocart_wrap flex_view_xs middle">
                          <button type="button" name="add" className="btn add_to_cart collection_addCart" onClick={(e) => this.AddtoCart(e)} >
                            <span className="AddToCartText" data-text="Add to cart" data-process="Adding...">Add to cart</span>
                          </button>
                          <button type="submit" name="buynow" className="btn buynow collection_addCart" onClick={(e) => this.AddtoCart(e, "checkout")}>
                            <span data-text="Buy Now" >Buy Now</span>
                          </button>
                        </div>
                      ))
                  )} */}
              </div>
            </div>
          </div>
        </div>
      </li>
    )
  }
}

export default HeaderSearchProduct;
