import React from "react";
import { connect } from "react-redux";
import { searchStart,setSearchToggle } from "../../redux/search/searchAction";
import HeaderSearchProduct from "./HeaderSearchProduct";
import { withRouter } from 'react-router-dom';

import {searchbarEvent} from '../../clever-tap-events/SearchbarEvent'



class SearchContainer extends React.Component {
  constructor(props) {
    super(props);
    this.inputBox = React.createRef();
    this.state = {
      query: "",
    };
  }
  componentDidMount(){
    document.querySelector('.search_form .input_box').focus();
  }
  handleChange = (e) => {
    const value = e.target.value;
    this.setState(
      {
        [e.target.name]: value,
      },
      () => {
        const { setSearchStart } = this.props;
        setSearchStart(value);
      }
    );
  };

  handleSubmit = (e) => {
    e.preventDefault();
    const { history } = this.props;
    let { query } = this.state;
    let { setSearchStart } = this.props;
    searchbarEvent(query)
    setSearchStart("");
    if(history){
      history.push(`/search?q=${query}`);
    }
  };

  sendData = () => {
    if (this.props.data && this.props.searchProductCount) {
      this.props.searchProductCount(this.props.data.products.length);
    }
  };
  clearQuery = () => {
    let { setSearchStart } = this.props;
    setSearchStart("");
  };
  closeSearch = () => {
    const { toggleSearch, setSearchStart } = this.props;
    this.setState(
      {
        query: "",
      },
      () => {
        toggleSearch(false);
        setSearchStart("");
      }
    );
  };
  render() {
    const {searchResult,searchStart} = this.props.showSearch.search;
    
    if (!this.props.showSearch) {
      return false;
    }
    let count = 0;
    if(!cn(searchResult)){
      count = searchResult.length;
    }
    let term = this.state.query;
    if (this.props.term && this.props.term === "") {
      term = "";
    }
    return (
      <div className="search-button">
        <div className="search_form">
          <form
            className="search"
            action="/search"
            onSubmit={(e) => this.handleSubmit(e)}
          >
            <input
              id="menuSearch"
              onChange={this.handleChange}
              placeholder="Search"
              type="text"
              className="input_box"
              name="query"
              value={term}
              ref={this.inputBox}
              autoComplete="off"
            />
            {/* <label for="menuSearch">Search</label> */}
            <button className="submit" type="submit">
              <img src={`${pwa.icons.search}`} alt="search" />
            </button>
              <span onClick={this.closeSearch} className="close-search">
                <img alt="close search" src={pwa.icons.closeWhite} />
              </span>
          </form>
        </div>
        <div className={`top-search-results ${term.length === 0 ? 'no-term' :''}`}>  
          {term.length > 0 && count === 0 ? (
            <ul className="collection-products">
              <li>
                <h3 className="search_result_title">
                  No Results found for {searchStart}
                </h3>
              </li>
            </ul>
          ) : (
            <ul className="collection-products">
              {searchResult.map((product) => (
                <HeaderSearchProduct
                  product={product}
                  img_url="grande"
                  key={product.id}
                  type="listing"
                />
              ))}
            </ul>
          )}
        </div>
      </div>
    );
  }
}
const mapDispatchToProps = (dispatch) => ({
  setSearchStart: (term) => dispatch(searchStart(term)),
  toggleSearch : (value) => dispatch(setSearchToggle(value))
});
const mapStateToProps = (state) => {
  return {
    showSearch: state,
    data: state.search.searchData,
    term: state.search.searchTerm,
  };
  
}
  
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(SearchContainer));
