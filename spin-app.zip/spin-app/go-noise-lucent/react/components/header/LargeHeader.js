import React, { Component } from "react";
import SiteNav from "./SiteNav";
import UrlSet from "../UrlSet";
import SearchContainer from "./SearchContainer";
import MediaQuery from "../MediaQuery";
import MobileNav from "../MobileNav/MobileNav";
import { connect } from "react-redux";
import { setMobileNavToggle } from "../../redux/mobile-nav-reducer/MobileNavAction";
// import { setSideCartToggle, setCartStart } from "../../redux/cart/cartAction";
import { setSearchToggle } from "../../redux/search/searchAction";
class LargeHeader extends Component {
  state = {
    lapsScreenShow: false,
  };
  updateDimensions = () => {
    this.checkMenuType()
  };
  componentDidMount() {
    const { toggleSearch } = this.props;
    toggleSearch(false);
    this.checkMenuType()
    window.addEventListener("resize", this.updateDimensions);
  }
  componentWillUnmount() {
    window.removeEventListener("resize", this.updateDimensions);
  }
  checkMenuType = () => {
    let lapsScreenShow = false;
    let windowWidth = window.innerWidth;
    if (windowWidth >= 1200) {
      let firstLink = document.querySelector(
        ".large-header .main-menu .first-level-li"
      );
      let parentMenu = document.querySelector(
        ".large-header .main-menu ul.nav"
      );
      if (!cn(firstLink) && !cn(parentMenu)) {
        if (parentMenu.offsetHeight > firstLink.offsetHeight) {
          lapsScreenShow = true;
        }
      }
    }
    if (windowWidth < 1200) {
      lapsScreenShow = true;
    }
    this.setState({lapsScreenShow})
  };
  openMobileMenu = () =>{
    var root = document.getElementsByTagName( 'html' )[0];
    root.classList.add('overflow-hidden');
    //document.body.classList.add("overflow-hidden");
    this.props.setMobileNavToggle(true)
    document.body.style.height = '100%';
    root.style.height = '100%';
  }
  closeMobileMenu = () =>{
    var root = document.getElementsByTagName( 'html' )[0];
    root.classList.remove('overflow-hidden');
    document.body.classList.remove("overflow-hidden");
    this.props.setMobileNavToggle(false);
    document.body.style.height = 'auto';
    root.style.height = 'auto';
  }
  render() {
    const { toggleSearch, cart } = this.props;
    let showSearch = this.props.showSearch;
    if (this.props.history.location.pathname === "/search") {
      showSearch = false;
    }
    let {lapsScreenShow} = this.state;
    let {
      container,
      headerSettings,
      setMobileNavToggle,
      showMobileNav,
      // setSideCartToggle,
      startCartFetch,
    } = this.props;
    let cartItems = 0;
    if (cart.cart) {
      cartItems = cart.cart.item_count;
    }
    return (
      <div className="large-header" ref={this.headerRef}>
        <div className={container}>
          <div className="flex-view-xs middle space-between">
            {lapsScreenShow && (
              <>
                <div className="mobile_menu_btn">
                  {showMobileNav ? (
                    <span title="Menu" className="menu fake_anchor_tag close-menu" onClick={() => this.closeMobileMenu(false)} >
                      <img src={`${pwa.icons.closeWhite}`} alt="Menu-close-icon" />
                    </span>
                  ) : (
                    <span
                      title="Menu"
                      className="menu fake_anchor_tag"
                      onClick={() => this.openMobileMenu(true)}
                    >
                      <img src={`${pwa.icons.monileMenu}`} alt="Menu-icon" />
                    </span>
                  )}
                </div>
                {showMobileNav ? (
                  <MobileNav headerSettings={headerSettings} />
                ) : null}
              </>
            )}
            <div className="logo-side side">
              <div className={`site-logo ${lapsScreenShow && 'text-center' }`}>
                <UrlSet href="/" itemProp="url">
                  {headerSettings.site_logo ? (
                    <img
                      itemProp="logo"
                      src={headerSettings.site_logo}
                      alt={window.shopObj.name}
                    ></img>
                  ) : (
                    <h6>{window.shopObj.name}</h6>
                  )}
                </UrlSet>
              </div>
            </div>

            {lapsScreenShow === false && (
              <div className="menu-side side">
                <nav className="main-menu text-center">
                  <SiteNav checkMenuType={this.checkMenuType} />
                </nav>
                {showSearch && <SearchContainer />}
                </div>
            )}
            {lapsScreenShow && showSearch && <div className="mobile-search-container"> <SearchContainer /></div> }
            <div className="icon-side side">
              <ul className="flex-view-xs middle right">
                  <li>
                    <div className="search-button">
                      {this.props.showSearch ? null : (
                        <img
                          onClick={() => {
                            if (window.location.pathname.includes("/search")) {
                              toggleSearch(false);
                            } else {
                              toggleSearch(true);
                            }
                            setMobileNavToggle(false)
                          }}
                          className="showInput icon-img"
                          src={`${pwa.icons.search}`}
                        />
                      )}
                    </div>
                  </li>
                <li onClick={() => {
                  var root = document.getElementsByTagName( 'html' )[0];
                  document.body.style.height = '100%';
                  root.style.height = '100%'; 
                  setMobileNavToggle(false)}}>
                  <span title="Cart" className="side-cart cart">
                    <UrlSet href='/cart'>
                      <img className="icon-img" src={pwa.icons.cart} alt="cart" />
                      {cartItems > 0 && (
                        <span className="count">{cartItems}</span>
                      )}
                    </UrlSet>
                  </span>
                </li>
              <MediaQuery query="lap-and-up">
                <li>
                  <div className="accounts">
                    {simply.customerLoggedin ? (
                      <UrlSet href="/account">
                        <img
                          className="icon-img"
                          src={pwa.icons.account}
                          alt="account"
                        />
                      </UrlSet>
                    ) : (
                      <a href="/account/login">
                        <img
                          className="icon-img"
                          src={pwa.icons.account}
                          alt="account"
                        />
                      </a>
                    )}
                  </div>
                </li>
              </MediaQuery>
              </ul>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  showMobileNav: state.mobileNav.showNav,
  showSearch: state.search.searchToggle,
  cart: state.cart,
});
const mapDispatchToProps = (dispatch) => ({
  setMobileNavToggle: (item) => dispatch(setMobileNavToggle(item)),
  // setSideCartToggle: (side_cart) => dispatch(setSideCartToggle(side_cart)),
  startCartFetch: (value) => dispatch(setCartStart(value)),
  toggleSearch: (toggle) => dispatch(setSearchToggle(toggle)),
});
export default connect(mapStateToProps, mapDispatchToProps)(LargeHeader);
