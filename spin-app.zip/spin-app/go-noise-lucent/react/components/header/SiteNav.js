import React, { Component } from 'react';
import FirstLevel from './menu-types/FirstLevel';

class SiteNav extends Component {
  componentDidMount(){
    this.props.checkMenuType();
  }
  render() {
    let mainMenu = pwa.deskopMainMenu;
   
    if (!mainMenu) {
      return null;
    }
    let blocks = pwa.header.blocks;
    
    return (
      <ul className="ul nav clearfix">
        {mainMenu.map((link, index) => {
          return(<FirstLevel link={link} key={index} blocks={blocks}/>)
        })}
      </ul>
    );
  }
}

export default SiteNav;