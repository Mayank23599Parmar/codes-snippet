import React, { Component } from 'react';
import LargeHeader from './LargeHeader';
import { withRouter } from 'react-router-dom';


class Header extends Component {
  componentDidMount(){
    let mainText = document.getElementById('main-text-speed-data');
    if(mainText){
      //mainText.remove();
    }
    const screenLoading = document.querySelector(".pwa_theme .first-load");
    if(screenLoading){
      screenLoading.classList.add("hide");
      document.querySelector("body").classList.remove("wait-header");
    }
  }

  render() {
    const headerSettings = window.pwa.header;
    /* Container */
    let container;
    if (headerSettings.full) {
      container = 'container-fluid';
    }
    else {
      container = 'container';
    }

    return (
      <>
        <header className="main-header" id="mainHeader">
          <LargeHeader history={this.props.history} container={container} headerSettings={headerSettings}/> 
        </header>
      </ >
    );
  }
}

export default withRouter(Header);