import React, { Component } from 'react';
import UrlSet from '../../UrlSet';
import { SubMenuProductEvent } from '../../../clever-tap-events/MenuChildEvent';

class ThirdLevel extends Component {
  
  eventHandler = (data)=>{
    SubMenuProductEvent(data)
  }
  
  render() {
    //console.log(this.props, "third level props")
    let { link , subMenu } = this.props;
    // if (!showMenu || !subMenu) {
    //   return null;
    // }
    // if(link.length > 3 && subMenu.handle != "use-case"){
    //     childrenMenu = childrenMenu.slice(0,3)
    //   }
    let links = link;
    if(links.length > 3 && subMenu.handle != "use-case"){
        links = links.slice(0,3)
      }
      
    
    return (
      <div className="child-menu">
        <ul className="child-menu-list">
          {links.map((item, index) => {
            return (
            
              <li className="child-li" key={index}>
                <UrlSet href={item.url} onClick={()=>this.eventHandler(item)}>
                {item.image && 
                  <div className="image">
                    <img src={item.image} alt={item.title} />
                  </div>}
                
                  <p>{item.title}</p>
                </UrlSet>
                {item.tag.includes("nav_new_tag") &&
                    <div className="new-tag-wrapper">
                        <span>NEW</span>
                    </div>
                    }
              </li>

            )
            
          })}

        </ul>

      </div>
    );
  }
}

export default ThirdLevel;