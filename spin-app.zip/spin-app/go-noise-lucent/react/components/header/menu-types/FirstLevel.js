import React, { Component } from 'react';
import MegaMenu from './MegaMenu';
import SecondLevel from './SecondLevel';
import {NavLink} from 'react-router-dom';
import {menuClickEvent} from '../../../clever-tap-events/MenuEvents'
import {UrlSet} from '../../UrlSet';

class FirstLevel extends Component {
  state = {
    showMenu: false
  }
  showMenu = (e) => {
    this.setState({ showMenu: true })
  }
  hideMenu = (e) => {
    this.setState({ showMenu: false })
  }


  render() {
    let { blocks, link } = this.props;
    //console.log(this.props);
    let { showMenu } = this.state;
    let checkMega = blocks.find(block => block.mega === link.title);
    let supportMenu = blocks.find(block => link.title === 'Support' && block.support_menu_header);
    let subMenu = link.subMenu;
    return (
      <li className={checkMega ? "li mega first-level-li" : "li relative first-level-li"} onClick={(e) => this.hideMenu(e)} onMouseEnter={(e) => this.showMenu(e)} onMouseLeave={(e) => this.hideMenu(e)}>
        { simply.template == 'customers/login' || simply.template == 'gift_card' ?
        <a className="first-level-a" href={link.url}>
        {link.title}
        </a>
        :
        <NavLink className="first-level-a" exact to={link.url} onClick = {()=>menuClickEvent(link.title, link.url)}>
          {link.title}
          </NavLink>
        }
          
        {checkMega ? <MegaMenu subMenu={subMenu} showMenu={showMenu} mega={checkMega} supportMenu={supportMenu ? supportMenu.support_menu_header : null} /> : <SecondLevel subMenu={subMenu} showMenu={showMenu} />}
      </li>
    );
  }
}



export default FirstLevel;