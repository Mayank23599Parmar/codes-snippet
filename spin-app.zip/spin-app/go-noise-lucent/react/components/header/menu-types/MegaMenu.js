import React, { Component } from 'react';
import Srcset from '../../SrcSet';
import UrlSet from '../../UrlSet';
import SecondLevel from './SecondLevel';
import ThirdLevel from './ThirdLevel';
import SupportMenuComponent from './SupportMenu';
import { SubMenuEvent,  SubMenuViewAllEvent} from '../../../clever-tap-events/MenuChildEvent';
class MegaMenu extends Component {
  render() {
    let { subMenu, showMenu, mega, supportMenu } = this.props;
    if (!showMenu || !subMenu) {
      return null;
    }
    
    
    return (
       <div className={`child-menu mega-menu mega-menu-new ${mega.mega === "Support" && supportMenu ? `custom-mega-menu` : `` }`} >
         <div className="megamenu-wrap">
          <div className="container">
            <ul className={`flex-view ${mega.mega === "Support" && supportMenu ? 'support-menu space-between custom-menu': 'center middle'}`}>
              {
                mega.mega === "Support" && supportMenu ? <SupportMenuComponent subMenu={subMenu} supportMenu={supportMenu}/> :
                subMenu.map((link, index) => {
                  //console.log(link.subMenu,link)
                  return (
                    <li key={`${link.title}`} className={`menu-new ${link.handle}`}>
                      <UrlSet className="link" href={link.url} onClick={()=>SubMenuEvent(link)}>
                        {/* {
                          link.image &&
                          <div className="img">
                            <Srcset alt={link.title} src={link.image} />
                          </div>
                        } */}
                        <span className="title">{link.title}</span>
                      </UrlSet>
                      
                      {link.subMenu != undefined?(
                    
                          <ThirdLevel link={link.subMenu} subMenu={link} />
                        
                      ):null}
                      <div className="view-all-wrap">
                      {link.subMenu != undefined && link.subMenu.length > 3 ?(
                    
                    
                    <UrlSet href={link.url} onClick={()=>SubMenuViewAllEvent(link)}>
                          <span className="menu-item-title">View all</span>
                        </UrlSet>
                    
                        
                      ):null}
                        </div>
                    </li>
                  )
                })
              }
              
            </ul>
          </div>
        </div>
      </div>
    );
  }
}

export default MegaMenu;