import React, { Component } from 'react'
import Srcset from '../../SrcSet';
import UrlSet from '../../UrlSet';
export class SupportMenu extends Component {
	render() {
		const { subMenu, supportMenu } = this.props;
		return (
			<>
				{
					subMenu.map((link, index) => {
						if (supportMenu) {
							let showHead = index === 0 ? <>
								<h5 className=' bold-text'>{supportMenu}</h5>
							</> : '';
							return (
								<li key={index} className='custom-li'>
									{showHead}
									<h5 className='bold-text'>{link.title}</h5>
									<div className="">
										<ul className="extra-submenu">
											{link.subMenu.map((item, indexinner) => {
												return (
													<li key={indexinner}>

														<UrlSet href={item.url}>
															<p className="">{index > 0 && <span className="support-icons"><Srcset alt={item.title} src={item.image} /></span>} {item.title} {index > 0 && <span className="arrow down"></span>}</p>
														</UrlSet>
													</li>
												)
											})}
										</ul>
									</div>
								</li>
							)
						}

					})
				}
			</>
		)
	}
}

export default SupportMenu
