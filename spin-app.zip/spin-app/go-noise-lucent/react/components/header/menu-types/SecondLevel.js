import React, { Component } from 'react';
import UrlSet from '../../UrlSet';

class SecondLevel extends Component {
  render() {
    let { subMenu, showMenu } = this.props;
    if (!showMenu || !subMenu) {
      return null;
    }
    return (
      <div className="second-level child-menu">
        <ul className="second-ul">
          {subMenu.map((item, index) => {
            return (
              <li className="second-li" key={index}>
                <UrlSet href={item.url}>
                  {item.title}
                </UrlSet>
              </li>
            )
          })}

        </ul>

      </div>
    );
  }
}

export default SecondLevel;