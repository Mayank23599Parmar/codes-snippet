import React from 'react';
import HtmlParser from 'react-html-parser';
class FooterContent extends React.Component {
    render() {
        const { footercontent } = window.pwa;
        return (
            <div className="home-footercontent" id={`section_${footercontent.sectionId}`}>
                <div className="container">
                    {footercontent.title ? <h2 className="title">{footercontent.title}</h2> : null}
                    <div className="desc-wrapper">
                        <div className="desc">{HtmlParser(footercontent.html_text)}</div>
                    </div>
                </div>
            </div>
        )
    }
}
export default FooterContent;