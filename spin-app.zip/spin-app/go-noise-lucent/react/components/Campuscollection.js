import React from 'react';

import HtmlParser from 'react-html-parser'

class Campuscollection extends React.Component{
    render(){
        
        return(
            <div className="home-feature-column" >
                <div className="text-area">
                    <div className="text-wrapper">
                        <h1 className="color-white">Shop the Education Store for savings.</h1>
                        <p className="color-white"><span>Furthering efforts to empower students countrywide,<br/>Noise is offering exclusive student discounts on our range of wearables. </span> </p>
                    </div>
                </div>
                <div className="">
                    <div className="flex-view-xs">
                            
                            <div className='col-sm-6 col-xs-12'>
                                <div className="block-content">
                                    <div className="text">
                                    <h2 className="title">Smart Wearables</h2>
                                    <h5 className="desc">Upgrade your lifestyle</h5>
                                    <a href="/collections/smart-watches" className="text-link">Know More <img className="icon-img" src={pwa.icons.peachRightArrow}/></a>
                                    </div>
                                    <div className="img">
                                        
                                        <a href="/collections/smart-watches">
                                        <img alt="img" src="https://cdn.shopify.com/s/files/1/0997/6284/files/Mask_Group_9b20cfe4-e588-4373-9bef-788ee2a156e4.png?v=1623252230" />
                                        </a> 
                                    </div>
                                </div>
                            </div> 
                            <div className='col-sm-6 col-xs-12 bg-grey bg-mobile-grey'>
                                <div className="block-content">
                                    <div className="text">
                                    <h2 className="title">Wireless Earbuds</h2>
                                    <h5 className="desc">Go Wireless</h5>
                                    <a href="/collections/wireless-earbuds" className="text-link">Know More <img className="icon-img" src={pwa.icons.peachRightArrow}/></a>
                                    </div>
                                    <div className="img">
                                        
                                        <a href="/collections/wireless-earbuds">
                                        <img alt="img" src="https://cdn.shopify.com/s/files/1/0997/6284/files/Mask_Group_cdcfc23b-848e-44ee-a3ce-5648528ce620.png?v=1623252265" />
                                        </a> 
                                    </div>
                                </div>
                            </div> 
                            <div className='col-sm-6 col-xs-12 bg-grey'>
                                <div className="block-content">
                                    <div className="text">
                                    <h2 className="title">Bluetooth Headphones</h2>
                                    <h5 className="desc">{HtmlParser('Tune into your</br>Inner Noise')}</h5>
                                    <a href="/collections/bluetooth-earphones" className="text-link">Know More <img className="icon-img" src={pwa.icons.peachRightArrow}/></a>
                                    </div>
                                    <div className="img">
                                        
                                        <a href="/collections/bluetooth-earphones">
                                        <img alt="img" src="https://cdn.shopify.com/s/files/1/0997/6284/files/Mask_Group_dd1608b7-acbc-4d10-ac1e-28d08abdae8d.png?v=1623253403" />
                                        </a> 
                                    </div>
                                </div>
                            </div> 
                            <div className='col-sm-6 col-xs-12 bg-mobile-grey'>
                                <div className="block-content">
                                    <div className="text">
                                    <h2 className="title">Accessories</h2>
                                    <h5 className="desc">{HtmlParser('Make the best of your</br>Noise gadgets')}</h5>
                                    <a href="/collections/accessories" className="text-link">Know More <img className="icon-img" src={pwa.icons.peachRightArrow}/></a>
                                    </div>
                                    <div className="img">
                                        
                                        <a href="/collections/accessories">
                                        <img alt="img" src="https://cdn.shopify.com/s/files/1/0997/6284/files/Mask_Group_b2a9290a-8e7d-462a-844d-6f738ee98051.png?v=1623253436" />
                                        </a> 
                                    </div>
                                </div>
                            </div> 
                         
                    </div>
                </div>
            </div>
        )
    }
}
export default Campuscollection;