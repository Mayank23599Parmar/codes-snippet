import React from "react";
import { Helmet } from "react-helmet";
import HtmlParser from "react-html-parser";
import { connect } from 'react-redux';
import {fetchShopSEO} from '../redux/shop/shopAction';
class SeoTags extends React.Component {
  componentDidMount(){
    let {path} = this.props;
    this.props.fetchShopSEO(path)
  }
  componentDidUpdate(prevProps) {
    // Typical usage (don't forget to compare props):
    let {path} = this.props;
    if(!path.includes('/cart')){
      if(path != prevProps.path){
        this.props.fetchShopSEO(path);
      }
    }
    if(path == prevProps.path){
      this.googleAnalytics();
    }
  }
  
  googleAnalytics = () =>{
    try {
      let url = window.location.pathname + window.location.search;
      setTimeout(function(){ 
          ga('send', 'pageview', url); 
      }, 1000);
    }catch(e){
      console.log(e);
    }
  }
  render() {
    const { seoData, path } = this.props;

    if (!seoData || window.location.href != seoData.meta_url) {
      return null;
    }
    else if(path.includes('/cart')){
      return(<Helmet>
      <title> Your Shopping Cart–Noise</title>
      <link rel="canonical" href="https://www.gonoise.com/cart"/>
      <meta property="og:type" content="website"/>
      <meta property="og:title" content="Your Shopping Cart" />
      <meta property="og:url" content="https://www.gonoise.com/cart" />
      <link rel="canonical" href="https://www.gonoise.com/cart"/>
      </Helmet>)
    }else{
      if(document.querySelectorAll("link[rel='canonical']").length > 1){
        document.querySelector("link[rel='canonical']").remove();
      }
      if(document.querySelectorAll("meta[name='description']").length > 1){
        document.querySelector("meta[name='description']").remove();
      }
    }

    const meta_title = seoData.meta_title;
    const meta_og_title = seoData.meta_og_title
      ? seoData.meta_og_title
      : meta_title;
    const meta_twitter_title = seoData.meta_twitter_title
      ? seoData.meta_twitter_title
      : meta_title;

    const meta_description = seoData.meta_description;
    const meta_og_description = seoData.meta_og_description
      ? seoData.meta_og_description
      : meta_description;
    const meta_twitter_description = seoData.meta_twitter_description
      ? seoData.meta_twitter_description
      : meta_description;

    const meta_og_img = seoData.meta_og_img ? seoData.meta_og_img : null;
    const meta_twitter_img = seoData.meta_twitter_img
      ? seoData.meta_twitter_img
      : null;

    const meta_keywords = seoData.meta_keywords;
    const meta_url = seoData.meta_url;
    const meta_shop_name = seoData.meta_shop_name;

    const meta_price_amount = seoData.meta_price_amount
      ? seoData.meta_price_amount
      : null;
    const meta_price_currency = seoData.meta_price_currency
      ? seoData.meta_price_currency
      : null;
  
    return (
      <Helmet>
        <title>
          {meta_title
            ? `${HtmlParser(meta_title)} - Noise`
            : `Noise | Wireless Earbuds, Bluetooth Earphones and Smart Watches Online`}
        </title>
        <link rel="canonical" href={meta_url} />
        <meta name="seo_tags" content="start" />
        <meta name="description" content={meta_description} />
        <meta name="keywords" content={meta_keywords} />
        <meta property="og:type" content="website" />
        <meta property="og:title" content={meta_og_title} />
        <meta property="og:description" content={meta_og_description} />
        <meta property="og:url" content={meta_url} />
        
        {meta_og_img && <meta property="og:image" content={meta_og_img} />}
        {meta_og_img && (
          <meta property="og:image:secure_url" content={meta_og_img} />
        )}
        {meta_og_img && <meta property="og:image:width" content="200" />}
        {meta_og_img && <meta property="og:image:height" content="200" />}
        <meta property="og:site_name" content="gonoise.com/" />

        {meta_price_amount && (
          <meta property="og:price:amount" content={meta_price_amount} />
        )}
        {meta_price_currency && (
          <meta property="og:price:currency" content={meta_price_currency} />
        )}

        <meta name="twitter:card" content="summary" />
        <meta name="twitter:title" content={meta_twitter_title} />
        <meta name="twitter:description" content={meta_twitter_description} />
        <meta name="twitter:url" content={meta_url} />
        {meta_twitter_img && (
          <meta name="twitter:image" content={meta_twitter_img} />
        )}
        <meta name="twitter:site" content="@gonoise" />
        <meta name="twitter:app:name:googleplay" content={meta_shop_name} />
        <meta name="twitter:app:id:googleplay" content="com.gonoise" />
        <meta name="seo_tags" content="end" />
      </Helmet>
    );
  }
}

const mapStateToProps = state => ({
  seoData: state.shop.seoData,
 });
 
 const mapDispatchToProps = dispatch => ({
  fetchShopSEO: url => dispatch(fetchShopSEO(url)),
 });
 
 export default connect(mapStateToProps, mapDispatchToProps)(SeoTags);
 