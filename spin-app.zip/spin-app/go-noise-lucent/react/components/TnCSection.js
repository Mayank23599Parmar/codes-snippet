import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import TnCInnerSection from "./TnCInnerSection";
class TnCSection extends Component {
  render() {
    const { specifications } = this.props;
    if(Object.keys(specifications).length === 0){
      return false;
    }
    if(cn(specifications.details)){
      return null;
    }
    let sepcArr = specifications.details.split("<>");
    let specificationDetails = sepcArr.map((ele, index) => {
      let eleArr = ele.split(" title#");
      let title = eleArr[0];
      eleArr = eleArr[1].split("$$");
      return (
        <TnCInnerSection key={index} title={title} eleArr={eleArr} />
      );
    });

    return (
      <div>
        <div className="box-section">
          <div className="container">
            <div className="flex-view-xs space product_detail_wrap">
              <div className="specification-wrap">
                <h2 className="header-title">{specifications.title}</h2>
                <ul className="specifications">{specificationDetails}</ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default TnCSection;
