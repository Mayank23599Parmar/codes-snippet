export const sortBy = [
    { title: "Featured", sort_query: "manual" },
    { title: "Best Selling", sort_query: "best-selling" },
    { title: "Alphabetically, A-Z", sort_query: "title-ascending" },
    { title: "Alphabetically, Z-A", sort_query: "title-descending" },
    { title: "Price, low to high", sort_query: "price-ascending" },
    { title: "Price, high to low", sort_query: "price-descending" },
    { title: "Date, old to new", sort_query: "created-ascending" },
    { title: "Date, new to old", sort_query: "created-descending" }
];