import axois from 'axios';
export default axois.create({
  baseURL: "/cart/update.js",
  params: {
    dataType: 'json'
  }
})