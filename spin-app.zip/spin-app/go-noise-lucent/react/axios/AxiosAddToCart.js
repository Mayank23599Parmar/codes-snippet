import axois from 'axios';
export default axois.create({
  baseURL: "/cart/add.js",
  params: {
    dataType: 'json'
  }
})