import React from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
// cart and menu
import { setMobileNavToggle } from './redux/mobile-nav-reducer/MobileNavAction';
import { setCartStart } from './redux/cart/cartAction';
import {closeSideCart} from './components/Helper';
import { setSearchToggle } from "./redux/search/searchAction";
// // pixles
import { FacebookPixels } from './pixels/FacebookPixels';
import SeoTags from './components/SeoTags';
//loader
import Loader from "./components/loader/loader";

//clear search data
import { searchStart } from './redux/search/searchAction';

// //footer script 
// import {utmInit} from './components/FooterScript';
class App extends React.Component {

  state = {
    subscriptionSubmitted: false,
    updatePage: false
  }

  homeScriptButtonToggle = () =>{
    let btn = document.getElementById('c9-button');
    if(btn){
      if(window.location.pathname == '/' ){
        btn.style.display = "block";
      }else{
        btn.style.display = "none";
      }
    }
  }
  productLaunchScript = () =>{
    document.querySelectorAll('.product-launch-script').forEach(function(a){
      a.remove()
    })
    if(window.location.href.includes('noise-buds-solo-active-noise-cancellation-truly-wireless-earbuds')){
      let url = window.location.href
      if(window.location.hash!='#gleam'&&(''+document.cookie).match(/(^|;)\s*GleamlIWQo=X($|;)/)){return;}
      var s = document.createElement('script');
      s.type = 'text/javascript';
      s.async = true;
      s.classList.add('product-launch-script');
      s.src = "https://widget.gleamjs.io/lIWQo/ol.js";
      var x = document.getElementsByTagName('script')[0];
      x.parentNode.insertBefore(s, x);
    }
  }

  manageVerloopWidget = (location)=>{
    let verloopWidget = document.querySelector('.verloop-widget');
          if(verloopWidget){
              if(location.pathname.includes('/products/')){
                  verloopWidget.style['display'] = "none";
              }else{
                  verloopWidget.style['display'] = "block";
              }
     }
   }
 
  componentWillMount() {
    //pixels
    const fbp = new FacebookPixels();
    setTimeout(()=>{
      this.homeScriptButtonToggle();
    },3000);
    this.unlisten = this.props.history.listen((location, action) => {
      this.manageVerloopWidget(location)
      this.setState({updatePage:true},()=>{
        fbp.pageView();
        // this.googleAnalytics();
        this.props.setMobileNavToggle(false);
        let obj = { term:"", products:[] };

        this.props.toggleSearch(false);
        this.props.setSearchStart("");
        closeSideCart();
        window.scrollTo(0, 0);
        // pwa.shopifyAppsLoadAsync();
      });
    });
  }

  setSeoData = async (history) => {
    history = history.location.pathname === "/error" ? '' : history;
    let seoData = await seoApi(history);
    this.setState({ seoData });
  }
  componentDidMount(){
    setTimeout(() => {
      this.props.setCartStart();   
    }, 5000);
  }
  render() {
    const {loaderData}  = this.props;
    // const { seoData } = this.state;
    return (
      <>
        {loaderData ? (<Loader />) : (
          <>
          <div className={this.subscriptionSubmitted ? 'is_posted' : 'not_posted'}>{this.props.children}</div>
          {
            (!this.props.location.pathname.includes('/account') ) && this.state.updatePage &&
           <SeoTags path={this.props.history.location.pathname}/>
          }
          </>
        )}

      </>
    );
  }
}
const mapStateToProps = state => ({
  loaderData: state.shop.loader
})
const mapDispatchToProps = dispatch => (
  {
    setMobileNavToggle: item => dispatch(setMobileNavToggle(item)),
    // setSideCartToggle: cart_toggle => dispatch(setSideCartToggle(cart_toggle)),
    setSearchStart: obj => dispatch(searchStart(obj)),
    toggleSearch: value => dispatch(setSearchToggle(value)),
    setCartStart: () => dispatch(setCartStart()),
  }
)
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(App));