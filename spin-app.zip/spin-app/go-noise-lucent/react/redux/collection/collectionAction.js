import collectionTypes from './collectionTypes';

export const startCollection = handle => ({
  type: collectionTypes.START_COLLECTION,
  payload: handle
})
export const startCollectionLoading = loading => ({
  type: collectionTypes.START_COLLECTION_LOADING,
  payload: loading
})
export const setCollectionData = data => ({
  type: collectionTypes.SET_COLLECTION,
  payload: data
})
export const setCollectionErrorPage = data => ({
  type: collectionTypes.SET_COLLECTION_ERROR_PAGE,
  payload: data
})
export const setCollectionBannerData = data => ({
  type: collectionTypes.SET_BANNER_DATA,
  payload: data
})
export const showRecommendationCollectionProducts = data => ({
  type: collectionTypes.SHOW_RECOMDATION_PRODUCTS,
  payload: data
})
export const setRecomdationVariant = data => ({
  type: collectionTypes.SET_RECOMEDATION_PRODUCT_VARIANT,
  payload: data
})
export const showCollectionProductPopup = data => ({
  type: collectionTypes.SHOW_COLLECTION_PRODUCT_POPUP,
  payload: data
});
export const setCollectionProductPopupDetail = data => ({
  type: collectionTypes.SET_COLLECTION_PRODUCT_POPUP_DETAIL,
  payload: data
})
export const setCollectionProductArray = data => ({
  type: collectionTypes.SET_COLLECTIONpRODUCT_ARRAY,
  payload: data
})