import collectionTypes from './collectionTypes';
const initData = {
  collectionInfo: "",
  currentSort: '',
  currentFilter: '',
  handle: '',
  loading: true,
  bannerData: "",
  errorPage: false,
  showRecommendationProducts: false,
  recomendationProductVariant: {},
  showCollectionProductPopup: false,
  setCollectionProductData: {},
  collectionRecomendationArray: []
}
const collectionReducer = (state = initData, action) => {
  switch (action.type) {
    case collectionTypes.START_COLLECTION:
      return {
        ...state,
        handle: action.payload
      }
    case collectionTypes.START_COLLECTION_LOADING:
      return {
        ...state,
        loading: action.payload
      }
    case collectionTypes.SET_COLLECTION:
      return {
        ...state,
        collectionInfo: action.payload
      }
    case collectionTypes.SET_BANNER_DATA:
      return {
        ...state,
        bannerData: action.payload
      }
    case collectionTypes.SET_COLLECTION_ERROR_PAGE:
      return {
        ...state,
        errorPage: action.payload
      }
    case collectionTypes.SHOW_RECOMDATION_PRODUCTS:
      return {
        ...state,
        showRecommendationProducts: action.payload
      }
    case collectionTypes.SET_RECOMEDATION_PRODUCT_VARIANT:
      return {
        ...state,
        masterProductImg: action.payload.masterProductImg,
        recomendationProductVariant: action.payload.variant
      }
    case collectionTypes.SHOW_COLLECTION_PRODUCT_POPUP:
      return {
        ...state,
        showCollectionProductPopup: action.payload
      }
    case collectionTypes.SET_COLLECTION_PRODUCT_POPUP_DETAIL:
      return {
        ...state,
        setCollectionProductData: action.payload
      }
    case collectionTypes.SET_COLLECTIONpRODUCT_ARRAY:
      return {
        ...state,
        collectionRecomendationArray: action.payload
      }
    default:
      return state;
  }
}
export default collectionReducer;