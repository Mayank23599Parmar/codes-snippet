
import { takeLatest, put, call, all } from 'redux-saga/effects';
import collectionTypes from './collectionTypes'
import { setCollectionData, startCollectionLoading, setCollectionBannerData,setCollectionErrorPage } from './collectionAction';
function* collectionStartAction(action) {
  yield put(setCollectionErrorPage(false));
  yield put(startCollectionLoading(true));
  let data;
  let collectionData,div;
  let collectionBanner;
  let query = action.payload;
  let errorMsg = "Collection JSON data wrong format";
  try {
    data = yield fetch(`${query}`);
    if(data.status === 404){
      yield put(setCollectionErrorPage(true));
    }
    else{
      data = yield data.text();
      div = document.createElement('div');
      div.innerHTML = data;
      collectionData = JSON.parse(div.children[1].innerText);
      yield put(setCollectionData(collectionData));
      collectionBanner = JSON.parse(div.children[0].innerText);
      yield put(setCollectionBannerData(collectionBanner));
    }
  }
  catch (e) {
    console.log(e);
  }
  yield put(startCollectionLoading(false));
} 


function* collectionStart() {
  yield takeLatest(
    collectionTypes.START_COLLECTION,
    collectionStartAction
  )
}


export function* collectionSagas() {
  yield all([
    call(collectionStart)
  ])
}