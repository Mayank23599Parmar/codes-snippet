import productTypes from './productTypes';

const startProductLoading = loading => ({
  type: productTypes.START_PRODUCT_LOADING,
  payload: loading
})

const fetchProduct = handle => ({
  type: productTypes.FETCH_PRODUCT,
  payload: handle
})

const setProduct = product => ({
  type: productTypes.SET_PRODUCT,
  payload: product
});

const setSwatchImages = data =>({
  type: productTypes.SET_SWATCH_IMAGE,
  payload: data
})

const setCompareProducts = data =>({
  type: productTypes.SET_COMPARE_PRODUCTS,
  payload: data
})

const setVariant = variant => ({
  type: productTypes.SET_VARIANT,
  payload: variant
});

const setThemeSettings = variant => ({
  type: productTypes.SET_THEME_SETTINGS,
  payload: variant
});

const updateVariant = variant => ({
  type: productTypes.UPDATE_VARIANT,
  payload: variant
});

const setSoldOut = soldout => ({
  type: productTypes.SET_SOLDOUT,
  payload: soldout
});

const unSetProduct = unset => ({
  type: productTypes.UNSET_PRODUCT,
  payload: unset
});

const setMetafield = product => ({
  type: productTypes.SET_METAFIELD,
  payload: product
});

const getPreOrder = data => ({
  type: productTypes.GET_PRE_ORRDER,
  payload: data
});
const setPreOrder = data => ({
  type: productTypes.SET_PRE_ORRDER,
  payload: data
});

const submitNotifyForm = data =>({
  type: productTypes.SUBMIT_NOTIFY,
  payload: data
})

const fetchRelatedProducts = data =>({
  type: productTypes.FETCH_RELATED_PRODUCTS,
  payload: data
})

const setRelatedProducts = data =>({
  type: productTypes.SET_RELATED_PRODUCTS,
  payload: data
})

const setCustomRelatedProduct = data =>({
  type: productTypes.SET_CUSTOM_RELATED_PRODUCT,
  payload: data
})

const setRecommendationProducts = data =>({
  type: productTypes.SET_RECOMADTION_PRODUCTS,
  payload: data
})

const showRecommendationProducts = data =>({
  type: productTypes.SHOW_RECOMADTION_PRODUCTS,
  payload: data
})

const showFrequntlyContent =data =>({
  type: productTypes.SET_FREQUNTLY_CONTENT,
  payload: data
})
const showProductDetailPopup=data=>({
  type:productTypes.SHOW_PRODUCT_DETAIL_POPUP,
  payload:data
})
const setProductDetailPopupContent=data=>({
  type:productTypes.SET_PRODUCT_DETAIL_POPUP_CONTENT,
  payload:data
})
const setMasterPopupProductVariant=data=>({
  type:productTypes.SET_MASTER_POPUP_PRODUCT_VARIANT,
  payload:data
})
const setProductAddedInCart=data=>({
  type:productTypes.SET_PRODUCT_ADDED_IN_CART,
  payload:data
})
const setCartQuantityForPopupProducts=data=>({
  type:productTypes.SET_CART_QUANTITY_FOR_POPUP_PRODUCTS,
  payload:data
})
const setCartValueInRecomendationModal=data=>({
  type:productTypes.SET_CART_VALUE_IN_RECOMENDATION_MODAL,
  payload:data
})
const selectedVarintforModal=data=>({
  type:productTypes.SET_SELECTED_VARIANT_FOR_POPUP,
  payload:data
})
export {
  startProductLoading,
  fetchProduct,
  setProduct,
  setVariant,
  setSoldOut,
  submitNotifyForm,
  setRecommendationProducts,
  showRecommendationProducts,
  unSetProduct,
  setMetafield,
  setSwatchImages,
  updateVariant,
  setCompareProducts,
  setPreOrder,
  fetchRelatedProducts,
  setRelatedProducts,
  getPreOrder,
  setThemeSettings,
  setCustomRelatedProduct,
  showFrequntlyContent,
  showProductDetailPopup,
  setProductDetailPopupContent,
  setMasterPopupProductVariant,
  setProductAddedInCart,
  setCartQuantityForPopupProducts,
  setCartValueInRecomendationModal,
  selectedVarintforModal
};