import productTypes from "./productTypes";
import { productViewEvent } from "../../clever-tap-events/ProductviewEvent";
import { showRecommendationProducts } from "./productAction";
const INITIAL_VALUE = {
  product: {
    images: [],
  },
  settings: null,
  soldout: false,
  variant: null,
  loading: true,
  metafields: null,
  swatchesImagesDetails: {},
  compareProducts: {},
  preOrder: {},
  recommendationProducts :[],
  showRecommendationProducts: false,
  relatedProducts:null,
  customRelatedProduct:null,
  frequntlyContent:{},
  showProductPopup:false,
  setProductPopupContent:{},
  setMasterPopupProductVariant:{},
  checkCart:[],
  cartQuantity:null,
  selectedVarintForPopUp:{}
};
const productReducer = (state = INITIAL_VALUE, action) => {

  switch (action.type) {
    case productTypes.START_PRODUCT_LOADING:
      return {
        ...state,
        loading: action.payload,
      };
    case productTypes.SET_THEME_SETTINGS:{
      return{
        ...state,
        settings: action.payload
      }
    } 
    case productTypes.SET_PRODUCT:
      let frequntly_bought= [];

      if(!cn(action.payload.frequntly_bought) && pwa.frequentlyEnable){
        action.payload.frequntly_bought.forEach(x=>{
          if (Object.keys(x).length !== 0) {
            if(x.product.id !== action.payload.productData.id){
              if(x.product.available){
                frequntly_bought.push(x);
              }
            }
          }
        })
      }
      productViewEvent(action.payload.selected_or_first_available_variant, state);
      return {
        ...state,
        product: action.payload.productData,
        settings: action.payload.settings,
        swatchesImagesDetails: action.payload.swatchImagesDetails,
        variant: action.payload.selected_or_first_available_variant,
        metafields: action.payload.metafields,
        compareProducts: action.payload.compareProducts,
        recommendationProducts: frequntly_bought,
        relatedProducts : action.payload.relatedProducts,
        loading: false,
        frequntlyContent:action.payload.frequntly_coupon,
        setMasterPopupProductVariant:action.payload.setMasterPopupProductVariant
      };
    case productTypes.SET_SWATCH_IMAGE:
      return {
        ...state,
        swatchesImagesDetails: action.payload,
      };
    case productTypes.SET_COMPARE_PRODUCTS:
      return {
        ...state,
        compareProducts: action.payload,
      };
    case productTypes.SET_VARIANT:
      try {
        productViewEvent(action.payload, state);
      } catch (e) {
        console.log(e);
      }
      return {
        ...state,
        variant: action.payload,
      };
    case productTypes.UPDATE_VARIANT:
      try {
        productViewEvent(action.payload, state);
      } catch (e) {
        console.log(e);
      }
      return {
        ...state,
        variant: action.payload,
      };
    case productTypes.SET_SOLDOUT:
      return {
        ...state,
        soldout: action.payload,
      };
    case productTypes.UNSET_PRODUCT:
      return {
        product: null,
        soldout: false,
        variant: null,
      };
    case productTypes.SET_METAFIELD:
      return {
        ...state,
        metafields: action.payload,
      };
    case productTypes.SET_PRE_ORRDER:
      return {
        ...state,
        preOrder: action.payload,
      };
    case productTypes.SET_RELATED_PRODUCTS:
      return{
        ...state,
        relatedProducts : action.payload
      }
    case productTypes.SET_CUSTOM_RELATED_PRODUCT:
      return{
        ...state,
        customRelatedProduct: action.payload
      }
      case productTypes.SET_RECOMADTION_PRODUCTS:
        return {
          ...state,
          recommendationProducts: action.payload
        }
      case productTypes.SHOW_RECOMADTION_PRODUCTS:
        return {
          ...state,
          showRecommendationProducts: action.payload
        }
       case productTypes.SET_FREQUNTLY_CONTENT:
         return{
           ...state,
           frequntlyContent:action.payload
         }
         case productTypes.SHOW_PRODUCT_DETAIL_POPUP:
           return{
             ...state,
             showProductPopup:action.payload
           }
           case productTypes.SET_PRODUCT_DETAIL_POPUP_CONTENT:
            return{
              ...state,
              setProductPopupContent:action.payload
            }
            case productTypes.SET_MASTER_POPUP_PRODUCT_VARIANT:
              return{
                ...state,
                setMasterPopupProductVariant:action.payload
              }
              case productTypes.SET_PRODUCT_ADDED_IN_CART:
                return{
                  ...state,
                  checkCart:[...state.checkCart,action.payload]
                }
                case productTypes.SET_CART_QUANTITY_FOR_POPUP_PRODUCTS:
                  return{
                    ...state,
                    cartQuantity:action.payload

                  }
                  case productTypes.SET_SELECTED_VARIANT_FOR_POPUP:
                  return{
                    ...state,
                    selectedVarintForPopUp:action.payload

                  }
    default:
      return state;
  }
};
export default productReducer;
