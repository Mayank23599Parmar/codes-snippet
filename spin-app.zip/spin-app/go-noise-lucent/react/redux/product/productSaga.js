import { takeLatest, put, call, all } from "redux-saga/effects";
import productTypes from "./productTypes";
import { showToast } from "../../components/Helper";;
import {
  setProduct,
  startProductLoading,
  setRelatedProducts,
  showFrequntlyContent
} from "./productAction";

function* fetchProduct(action) {
  yield put(startProductLoading(true));
  let data, dataJson;
  let query = action.payload;
  // let errorMsg = "Product JSON data wrong format";
  try {
    data = yield fetch(`/products/${query}`);
    if (data.status === 404) {
      yield put(setProduct(false));
    } else {
      let resData = yield data.text();
      let mainDiv = document.createElement('div');
      mainDiv.innerHTML = resData;
      let scriptData = mainDiv.getElementsByClassName('section-data');
      dataJson = JSON.parse(scriptData[0].innerHTML)
    }

    yield put(setProduct(dataJson));
    let relatedProducts=[];
    if(dataJson.productData.id){
    
      let relatedData;
      try{
        
        dataJson.relatedProducts = [];
        relatedData = yield fetch(`/recommendations/products.json?product_id=${dataJson.productData.id}`)

        let resData = yield relatedData.json();
        if(resData.products && resData.products.length > 0 && pwa.frequentlyEnable){
          relatedProducts=resData.products;

        }
      } catch(e){
        console.log(e);
      }  
    }
    yield put(setProduct(dataJson));
    // yield put(setRelatedProducts(null));
       yield put(setRelatedProducts(relatedProducts))
    // yield put(setThemeSettings(dataJson.settings));
    // yield put(setSwatchImages(dataJson.swatchImagesDetails));
    // yield put(setVariant(dataJson.recommendationProducts.selected_or_first_available_variant));
    // yield put(setMetafield(dataJson.metafields));
    // if(dataJson.customRelatedProduct){
    //   yield put(setCustomRelatedProduct(dataJson.customRelatedProduct));
    // }
    // else{
    //   yield put(setCustomRelatedProduct(null));
    // }
    
    // yield put(setCompareProducts(dataJson.compareProducts));
    // yield put(setRecommendationProducts(frequntly_bought))

  } catch (e) {
    console.log(e);
  }
  // yield put(startProductLoading(false));
}

function* productStart() {
  yield takeLatest(productTypes.FETCH_PRODUCT, fetchProduct);
}

function* fetchPreOrder(action) {
  let results, dataJson;
  let query = action.payload.query;
  let emailId = simply.customerEmail;
  let phoneNo = action.payload.dataPass.phone
  let options;
  const { callbackFunc } = action.payload; 
  try {
    results = yield fetch(query, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        "x-auth-secret": '0329b8ad3bce0bcfdda8ca65c37143c3ccc1e8ae0545da19898ca08bba8ed1a5',
      },
    })
    results = yield results.json()
    if(results.status === "created"){
        options = {
          key: results.key, // Enter the Key ID generated from the Dashboard
          amount: results.amount_due, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
          currency: "INR",
          name: "Noise",
          description: "Test Transaction",
          image:
            "https://cdn.shopify.com/s/files/1/0997/6284/files/noise_icon_black_on_white.svg?v=1587630341",
          order_id: results.id, //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
          callback_url: "https://pre-order.gonoise.in/pre/order/callback",
          prefill: {
            email: emailId,
            contact: phoneNo,
          },
          notes: {
            address: "Razorpay Corporate Office",
          },
          theme: {
            color: "#000000",
          },
        };
        let rzp1 = new Razorpay(options);
        rzp1.open();
      
      callbackFunc();
    }
    else{
      showToast(results.message, "top");
      callbackFunc();
    }
  } catch (e) {
    console.log(e);
  }
}

function* notifySumbit(action){
  let url ='https://script.google.com/macros/s/AKfycbzDCwWeYlzV7mYcQ1K-PlPB-CNL0b9ziygLqk03w5641vYRdcs/exec'
  let results
  let response
  try{
    results = yield fetch(url,{
      method:'POST',
      body:action.payload.formData
    })    
    response =  yield results.json();
    if(response.result === 'success'){
      action.payload.callBackFunction()
      // showToast("Successfully Submited", "top");
    }
    else{
      action.payload.callBackFunction();
      // showToast("Something went wrong please try again", "top");
    }
  }
  catch (e){
    console.log(e);
  }

}

function* notifyFuc() {
  yield takeLatest(productTypes.SUBMIT_NOTIFY,notifySumbit)
}

function* preOrderData() {
  yield takeLatest(productTypes.GET_PRE_ORRDER, fetchPreOrder);
}

function* fetchRelatedProductsAction(action){
  let data;
  try{
    data = yield fetch(`/recommendations/products.json?product_id=${action.payload}`)
    let resData = yield data.json();
    if(resData.products && resData.products.length > 0 ){
      yield put(setRelatedProducts(resData.products));
    }
    else{
      yield put(setRelatedProducts([]));
    }
  } catch(e){
    console.log(e);
  }
}

function* relatedProductsAction(){
  yield takeLatest(productTypes.FETCH_RELATED_PRODUCTS, fetchRelatedProductsAction);
}

export function* productSagas() {
  yield all([call(productStart), call(relatedProductsAction),call(preOrderData),call(notifyFuc)]);
}
