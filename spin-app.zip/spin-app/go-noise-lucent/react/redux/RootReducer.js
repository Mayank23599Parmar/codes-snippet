import { combineReducers } from 'redux';
import { persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
import searchReducer from './search/searchReducer';
import MobileNavReducer from './mobile-nav-reducer/MobileNavReducer';
import shopReducer from './shop/shopReducer';
import cartReducer from './cart/cartReducer';
import productReducer from './product/productReducer';
import collectionReducer from './collection/collectionReducer';
import supportReducer from './support/supportReducer';
import accountReducer from './account/accountReducer';
import blogReducer from './blog/blogReducer';
import articleReducer from './article/articleReducer';

const presistConfig = {
 key: 'root',
 storage,
 whitelist: [],
};
const rootReducer = combineReducers({
 shop: shopReducer,
 mobileNav: MobileNavReducer,
 search: searchReducer,
 product: productReducer,
 cart: cartReducer,
 collection: collectionReducer,
 support: supportReducer,
 account: accountReducer,
 blog: blogReducer,
 article: articleReducer
});
export default persistReducer(presistConfig, rootReducer);
