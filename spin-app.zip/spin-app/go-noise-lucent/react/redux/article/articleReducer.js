import articleTypes from "./articleTypes";
const INITIAL_VALUE = {
  articleData: {},
  articleLoading: true,
};
const articleReducer = (state = INITIAL_VALUE, action) => {
  switch (action.type) {
    case articleTypes.SET_ARTICLE:
      return {
        ...state,
        articleData: action.payload,
      };
    case articleTypes.START_ARTICLE_LOADING:
      return {
        ...state,
        articleLoading: action.payload,
      };
    default:
      return state;
  }
};
export default articleReducer;
