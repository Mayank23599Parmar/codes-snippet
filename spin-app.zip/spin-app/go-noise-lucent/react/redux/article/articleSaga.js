import { takeLatest, put, call, all } from "redux-saga/effects";
import articleTypes from "./articleTypes";
import { setArticle, startArticleLoading } from "./articleActions";

function* fetcArticle(action) {
  startArticleLoading(true);
  let data, dataJson;
  if( !cn(action.payload.callback)){
    action.payload.callback()
    }
  try {
    data = yield fetch(`/blogs/${action.payload.query}?view=react`);
    if (data.status === 404) {
      yield put(setArticle(false));
    } else {
      dataJson = yield data.json();
      if(dataJson){
        yield put(setArticle(dataJson))
        
      }
    
      yield put(startArticleLoading(false));
    

    }
  } catch (e) {
    console.log(e);
  }
  
}

function* articleStart() {
  yield takeLatest(articleTypes.FETCH_ARTICLE, fetcArticle);
}

export function* articleSagas() {
  yield all([call(articleStart)]);
}
