import articleTypes from './articleTypes'

export const setArticle = (data) =>({
    type:articleTypes.SET_ARTICLE,
    payload:data
})

export const fetchArticle = (data) =>({
    type:articleTypes.FETCH_ARTICLE,
    payload:data
})

export const startArticleLoading = (data) =>({
    type:articleTypes.START_ARTICLE_LOADING,
    payload: data
})