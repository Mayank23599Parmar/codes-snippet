import { all, call } from "redux-saga/effects";
import { searchSagas } from "./search/searchSaga";
import { cartSagas } from "./cart/cartSaga";
import { productSagas } from "./product/productSaga";
import { collectionSagas } from "./collection/collectionSaga";
import { supportSagas } from "./support/supportSaga";
import { accountSagas } from "./account/accountSaga";
import { blogSagas } from "./blog/blogSaga";
import { articleSagas } from "./article/articleSaga";
import {shopSagas} from "./shop/shopSaga";
export function* rootSaga() {
  yield all([
    call(shopSagas),
    call(searchSagas),
    call(cartSagas),
    call(collectionSagas),
    call(productSagas),
    call(supportSagas),
    call(accountSagas),
    call(blogSagas),
    call(articleSagas)
  ]);
}
