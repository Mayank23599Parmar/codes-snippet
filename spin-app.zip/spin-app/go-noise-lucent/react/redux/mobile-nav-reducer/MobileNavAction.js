import mobileNavType from './MobileNavType';
export const setMobileNavToggle = nav_state =>({
  type:mobileNavType.TOGGLE_MOBILE_NAV,
  payload:nav_state
});
