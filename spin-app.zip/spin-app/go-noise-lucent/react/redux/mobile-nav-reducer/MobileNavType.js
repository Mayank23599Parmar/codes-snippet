const MobileNavType = {
TOGGLE_MOBILE_NAV:"TOGGLE_MOBILE_NAV"
}
export default MobileNavType;