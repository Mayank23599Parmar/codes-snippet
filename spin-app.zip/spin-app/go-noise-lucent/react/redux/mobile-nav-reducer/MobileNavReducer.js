import mobileNavType from './MobileNavType';

const INIT_VALUES = {
  showNav: false
}
const MobileNavReducer = (state = INIT_VALUES, action) => {
  switch (action.type) {
    case mobileNavType.TOGGLE_MOBILE_NAV:
      return{
        showNav:action.payload
      }
    default:
      return state
  }
}
export default MobileNavReducer;