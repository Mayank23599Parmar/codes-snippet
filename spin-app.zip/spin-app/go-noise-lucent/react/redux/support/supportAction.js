import supportTypes from './supportTypes';

export const setLoading = data => ({
 type: supportTypes.SET_LOADING,
 payload: data,
});

export const setSupportData = data => ({
 type: supportTypes.SET_SUPPORT_PAGE_DATA,
 payload: data,
});

export const setSupportPageData = data => ({
 type: supportTypes.GET_SUPPORT_PAGE_DATA,
 payload: data,
});

export const setCurrentTab = tab => ({
 type: supportTypes.SET_CURRENT_TAB,
 payload: tab,
});

export const currentTabChange = change => ({
    type: supportTypes.SET_TAB_CHANGE,
    payload: change
})

export const sendOTP = data => ({
 type: supportTypes.SEND_OTP,
 payload: data,
});

export const setOTP = data => ({
 type: supportTypes.SET_OTP,
 payload: data,
});

export const closeOtpModal = data => ({
 type: supportTypes.CLOSE_OTP_MODAL,
 payload: data,
});

export const submitRegisterWarranty = (data) =>({
    type: supportTypes.SUBMIT_WARRANTY_REGISTER,
    payload: data
})

export const submitContactForm = (data) =>({
    type: supportTypes.SUBMIT_CONTACTFORM,
    payload: data
})

export const fetchWarrantyProducts = (data) =>({
    type:supportTypes.FETCH_WARRANTY_PRODUCTS,
    payload:data
})

export const setWarrantyProuducts = (data) =>({
    type:supportTypes.SET_WARRANTY_PRODUCTS,
    payload:data
})

export const setCompareProduct = data => ({
    type:supportTypes.SET_COMPARE_PRODUCTS,
    payload:data
})

export const varifyOtp = data => ({
    type:supportTypes.VARIFY_OTP,
    payload:data
})
export const errorPage = value =>({
    type:supportTypes.PAGE_NOT_FOUND,
    payload: value
})