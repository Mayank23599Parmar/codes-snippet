import supportTypes from "./supportTypes";

const INITIAL_VALUE = {
  loading: true,
  tabChange: false,
  supportData: {
    banner: {},
    warrantyRegister: {
      otp: "",
      phoneNumber: "",
      openOtpModal: false,
    },
    registerComplaint: {},
    warrantyProducts: {},
    defaultPage: '',
    campusNoiseMaker:'',
    questfortheBest:{},
    AnniversarySale:{},
    downloadInvoice:'',
    pageNotFound:false,
    compare:{'currentProduct':'','data':[]}
  },
  currentTab: "faq",
};

const supportReducer = (state = INITIAL_VALUE, action) => {
  switch (action.type) {
    case supportTypes.SET_LOADING:
      return {
        ...state,
        loading: action.payload,
        supportData: {
          ...state.supportData,
          pageNotFound: false
        }
       };

    case supportTypes.SET_SUPPORT_PAGE_DATA:
      return {
        ...state,
        loading: false,
        currentTab: action.payload.tab,
        supportData: {
          ...state.supportData,
          ...action.payload.data,
          compare:{
            ...state.compare,
            data:action.payload.data.compare
          }
        },
      };

    case supportTypes.SET_CURRENT_TAB:
      return {
        ...state,
        currentTab: action.payload,
        supportData: {
          ...state.supportData,
          pageNotFound: false
        }
      };

    case supportTypes.SET_TAB_CHANGE:
      return {
        ...state,
        tabChange: action.payload,
      };
    case supportTypes.SET_OTP:
      return {
        ...state,
        loading: false,
        supportData: {
          ...state.supportData,
          warrantyRegister: {
            ...state.supportData.warrantyRegister,
            otp: action.payload.otp,
            phoneNumber: action.payload.phoneNumber,
            openOtpModal: true,
          },
        },
      };

    case supportTypes.CLOSE_OTP_MODAL:
      return {
        ...state,
        supportData: {
          ...state.supportData,
          warrantyRegister: {
            ...state.supportData.warrantyRegister,
            openOtpModal: action.payload,
          },
        },
      };

    case supportTypes.SET_WARRANTY_PRODUCTS:
      return {
        ...state,
        warrantyProducts: action.payload,
      };
    case supportTypes.SET_COMPARE_PRODUCTS:
      return {
        ...state,
        compare:{
          ...state.compare,
          currentProduct: action.payload
        }
      }
    case supportTypes.PAGE_NOT_FOUND:
      return{
        ...state,
        supportData: {
          ...state.supportData,
          pageNotFound: action.payload
        }
      }  
    default:
      return state;
  }
};

export default supportReducer;
