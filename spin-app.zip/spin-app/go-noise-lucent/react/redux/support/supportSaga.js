import { put, call, all, takeEvery, takeLatest } from 'redux-saga/effects';
import supportTypes from './supportTypes';
import { setSupportData, setOTP, submitRegisterWarranty, fetchWarrantyProducts,setWarrantyProuducts,errorPage,setLoading } from './supportAction';
// import { showToast } from '../../components/Helper'

function* getSupportPageData(action) {
	yield put(setLoading(true));
	let supportData = {
		banner: {},
		faqJson: {},
		warrantyJson: {},
		troubleshootJson: {},
		shippingDetailsJson: {},
		termsConditionJson: {},
		warrantyRegister: {},
		registerComplaint: {},
		exclusiveOffersJson: {},
		eWasteJson: {},
		siteMapJson: {},
		contactUsJson:{},
		aboutUsJson:{},
		privacyPolicyJson:{},
		corporateEnquiryJson:{},
		inThePressJson:{},
		careerJson:{},
		becomeAffiliateJson:{},
		storiesJson:{},
		appJson:{},
		compare:[],
		pro3prideJson:{},
		campusNoiseMaker:"",
		questfortheBest:{},
		AnniversarySale:{},
		downloadInvoice:"",
		defaultPage: ""
	};
	//Req to page and get section data
	// let data = yield fetch('/pages/react-pages');
	let pageHandle = /[^/]*$/.exec(window.location.href.split('?')[0])[0];
	let defaultPageData =  yield fetch(`/pages/${pageHandle}?view=react-pages`);
	
	if(defaultPageData.status === 404){
		yield put(errorPage(true));
	}else{
		defaultPageData = yield defaultPageData.text();
		let defaultDiv = document.createElement('dthis.props.data.data.warrantyDataFileiv');
		defaultDiv.innerHTML = defaultPageData;
		defaultPageData = defaultDiv.getElementsByClassName('section-data');
		
		// let resData = yield data.text();
		// let mainDiv = document.createElement('dthis.props.data.data.warrantyDataFileiv');
		// mainDiv.innerHTML = resData;
		// const pageData = mainDiv.getElementsByClassName('section-data');
		try {
			Array.prototype.forEach.call(defaultPageData, el => {
				if (el.getAttribute('data-type') === 'support-section-data') {
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse(el.innerHTML);
					supportData.banner = obj;
				}
				if (el.getAttribute('data-type') === 'faq-section-data') {
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse(el.innerHTML);
					supportData.faqJson = obj;
				}
				if (el.getAttribute('data-type') === 'warranty-section-data') {
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse(el.innerHTML);
					supportData.warrantyJson = obj;
				}
				if (el.getAttribute('data-type') === 'troubleshoot-section-data') {
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse(el.innerHTML);
					supportData.troubleshootJson = obj;
				}
				if (el.getAttribute('data-type') === 'contact-us-section-data') {
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse(el.innerHTML);
					supportData.contactUsJson = obj;
				}
				if (el.getAttribute('data-type') === 'shipping-details-section-data') {
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse(JSON.stringify(el.innerHTML));
					supportData.shippingDetailsJson = obj;
				}
				if (el.getAttribute('data-type') === 'terms-and-condition-section-data') {
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse(JSON.stringify(el.innerHTML));
					supportData.termsConditionJson = obj;
				}
				if (el.getAttribute('data-type') === 'warrantyregister-section-data') {
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse(el.innerHTML);
					supportData.warrantyRegister = obj;
				}
				if (el.getAttribute('data-type') === 'register-complaint-section-data') {
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse(el.innerHTML);
					supportData.registerComplaint = obj;
				}
				if(el.getAttribute('data-type')=== 'exclusive-section-data'){
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse(JSON.stringify(el.innerHTML));
					supportData.exclusiveOffersJson = obj;
				}
				if(el.getAttribute('data-type')=== 'ewaste-managment-section-data'){
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse(JSON.stringify(el.innerHTML));
					supportData.eWasteJson = obj;
				}
				if(el.getAttribute('data-type')=== 'site-map-section-data'){
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse((el.innerHTML));
					supportData.siteMapJson = obj;
				}
				if(el.getAttribute('data-type')=== 'about-us-section-data'){
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse(JSON.stringify(el.innerHTML));
					supportData.aboutUsJson = obj;
				}
				if(el.getAttribute('data-type')=== 'privacy-policy-section-data'){
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse(JSON.stringify(el.innerHTML));
					supportData.privacyPolicyJson = obj;
				}
				if(el.getAttribute('data-type')=== 'corporate-enquiry-section-data'){
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse((el.innerHTML));
					supportData.corporateEnquiryJson = obj;
				}
				if(el.getAttribute('data-type') === 'in-the-press'){
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse((el.innerHTML));
					supportData.inThePressJson = obj;
				}
				if(el.getAttribute('data-type') === 'career-section-data'){
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse((el.innerHTML));
					supportData.careerJson = obj;
				}
				if(el.getAttribute('data-type') === 'become-affiliate-section-data'){
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse((el.innerHTML));
					supportData.becomeAffiliateJson = obj;
				}
				if(el.getAttribute('data-type') === 'stories-section-data'){
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse((el.innerHTML));
					supportData.storiesJson = obj;
				}
				if(el.getAttribute('data-type') === 'noisefitapp-section-data'){
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse((el.innerHTML));
					supportData.appJson = obj;
				}
				if(el.getAttribute('data-type') === 'compare-product'){
					let obj = JSON.parse((el.innerHTML));
					supportData.compare.push(obj);
				}
				if(el.getAttribute('data-type') === 'pro3-pride-section-data'){
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse((el.innerHTML));
					supportData.pro3prideJson = obj;
				}
				if(el.getAttribute('data-type') === 'default-page'){
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse((el.innerHTML));
					supportData.defaultPage = obj;
				}
				if(el.getAttribute('data-type') === 'campusnoisemaker-page'){
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse((el.innerHTML));
					supportData.campusNoiseMaker = obj;
				}
				if(el.getAttribute('data-type') === 'quest-for-the-best'){
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse((el.innerHTML));
					supportData.questfortheBest = obj;	
				}
				if(el.getAttribute('data-type') === 'anniversary-sale'){
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse((el.innerHTML));
					supportData.AnniversarySale = obj;	
				}
				if(el.getAttribute('data-type') === 'download-your-purchase-invoice'){
					let obj = {};
					obj.type = el.getAttribute('data-type');
					obj.data = JSON.parse((el.innerHTML));
					supportData.downloadInvoice = obj;
				}
			});
			
		} catch (e) {
			console.log(e);
		}
		yield put(setSupportData({data:supportData,tab:action.payload}));
	}
}

function* fetchProductData({payload}){
	let results = yield fetch('https://pre-order.gonoise.in/warranty/products	',{
		method:'GET'
	})
	if(results.status === 200){
		let data = yield results.json();
		yield put(setWarrantyProuducts(data.data));
	}
	
}

function* warrantyProducts(action){
	yield takeEvery(supportTypes.FETCH_WARRANTY_PRODUCTS,fetchProductData)
}

function* sendOTP({ payload }) {
	let otp = Math.floor(Math.random() * 899999 + 100000);

	let phoneNumber = payload;
	let url = 'https://pre-order.gonoise.in/warranty/otp'

	let objectpass ={
		phone : phoneNumber,
	}

	let result = yield fetch(url, {
		method: 'POST',
		body: JSON.stringify(objectpass),
		headers: {
			'Content-Type': 'application/json',
			'x-auth-secret': '0329b8ad3bce0bcfdda8ca65c37143c3ccc1e8ae0545da19898ca08bba8ed1a5'
		}
	})
	let res = yield result.json();
	if(res.status === "200"){
		yield put(setOTP({ otp, phoneNumber }));
	}
}

function* varifyOTPAction ({payload}){
	let url = 'https://pre-order.gonoise.in/warranty/otp/verify'

	let objectpass =payload.data

	let result = yield fetch(url, {
		method: 'POST',
		body: JSON.stringify(objectpass),
		headers: {
			'Content-Type': 'application/json',
			'x-auth-secret': '0329b8ad3bce0bcfdda8ca65c37143c3ccc1e8ae0545da19898ca08bba8ed1a5'
		}
	})
	let res = yield result.json();
	if(res.status === "200"){
		payload.matchotpcallback()
	}
	else{
		payload.errorotpcallback()
	}
}

function* warrantyRegister({ payload }){
	try {
		const results = yield fetch('https://backend.gonoise.in/warranty/add',{
			body:JSON.stringify(payload.datapass),
			method:'POST',
			headers:{
				"Content-Type":"application/json"
			}
		})
		let data = yield results.json(); 	
		console.log(data, "warranty status data---->")
		if(data.success){
			payload.callBackFunction();
		}
		else{
			payload.errorCallback();
		}
		
	} 
	catch (error) {
		console.log(error);	
	}
}

function* contactForm({payload}){
	try{
		const result = yield fetch('https://pre-order.gonoise.in/contact',{
			method:'POST',
			headers: {
				'Content-Type': 'application/json',	
			},
			body: JSON.stringify(payload.formData) 
		})

		let data = yield result.json(); 	
		if(data.status === '200'){
			alert('Your message has been successfully sent.');
			payload.callbackFunc();
		}
		else{
			alert('Please Enter Valid Data');
			payload.callbackFunc();
		}
	}
	catch(e){
		console.log(e);
	}
}

function* warrantyRegisterAction(action){
	yield takeEvery(supportTypes.SUBMIT_WARRANTY_REGISTER,warrantyRegister);
}

function* startGetSupportPageData(action) {
	yield takeEvery(supportTypes.GET_SUPPORT_PAGE_DATA, getSupportPageData);
}

function* startSendOTP(action) {
	yield takeEvery(supportTypes.SEND_OTP, sendOTP);
}

function* contactFormAction(action){
	yield takeEvery(supportTypes.SUBMIT_CONTACTFORM,contactForm)
}

function* varificationOTP(action){
	yield takeEvery(supportTypes.VARIFY_OTP,varifyOTPAction)
}

export function* supportSagas() {
	yield all([call(startGetSupportPageData), call(startSendOTP), call(warrantyRegisterAction), call(contactFormAction), call(warrantyProducts), call(varificationOTP)]);
}
