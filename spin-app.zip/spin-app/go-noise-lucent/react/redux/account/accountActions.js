import accountTypes from './accountTypes';

//Set loader
export const setLoader = bool => ({
 type: accountTypes.SET_LOADER,
 payload: bool,
});

export const submitNewsLetter = email => ({
 type: accountTypes.SUBMIT_NEWSLETTER,
 payload: email,
});

//Generate OTP
export const generateOTP = data => ({
 type: accountTypes.OTP_GENERATE,
 payload: data,
});

//verification OTP
export const OTPVerification = data => ({
 type: accountTypes.OTP_VERIFICATION,
 payload: data,
});

export const registerCustomer = data => ({
 type: accountTypes.REGISTER_CUSTOMER,
 payload: data,
});

export const registerSuccess = data => ({
 type: accountTypes.REGISTER_SUCCESS,
 payload: data,
});

/* fetch customer account info */
export const fetchAccountInfo = Id => ({
 type: accountTypes.FETCH_ACCOUNT_INFO,
 payload: Id,
});

/* Set customer account Info */
export const setAccountInfo = data => ({
 type: accountTypes.SET_ACCOUNT_INFO,
 payload: data,
});

/* Set Account Tab */
export const setAccountTab = currentTab => ({
 type: accountTypes.SET_ACCOUNT_TAB,
 payload: currentTab,
});

/* Set Address tab Loading */
export const setAddressLoading = bool => ({
 type: accountTypes.SET_ADDRESS_LOADING,
 payload: bool,
});

/* Add Address async */
export const addAddress = data => ({
 type: accountTypes.ADD_ADDRESS,
 payload: data,
});

/* Edit Address async */
export const editAddress = data => ({
 type: accountTypes.EDIT_ADDRESS,
 payload: data,
});

/* Default Address async */
export const defaultAddress = id => ({
 type: accountTypes.UPDATE_DEFAULT_ADDRESS,
 payload: id,
});

/* Delete Address async */
export const deleteAddress = id => ({
 type: accountTypes.DELETE_ADDRESS,
 payload: id,
});

/* Get Orders */
export const getOrders = Id => ({
 type: accountTypes.GET_ORDERS,
 payload: Id,
});

/* Set Orders */
export const setOrders = data => ({
 type: accountTypes.SET_ORDERS,
 payload: data,
});

/* Set Selected Order ID (order-details) */
export const setSelectedOrderData = data => ({
 type: accountTypes.SET_SELECTED_ORDER_DATA,
 payload: data,
});

/* Update User Information */
export const updateProfileInfo = data => ({
 type: accountTypes.UPDATE_PROFILE_INFO,
 payload: data,
});


/* pre-order data */
export const GetPreOrder = data =>({
    type: accountTypes.GET_PRE_ORDER_DATA,
    payload: data,
})
export const SetPreOrder = data =>({
    type: accountTypes.SET_PRE_ORDER_DATA,
    payload: data,
})
export const makePreOrderPayment = data => ({
    type: accountTypes.MAKE_PRE_ORDER_PAYMENT,
    payload: data
})
export const preOrderDetails = data => ({
    type: accountTypes.PREORDER_DETAILS,
    payload: data
})
export const setPreOrderLoading = data => ({
    type: accountTypes.SET_PRE_ORDER_LOADING,
    payload: data
})