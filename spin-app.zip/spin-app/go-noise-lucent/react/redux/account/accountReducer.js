import accountTypes from "./accountTypes";
const INITIAL_VALUE = {
  profile:{},
  orders: {
    loading: true,
    orderData: [],
    setSelectedOrderData: {},
  },
  preOrder: {
    loading: true,
    orderData: [],
    selectedOrder: {},
  },
  addressLoading: false,
  loading: true,
  currentTab: "personalInfo",
};

const accountReducer = (state = INITIAL_VALUE, action) => {
  switch (action.type) {
    case accountTypes.SET_LOADER: {
      return {
        ...state,
        loading: action.payload,
      };
    }

    case accountTypes.SET_ACCOUNT_INFO: {
      let profile = action.payload;
      return {
        ...state,
        loading: false,
        profile
      };
    }

    case accountTypes.SET_ACCOUNT_TAB: {
      return {
        ...state,
        currentTab: action.payload,
      };
    }

    case accountTypes.SET_ADDRESS_LOADING: {
      return {
        ...state,
          addressLoading: action.payload,
      };
    }

    case accountTypes.SET_ORDERS: {
      return {
        ...state,
          orders: {
            ...state.orders,
            loading: false,
            orderData: action.payload,
          },
      };
    }

    case accountTypes.SET_SELECTED_ORDER_DATA: {
      return {
        ...state,
        orders: {
          ...state.orders,
          setSelectedOrderData: action.payload,
        },
        preOrder:{
          ...state.preOrder,
          loading: false
        },
        currentTab: "order-details",
      };
    }

    case accountTypes.SET_PRE_ORDER_LOADING:{
      return{
        ...state,
        preOrder:{
          ...state.preOrder,
          loading: action.payload
        }
      }
    }

    case accountTypes.SET_PRE_ORDER_DATA: {
      return {
        ...state,
        loading: false,
        preOrder: {
          ...state.preOrder,
          orderData: action.payload,
          loading: false
        },
      };
    }

    default:
      return state;
  }
};
export default accountReducer;
