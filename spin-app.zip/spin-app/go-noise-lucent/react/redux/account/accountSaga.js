import { takeLatest, put, take } from "redux-saga/effects";
import accountTypes from "./accountTypes";
import apiConfig from "../../components/api-config";
import { showToast,RazorPayHandle } from "../../components/Helper";
import {
  setAccountInfo,
  fetchAccountInfo,
  setAddressLoading,
  setOrders,
  SetPreOrder,
  setSelectedOrderData,
  setPreOrderLoading
} from "../account/accountActions";

// newsletter customer
function* submitNewsletter(action) {
  const res = yield accountPostAjax(apiConfig.newsLetter, {
    email: action.payload.email,
  });
  if (action.payload.callback) {
    action.payload.callback(res);
  }
}

//register Customer
function* registerCustomer({ payload }) {
  const res = yield accountPostAjax(apiConfig.register, payload.obj);
  yield payload.callBack(res);
}

//Generate OTP
function* generateOTP({ payload }) {
  const res = yield accountPostAjax(apiConfig.generateOTP, {
    phone: payload.number,
    email: payload.email
  });
  if (res.status !== "200") {
    if(res.status === '409'){
      showToast("Phone number is already in use. You can Sign In or reset your password.", "top");
      payload.callbackerror();

    }
    else if(res.status === '410'){
      showToast("Your account already exists. You can Sign In or reset your password.", "top");
      payload.callbackerror();
    }
    else{
      showToast("something went wrong please try again", "top");
      payload.callbackerror();
    }
  } else if (res.status === "200") {
    showToast("OTP sent!", "top");
    payload.callBack();
  }
  if (res) {
    return res;
  }
}

/* Verify OTP */
function* verifyOTP({ payload }) {
    let callBack = payload.callBack;
    try{
      const res = yield accountPostAjax(apiConfig.verifyOTP, payload.reqData);
      callBack(res);
    }
    catch(e){
      console.log(e);
    }
}

/* Fetch Account Info */
function* fetchAccountInfoAsync({ payload }) {
  const res = yield accountGetAjax(`detail/${payload}`);
  if (res.status === "200") {
    yield put(setAccountInfo(res.data));
    yield put(setAddressLoading(false));
  }
}

/* Update Account Info */
function* updateProfileInfo({ payload }) {
  const res = yield accountPutAjax(
    apiConfig.updateProfile + `/${simply.customerId}`,
    payload.data
  );
  if (res.status === "200") {
   //  yield fetchAccountInfo(simply.customerId);
    yield put(setAccountInfo(res.data));
    payload.callBack();
  } else {
    payload.callBack();
    showToast("Something went wrong please try again later", 200);
  }
}

/* Add Address */
function* addAddress({ payload }) {
  yield put(setAddressLoading(true));
  const res = yield accountPostAjax(
    apiConfig.address + `/${simply.customerId}`,
    payload
  );
  if (res.status === "200") {
    yield put(fetchAccountInfo(simply.customerId));
  }
}

/* Edit Address */
function* editAddress({ payload }) {
  yield put(setAddressLoading(true));
  const res = yield accountPutAjax(
    `address/${simply.customerId}/${payload.id}`,
    payload.data
  );
  if (res.status === "200") {
    yield put(fetchAccountInfo(simply.customerId));
  }
}

/* Update Default Address */
function* updateDefaultAddress({ payload }) {
  yield put(setAddressLoading(true));
  const res = yield accountPutAjax(
    `address/default/${simply.customerId}/${payload}`,
    {}
  );
  if (res.status === "200") {
    yield put(fetchAccountInfo(simply.customerId));
  }
}

/* Delete Address */
function* deleteAddress({ payload }) {
  try {
    yield put(setAddressLoading(true));
    const response = yield fetch(
      apiConfig.postUrl + `address/${simply.customerId}/${payload}`,
      {
        method: "delete",
        headers: {
          "x-auth-secret": apiConfig.key,
        },
      }
    );
    const res = yield response.json();
    if (res.status === "200") {
      yield put(fetchAccountInfo(simply.customerId));
    }
  } catch (e) {
    return e;
  }
}

/* Get Orders */
function* getOrders({ payload }) {
  try {
    const res = yield accountGetAjax(`order/${payload}`);
    if (res.status === "200") {
      yield put(setOrders(res.data));
    }
  } catch (e) {
    return e;
  }
}

/* preOrder Details */
function* preOrderDetails({ payload }) {
  try {
    yield put(setPreOrderLoading(true))
    const res = yield accountGetAjax(`single/order/${payload}`);
    if (res.status === "200") yield put(setSelectedOrderData(res.data))
    else yield put(setPreOrderLoading(false))
  } catch (e) {
    return e;
  }

}

function* getPreOrderData({ payload }) {
  try {
    const res = yield accountGetAjax(`${apiConfig.preOrder}/${payload}`);
    yield put(SetPreOrder(res));
  } catch (e) {
    yield put(SetPreOrder([]));
    return e;
  }
}

function* makePreOrderPayment({ payload }) {
   const {orderId,addressId} = payload;
   try {
     const res = yield accountGetAjax(`${apiConfig.preOrderPayment}/${orderId}/${addressId}`);
     const data = {
       key: res.key,
       order_id: res.order.id,
       amount: res.order.amount,
       email: res.email,
       contact: res.phone
     }
     RazorPayHandle(data);
   } catch (e) {
     console.log(e)
   }
 }


export function* accountSagas() {
  //newsletter customer
  yield takeLatest(accountTypes.SUBMIT_NEWSLETTER, submitNewsletter);
  //Register customer
  yield takeLatest(accountTypes.REGISTER_CUSTOMER, registerCustomer);
  //Generate OTP
  yield takeLatest(accountTypes.OTP_GENERATE, generateOTP);
  //OTP Verification
  yield takeLatest(accountTypes.OTP_VERIFICATION, verifyOTP);
  //Fetch Account Info
  yield takeLatest(accountTypes.FETCH_ACCOUNT_INFO, fetchAccountInfoAsync);
  //Add new address
  yield takeLatest(accountTypes.ADD_ADDRESS, addAddress);
  //Edit address
  yield takeLatest(accountTypes.EDIT_ADDRESS, editAddress);
  //Default address
  yield takeLatest(accountTypes.UPDATE_DEFAULT_ADDRESS, updateDefaultAddress);
  //Delete address
  yield takeLatest(accountTypes.DELETE_ADDRESS, deleteAddress);
  //Get Orders
  yield takeLatest(accountTypes.GET_ORDERS, getOrders);
  //Order Details
  yield takeLatest(accountTypes.PREORDER_DETAILS, preOrderDetails);
  //Update Profile Info
  yield takeLatest(accountTypes.UPDATE_PROFILE_INFO, updateProfileInfo);
  // get pre-order data
  yield takeLatest(accountTypes.GET_PRE_ORDER_DATA, getPreOrderData);
  // make pre-order payment
  yield takeLatest(accountTypes.MAKE_PRE_ORDER_PAYMENT, makePreOrderPayment);
}

function* accountPostAjax(action, data) {
  try {
    const response = yield fetch(`${apiConfig.postUrl}${action}`, {
      method: "post",
      headers: {
        "Content-Type": "application/json",
        "x-auth-secret": apiConfig.key,
      },
      body: JSON.stringify(data),
    });
    const res = yield response.json();
    return res;
  } catch (e) {
    return e;
  }
}

function* accountGetAjax(action) {
  try {
    const response = yield fetch(`${apiConfig.postUrl}${action}`, {
      method: "get",
      headers: {
        "Content-Type": "application/json",
        "x-auth-secret": apiConfig.key,
      },
    });
    const res = yield response.json();
    return res;
  } catch (e) {
    return e;
  }
}

function* accountPutAjax(action, data) {
  try {
    const response = yield fetch(`${apiConfig.postUrl}${action}`, {
      method: "put",
      headers: {
        "Content-Type": "application/json",
        "x-auth-secret": apiConfig.key,
      },
      body: JSON.stringify(data),
    });
    const res = yield response.json();
    return res;
  } catch (e) {
    return e;
  }
}
