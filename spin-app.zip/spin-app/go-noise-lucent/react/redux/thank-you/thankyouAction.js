import thankyouTypes from './thankyouTypes';

export const setName = name => ({
  type: thankyouTypes.SET_STORE_NAME,
  payload: name
});
export const setAll = name => ({
  type: thankyouTypes.SET_ALL,
  payload: name
});