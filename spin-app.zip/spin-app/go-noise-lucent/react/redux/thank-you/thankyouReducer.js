import thankyouTypes from './thankyouTypes';
const INITIAL_VALUE = {
  store_name: 'test',
}
const thankyouReducer = (state = INITIAL_VALUE, action) => {
  switch (action.type) {
    case thankyouTypes.SET_ALL:
      state = action.payload;
      return{
        ...state
      }
    case thankyouTypes.SET_STORE_NAME:
      let win = window.frames[0];
      let obj = {...state,store_name:action.payload};
      win.postMessage(JSON.stringify(obj));
      return {
        ...state,
        store_name: action.payload
      }
    default:
      return state
  }
}
export default thankyouReducer;