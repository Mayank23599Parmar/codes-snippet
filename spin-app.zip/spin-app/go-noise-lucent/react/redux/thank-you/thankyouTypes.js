const thankyouTypes = {
  SET_STORE_NAME:'SET_STORE_NAME',
  SET_ALL:"SET_ALL"
}

export default thankyouTypes;