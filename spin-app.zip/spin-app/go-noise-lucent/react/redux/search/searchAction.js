import searchTypes from './searchTypes';
  
export const setSearchLoading = (act) => ({
  type: searchTypes.SHOW_LOADING,
  payload: act
})

export const searchStart = name => ({
  type: searchTypes.SEARCH_START,
  payload: name
});
export const searchEnd = name => ({
  type: searchTypes.SEARCH_END,
  payload: name
});

export const showSearch = name => ({
  type: searchTypes.SHOW_SEARCH,
  payload: name
});
export const searchResult = name => ({
  type: searchTypes.SEARCH_REASULT,
  payload: name
});

export const setSearchToggle = search => ({
  type: searchTypes.TOGGLE_SEARCH,
  payload: search
});

export const fetchTrendingProducts = data =>({
  type: searchTypes.FETCH_TRENDING_PRODUCTS,
  payload: data
})

export const setTrendingProducts = data => ({
  type: searchTypes.SET_TRENDING_PRODUCTS,
  payload: data
})