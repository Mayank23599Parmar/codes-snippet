import { takeLatest, put, call, all, takeEvery } from "redux-saga/effects";
import searchType from "./searchTypes";
import {
  setSearchLoading,
  showSearch,
  searchResult,
  searchEnd,
  // setSearchToggle,
  // fetchTrendingProducts,
  setTrendingProducts,
} from "./searchAction";

function* searchStartAction(query) {
  let search = false;
  let data;
  yield put(setSearchLoading(true));
  if (query.payload === "") {
    search = false;
    data = [];
  } else {
    try {
      data = yield fetch(
        "https://qe7zibkvwp784f4s1c7rbgi3-fast.searchtap.net/v2",
        {
          method: "POST",
          headers: {
            authorization: "Bearer 65QQHNTHXI9UU7M9IQYSMBYU",
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            collection: "IZL4D4M6288PT4789FMLAGMM",
            count: 100,
            filter: "isSearchable = 1",
            groupCount: -1,
            facetCount: 99,
            searchFields: ["*"],
            numericFacets: {
              discounted_price: [
                "[0,500)",
                "[500,1000)",
                "[1000,2000)",
                "[2000,3000)",
                "[3000,5000)",
                "[5000,10000)",
              ],
            },
            sort: ["-isActive", "-popularityScore", "-created_at", "-_rank"],
            fields: [
              "created_at",
              "variants",
              "options",
              "discount",
              "discounted_price",
              "handle",
              "hasMultiplePrice",
              "isActive",
              "isSearchable",
              "price",
              "product_type",
              "image",
              "images",
              "tags",
              "color",
              "vendor",
              "title",
              "metafields",
              "featured",
              "selected_or_first_available_variant",
              "featured_image",
              "available",
            ],
            query: query.payload,
          }),
        }
      );
      data = yield data.json();
    } catch (error) {
      data = [];
      console.log(error);
    }
    try {
      data = data.results;
      search = true;
    } catch (e) {
      data = [];
    }
  }
  yield put(showSearch(search));
  yield put(searchResult(data));
  yield put(searchEnd(query.payload));
}
function* searchStart() {
  yield takeLatest(searchType.SEARCH_START, searchStartAction);
}

function* fetchTrendingProductAction() {
  let data;
  try {
    data = yield fetch(
      "https://qe7zibkvwp784f4s1c7rbgi3-fast.searchtap.net/v2",
      {
        method: "POST",
        headers: {
          authorization: "Bearer 65QQHNTHXI9UU7M9IQYSMBYU",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          collection: "4NNJV9USHS8WD2WVWKG61X19",
          count: 30,
          facetCount: 100,
          fields: [
            "*"
          ],
          filter: "",
          geo: {},
          groupCount: -1,
          highlightFields: [],
          numericFacetFilters: {},
          numericFacets: {},
          query: "",
          searchFields: ["*"],
          skip: 0,
          sort: [],
          textFacetFilters: {},
          textFacetQuery: null,
          textFacets: [],
          typoTolerance: 1,
        }),
      }
    );
    data = yield data.json();
    data = data.results;
    yield put(setTrendingProducts(data));
  } catch (error) {
    data = [];
    console.log(error);
  }
}

function* searchTrending() {
  yield takeEvery(
    searchType.FETCH_TRENDING_PRODUCTS,
    fetchTrendingProductAction
  );
}

export function* searchSagas() {
  yield all([call(searchStart), call(searchTrending)]);
}
