import searchTypes from './searchTypes';

const INITIAL_VALUE = {
  searchData: null,
  searchStart:false,
  searchEnd:false,
  showSearch:false,
  searchResult:[],
  searchToggle: false,
  trendingProducts: []
}

const searchReducer = (state = INITIAL_VALUE, action) => {
  switch (action.type) {
    case searchTypes.TOGGLE_SEARCH:
      return {
        ...state,
        searchToggle: action.payload
      }
    case searchTypes.SEARCH_REASULT:
      return {
        ...state,
        searchResult: action.payload
      }
    case searchTypes.SHOW_SEARCH:
      return {
        ...state,
        showSearch: action.payload
      }
    case searchTypes.SEARCH_START:
      return {
        ...state,
        searchStart: action.payload
      }
      case searchTypes.SEARCH_END:
      return {
        ...state,
        searchEnd: action.payload
      }
    case searchTypes.SHOW_LOADING: 
      return {
        ...state,
        loading: action.payload
      }
    case searchTypes.SET_TRENDING_PRODUCTS:
      return {
        ...state,
        trendingProducts: action.payload
      }
    default:
      return state
  }
}

export default searchReducer;