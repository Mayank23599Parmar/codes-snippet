import { put, takeEvery } from 'redux-saga/effects';
import {setShopSEO} from './shopAction';
import shopTypes from './shopTypes';
import {reactShopifyAnalytics} from '../../components/Helper';

function* fetchSEO({payload}){
    let seoResponse, url,finalRes = {};
    url = `${payload}?view=seodata`;
    try {
        seoResponse = yield fetch(url)
        finalRes = yield seoResponse.json();  
        yield put(setShopSEO(finalRes));
        reactShopifyAnalytics(finalRes)
    } catch (e) {
        seoResponse = null;
        // console.error('There was an error.', e)
    }
}

export function* shopSagas(action){
	yield takeEvery(shopTypes.FETCH_SHOP_SEO,fetchSEO)
}

