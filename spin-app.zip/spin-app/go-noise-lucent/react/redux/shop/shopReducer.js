import shopTypes from './shopTypes';
const INITIAL_VALUE = {
  shop: null,
  collectionList: null,
  loader:false,
  seoData:{}
}
const shopReducer = (state = INITIAL_VALUE, action) => {
  switch (action.type) {
    case shopTypes.SET_SHOP:
      return {
        ...state,
        shop: action.payload
      }
    case shopTypes.SET_LOADER:
    return {
      ...state,
      loader: action.payload
    }
    case shopTypes.SET_SHOP_SEO:
    return {
      ...state,
      seoData: action.payload
    }
    default:
      return state
  }
}
export default shopReducer;