const shopTypes = {
  SET_SHOP:'SET_SHOP',
  SET_LOADER:'SET_LOADER',
  SET_SHOP_SEO:'SET_SHOP_SEO',
  FETCH_SHOP_SEO:'FETCH_SHOP_SEO'
}
export default shopTypes;