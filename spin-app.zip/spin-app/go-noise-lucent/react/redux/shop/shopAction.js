import shopTypes from './shopTypes';
const setShop = shop => ({
  type: shopTypes.SET_SHOP,
  payload: shop
});
const setLoader = loader => ({
  type: shopTypes.SET_LOADER,
  payload: loader
});
const fetchShopSEO = url =>({
  type: shopTypes.FETCH_SHOP_SEO,
  payload: url
})
const setShopSEO = data =>({
  type: shopTypes.SET_SHOP_SEO,
  payload: data
})
export {
  setShop,
  setLoader,
  setShopSEO,
  fetchShopSEO
};