import { takeLatest, put, call, all } from "redux-saga/effects";
import blogTypes from "./blogTypes";
import { setBlog, startBlogLoading } from "./blogActions";

function* fetcBlogs() {
  yield put(startBlogLoading(true));
  let data, dataJson;
  try {
    data = yield fetch(`/blogs/posts?view=react`);
    if (data.status === 404) {
      yield put(setBlog(false));
    } else {
      dataJson = yield data.json();
      yield put(setBlog(dataJson))
      yield put(startBlogLoading(false));

    }
  } catch (e) {
    console.log(e);
  }
}

function* blogStart() {
  yield takeLatest(blogTypes.FETCH_BLOG, fetcBlogs);
}

export function* blogSagas() {
  yield all([call(blogStart)]);
}
