import blogTypes from './blogTypes'

export const setBlog = (data) =>({
    type:blogTypes.SET_BLOG,
    payload:data
})

export const fetchBlog = (data) =>({
    type:blogTypes.FETCH_BLOG,
    payload:data
})

export const startBlogLoading = (data) =>({
    type:blogTypes.START_BLOG_LOADING,
    payload: data
})