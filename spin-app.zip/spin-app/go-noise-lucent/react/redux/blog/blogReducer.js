import blogTypes from "./blogTypes";
const INITIAL_VALUE = {
  blogData: {},
  blogLoading: true,
};
const blogReducer = (state = INITIAL_VALUE, action) => {
  switch (action.type) {
    case blogTypes.SET_BLOG:
      return {
        ...state,
        blogData: action.payload,
      };
    case blogTypes.START_BLOG_LOADING:
      return {
        ...state,
        blogLoading: action.payload,
      };
    default:
      return state;
  }
};
export default blogReducer;
