const blogTypes={
    START_BLOG_LOADING:'START_BLOG_LOADING',
    FETCH_BLOG:'FETCH_BLOG',
    SET_BLOG:'SET_BLOG'
}

export default blogTypes