export const cartUtils = cartItems => {
  let cart_count = cartItems.item_count;
  let free_count = 0;
  let combo_count = 0;
  let eligible = false;
  let non_free_count = 0;

  let itemtags = cartItems.tags;
  let allItems = cartItems.items;

  allItems.map(item => {
    let product = item;
    let productId = product.id;
    
    if (process.env.NODE_ENV === 'development') {
      productId = atob(product.variant.id).split("/").reverse()[0];
      if (productId.indexOf('?') !== -1) {
        productId = productId.split('?')[0];
      }
    }

    let productTags = itemtags[productId];
    if(!productTags){
      return false;
    }
    let tags = productTags.split(',');

    if (tags.includes('combo-fs')) {
      combo_count = combo_count + product.quantity;
    };
    if (tags.includes('free-sample')) {
      free_count = free_count + product.quantity;
    };

    return null
  })

  non_free_count = cart_count - free_count;

  if (combo_count > 0 && free_count < 2) {
    eligible = true;
  } else if (combo_count > 0 && free_count === 2) {
    eligible = false
  } else if (non_free_count > 1 && free_count < 2) {
    eligible = true
  } else if (non_free_count <= 1) {
    eligible = false
  } else if (free_count > 1) {
    eligible = false
  }

  cartItems.freeSampleEligible = eligible;
  cartItems.cartCount = cart_count;
  cartItems.nonFreeCount = non_free_count;
  cartItems.freeCount = free_count;
  cartItems.comboCount = combo_count;

  window.freeSampleEligible = eligible ? true : false;

  window.cartData = cartItems;
  
  return cartItems;
}