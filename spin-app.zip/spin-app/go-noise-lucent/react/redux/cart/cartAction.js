import cartTypes from './cartTypes';
export const addToCart = data => {
  return({
 type: cartTypes.ADD_TO_CART,
 payload: data,
})};
export const updateCart = qtyArray => ({
 type: cartTypes.UPDATE_CART,
 payload: qtyArray,
});
export const updateCart1 = data => ({
  type: cartTypes.UPDATE_CART_1,
  payload: data,
 });
 export const clearCart1 = () => ({
  type: cartTypes.CLEAR_CART
 });
export const setCartStart = start => ({
 type: cartTypes.SET_CART_START,
 payload: start,
});
export const setCartData = cart => ({
 type: cartTypes.SET_CART,
 payload: cart,
});
export const setCartLoading = loading => ({
 type: cartTypes.SET_CART_LOAD,
 payload: loading,
});
// export const setSideCartToggle = side_cart => ({
//  type: cartTypes.TOGGLE_SIDE_CART,
//  payload: side_cart,
// });
export const setCartGst = data => ({
 type: cartTypes.SET_GST,
 payload: data,
});
export const checkGSTNumber =data =>({
  type:cartTypes.CHECK_GST,
  payload:data
})
