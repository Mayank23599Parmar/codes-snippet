import { takeLatest, put, call, all, takeEvery } from 'redux-saga/effects';
import cartTypes from './cartTypes';
import {
 setCartStart,
 setCartData,
 setCartLoading,
//  setSideCartToggle,
 setCartGst,
} from './cartAction';
import ajaxUpdateCart from "../../axios/AxiosUpdateCart";

// sidecart data set
function* cartStartAction(cart) {
    try{
        let data;
        // if (cart.payload) {
        // yield put(setSideCartToggle(true));
        // }
        // yield put(setCartLoading(true));
        data = yield fetch(`/cart?view=react`);
        data = yield data.json();
        yield put(setCartData(data));
        yield put(setCartLoading(false));
    }catch(e){
        console.log(e);
    }
}
function* cartStart() {
    try{
        yield takeLatest(cartTypes.SET_CART_START, cartStartAction);
    }catch(e){
        console.log(e);
    }
 
}
// sidecart data set end
// update cart on quantity update on sidecart start
function* cartUpdateAction(action) {
 yield ajaxCart("/cart/update.js",{ updates: action.payload });
 yield put(setCartStart());
}
function* updateCart() {
 yield takeLatest(cartTypes.UPDATE_CART, cartUpdateAction);
}
// update cart on quantity update on sidecart start

//update cart with gift wrap

function* cartUpdateAction1(action) {
 // window.location.reload();
  yield ajaxCart("/cart/update.js",{ updates: action.payload });
  yield put(setCartLoading(true));
  yield put(setCartStart(true));
  
 }
 function* updateCart1() {
  yield takeLatest(cartTypes.UPDATE_CART_1, cartUpdateAction1);
 }
//update cart with gift wrap
function* clearCartUpdate() {
  yield ajaxCart("/cart/clear.js");
  yield put(setCartStart());
}
function* clearCart1() {
  yield takeLatest(cartTypes.CLEAR_CART, clearCartUpdate);
 }

// product add to cart on and sidecart update start
function* AddToCartAction(action) {
 if (action.payload.type === 'cart') {
    yield ajaxCart("/cart/add.js", action.payload.form);
    yield put(setCartLoading(true));
    yield put(setCartStart(true));
    if(!cn(action.payload.callback)){
      action.payload.callback();
    }
 }
 else if( action.payload.type === 'checkoutcoupon'){
  let datafetch = yield fetch('/cart/add.js', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(action.payload.form)
  });
  datafetch = yield datafetch.json();
  window.location.href = `/checkout?discount=${action.payload.code}`;
  
}
 else {
    let datafetch = yield fetch('/cart/add.js', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(action.payload.form)
  })
  datafetch = yield datafetch.json();
  window.location.href = '/checkout';
 }
}
function* AddToCart() {
    yield takeLatest(cartTypes.ADD_TO_CART, AddToCartAction);
}
// product add to cart on and sidecart update start

//product cart gst update
function* setCartGST({ payload }) {
 const data = `attributes[gst]=${payload}`;
 yield ajaxUpdateCart.post('', data);
 window.location.href = '/checkout';

}
function* setGSTStart(){
    yield takeLatest(cartTypes.SET_GST, setCartGST);
}

export function* cartSagas() {
 yield all([
  call(cartStart),
  call(updateCart),
  call(updateCart1),
  call(clearCart1),
  call(AddToCart),
  call(setGSTStart)
 ]);
}

/* shopify cart actions */
function* ajaxCart(url,data){
  try{
    let res = yield fetch(url,{
      method: "POST",
      headers: {
          'Content-Type': 'application/json'
      },
        body: JSON.stringify(data)
    })
    res = yield res.json();
    return res;
  }
  catch(e){

  }
}