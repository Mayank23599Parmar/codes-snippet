import cartTypes from './cartTypes';
// import {cartUtils} from './cartUtils';
const INITIAL_VALUE = {
  cart: {},
  show: false,
  loading:false,
  gstError:false
}
const cartReducer = (state = INITIAL_VALUE, action) => {
  switch (action.type) {
    case cartTypes.SET_CART_LOAD:
      return {
        ...state,
        loading: action.payload
      }
    case cartTypes.SET_CART:
      return {
        ...state,
        cart: action.payload 
      }
    // case cartTypes.TOGGLE_SIDE_CART:
    //   return {
    //     ...state,
    //     show: action.payload
    //   }
    case cartTypes.CHECK_GST:
      return {
        ...state,
        gstError:action.payload
      }
    default:
      return state
  }
}
export default cartReducer;
