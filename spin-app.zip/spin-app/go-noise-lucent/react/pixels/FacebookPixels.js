import ReactPixel from 'react-facebook-pixel';
//facebook pixels

const advancedMatching = {}; // optional, more info: https://developers.facebook.com/docs/facebook-pixel/pixel-with-ads/conversion-tracking#advanced_match
const options = {
  autoConfig: false, 	// set pixel's autoConfig
  debug: false, 		// enable logs
};
ReactPixel.init('898267430259051', advancedMatching, options);
class FacebookPixels {
  pageView = () => {
    ReactPixel.fbq('track', 'PageView');
  }
  addToCart = (id, product) => {

    let vid = id;
    let name = product.title;
    let price =  product.variants.map(varnt => {
      if (varnt.id === id) {
        return varnt.price;
      }
      return null;
    })

    price = price.toString();

    ReactPixel.fbq('track', 'AddToCart', {
      content_ids: [vid],
      content_name: name, 
      content_type: 'product',
      value: price,
      currency: 'INR' 
    });          
  }
}

export { FacebookPixels };