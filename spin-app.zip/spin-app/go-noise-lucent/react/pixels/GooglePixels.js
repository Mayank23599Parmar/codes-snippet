import ReactGA from 'react-ga';
ReactGA.plugin.require('ecommerce');

class googlePixels {
  constructor() {
    ReactGA.initialize('UA-66061979-1', { debug: false, alwaysSendToDefaultTracker: true });
  }
  pageView = () => {
    ReactGA.pageview(window.location.pathname + window.location.search);
  }
  addToCart = (id, product) => {

    let vid = id;
    let name = product.title;
    let variant = '';

    product.variants.map(varnt => {
      if (varnt.id === id) {
        let values = []
        if (varnt.selectedOptions) {
          varnt.selectedOptions.map(option => {
            values.push(option.value);
            return false
          });
        }
        variant = values.toString();
      }
      return false
    })


    ReactGA.ga('ec:addProduct', {
      'id': vid,
      'name': name,
      'variant': variant,
      'position': 1,
    });

    let eventName = 'Added Product';
    if (product.toCheckout) {
      eventName = 'Clicked on Buy Now';
    }

    ReactGA.ga('ec:setAction', 'add');
    ReactGA.ga('send', 'event', 'EnhancedEcommerce', eventName, 'add to cart');

    // ReactGA.ga('ecommerce',"AddToCart", {
    //   'id': 'P12345',                   // Product ID (string).
    //   'name': 'Android Warhol T-Shirt', // Product name (string).
    //   'category': 'Apparel',            // Product category (string).
    //   'brand': 'Google',                // Product brand (string).
    //   'variant': 'Black',               // Product variant (string).
    //   'position': 1,                    // Product position (number).
    // });
  }

  event = (data) => {
    let { category, type, currentTarget } = data;
    let args = {
      category: category,
      action: type, 
      label: currentTarget.href,
    }
    ReactGA.event(args);
  }
}

export {
  googlePixels
}
