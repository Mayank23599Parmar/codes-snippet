import React from "react";
import { connect } from "react-redux";
import {
  searchStart,
  fetchTrendingProducts,
} from "../../redux/search/searchAction";
import SimplySearchProduct from "./SimplySearchProduct";
import { searchbarEvent } from "../../clever-tap-events/SearchbarEvent";
import Srcset from "../../components/SrcSet";
import UrlSet from "../../components/UrlSet";

class SearchPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      query: "",
      products: [],
      count: ""
    };
  }

  componentDidMount() {
      //console.log("inside did mount");
      let pageQueryStr = this.props.location.search.substring(1);
      let searchquery = pageQueryStr.split("=");
      var test1 = searchquery[1].replace(/%20/g, " ");
      const { setSearchStart, fetchTrendingProducts } = this.props;
      if(searchquery.length === 2){
        if(searchquery[1].includes('cache:')){
          let res = searchquery[1].replace('cache:','').replace('+&cd','');
          res = res.split(':');
          res = res[2].replace('//www.gonoise.com','');
          this.props.history.push(res);
        }
        setSearchStart(searchquery[1]);
        fetchTrendingProducts();
        this.setState({ query: test1 });
      }
  };
  handleChange = (e) => {
    const { setSearchStart } = this.props;
    const { query } = this.state;
    let value = e.target.value;
    //console.log(value);
    var test = value.replace(/%20/g, " ");
    this.setState({ query: test }, () => {
      const { setSearchStart } = this.props;
      setSearchStart(test);
    });
  };
  handleSubmit = (e) => {
    e.preventDefault();
    searchbarEvent(this.state.query);
  };
  componentWillUnmount() {
    const { setSearchStart } = this.props;
    setSearchStart("");
  }
  render() {
    const { products, term ,setSearchStart} = this.props;
    const { query } = this.state;
    
    if(query!==""){
      if(products.length===0){
 
        setSearchStart(query);
      }
    }
  
    let pageQueryStr = this.props.location.search.substring(1);
    let searchquery = pageQueryStr.split("=");
    let trendingProductsHtml = this.props.trendingProducts.map(
      (prod, index) => {
        let handle = prod.redirectUrl.replace('https://www.gonoise.com/','')
        return (
          <span key={index}>
            <UrlSet href={handle}>{prod.displayLabel}</UrlSet>
          </span>
        );
      }
    );
    return (
      <div id="search-page">
        <div className="search_form">
          <form className="search" onSubmit={(e) => this.handleSubmit(e)}>
            <div className="input-wrapper">
            <input id="pageSearch" onChange={e => this.handleChange(e)} placeholder="Search" type="text"
              className="input_box"
              name="query"
              value={query}
              ref={this.inputBox}
              autoComplete="off"
            />
            <span className="search-icon"><img src={pwa.icons.searchOrange} alt="search"/></span>
            </div>
            <div className='trending-products flex-view-xs space-between'>
              <div className="img">
                <Srcset src={pwa.icons.trendingRed} />
                <span className="error"> Trending Searches </span>
              </div>
              <div className='products' >{trendingProductsHtml}</div>
            </div>
          </form>
        </div>
        <div className="product-list">
          <ul className="list flex-view-xs" ref={this.ref}>
            {products.length > 0 &&
              products.map((product, index) => {
                return (
                  <li key={index} className="col-sm-6 col-xs-12">
                    <SimplySearchProduct product={product} searchTerm={query} key={index} />
                  </li>
                );
              })}
          </ul>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  setSearchStart: (term) => dispatch(searchStart(term)),
  fetchTrendingProducts: (data) => dispatch(fetchTrendingProducts(data)),
});

const mapStateToProps = (state) => ({
  products: state.search.searchResult,
  term: state.search.searchEnd,
  trendingProducts: state.search.trendingProducts,
});

export default connect(mapStateToProps, mapDispatchToProps)(SearchPage);
