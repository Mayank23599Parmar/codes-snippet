import React, { Component } from 'react';
// import Srcset from '../../components/SrcSet';
import UrlSet from '../../components/UrlSet';
import VariantSelector from '../../components/VariantSelector';
import { connect } from 'react-redux';
import { addToCart } from '../../redux/cart/cartAction';
import { fetchProductTitle, showCartPopUp } from '../../components/Helper';
import { ctaEvent, AddToCartCTA } from '../../clever-tap-events/AddToCartEvent'
import Notifypopup from "../product-page/Notifypopup";

class SimplySearchProduct extends Component {
  constructor(props) {
    super(props);
    this.ref = React.createRef();
    this.state = {
      selectedVariant: null,
      productData: null,
      showNotifypop: false,
    }
  }
  addTocart = (e) => {
    const { product } = this.props;
    let selectedVariant = this.state.selectedVariant;
    if (this.state.selectedVariant === null) {
      selectedVariant = product.selected_or_first_available_variant ? product.selected_or_first_available_variant : product.variants[0];
    }

    const form = { id: parseInt(selectedVariant.id), quantity: 1 }
    const data = {
      "type": e.currentTarget.name,
      form
    }
    this.props.addToCart(data);
    showCartPopUp(<div className="main-cart-pop-div"><div className="pop-up-image"><img src={selectedVariant.image.src} alt="img" /></div><span className="pop-up-text">Added To Bag</span></div>, "top-right");
    let Ctobj = { selectedVariant: this.state.selectedVariant, title: this.state.productData.title, type: this.state.productData.product_type }
    AddToCartCTA(Ctobj)
  }


  setSelectedVariant = (selectedVariant) => {
    const { image } = selectedVariant;
    let src = this.state.featured_image;
    if (image.src) {
      src = image.src;
    }
    if (this.ref.current) {
      let image = this.ref.current.querySelector('.product-img');
      image.setAttribute("srcset", src);
    }
    this.setState({ selectedVariant, featured_image: src })
  }
  componentDidMount() {
    const { product } = this.props;
    if (!product) {
      return
    }
    const selectedVariant = product.selected_or_first_available_variant ? product.selected_or_first_available_variant : product.variants[0];
    const productData = product
    this.setState({ selectedVariant, productData })
  }
  componentDidUpdate(prevProps) {
    const { product } = this.props;
    if (prevProps.searchTerm !== this.props.searchTerm) {
      this.setState({ selectedVariant: null, productData: null })
    }
  }
  toggleModale = (value) => {
    this.setState({ showNotifypop: value });
  };
  render() {
    const { product } = this.props;
    const { selectedVariant } = this.state;
    let updatedSelectedVariant = selectedVariant;
    console.log(updatedSelectedVariant, 'updatedSelectedVariant');
    if (cn(updatedSelectedVariant)) {
      updatedSelectedVariant = product.selected_or_first_available_variant ? product.selected_or_first_available_variant : product.variants[0];
      if (cn(updatedSelectedVariant)) {
        return null;
      }
    }

    const { image } = updatedSelectedVariant;
    let src = '';
    if (!cn(image)) {
      src = image.src;
    } else {
      if (!cn(product.image)) {
        src = product.image.src;
      }
    }

    const { variants, options } = product;
    let { swatchTitleShow } = false;
    let actual_title = product.title;
    let tagTitle = fetchProductTitle(product.tags);
    if (tagTitle) {
      actual_title = tagTitle;
    }
    let vclass = "";
    return (
      <>
         {this.state.showNotifypop && (
          <Notifypopup
            title={actual_title}
            variant={updatedSelectedVariant}
            toggleModale={this.toggleModale}
          />
        )}
      <div className={`product-main detail-${product.id}`}>
        <div className="text-wrapper">
          <h3 className="title">
            <UrlSet className="product-link" href={`/products/${product.handle}`}>
              <span className="product-title">{actual_title}</span>
            </UrlSet>
          </h3>
          <div className="product-price ">
            <h5 className="price">₹{(parseInt(updatedSelectedVariant.price))}</h5>
            {updatedSelectedVariant.compare_at_price && updatedSelectedVariant.compare_at_price > updatedSelectedVariant.price &&
              <p className="compare">
                ₹{(parseInt(updatedSelectedVariant.compare_at_price))}
              </p>}
          </div>
        </div>
        <div className="image">
          <div className="relative img-cell ">
            <div className="img" ref={this.ref}>
              <UrlSet className="product-link" href={`/products/${product.handle}`}>
                <img alt={product.title} src={src} className="product-img lazyautosizes lazyloaded" />
              </UrlSet>
            </div>
          </div>
        </div>

        <div className={`variants-wrapper ${vclass}`}>
          {options.map((option, index) => {
            return (
              <ul className="swatch-wrap" key={index}>
                {swatchTitleShow ? (
                  <h3 className="swatch-title">{option.name}</h3>
                ) : null}
                {(variants.length === 1 && variants[0].title === "Default Title") ? "" : variants.map((variant, ind) => {
                  return <VariantSelector
                    key={ind}
                    option={option.name}
                    selectedVariant={updatedSelectedVariant}
                    variantImages={pwa.variantImages}
                    variant={variant}
                    setSelectedVariant={() => this.setSelectedVariant(variant)}
                  />;
                })}
              </ul>
            );
          })}
        </div>
        <div className="text">
          {
            updatedSelectedVariant.inventory_quantity == 0 ? 
            <button className="btn" onClick={() => this.setState({ showNotifypop: true }) }>
              <span data-text="ADD TO CART">{'Notify Me'}</span>
            </button> : 
           <button className="btn" name="cart" onClick={this.addTocart}>
              <span data-text="ADD TO CART">{'Add To Bag'}</span>
            </button>
          
          }
          <div className="links clearfix">
            <UrlSet href={`/products/${product.handle}`} className="text-Know">Know more <img className="icon-img" src={pwa.icons.peachRightArrow} /></UrlSet>
            <UrlSet href={`/products/${product.handle}`} className="text-compare">Compare <img className="icon-img" src={pwa.icons.plus} /></UrlSet>
          </div>
        </div>
      </div>
      </>
    );
  }
}
const mapDispatchToProps = dispatch => (
  {
    startCartFetch: value => dispatch(setCartStart(value)),
    addToCart: data => dispatch(addToCart(data))
  }
)
export default connect(null, mapDispatchToProps)(SimplySearchProduct);