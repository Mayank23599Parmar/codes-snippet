import React from "react";
import ReactModal from "react-modal";
import MediaQuery from "../../components/MediaQuery";
import Srcset from "../../components/SrcSet";
class HomeVideo extends React.Component {
  constructor(props) {
    super(props);

    this.customStyles = {
      overlay:{
        zIndex: 6
      },
      content: {
        top: "50%",
        left: "50%",
        right: "auto",
        bottom: "auto",
        marginRight: "-50%",
        transform: "translate(-50%, -50%)",
        position:"absolute",
        backgroundColor: "#000",
        maxWidth:'600px',
        padding: '0px',
        width: "calc(100% - 20px)"
      },
    };
    this.state = {
      showVideoModal: false,
    };
  }

  toggleModale = (value) => {
    this.setState({ showVideoModal: value });
  };

  render() {
    const { section } = this.props;
    const { showVideoModal } = this.state;
    return (
      <div className="home-video-wrapper">
        <div
          className="text-area"
          onClick={() => {
            this.toggleModale(true);
          }}
        >
          <h1>{section.settings.heading_video}</h1>
          <h3>{section.settings.subheading_video}</h3>
          {section.settings.button_text && section.settings.button_link && <button className='btn'>{section.settings.button_text}</button>}
          
        </div>
        <MediaQuery query="tablet-and-up">
          {
            section.settings.video_url?  <video
            playsInline
            width="100%"
            height="100%"
            controls={section.settings.video_control}
            autoPlay={true}
            muted={section.settings.muteVideo}
            loop={section.settings.loopVideo}
            className="video-container video-container-overlay"
            poster={section.settings.video_image != '' ? section.settings.video_image :""}
          >
            <source src={section.settings.video_url} type="video/mp4" />
          </video>: <div className="img"><Srcset  src={section.settings.image_desktop} /></div>
          }
      
        </MediaQuery>
        <MediaQuery query="phone">
          {
            section.settings.video_url_mobile? <video
            playsInline
            width="100%"
            height="100%"
            controls={section.settings.video_control}
            autoPlay={true}
            muted={section.settings.muteVideo}
            loop={section.settings.loopVideo}
            className="video-container video-container-overlay"
            poster={section.settings.video_image != '' ? section.settings.video_image :""}
          >
            <source src={section.settings.video_url_mobile} type="video/mp4" />
          </video>: <div className="img"><Srcset  src={section.settings.image_mobile} /></div>
          }
       
        </MediaQuery>
        {section.settings.button_link && 
        <ReactModal
          isOpen={showVideoModal}
          contentLabel="onRequestClose Example"
          onRequestClose={() => this.toggleModale(false)}
          shouldCloseOnOverlayClick={true}
          style={this.customStyles}
        >
          <div className="video-wrapper">
          <iframe
            playsInline
            width="100%"
            height="100%"
            src={section.settings.button_link}
            className="video-container video-container-overlay modal-video"
          >
          </iframe></div>
        </ReactModal>}
      </div>
    );
  }
}
export default HomeVideo;
