import React from 'react';
import Srcset from '../../components/SrcSet';
import UrlSet from '../../components/UrlSet';
// import MediaQuery from '../../components/MediaQuery';

const HomeStories = (props) => {
    const { section } = props;
    return (
        <div className="home-stories" id={`section_${section.sectionId}`}>
            <div className="container">
                <div className="text">
                    <h2 className="title">{section.settings.title}</h2>
                    <h5 className="desc">{section.settings.text}</h5>
                </div>
                <div className="flex-view-xs">
                    {section.blocks.map((item, index) => {
                        return (
                            <div className={`col-sm-6 col-xs-12`} key={section.blocksId[index]}>
                                <UrlSet className="urlSet" href={item.articleUrl}>
                                    <div className="block-content">
                                        <div className="img">
                                            {item.image ? <Srcset alt="img" src={item.image} /> : null}
                                        </div>
                                        <div className="detail">
                                            <h4 className="story_title">{item.story_title}</h4>
                                            <label className="date">{item.date}</label>
                                        </div>
                                    </div>
                                </UrlSet>
                            </div>
                        )
                    })}
                </div>
                <div className="bottom-container">
                    <UrlSet href={'/pages/stories'}>
                        <label className="read_all">{'Read All >'}</label>
                    </UrlSet>
                </div>
            </div>
        </div>
    );
}

export default HomeStories