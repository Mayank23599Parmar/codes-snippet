import React from 'react';
import Srcset from '../../components/SrcSet';
// import UrlSet from '../../components/UrlSet';
import MediaQuery from '../../components/MediaQuery';

const HomeInThePress = (props) => {
    const { section } = props;
    return (
        <div className="home-in-the-press" id={`section_${section.sectionId}`}>
            <div className="container">
                <div className="text">
                    <h2 className="title">{section.settings.title}</h2>
                    <h5 className="desc">{section.settings.text}</h5>
                </div>
                <div className="flex-view-xs">
                    {section.blocks.map((item, index) => {
                        return (
                            <div className={`col-sm-4 col-xs-6`} key={section.blocksId[index]}>
                                <div className="block-content">
                                    <div className="img">
                                        <MediaQuery query="lap-and-up">
                                            {item.image ?
                                                <Srcset alt="img" src={item.image} />
                                                : null
                                            }
                                        </MediaQuery>
                                        <MediaQuery query="phone-and-tablet">
                                            {item.image_xs ?
                                                <Srcset alt="img" src={item.image_xs} />
                                                : null
                                            }
                                        </MediaQuery>
                                    </div>
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>
        </div>
    );
}

export default HomeInThePress;