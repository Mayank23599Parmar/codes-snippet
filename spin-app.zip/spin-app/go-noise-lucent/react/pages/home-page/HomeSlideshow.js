import React, { Component } from 'react';
import Slider from "react-slick";
import Srcset from '../../components/SrcSet';
import UrlSet from '../../components/UrlSet';
import MediaQuery from '../../components/MediaQuery';
import {HomeBanner} from '../../clever-tap-events/BannerEvent'

class HomeSlideshow extends Component {
  render() {
    const {section} = this.props;
    const blocksId = section.blocksId;
    let settings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
      adaptiveHeight: true,
      arrows: false,
      autoplay: true,
      autoplaySpeed: 2000
    };
    return (
      <div className="slideshow" id={`section_${section.sectionId}`}>
        {/* <iframe width="100%" height="600" src="http://www.youtube.com/embed/mbLgK_MnuHA?autoplay=1" frameborder="0" allowfullscreen></iframe> */}
        <div className={section.settings.full ? '' :'container'}>
          <div className="slickSlider">
          <Slider {...settings}>
            {section.blocks.map((item,index)=>{
              return(
              <div className={`single-item block-${blocksId[index]}-${index+1}`} key={blocksId[index]}>
                <div className="img">
                  <UrlSet href={item.img_link} className={item.overlay && 'overlay', 'img-link'} onClick={()=>HomeBanner(item.img_link)}>
                    <MediaQuery query="lap-and-up">
                      {item.image && 
                      <Srcset alt="img" src={item.image} />
                      }
                    </MediaQuery>
                    <MediaQuery query="phone-and-tablet">
                      {item.image_xs &&
                      <Srcset alt="img" src={item.image_xs} />
                      }
                    </MediaQuery>
                  </UrlSet>
                </div>
                <div className={item.text_alignment,' slide-text'}>
                  <div className="container">
                  <div className="text-wrapper">
                    <h1>Noise</h1>
                    {item.slider_header &&
                      <h4 >{item.slider_header}</h4>
                    }
                    {item.slider_text &&
                      <h2>{item.slider_text}</h2>
                    }
                    {item.launched_text &&
                      <h5>{item.launched_text}</h5>
                    }
                    {item.slider_btn &&
                      <UrlSet href={item.slider_link} className="btn">{item.slider_btn}</UrlSet>
                    }
                    {item.slider_btn2 && item.slider_link2 &&
                      <UrlSet href={item.slider_link2} className="btn fancybox fancybox.iframe">{item.slider_btn2}</UrlSet>
                    }
                  </div>
                  </div>
                </div>
              </div>)
            })}
          </Slider>
          </div>
          </div>
      </div>
    );
  }
}

export default HomeSlideshow;