import React from 'react';
import Srcset from '../../components/SrcSet';
import UrlSet from '../../components/UrlSet';
import HtmlParser from 'react-html-parser'
const HomeImageWithTopText = (props) =>{
    const {section} = props;
    return(
        <div className="home-image-with-top-text" id={`section_${section.sectionId}`}>
                <div className="container">
                    <div className="text">
                        <h2 className="title">{section.settings.title}</h2>
                        <h5 className="desc">{HtmlParser(section.settings.text)}</h5>
                        {section.settings.btn_text && section.settings.btn_url && <UrlSet href={section.settings.btn_url} className="text-link">{section.settings.btn_text}<img className="icon-img" src={pwa.icons.peachRightArrow}/></UrlSet>}
                    </div>
                    <div className="img">
                        {section.settings.btn_url ? 
                        <UrlSet href={section.settings.btn_url}>
                        <Srcset alt={section.settings.title} src={section.settings.image} />
                        </UrlSet> : <Srcset alt={section.settings.title} src={section.settings.image} />}
                    </div>
                </div>
            </div>
    );
}
export default HomeImageWithTopText;