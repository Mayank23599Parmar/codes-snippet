import React from 'react';
import Srcset from '../../components/SrcSet';
import UrlSet from '../../components/UrlSet';
import { fetchProductTitle } from '../../components/Helper';
class HomeFeatureProduct extends React.Component{
    render(){
        const {section} = this.props;
        return(
            <div className="home-feature-product" id={`section_${section.sectionId}`}>
                <div className={section.settings.full ? '' :'container'}>
                    {section.settings.title && <h2 className="main-title">{section.settings.title}</h2>}
                    <ul className="flex-view-xs space">
                        {section.products.map((item,index)=>{
                            let actual_title = item.title;
                            let tagTitle = fetchProductTitle(item.tags);
                            if (tagTitle) {
                                actual_title = tagTitle;
                            }
                            let url = `products/${item.handle}`;
                            return(
                            <li key={item.id} className={`${section.settings.column_width} col-xs-12`}>
                                <div className="block-content">
                                    <div className="text">
                                        <h3 className="title">
                                            <UrlSet href={url}>{actual_title}</UrlSet>
                                        </h3>
                                        
                                        <h5 className="type">{item.type}</h5>
                                    </div>
                                        
                                    <div className="img">
                                    <UrlSet href={url}> <Srcset alt={item.title} src={item.featured_image} /></UrlSet>   
                                    </div>
                                    <UrlSet href={url} className="text-link">Know More <img className="icon-img" src={pwa.icons.peachRightArrow}/></UrlSet>
                                </div>
                            </li> 
                            )
                        })}
                    </ul>
                </div>
            </div>
        )
    }
}
export default HomeFeatureProduct;