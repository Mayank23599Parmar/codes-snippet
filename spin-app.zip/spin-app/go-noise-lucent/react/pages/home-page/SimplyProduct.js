import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import Srcset from '../../components/SrcSet';
import UrlSet from '../../components/UrlSet';
import VariantSelector from '../../components/VariantSelector';
import { connect } from 'react-redux';
import { addToCart } from '../../redux/cart/cartAction';
import { formatMoney,findDiscount,fetchProductTitle,showCartPopUp } from '../../components/Helper';
import {setCompareProduct} from '../../redux/support/supportAction';
import {ctaEvent, AddToBagCollectionCT, BuyNowCTCollection} from '../../clever-tap-events/AddToCartEvent'
import {notifyMeEvent} from '../../clever-tap-events/NotifyEvent'
// import {knowMore} from  '../../clever-tap-events/KnowButton'
import { showRecommendationCollectionProducts ,setRecomdationVariant,setCollectionProductArray} from '../../redux/collection/collectionAction';
import HtmlParser from 'react-html-parser';

class SimplyProduct extends Component {
  constructor(props) {
    super(props);
    this.ref = React.createRef();
    this.state = {
      selectedVariant: null,
      featured_image: ''
    }
   
  }
  addToCart = (product) =>{

    const { collectionRecommendationProducts } = this.props;
    if(this.state.selectedVariant.available === false){
      return;
    }
    const form = { id: parseInt(this.state.selectedVariant.id) ,quantity:1 }
    const data = {
      "type":"cart",
      form
    }
    // this.props.addToCart(data);
    this.props.addToCart({"type":"cart",form
    ,callback:()=>{
      if(product.frequntly_bought.length !== 0  && pwa.frequentlyEnable){
        var root = document.getElementsByTagName( 'html' )[0];
        document.body.classList.add('overflow-hidden');
        root.classList.add('overflow-hidden');
        document.body.style.height = "100%";
        root.style.height = "100%";
        this.props.setCollectionProductArray(product.frequntly_bought)
        this.props.setRecomdationVariant({masterProductImg:this.props.product.featured_image, variant:this.state.selectedVariant})
        this.props.showRecommendationProductsAction(true);
      }
    }
  });
  if(!pwa.frequentlyEnable){
    showCartPopUp(<div className="main-cart-pop-div"><div className="pop-up-image"><img src={this.state.selectedVariant.featured_image.src} alt="img" /></div><span className="pop-up-text">Added To Bag</span></div>, "top-right");
  }
    AddToBagCollectionCT(this.state.selectedVariant)
  }
  buyNow = (e) =>{
    if(this.state.selectedVariant.available === false){
      return;
    }
    const form = { id: parseInt(this.state.selectedVariant.id) ,quantity:1 }
    const data = {
      "type":"checkout",
      form
    }
    this.props.addToCart(data);
    BuyNowCTCollection(this.state.selectedVariant)
  }
  componentWillMount (){
    const { product } = this.props;
    const selectedVariant = product.selected_or_first_available_variant ? product.selected_or_first_available_variant : product.variants[0];
    const {featured_image} = selectedVariant;
    let src = product.featured_image;
    if(featured_image){
      src = featured_image.src;
    }
    if(selectedVariant){
        this.setState({ selectedVariant,featured_image:src})
    }else{
      this.setState({ featured_image:src })
    }
  }
  setSelectedVariant = (selectedVariant) =>{
    const {featured_image} = selectedVariant;
    let src = this.state.featured_image;
    if(featured_image.src){
      src = featured_image.src;
    }
    if(this.ref.current){
      let image = this.ref.current.querySelector('.product-img');
      image.setAttribute("srcset",src);
    }
    this.setState({selectedVariant,featured_image:src})
  }
  setCompareProduct = ()=>{
    const {product,history} = this.props;
    // this.props.setCompareProduct(product.id);
    history.push(`/pages/compare?product=${product.id}`);
  }
  render() {
    const {product,compareShow,showRecommendationProducts,collectionRecommendationProducts} = this.props;
    if(!product){
      return
    }
    const { variants, options, variantImages, avgRating } = product;
    const {selectedVariant,featured_image} = this.state;
    let { swatchTitleShow } = false;
    let actual_title = product.title;
    let tagTitle = fetchProductTitle(product.tags);
    if(tagTitle){
      actual_title = tagTitle;
    }
    let hasSalePrice = product.tags.find((tag)=>tag.includes('sale_'));
    // let hasdiscount = product.tags.find((tag)=>tag.includes('coupon_'));
    let uspData = product.tags.find((tag)=>tag.includes('USP_'));
    
    let phonePeCart = product.tags.includes("phonepe") ? true : false;
    let strapCompatible = product.tags.includes("strap-collection-usp") ? true : false;
    let usp = [];
    if (uspData){
      let uspTag = uspData.replace('USP_',' ');
      usp = uspTag.split('_');
    }
    
    let ptag = product.tags.find((tag)=>tag.includes('ptag_'));
    if(ptag){
      var productTag = ptag.replace('ptag_',' ');
    }

    let coming_soon = product.tags.find((tag)=>tag.includes('coming-soon'));

    let salePrice = 0 ;
    if(hasSalePrice){
      let salePriceTag=hasSalePrice.split('_');
      if(salePriceTag.length === 2){
        salePrice = parseInt(salePriceTag[1]);
      }
    }

    let vclass = "";
    let sold_out = false;
    let showBuyNow = false;
    //console.log(product.variants);
    product.variants.map(item =>{
      if(item.available === true){
        showBuyNow = true;
        return showBuyNow
      }
    })
    console.log('showbuynow',showBuyNow)
    if(!cn(selectedVariant)){
      if(!selectedVariant.available){
        sold_out = true;
      }
    }
    let defaultVariant = false;
    if(variants.length === 1){
      if(variants[0].title == 'Default Title'){
        defaultVariant = true;
      }
    }
 
    return (
      <>
      <div className={`product-main detail-${product.id}`}>
        <div className="image">
          {ptag && <div className="tag"><p>{productTag}</p></div> }
          <div className="relative img-cell">
            <div className="img" ref={this.ref}>
              <UrlSet className="product-link" href={`/products/${product.handle}`}>
                <Srcset alt={product.title} src={featured_image} className="product-img" />
                {pwa.switch_image &&
                  <Srcset alt={product.title} src={product.images[1]} className="img_blur alter_img"/>
                }
              </UrlSet>
            </div>
          </div>
        </div>
        <div className="productInfo_wrapper">
        <div className="text-wrapper">
          <h2 className="title">
            <UrlSet className="product-link" href={`/products/${product.handle}`}>
              <span className="product-title">{actual_title}</span>
            </UrlSet>
          </h2>
          <div className="product-price">
          <h5 className="price">{hasSalePrice && salePrice > 0 ? formatMoney(salePrice * 100)  : formatMoney(parseInt(selectedVariant.price))}</h5>
              {selectedVariant.compare_at_price && selectedVariant.compare_at_price > selectedVariant.price &&
              <p className="compare">
                {formatMoney(parseInt(selectedVariant.compare_at_price)).substring(1)}
              </p>}  
          </div>
         <div className="average-main">{avgRating && <div className="avgRating-wrapper"><div className="avgRating"><span className="jdgm-star jdgm--on"></span><p>{HtmlParser(avgRating)}</p></div></div>}</div>
        </div>
        {defaultVariant === false && 
        <div className={`variants-wrapper ${vclass}`}>
          {options.map((option, index) => {
            return (
              <ul className="swatch-wrap" key={index}>
                {swatchTitleShow ? (
                  <h3 className="swatch-title">{option}</h3>
                ) : null}
                {variants.map((variant) => {
                  return <VariantSelector
                    key={variant.id}
                    option={option}
                    selectedVariant={selectedVariant}
                    variantImages={variantImages}
                    variant={variant}
                    setSelectedVariant={()=>this.setSelectedVariant(variant)}
                  />;
                })}
              </ul>
            );
          })}
        </div>}
        <UrlSet className="" href={`/products/${product.handle}`}>
        {strapCompatible && <div className="compatible-wrapper"><p>Compatible</p></div>}
        <div className ="usp_wrapper">
           {usp.map((item,index)=><p className="usp" key={index}>{item}</p>)}
        </div>
        </UrlSet>
        <div className="compare_wrapper">{compareShow && <span className="text-compare" onClick={this.setCompareProduct}>Compare</span>}</div>
        <div className="text">
            {phonePeCart && 
            <div className="addtocart-wrap">
            {(sold_out ? (
            <button className="btn" name="cart" id="soldOut" onClick={this.addToCart}>
              <span data-text="Sold Out">Sold Out</span>
            </button>
            ) : (
            <button className="btn" name="cart" onClick={this.addToCart}>
              <span data-text="Add To Cart">Add To Cart</span>
            </button>
            ))}
            </div>
            }
              <div className="links clearfix">
              {!phonePeCart &&
               <div>
                 {(!sold_out ? (
                   <div className="cta-wrapper">
                     <p>{(showBuyNow)}</p>
                      <button className="cart-btn btn" name="cart" onClick={()=>this.addToCart(product)}>
                          <span data-text="Add To Cart">Add To Bag</span>
                      </button>
                      <button className="buy-now btn" name="cart" onClick={this.buyNow}>
                          <span data-text="Buy Now">Buy Now</span>
                      </button>
                   </div>
                    
              ) : (
                <>
                {( coming_soon ? (
                  <div className="cta-wrapper">
                  {/* <button className="btn sold-out-btn" name="cart" id="coming-soon">
                    <span className="product-title">Coming Soon</span>
                  </button> */}
                  <UrlSet id="coming-soon" className="btn coming-soon-btn" href={`/products/${product.handle}`}>Coming Soon</UrlSet>
                  </div>
                ) : (
                  <div className="cta-wrapper">
                  <button className="btn sold-out-btn" name="cart" id="soldOut">
                    <span className="product-title">Sold Out</span>
                  </button>
                  </div>
                ))}
                </>
              ))}
              {/*<UrlSet href={`/products/${product.handle}`} className="text-Know" onClick={()=>knowMore(product)}>Know more <img className="icon-img" src={pwa.icons.peachRightArrow}/></UrlSet>*/}
              {/* {compareShow && <span className="text-compare" onClick={this.setCompareProduct}>Compare <img className="icon-img" src={pwa.icons.plus}/></span>} */}
               </div>
              }
              

              </div>
            </div> 
         
        </div>
      </div>
 
    </>
    );
  }
}
const mapStateToProps = (state) => ({
  collectionRecommendationProducts: state.collection.collectionRecommendationProducts,

});
const mapDispatchToProps = dispatch => (
  {
    startCartFetch: value => dispatch(setCartStart(value)),
    addToCart : data => dispatch(addToCart(data)),
    setCompareProduct: id => dispatch(setCompareProduct(id)),
    showRecommendationProductsAction :(data) => dispatch(showRecommendationCollectionProducts(data)),
    setRecomdationVariant :(data) => dispatch(setRecomdationVariant(data)),
    setCollectionProductArray: data => dispatch(setCollectionProductArray(data)),
  }
)
export default withRouter(connect(mapStateToProps,mapDispatchToProps)(SimplyProduct));
