import React from 'react';
// import Slider from "react-slick";
import Srcset from '../../components/SrcSet';
// import UrlSet from '../../components/UrlSet';
import HtmlParser from 'react-html-parser'
const HomeIDCBanner = (props) => {
    const { section } = props;
    return (
        <div className="home-idc-banner" id={`section_${section.sectionId}`}>
            {/* <div className="slickSlider"> */}
            {/* <Slider {...settings}> */}
            <div className="container">
                <div className="left">
                    <div className="text">
                        <h2 className="title">{HtmlParser(section.settings.title)}</h2>
                        <h5 className="desc">{HtmlParser(section.settings.text)}</h5>
                    </div>
                    <div className="idc-img">
                        <Srcset alt={section.settings.title} src={section.settings.center_image} />
                    </div>
                </div>
                <div className="rohit-img">
                    <Srcset alt={section.settings.title} src={section.settings.image} />
                </div>
            </div>
            {/* </Slider> */}
            {/* </div> */}
        </div>
    );
}
export default HomeIDCBanner;