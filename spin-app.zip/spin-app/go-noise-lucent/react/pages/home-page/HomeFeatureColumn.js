import React from 'react';
import Srcset from '../../components/SrcSet';
import UrlSet from '../../components/UrlSet';
import HtmlParser from 'react-html-parser'
import {knowMoreHome, knowMoreImageHome} from  '../../clever-tap-events/KnowButton'

class HomeFeatureColumn extends React.Component{
    render(){

        const {section} = this.props;
        const spin=document.getElementById("wheelio2-app-cointainer");
        setTimeout(()=>{console.log(spin,"spin");},3000)
        
        return(
        <div className="home-feature-column" id={`section_${section.sectionId}`}>
                <div className={section.settings.full ? '' :'container'}>
                    <div className="flex-view-xs">
                        {section.blocks.map((item,index)=>{
                            return(
                            <div className={`col-sm-6 col-xs-12`} key={section.blocksId[index]}>
                                <div className="block-content">
                                    <div className="text">
                                    <h2 className="title">{item.title}</h2>
                                    <h5 className="desc">{HtmlParser(item.text)}</h5>
                                    {item.btn_text && item.btn_url && <UrlSet href={item.btn_url} className="text-link" onClick={()=>knowMoreHome(item)}>{item.btn_text}<img className="icon-img" src={pwa.icons.peachRightArrow} /></UrlSet>}
                                    </div>
                                    <div className="img">
                                        {item.btn_url ? 
                                        <UrlSet href={item.btn_url} onClick={()=>knowMoreImageHome(item)}>
                                        <Srcset alt={item.title} src={item.image} />
                                        </UrlSet> : <Srcset alt={item.title} src={item.image} />}
                                    </div>
                                </div>
                            </div> 
                            )
                        })}
                    </div>
                </div>
            </div>
        )
    }
}
export default HomeFeatureColumn;