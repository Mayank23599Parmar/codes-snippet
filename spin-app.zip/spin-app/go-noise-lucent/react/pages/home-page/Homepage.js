import React from "react";
import HomeSlideshow from './HomeSlideshow';
import HomeImageWithTopText from './HomeImageWithTopText';
import HomeFeatureColumn from './HomeFeatureColumn';
import HomeFeatureProduct from './HomeFeatureProduct';
import HomeVideo from '../home-page/HomeVideo'
import HomeIDCBanner from './HomeIDCBanner'
import HomeInThePress from './HomeInThePress';
import HomeStories from './HomeStories';

// Extra general component
import TrustBatches from '../../components/TrustBatches';
import Newsletter from '../../components/Newsletter';
import FooterHomepage from '../../components/Footer/FooterHomepage';

class Homepage extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      homePageData : []
    }
  }
  // componentDidMount(){
  //   this.sethomepageData();
  // }
  // sethomepageData = async() =>{
      
  //     this.setState({ homePageData: dataJson});
  // }
  render() { 
    const homepagehtml = document.getElementsByClassName("section-data");
      let dataJson = [];
      Array.prototype.forEach.call(homepagehtml, (el)=> {
          let obj = {};
          obj.type = el.getAttribute('data-type');
          obj.data = JSON.parse(el.innerHTML);
          dataJson.push(obj);
      });
    return (
      <div className="home-page">
        {dataJson.length > 0 ?
          dataJson.map((item, index) => {
            switch(item.type) {
              case "home-slideshow":
                return <HomeSlideshow key={item.data.sectionId} section={item.data}/>;
              case "home-idc-banner":
                  return <HomeIDCBanner key={item.data.sectionId} section={item.data}/>;
              case "home-feature-column":  
                return <HomeFeatureColumn key={item.data.sectionId} section={item.data}/>;
              case "home-feature-product" :
                return <HomeFeatureProduct key={item.data.sectionId} section={item.data}/>;
              case "home-image-with-top-text" :
                return <HomeImageWithTopText key={item.data.sectionId} section={item.data}/>;
              case "home-video" :
                return <HomeVideo key={item.data.sectionId} section={item.data}/>;
              case "home-in-the-press":
                return <HomeInThePress key={item.data.sectionId} section={item.data} />;
              case "home-stories":
                return <HomeStories key={item.data.sectionId} section={item.data} />;
              default: return '';
            }
        })
        : null }
        <TrustBatches />
        <Newsletter />
        <FooterHomepage isHome={true} />
      </div>
    );
  }
}
export default Homepage;
