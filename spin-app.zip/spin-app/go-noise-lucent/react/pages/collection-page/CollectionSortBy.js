import React from 'react';
/* Comp imports */
import { sortBy } from '../../Settings';
class CollectionSortBy extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      sort : 'manual'
    }
  }
  componentDidMount(){
    let { sort_query } = this.props;
    if(cn(sort_query)){
      sort_query = 'manual';
    }
    this.setState({ sort: sort_query });
  }
  changeSortBy = (e) => {
    let currentVal = e.currentTarget.value;
    this.setState({ sort: currentVal }, () => {
      this.setSortBy();
    });
  }
  setSortBy = () => {
    let { collection } = this.props;
    let { sort } = this.state;
    let url;
    if (sort) {
        url = `/collections/${collection.info.handle}?sort_by=${sort}`;
    } else {
        url = `/collections/${collection.info.handle}`;
    }
    this.props.history.push(url);
  }
  render() {
    const { sort } = this.state;

    return (
      <div className="collections-select">
        <div className="product-count">
          
            
          {/* if collection product is heigher then display product then show collection product value in number else show display product value in number */}
          Showing 1 – {this.props.toProducts > this.props.collection.products.length?this.props.collection.products.length:this.props.toProducts} products of {this.props.collection.products.length} products
        </div>
        <div className='sort-dropdown'>
          <p className='sort-by-title'>Sort By : </p>
          <div className="sort-select-wrap">
            <select name="sortBy" value={sort} className="sort-select" onChange={this.changeSortBy}>
              {sortBy &&
              sortBy.map((item,index)=>{
                  return (<option value={item.sort_query} key={index}>{item.title}</option>)
              })
              }
            </select>
          </div>
        </div>
      </div>
    );
  }
}
export default CollectionSortBy;