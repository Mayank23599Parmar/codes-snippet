import React, { Component } from 'react';
import { connect } from 'react-redux';
import SimplyProductSale from '../home-page/SimplyProductSale';
import CollectionSortBy from './CollectionSortBy';
import SortBy from './SortBy';

class CollectionTemplateSale extends Component {

    constructor(props) {
        super(props)
        this.state = {
            showproducts: props.collectionData.collectionInfo.productPerPage,
            isShowSortBy: false,
            isSwatch: false
        }
    }


    loadmore = () => {
        const { collectionData, } = this.props;
        let collection = collectionData.collectionInfo;
        let { products } = collection;
        let nextloadmore = this.state.showproducts + collection.productPerPage;
        if (nextloadmore > products.length) {
            nextloadmore = products.length
        }
        this.setState({ showproducts: nextloadmore })
    }

    showSwatch = () => {
        this.setState({ isSwatch: true })
    }

    hideSwatch = () => {
        this.setState({ isSwatch: false })
    }

    onSortBy = () => {
        this.setState({ isShowSortBy: true })
    }

    onCloseSortBy = () => {
        this.setState({ isShowSortBy: false })
    }

    onFilter = () => {

    }

    render() {
        const { collectionData, collection_url, sort_query } = this.props;
        let collection = collectionData.collectionInfo;
        let { products } = collection;
        if (!collectionData) {
            return false;
        }
        let compareShow = false;
        if (collection.info.handle === 'bestsellers-noisefit-app' || collection.info.handle === 'smart-watches' || collection.info.handle === 'smart-wearables' || collection.info.handle === 'wireless-earbuds' || collection.info.handle === 'bluetooth-earphones' || collection.info.handle === 'bluetooth-headphones' || collection.info.handle === 'wireless-audio') {
            compareShow = true;
        }
        return (
            <div className='collection-template collection-template-sale'>
                <div className="container">
                    {/* <div className="">
                        <CollectionSortBy toProducts={this.state.showproducts} collection={collection} collection_url={collection_url} history={this.props.history} sort_query={sort_query} />
                    </div> */}
                    <div className="collection-list">
                        <ul className="list flex-view-xs" ref={this.ref}>
                            {products &&
                                products.slice(0, this.state.showproducts).map((product, index) => {
                                    return (
                                        <li className='col-md-4 col-sm-12 col-xs-12' key={product.id} onMouseEnter={(e) => this.showSwatch(e)} onMouseLeave={(e) => this.hideSwatch(e)}>
                                            <SimplyProductSale product={product} compareShow={compareShow} />
                                        </li>
                                           )  
                                })
                            }
                        </ul>
                    </div>
                    
                    {
                        products.length > this.state.showproducts &&
                        <div className='load-btn'>
                            <button onClick={this.loadmore}>
                                Load more
                        </button>
                        </div>
                    }
                </div>
                <div className="bottom-container">
                    <div className="left" onClick={this.onSortBy}>
                        <img src={pwa.icons.sort_by} alt="sortBy" />
                        <span className="text">Sort By</span>
                    </div>
                    <div className="right" onClick={this.onFilter}>
                        <img src={pwa.icons.filter} alt="filter" />
                        <span className="text">Filter</span>
                    </div>
                </div>

                {this.state.isShowSortBy ?
                    <div className="sort-by-model">
                        <SortBy
                            toProducts={this.state.showproducts}
                            collection={collection}
                            collection_url={collection_url}
                            history={this.props.history}
                            sort_query={sort_query}
                            onClose={this.onCloseSortBy} />
                    </div>
                    : null
                }
            </div>
        );
    }
}
const mapStateToProps = state => (
    {
        collectionData: state.collection
    }
)
export default connect(mapStateToProps, null)(CollectionTemplateSale);