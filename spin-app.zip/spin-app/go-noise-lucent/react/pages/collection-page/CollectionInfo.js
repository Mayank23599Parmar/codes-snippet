import React, { Component } from 'react';
import { connect } from 'react-redux';
import HtmlParser from "react-html-parser";
import UrlSet from '../../components/UrlSet';

class CollectionInfo extends Component {
  render() {
    const { collectionInfo } = this.props.collectionData;
    if(!collectionInfo.info){
        return false;
    }
    const {info} = collectionInfo;
    return (
    <div className='collection-info'>
        <div className={`container col-${info.handle}`}>
            <div className="breadcrumb">
                <UrlSet href="/">Home</UrlSet>
                {/* <span className="separator"><img src={pwa.icons.blackRightArrow} alt="arrow"/></span> 
                <span className="sub-title">Collections </span> */}
                <span className="separator"><img src={pwa.icons.blackRightArrow} alt="arrow"/></span> 
                <span className="page-title">{info.title}</span>
            </div>
            <div className="collection-title hide">
                <h1 className="title">{info.title}</h1>
                <p className="desc">{HtmlParser(info.body_html)}</p>
            </div>
        </div>
    </div>
    );
  }
}
const mapStateToProps = state => (
    {
      collectionData: state.collection
    }
)
export default connect(mapStateToProps)(CollectionInfo);