import React, { Component } from 'react';
import { connect } from 'react-redux';
import { startCollection} from '../../redux/collection/collectionAction';
import Loading from '../../components/loader/loader';
import CollectionInfo from './CollectionInfo';
import CollectionTemplate from './CollectionTemplate';
import CollectionTemplateSale from './CollectionTemplateSale';
import TrustBatches from '../../components/TrustBatches';
import Newsletter from '../../components/Newsletter';
import CategoryContent from '../../components/CategoryContent';
import CollectionBanner from './CollectionBanner'
import ErrorPage from "../errorpage/ErrorPage";
import {getHeaderHeight} from '../../components/Helper';


class CollectionPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      errorPage : false
    }
  }

  componentDidMount() {
      this.init();   
  }
  init = () => {
    // To fetch collection Data
    let { startCollection} = this.props;
    let collection_handle = this.props.match.params.collectionHandle;
    let url;
    const query = new URLSearchParams(this.props.history.location.search);
    const sort_query = query.get('sort_by');
    if (sort_query) {
      url = `/collections/${collection_handle}?view=react&sort_by=${sort_query}`
    } else {
      url = `/collections/${collection_handle}?view=react`
    }
    startCollection(url);
  }
  render() {
    if (this.props.collectionData.errorPage) {
      return <ErrorPage show={true} />;
    }
   
 
    let collection_handle = this.props.match.params.collectionHandle;
    let salhandle = collection_handle === "noise-anniversary-days-sale" ? true : false;
    console.log('collection_handle------>',collection_handle,salhandle);
    const query = new URLSearchParams(this.props.history.location.search);
    const collection_url = this.props.match.url;
    const sort_query = query.get('sort_by');
    const { collectionData} = this.props;
    let { loading } = collectionData;
    const headerHeight = getHeaderHeight();
    let Style={height: `calc(100vh - ${headerHeight}px)`};
    if (loading) {
      return <div className='collection-page' style={Style}><Loading /></div>;
    }
    if(salhandle){
      return(
        <div className='collection-page'>
          <CollectionBanner collection_handle={collection_handle} />
          <CollectionTemplateSale history={this.props.history} collection_url={collection_url} sort_query={sort_query}/>
        </div>
      )
    }else{
      return (
        <div className='collection-page'>
          <CollectionBanner collection_handle={collection_handle} />
          <CollectionInfo />
          <CollectionTemplate history={this.props.history} collection_url={collection_url} sort_query={sort_query}/>
          <CategoryContent collectionData={collectionData} />
          <TrustBatches />
          <Newsletter />
        </div>
      );
    }
  }
}
const mapStateToProps = state => (
  {
    collectionData: state.collection,
  }
)
const mapDispatchToProps = dispatch => (
  {
    startCollection: handle => dispatch(startCollection(handle))
  }
)
export default connect(mapStateToProps, mapDispatchToProps)(CollectionPage);
