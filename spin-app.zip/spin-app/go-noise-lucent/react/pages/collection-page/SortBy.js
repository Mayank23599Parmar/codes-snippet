import React from 'react';
/* Comp imports */
import { sortBy } from '../../Settings';

class SortBy extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      sort: 'manual'
    }
  }
  componentDidMount() {
    let { sort_query } = this.props;
    if (cn(sort_query)) {
      sort_query = 'manual';
    }
    this.setState({ sort: sort_query });
  }
  changeSortBy = (e) => {
    console.log('e===>', e)
    let currentVal = e//.currentTarget.value;
    this.setState({ sort: currentVal }, () => {
      this.setSortBy();
    });
  }
  setSortBy = () => {
    let { collection } = this.props;
    let { sort } = this.state;
    let url;
    if (sort) {
      url = `/collections/${collection.info.handle}?sort_by=${sort}`;
    } else {
      url = `/collections/${collection.info.handle}`;
    }
    this.props.history.push(url);
  }
  render() {
    const { sort } = this.state;
    return (
      <div className="sort-container">
        <div className="head">
          <div className="left-title" >
            <img src={pwa.icons.sort_by} alt="sortBy" />
            <span className='sort-by-title'>Sort By</span>
          </div>
          <span className="close-icon" onClick={this.props.onClose}>
            <img src={pwa.icons.close} alt="close" />
          </span>
        </div>
        <div className="main-options">
          {sortBy && sortBy.map((item, index) => {
            return (
              <div className={"sort-item"} onClick={() => this.changeSortBy(item.sort_query)}>
                {sort == item.sort_query ?
                  <div className="selected">
                    <div className="dot"></div>
                  </div>
                  :
                  <div className="unselected"></div>
                }
                <span value={item.sort_query} key={index} className='option-text'>{item.title}</span>
              </div>
            )
          })
          }
        </div>
        {/* <div className="bottom-wrap">
          <div className="left">
            <div className="close-wrap" onClick={this.props.onClose}>
              <span className="close-text">Close</span>
            </div>
          </div>
          <div className="right">
            <div className="apply-wrap" onClick={this.onFilter}>
              <span className="apply-text">Apply</span>
            </div>
          </div>
        </div> */}
      </div>
    );
  }
}
export default SortBy;