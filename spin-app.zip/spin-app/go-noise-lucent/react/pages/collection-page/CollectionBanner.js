import React, { Component } from 'react';
import { connect } from 'react-redux';

/* Comp imports */
import MediaQuery from '../../components/MediaQuery';
import Srcset from '../../components/SrcSet';
import HtmlParser from 'react-html-parser'
class CollectionBanner extends Component {
  render() {
    let image, image_mob, banner_title, banner_sub_title, c_width;
    const { collectionData,collection_handle } = this.props;
    const { bannerData } = collectionData;
    if (!bannerData) {
      return null;
    } else {
      c_width = bannerData.settings.full;
      bannerData.blocks.map((item, index) => {
        if (item.collection == collection_handle) {
          image = item.image;
          image_mob = item.image_mob;
          banner_title = item.banner_title;
          banner_sub_title = item.banner_sub_title;
        }
      });
      if (!image) {
        image = bannerData.settings.image;
      }
      if (!image_mob) {
        image_mob = bannerData.settings.image_mob;
      }
      if(!banner_title){
        banner_title = '';
      }
      if(!banner_sub_title){
        banner_sub_title = '';
      }
    }
    return (
      <div id="collection_image" className={collection_handle}>
        <div className={c_width ? '' : 'container'}>
          <div className="text-area">
                  <div className="text-wrapper">
                  {banner_title &&
                      <h1 className="color-white">{HtmlParser(banner_title)}</h1>
                  }
                  <p className="color-white"></p>
                  {banner_sub_title &&
                      <h2 className="color-white">{HtmlParser(banner_sub_title)}</h2>
                  }
                  </div>
          </div>
          <div className="collection_img">
            {image &&
              <MediaQuery query="tablet-and-up">
                <div className="img">
                  <Srcset alt={collection_handle} src={image} />
                </div>
              </MediaQuery>
            }
            {image_mob &&
              <MediaQuery query="phone">
                <div className="mobile-img">
                  <Srcset alt={collection_handle} src={image_mob} />
                </div>
              </MediaQuery>
            }
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => (
  {
    collectionData: state.collection
  }
)
export default connect(mapStateToProps)(CollectionBanner);