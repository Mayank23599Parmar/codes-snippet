import React, { Component } from "react";
import { connect } from "react-redux";
import HtmlParser from "react-html-parser";
import { dateFormatter } from "../../components/Helper";
import UrlSet from "../../components/UrlSet";
import Srcset from "../../components/SrcSet";
import { FacebookShare, PinterestShare, TwitterShare, GoogleShare } from '../../components/SocialSharing';
export class ArticleTemplate extends Component {
  state={
    articelNewData:""
  }

  componentDidMount(){
    this.setState({articelNewData:this.props.articleData.articleData})
  }
  componentDidUpdate(prevProps, prevState) {
    if(prevProps.articleData.articleData.title != this.props.articleData.articleData.title){
      this.setState({articelNewData:this.props.articleData.articleData})
    }
  }
  render() {

    if (Object.keys(this.props.articleData).length === 0) {
      return false;
    }
    const {
      body_html,
      published_at,
      title,
      image,
    } = this.state.articelNewData;
    const { socialUrl, articleData } = this.props;
    let shuffled = articleData.moreArticles.sort(function () { return .5 - Math.random() });
    let selected = shuffled.slice(0, 3);
    let moreArtciles = selected.map((article, index) => {
      const { subArticleUrl, articleJson } = article;
      let src = '';
      if (!cn(articleJson.image)) {
        src = articleJson.image.src;
      }
      return <li key={index} className='col-sm-4'>
        <UrlSet href={subArticleUrl}>
          <div className='story' >
            <div className='image'>
              <Srcset src={src} />
            </div>
            <div className='info'>
              <p className='feature'>Feature</p>
              <p className='more-title'>{articleJson.title}</p>
              <p className='date'>{dateFormatter(articleJson.published_at)}</p>
            </div>
          </div>
        </UrlSet>
      </li>
    })
    return (
      <div className="article-template">
        <div className="container">
          <div className="article-container">
            <div className="page-head">
              <p className="time">{dateFormatter(published_at)}</p>
              <h3 className="title">{title}</h3>
            </div>
            <div className="social-icons flex-view-xs center">
              <div className='col-sm-3 col-xs-3'>
                <div className="icon" onClick={() => FacebookShare(socialUrl)}>
                  <Srcset src={pwa.icons.socialIcons.facebook} />
                </div>
              </div>
              <div className='col-sm-3 col-xs-3'>
                <div className="icon" onClick={() => PinterestShare(socialUrl, title, image.src)}>
                  <Srcset src={pwa.icons.socialIcons.pinterest} />
                </div>
              </div>
              <div className='col-sm-3 col-xs-3'>
                <div className="icon" onClick={() => TwitterShare(socialUrl, title)}>
                  <Srcset src={pwa.icons.socialIcons.twitter} />
                </div>
              </div>
              <div className='col-sm-3 col-xs-3'>
                <div className="icon" onClick={() => GoogleShare(socialUrl)}>
                  <Srcset src={pwa.icons.socialIcons.link} />
                </div>
              </div>
            </div>
            <div className="page-content">{HtmlParser(body_html)}</div>
            <div className="social-icons left flex-view-xs center">
              <div className='col-sm-3 col-xs-3'>
                <div className="icon" onClick={() => FacebookShare(socialUrl)}>
                  <Srcset src={pwa.icons.socialIcons.facebook} />
                </div>
              </div>
              <div className='col-sm-3 col-xs-3'>
                <div className="icon" onClick={() => PinterestShare(socialUrl, title, image.src)}>
                  <Srcset src={pwa.icons.socialIcons.pinterest} />
                </div>
              </div>
              <div className='col-sm-3 col-xs-3'>
                <div className="icon" onClick={() => TwitterShare(socialUrl, title)}>
                  <Srcset src={pwa.icons.socialIcons.twitter} />
                </div>
              </div>
              <div className='col-sm-3 col-xs-3'>
                <div className="icon" onClick={() => GoogleShare(socialUrl)}>
                  <Srcset src={pwa.icons.socialIcons.link} />
                </div>
              </div>
            </div>

            <div className='more-stories' >
              <h3>More Stories</h3>
              <ul className='stories flex-view' >
                {moreArtciles}
              </ul>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  articleData: state.article.articleData,
  loading: state.article.articleLoading,
});

export default connect(mapStateToProps, null)(ArticleTemplate);
