import React, { Component } from "react";
import { connect } from "react-redux";
import { fetchArticle,startArticleLoading } from "../../redux/article/articleActions";
import ArticleTemplate from "./ArticleTemplate";
import UrlSet from '../../components/UrlSet';
import {getHeaderHeight,checkErrorPage} from '../../components/Helper';
import ErrorPage from '../errorpage/ErrorPage';
import Loader from '../../components/loader/loader';
export class ArticlePage extends Component {
  componentDidMount() {
    this.init ();
  }
  async init (){
    let blog_handle = this.props.match.params.blogHandle;
    let article_handle = this.props.match.params.articleHandle;
    let query = blog_handle + "/" + article_handle;
    // await this.props.fetchArticle(query);
    // this.props.startArticleLoading(true);
    this.props.fetchArticle({
      query:query,
    callback:()=>{
      this.props.startArticleLoading(true)
    }
    
    
    });

  }
 componentDidUpdate(prevProps,prevState){
    if (this.props.match.params.articleHandle != prevProps.match.params.articleHandle) {
     
      let blog_handle = this.props.match.params.blogHandle;
      let article_handle = this.props.match.params.articleHandle;
      let query = blog_handle + "/" + article_handle;
      this.props.fetchArticle({
        query:query,
      callback:()=>{
        this.props.startArticleLoading(true)
      }
      
      
      });
    }
  }
  render() {
    let blog_handle = this.props.match.params.blogHandle;
    let article_handle = this.props.match.params.articleHandle;
    let socialUrl = `${window.shopObj.url}/blogs/${blog_handle}/${article_handle}`;
    const headerHeight = getHeaderHeight();
    let loading = this.props.loading;
    let Style = {};
    if(loading){
      Style={
        height: `calc(100vh - ${headerHeight}px)`
      }
    }
    if (loading) {
      return <div className="article-loader relative" style={Style}><Loader /></div>;
    }
    const pageStatus = checkErrorPage(window.location.href);
    if (pageStatus) {
      return <ErrorPage show={true} />;
    }
    return (
      <div id="article-page">
        <div className="normal-support-head">
          <div className="container">
            <div className="normal-support-head-container">
              <UrlSet href="/">Home</UrlSet>
              <span>
                <span className="arrow down"></span>
                <UrlSet href="/pages/stories">Stories</UrlSet>
                <span>
                  <span className="arrow down"></span>
                  <span>Article</span>
                </span>
              </span>
            </div>
          </div>
        </div>

        <ArticleTemplate socialUrl={socialUrl}/>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  loading: state.article.articleLoading,
});
const mapDispatchToProps = (dispatch) => ({
  fetchArticle: (handle) => dispatch(fetchArticle(handle)),
  startArticleLoading: (data) => dispatch(startArticleLoading(data))
});
export default connect(mapStateToProps, mapDispatchToProps)(ArticlePage);
