import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import Srcset from "../../components/SrcSet";
import MediaQuery from "../../components/MediaQuery";

class Ultraswappablestrap extends Component {
    render() {
        const { ultra_waterproof} = this.props;
        
    
        return (
          <div>
             
              <div className="Ultra-app-slider ultra-menstural ultra-waterproof ultra-swap">
              <div className="containers">
              <div className="slider-element">
              <div className="flex-view">
                
                <div className='text-area col-sm-6'>
                  <div className='text'>
                    <h3>Swappable straps</h3>
                    <p className='color-white'>Choose from a wide gamut of <br/>versatile straps to mix, match and <br/>style your smartwatch.</p>
                  </div>
                </div>
                <div className='image-area col-sm-6'>
                  <div className='img'>
                  <MediaQuery query='phone-and-tablet'>
                   
                  <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/multiple_straps.jpg?v=1626210435' />
                   
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                   
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/15.png?v=1626248645' />
                   
                  </MediaQuery>
                  </div>
                </div>
                
                
                
              </div>
            </div>
              </div>
            </div>
                
              
          </div>
        );
      }
}

export default Ultraswappablestrap;
