import React from "react";
/* Redux */
import { connect } from "react-redux";
/* Actions */
import {setVariant} from '../../redux/product/productAction';
/* helper */
import { queryString } from '../../components/Helper';
/* Comp imports */
import Loading from "../../components/loader/loader";
import ProductBar from './ProductBar';
// import ErrorPage from "../errorpage/ErrorPage";
import ProductSlider from './ProductSlider';
import ActiveRoundWatch from './ActiveRoundWatch';
import ActiveFourWatchSection from './ActiveFourWatchSection';
import ActiveSportsMode from './ActiveSportsMode';
import ActiveLiveMindfully from './ActiveLiveMindfully';
import ActiveLiveConnected from './ActiveLiveConnected';
class ActiveTemplate extends React.Component {
  constructor(props) {
    super(props)
    this.prodRef = React.createRef();
    this.featureRef = React.createRef();
    this.state = {
      showBar: false
    }
  }

  componentDidMount() {
    window.addEventListener('scroll', this.handleScroll);
    const { setVariant, productData } = this.props;
    let queryStringsData = queryString(location.href);
    // if(productData.product){
    //   if(queryStringsData.variant){
    //     let passVariant = productData.product.variants.find((vari)=>{
    //       return vari.id === parseInt(queryStringsData.variant.value);
    //     })
    //     if(passVariant){
    //       setVariant(passVariant);
    //     }
    //   }
    //   else{
    //     queryStringVariant(productData.variant);
    //   }
    // }
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.handleScroll);
  }

  handleScroll = (event) => {
    let productSection = this.prodRef.current;
    let featureSection = this.featureRef.current;
    if(window.pageYOffset <= featureSection.offsetTop && (window.pageYOffset + 100)  > productSection.offsetTop ){
      this.setState({showBar: false})
    }
    else{
      this.setState({showBar: true})
    }
  }

  render() {
    const { metafields, loading, product, compareProducts } = this.props.productData;
    const { showBar } = this.state
    if (loading) {
      return <Loading />;
    }
    // const pageStatus = checkErrorPage(window.location.href);
    // if (pageStatus) {
    //   return <ErrorPage show={true} />;
    // }
    if(cn(metafields)){
      return(
        <div>
        {showBar && <ProductBar prodRef={(this.prodRef)} />}
        <div ref={this.prodRef}><ProductSlider metaData={metafields} /></div>
        </div>
      )
    }

    return (
      <div>
        <ProductBar prodRef={(this.prodRef)} />
        <div ref={this.prodRef}><ProductSlider metaData={metafields} /></div>
        {metafields.active_round_image && <ActiveRoundWatch active_round_image={metafields.active_round_image} />}
        {metafields.Active_Four_Watch && <ActiveFourWatchSection Active_Four_Watch={metafields.Active_Four_Watch} />}
        {metafields.Active_Sports_Mode && <ActiveSportsMode Active_Sports_Mode={metafields.Active_Sports_Mode} />}
        {metafields.Active_Live_Mind && <ActiveLiveMindfully Active_Live_Mind={metafields.Active_Live_Mind} />}
        {metafields.Active_Live_Connect && <ActiveLiveConnected Active_Live_Connect={metafields.Active_Live_Connect} />}
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  productData: state.product,
});
const mapDispatchToProps = dispatch => ({
  setVariant: variant => dispatch(setVariant(variant))
});
export default connect(mapStateToProps,mapDispatchToProps)(ActiveTemplate);
