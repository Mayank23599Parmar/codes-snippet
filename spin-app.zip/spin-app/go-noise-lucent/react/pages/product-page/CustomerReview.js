import React, { Component } from 'react';
import HtmlParser from 'react-html-parser';
import Slider from "react-slick";
import Srcset from '../../components/SrcSet';
class CustomerReview extends Component {
  render() {
    let { customer_review } = this.props;
    if(!customer_review.title){
      return false;
    }
    let centerModeOn;
    if(screen.width < 768){
      centerModeOn = true;
    }
    else{
      centerModeOn = false 
    }
    let settings = {
      dots: false,
      arrows:true,
      infinite: true,
      speed: 500,
      centerMode: centerModeOn,
      slidesToShow: 2,
      slidesToScroll: 1,
      nextArrow:<span><img src="https://cdn.shopify.com/s/files/1/0997/6284/files/icons8-more-than-48.png?v=1606242875" style={{width: '50px',margin: '7px 9px'}} alt='next-arrow'/></span>,
      prevArrow:<span><img src="https://cdn.shopify.com/s/files/1/0997/6284/files/icons8-less-than-48.png?v=1606242875" style={{width: '50px',margin: '7px 5px'}} alt='prev-arrow'/></span>,
      responsive: [
        {
          breakpoint: 767,
          settings: {
            arrows: false,
            slidesToShow: 1,
            centerMode: true
          }
        }
      ]
    };
    let items = [];
    for(let i = 1 ; i < 10 ; i++ ){
      let author = customer_review["author_"+i];
      let profile_img = customer_review["profile_img_"+i];
      let desc = customer_review["content_"+i];
      let followers = customer_review["followers_"+i];
      if(author && profile_img && desc && followers){
        let content = <li className="customer-review-li" key={i}>
                        <div className="customer-inner-wrap background-white">
                          <div className="img">
                            <img src="https://cdn.shopify.com/s/files/1/0997/6284/files/group-5_2x_1335ddc0-8e29-4d52-b350-91af8e3a0b51.png?v=1604923514" alt="curl-icon"/>
                          </div>
                          <div className="text-content">
                            <p>{desc}</p>
                          </div>
                          <div className="bottom-section-wrap">
                            <div className="profile-img">
                              <img src={profile_img} alt={author}/>
                            </div>
                            <div className="profile-text">
                              <p className="author-name">{author}</p>
                              <p className="author-followers">{followers}</p>
                            </div>
                          </div>
                        </div>
                      </li>;
        items.push(content);
      }else{
        break;
      }
    }
    return (
    <div className="customer-review-section background-black">
      <div className="container">
        <div className="customer-review-inner">
          <div className="header-wrap">
          {customer_review.title &&
            <h2 className="title color-white text-center">{customer_review.title}</h2>
          }
          {customer_review.sub_title &&
            <h5 className="sub-title color-white text-center">{customer_review.sub_title}</h5>
          }
          </div>
          <div className="slickSlider">
            <ul className="slider-ul">
              <Slider {...settings}>
                {items && items}
              </Slider>
            </ul>
          </div>
        </div>	
      </div>
    </div>
    );
  }
}


export default CustomerReview;