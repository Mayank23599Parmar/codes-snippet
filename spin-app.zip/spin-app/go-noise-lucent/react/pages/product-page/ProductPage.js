import React, { Component } from 'react';
/* Redux */
import { connect } from 'react-redux';
import { fetchProduct,fetchRelatedProducts,showRecommendationProducts } from '../../redux/product/productAction';
import ColorFitPro3Template from './color-fit-pro-3/colorFitPro3Template';
import ColorFitPro3AssistTemplate from './colorfit-assist/ColorFitPro3AssistTemplate';
// import SoloLeadgen from './solo-leadgen/SoloLeadgen'
import BudsSoloProduct from './solo-leadgen/BudsSoloProduct';
import BudsPlay from './Budsplay';
import NoiseActiveProductMain from './NoiseActive.js/NoiseActiveProductMain';
// import ActiveTemplate from './ActiveTemplate';
import FlairNeckband from './FlairNeckband';
import NavPlus from './NavPlus';
import Qube from './Qube';
import Ultra from './Ultra';
/*Clevertap events*/
// import { productClickEvent } from '../../clever-tap-events/ProductPageEvents';

import {getHeaderHeight} from '../../components/Helper';
/* Comp imports */
import ProductTemplate from './ProductTemplate';
import PulseTemplate from './PulseTemplate';
import Loading from "../../components/loader/loader";

class ProductPage extends Component {
 componentDidMount() {
  this.init();
 }
 init = () => {
  // To fetch collection Data
  let { fetchProduct } = this.props;
  let product_handle = this.props.match.params.productHandle;
  if(product_handle === 'noise-colorfit-pro-3-full-touch-control-smart-watch' || product_handle === 'noise-colorfit-pro-3-full-touch-control-smart-watch-phonepe' || product_handle === 'noise-colorfit-pro-3-full-touch-control-smart-watch-partner-exclusive'){
    fetchProduct(`${product_handle}?view=color-fit-pro-3`);
  }else{
    fetchProduct(`${product_handle}?view=react`);
  }
  // this.props.showRecommendationProductsAction(false);
  document.body.classList.remove('overflow-hidden');
 };
  componentDidUpdate(){
    const { productData,fetchRelatedProducts } = this.props;
    const { product,relatedProducts } = productData;
    if(!product){
      return null;
    }
  }
 getProduct = () =>{
    let handle = this.props.match.params.productHandle;
    switch(handle) {
        case 'noise-colorfit-pro-3-assist-smart-watch-with-alexa-built-in':
          return <ColorFitPro3AssistTemplate history={this.props.history} />
          break;
        case 'noise-colorfit-pro-3-full-touch-control-smart-watch':
          return <ColorFitPro3Template history={this.props.history} />
          break;
        case 'noise-colorfit-pro-3-full-touch-control-smart-watch-phonepe':
          return <ColorFitPro3Template history={this.props.history} />
          break;
        case 'noise-colorfit-pro-3-full-touch-control-smart-watch-partner-exclusive':
          return <ColorFitPro3Template history={this.props.history} />
          break;
        case 'noise-buds-solo-active-noise-cancellation-truly-wireless-earbuds':
          return <BudsSoloProduct history={this.props.history} />
          break;
        case 'noise-buds-solo-active-noise-cancellation-truly-wireless-earbuds-partner-exclusive':
          return <BudsSoloProduct history={this.props.history} />
          break;
        case 'noise-buds-play-truly-wireless-earbuds':
          return <BudsPlay history={this.props.history} />
          break;
        case 'noise-buds-play-truly-wireless-earbuds-partner-exclusive':
          return <BudsPlay history={this.props.history} />
          break;
        case 'noisefit-active-smartwatch':
          return <NoiseActiveProductMain history={this.props.history} />
          break;
        case 'noisefit-active-smartwatch-partner-exclusive-2':
          return <NoiseActiveProductMain history={this.props.history} />
          break;
        case 'noise-flair-touch-bluetooth-wireless-neckband':
          return <FlairNeckband history={this.props.history} />
          break;
        case 'noise-flair-touch-bluetooth-wireless-neckband-partner-exclusive':
          return <FlairNeckband history={this.props.history} />
          break;
        case 'noise-colorfit-nav-plus-smartwatch':
        return <NavPlus history={this.props.history} />
        break;
        case 'noise-colorfit-qube-smartwatch':
        return <Qube history={this.props.history} />
        break;
        case 'noise-colorfit-qube-smartwatch-partner-exclusive':
        return <Qube history={this.props.history} />
        break;
        case 'noise-colorfit-ultra-smart-watch':
        return <Ultra history={this.props.history} />
        break;
        case 'noise-colorfit-ultra-smart-watch-partner-exclusive':
        return <Ultra history={this.props.history} />
        break;
        case 'noise-colorfit-pulse-smartwatch':
        return <PulseTemplate history={this.props.history} />
        break;
        case 'noise-colorfit-pulse-smartwatch-partner-exclusive':
        return <PulseTemplate history={this.props.history} />
        break;
        // case 'noisefit-active-smartwatch':
        //   return <ActiveTemplate history={this.props.history} />
        //   break;
        default:
          return <ProductTemplate history={this.props.history} />
    }
 }
 render() {
  let { product,loading } = this.props.productData;
  const headerHeight = getHeaderHeight();
  let loaderClass = '';
  let Style = {};
  // loading = true;
  if(loading){
    Style={
      height: `calc(100vh - ${headerHeight}px)`,
    }
  }
  return (
    <div id='product-page' className={`${product.handle} ${loaderClass}`} style={Style}>
    {loading ? <Loading /> : this.getProduct()}
    </div>
  );
 }
}

const mapStateToProps = state => ({
 productData: state.product,
});

const mapDispatchToProps = dispatch => ({
 fetchProduct: handle => dispatch(fetchProduct(handle)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ProductPage);
