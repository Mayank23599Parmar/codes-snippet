import React, { Component } from "react";
import Slider from 'react-slick';
import Srcset from "../../components/SrcSet";
import MediaQuery from "../../components/MediaQuery";

export class UltraAppslider extends Component {
  render() {
    const { noisefitSlider } = this.props;
    //console.log('noisefitSlider---->',this.props)
    let items = [];
    let settings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
      nextArrow:<span><img className="arrow-shift" src="https://cdn.shopify.com/s/files/1/0997/6284/files/Right_arrow.png?v=1626306149" style={{width: '20px',margin: '7px 9px'}} alt='next-arrow'/></span>,
      prevArrow:<span><img className="arrow-shift" src="https://cdn.shopify.com/s/files/1/0997/6284/files/Left_arrow.png?v=1626306149" style={{width: '20px',margin: '7px 5px'}} alt='prev-arrow'/></span>
    };
    for (let i = 1; i < 20; i++) {
        let slider_image_desk
      let slider_image;
      let content;
      let title;
      
      if (noisefitSlider["image_" + i]) {
        slider_image = noisefitSlider["image_" + i];
      }
      if (noisefitSlider["image_desk_" + i]) {
        slider_image_desk = noisefitSlider["image_desk_" + i];
      }
      
      if (noisefitSlider["content_" + i]) {
        content = noisefitSlider["content_" + i];
      }
      if (noisefitSlider["title_" + i]) {
        title = noisefitSlider["title_" + i];
      }
      if (
        slider_image_desk &&
        slider_image &&
        content &&
        title 
      ) {
        items.push({
            slider_image_desk: slider_image_desk,
          slider_image: slider_image,
          content: content,
          title: title
        });
      }
    }
    let sliderElements = items.map((item, index) => {
      return (
        <div className="slider-element">
          <div className="flex-view">
            <div className='image-area col-sm-6'>
              <div className='img'>
                    <MediaQuery query="lap-and-up">
                    <Srcset src={item.slider_image_desk} />
                  </MediaQuery>
                  <MediaQuery query="phone-and-tablet">
                  <Srcset src={item.slider_image} />
                     </MediaQuery>
                
              </div>
            </div>
            <div className='text-area col-sm-6'>
              <div className='text'>
                <h3 className='color-white'>{item.title}</h3>
                {/* <p className='color-white'>{item.content}</p> */}
              </div>
            </div>
            
          </div>
        </div>
      );
    });
    if(items.length<1){
      return false;
    }

    //return null;

    return  (
    <div className='noisefit-silder Ultra-app-slider'>
			<div className='container'>
         <h4 className='text-align-center color-white title'>More to explore with <span>NoiseFit App</span></h4>
				<Slider {...settings}>
					{sliderElements}
				</Slider>
			</div>
		</div>
    );
    
  }

}

export default UltraAppslider;
