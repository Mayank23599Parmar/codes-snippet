import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import Srcset from '../../components/SrcSet';
import UrlSet from '../../components/UrlSet';
import VariantSelector from '../../components/VariantSelector';
import { connect } from 'react-redux';
import { addToCart } from '../../redux/cart/cartAction';
import { formatMoney,fetchProductTitle } from '../../components/Helper';
import {setCompareProduct} from '../../redux/support/supportAction';
import {ctaEvent} from '../../clever-tap-events/AddToCartEvent'
// import {knowMore} from  '../../clever-tap-events/KnowButton'
import HtmlParser from 'react-html-parser';

class RelatedSimplyProduct extends Component {
  constructor(props) {
    super(props);
    this.ref = React.createRef();
    this.state = {
      selectedVariant: null,
      featured_image: ''
    }
  }
  addToCart = (e) =>{
    if(this.state.selectedVariant.available === false){
      return;
    }
    const form = { id: parseInt(this.state.selectedVariant.id) ,quantity:1 }
    const data = {
      "type":e.currentTarget.name,
      form
    }
    this.props.addToCart(data);
    ctaEvent(this.state.selectedVariant)
  }
  componentWillMount (){
    const { product } = this.props;
    const selectedVariant = product.selected_or_first_available_variant ? product.selected_or_first_available_variant : product.variants[0];
    const {featured_image} = selectedVariant;
    let src = product.featured_image;
    if(featured_image){
      src = featured_image.src;
    }
    if(selectedVariant){
        this.setState({ selectedVariant,featured_image:src })
    }else{
      this.setState({ featured_image:src })
    }
  }
  setSelectedVariant = (selectedVariant) =>{
    const {featured_image} = selectedVariant;
    let src = this.state.featured_image;
    if(featured_image.src){
      src = featured_image.src;
    }
    if(this.ref.current){
      let image = this.ref.current.querySelector('.product-img');
      image.setAttribute("srcset",src);
    }
    this.setState({selectedVariant,featured_image:src})
  }
  setCompareProduct = ()=>{
    const {product,history} = this.props;
    // this.props.setCompareProduct(product.id);
    history.push(`/pages/compare?product=${product.id}`);
  }
  render() {
    const {product,compareShow} = this.props;
    if(!product){
      return
    }
    const { variants, options, avgRating } = product;
    const {selectedVariant,featured_image} = this.state;
    let { swatchTitleShow } = false;
    let actual_title = product.title;
    let tagTitle = fetchProductTitle(product.tags);
    if(tagTitle){
      actual_title = tagTitle;
    }
    let hasSalePrice = product.tags.find((tag)=>tag.includes('sale_'));
    let hasdiscount = product.tags.find((tag)=>tag.includes('coupon_'));
    let uspData = product.tags.find((tag)=>tag.includes('USP_'));
    let phonePeCart = product.tags.includes("phonepe") ? true : false;
    let usp = [];
    if (uspData){
      let uspTag = uspData.replace('USP_',' ');
      usp = uspTag.split('_');
    }
    let ptag = product.tags.find((tag)=>tag.includes('ptag_'));
    if(ptag){
      var productTag = ptag.replace('ptag_',' ');
    }
    let salePrice = 0 ;
    if(hasSalePrice){
      let salePriceTag=hasSalePrice.split('_');
      if(salePriceTag.length === 2){
        salePrice = parseInt(salePriceTag[1]);
      }
    }

    let vclass = "";
    let sold_out = false;
    if(!cn(selectedVariant)){
      if(!selectedVariant.available){
        sold_out = true;
      }
    }
    let defaultVariant = false;
    if(variants.length === 1){
      if(variants[0].title == 'Default Title'){
        defaultVariant = true;
      }
    }
 
    return (
      <div className={`product-main detail-${product.id} `}>
        <div className="image">
          {ptag && <div className="tag"><p>{productTag}</p></div> }
          <div className="relative img-cell ">
            <div className="img" ref={this.ref}>
              <UrlSet className="product-link" href={`/products/${product.handle}`}>
                <Srcset alt={product.title} src={featured_image} className="product-img" />
                {pwa.switch_image &&
                  <Srcset alt={product.title} src={product.images[1]} className="img_blur alter_img"/>
                }
              </UrlSet>
            </div>
          </div>
        </div>
        <div className="productInfo_wrapper">
        <div className="text-wrapper">
          <h2 className="title">
            <UrlSet className="product-link" href={`/products/${product.handle}`}>
              <span className="product-title">{actual_title}</span>
            </UrlSet>
          </h2>
          <div className="product-price">
          <h5 className="price">{hasSalePrice && salePrice > 0 ? formatMoney(salePrice * 100)  : formatMoney(parseInt(selectedVariant.price))}</h5>
              {selectedVariant.compare_at_price && selectedVariant.compare_at_price > selectedVariant.price &&
              <p className="compare">
                {formatMoney(parseInt(selectedVariant.compare_at_price)).substring(1)}
              </p>}  
          </div>
          <div className="avgRating-wrapper ">
            <div className="avgRating ">
                {/* <div class="jdgm-star jdgm--on" data-id={product.id}></div> */}
                <div className="jdgm-widget jdgm-preview-badge" data-id={product.id}></div>
            </div>
          </div>
         {avgRating && <div className="avgRating-wrapper"><div className="avgRating"><span className="jdgm-star jdgm--on"></span><p>{HtmlParser(avgRating)}</p></div></div>}
        </div>
        {defaultVariant === false && 
        <div className={`variants-wrapper ${vclass}`}>
          {options.map((option, index) => {
            return (
              <ul className="swatch-wrap" key={index}>
                {swatchTitleShow ? (
                  <h3 className="swatch-title">{option}</h3>
                ) : null}
                {variants.map((variant) => {
                  return <VariantSelector
                    key={variant.id}
                    option={option.name?option.name:option}
                    selectedVariant={selectedVariant}
                    variantImages={pwa.variantImages}
                    variant={variant}
                    setSelectedVariant={()=>this.setSelectedVariant(variant)}
                  />;
                })}
              </ul>
            );
          })}
        </div>}
        <UrlSet className="" href={`/products/${product.handle}`}>
        <div className ="usp_wrapper">
           {usp.map((item,index)=><p className="usp" key={index}>{item}</p>)}
        </div>
        </UrlSet>
        <div>
                   
        </div>
        <div className="text">
          
            {phonePeCart && 
            <div className="addtocart-wrap">
            {(sold_out ? (
            <button className="btn" name="cart" id="soldOut" onClick={this.addToCart}>
              <span data-text="Sold Out">Sold Out</span>
            </button>
            ) : (
            <button className="btn" name="cart" onClick={this.addToCart}>
              <span data-text="Add To Cart">Add To Cart</span>
            </button>
            ))}
            </div>
            }
              <div className="links clearfix">
                {/*<UrlSet href={`/products/${product.handle}`} className="text-Know" onClick={()=>knowMore(product)}>Know more <img className="icon-img" src={pwa.icons.peachRightArrow}/></UrlSet>*/}
                {compareShow && <span className="text-compare" onClick={this.setCompareProduct}>Compare <img className="icon-img" src={pwa.icons.plus}/></span>}
              </div>
            </div> 
         
        </div>
      </div>
    );
  }
}
const mapDispatchToProps = dispatch => (
  {
    addToCart : data => dispatch(addToCart(data)),
    setCompareProduct: id => dispatch(setCompareProduct(id))
  }
)
export default withRouter(connect(null,mapDispatchToProps)(RelatedSimplyProduct));