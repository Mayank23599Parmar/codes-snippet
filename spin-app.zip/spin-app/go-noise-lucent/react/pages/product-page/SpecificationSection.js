import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import Srcset from "../../components/SrcSet";
import MainSpecification from "./MainSpecifications";
class SpecificationSection extends Component {
  render() {
    const { specifications } = this.props;
    if(Object.keys(specifications).length === 0){
      return false;
    }
    if(cn(specifications.details)){
      return null;
    }
    let sepcArr = specifications.details.split("<>");
    let specificationDetails = sepcArr.map((ele, index) => {
      let eleArr = ele.split(" title#");
      let title = eleArr[0];
      eleArr = eleArr[1].split("$$");
      return (
        <MainSpecification key={index} title={title} eleArr={eleArr} />
      );
    });

    return (
      <div>
        <div className="box-section background-black">
          <div className="container">
            <div className="flex-view-xs space product_detail_wrap">
              <div className="specification-wrap">
                <h3 className="header-title color-white">{specifications.title}</h3>
                <ul className="specifications">{specificationDetails}</ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default SpecificationSection;
