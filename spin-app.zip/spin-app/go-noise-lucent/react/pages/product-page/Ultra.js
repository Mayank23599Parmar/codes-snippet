import React from "react";
/* Redux */
import { connect } from "react-redux";
/* Actions */
import {setVariant} from '../../redux/product/productAction';
/* helper */
// import { queryString, queryStringVariant } from '../../components/Helper';
/* Comp imports */
import Loading from "../../components/loader/loader";
// import ErrorPage from "../errorpage/ErrorPage";
import ProductBanner from "./ProductBanner";
import FeaturedImage from "./FeaturedImage";
import ProductSlider from './ProductSlider';
// import CustomerReview from "./CustomerReview";
import ProductVideo from "./ProductVideo";
import ImageWithText from "./ImageWithText";
import InTheBoxSection from "./InTheBoxSection";
import SpecificationSection from "./SpecificationSection";
import FAQSection from './FAQSection';
import ProductReview from './ProductReview';
// import CompareProducts from './CompareProducts';
import ProductBar from './ProductBar';
import TextWithTitle from './TextWithTitle';
import WarrantySection from './WarrantySection';
import NoisfitappSlider from './NoisfitappSlider';
import SEODisclaimerSection from './SEODisclaimerSection';
import SEOQuestions from './SEOQuestions';
import RelatedProductsSection from './RelatedProductsSection';
import StrapProductDesc from './StrapProductDesc';
import UltraGrid from './UltraGrid';
import Ultrahealthassistant from './Ultrahealthassistant';
import UltraAppslider from './UltraAppslider'
import Ultrafeatureslider from './Ultrafeatureslider';
import Ultramenstural from './Ultramenstural';
import Ultrasportsmode from './Ultrasportsmode';
import Ultrawaterproof from './Ultrawaterproof';
import Ultrafeaturelast from './Ultrafeaturelast';
import Ultraswappablestrap from './Ultraswappablestrap';
import Ultratwowatch from './Ultratwowatch';
import Ultraproductivity from './Ultraproductivity';
import Ultradesktopstatic from './Ultradesktopstatic';
import Ultramainvideo from './Ultramainvideo';
import UltraAlluminiumBody from './UltraAlluminiumBody';
import UltraSEOQuestions from './UltraSEOQuestions';
import Offersimple from './Offersimple';
import MediaQuery from '../../components/MediaQuery';

class Ultra extends React.Component {
  constructor(props) {
    super(props)
    this.prodRef = React.createRef();
    this.featureRef = React.createRef();
    this.state = {
      showBar: false
    }
  }

  componentDidMount() {
    window.addEventListener('scroll', this.handleScroll);
    console.log('This is ultra page.');
    // const { setVariant, productData } = this.props;
    // let queryStringsData = queryString(location.href);
    // if(productData.product){
    //   if(queryStringsData.variant){
    //     let passVariant = productData.product.variants.find((vari)=>{
    //       return vari.id === parseInt(queryStringsData.variant.value);
    //     })
    //     if(passVariant){
    //       setVariant(passVariant);
    //     }
    //   }
    //   else{
    //     queryStringVariant(productData.variant);
    //   }
    // }
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.handleScroll);
  }

  handleScroll = (event) => {
    let productSection = this.prodRef.current;
    let featureSection = this.featureRef.current;
   // if(window.pageYOffset <= featureSection.offsetTop && (window.pageYOffset + 100)  > productSection.offsetTop ){
    if(window.pageYOffset <= (featureSection.offsetTop - 500) && (window.pageYOffset + 200)  > productSection.offsetTop ){

      this.setState({showBar: false})
    }
    else{
      this.setState({showBar: true})
    }
  }

  render() {
    const { metafields, loading, product, compareProducts, relatedProducts } = this.props.productData;
    const { showBar } = this.state
    //console.log(product.description);
    let prodDesc = product.description;
    let descproduct = product.tags.includes("strap-description") ? true : false;
    let offer2 = product.tags.includes("offer2") ? true : false;
    if (loading) {
      return <Loading />;
    }
    // const pageStatus = checkErrorPage(window.location.href);
    // if (pageStatus) {
    //   return <ErrorPage show={true} />;
    // }
    if(cn(metafields)){
      return(
        <div>
        {showBar && <ProductBar prodRef={(this.prodRef)} />}
        <div ref={this.prodRef}><ProductSlider metaData={metafields} /></div>
        <ProductReview product={product} />
        </div>
      )
    }

    return (
      <div>
        {offer2 &&
        <MediaQuery query="phone">
       {showBar &&<Offersimple product={product} prodRef={(this.prodRef)} />}
       </MediaQuery>
        }
        <ProductBar prodRef={(this.prodRef)} />
        {metafields.banner_section && <div><ProductBanner banner_section={metafields.banner_section}  /></div>}
        <div ref={this.prodRef}><ProductSlider metaData={metafields} /></div>
        {prodDesc && descproduct && <div><StrapProductDesc product={product} /></div>}
        {metafields.feature_section && <div ref={this.featureRef}><FeaturedImage feature_section={metafields.feature_section} /></div>}
        {/* {metafields.customer_review && <CustomerReview customer_review={metafields.customer_review} />} */}
        {metafields.ultra_grid && <UltraGrid ultra_grid={metafields.ultra_grid} />}
        {metafields.video_section && <ProductVideo video_section={metafields.video_section} />}
        {metafields.ultra_two_watch && <Ultratwowatch ultra_two_watch={metafields.ultra_two_watch} />}
        <Ultramainvideo />
        <UltraAlluminiumBody />
        {metafields.ultra_health_assist && <Ultrahealthassistant ultra_health_assist={metafields.ultra_health_assist} />}
        {metafields.noisefitSlider && <Ultrafeatureslider noisefitSlider={metafields.noisefitSlider} />}
        {metafields.ultra_menstural && <Ultramenstural ultra_menstural={metafields.ultra_menstural} />}
        <Ultradesktopstatic />
        {metafields.ultra_sports_mode && <Ultrasportsmode ultra_sports_mode={metafields.ultra_sports_mode} />}
        {metafields.text_with_title && <TextWithTitle text_with_title={metafields.text_with_title}/>}
        {metafields.image_with_text && <ImageWithText image_with_text={metafields.image_with_text} />}
        {metafields.box_section && <InTheBoxSection box_section={metafields.box_section} />}
        {metafields.noisefitSlider && <UltraAppslider noisefitSlider={metafields.noisefitSlider} />}
        <Ultraswappablestrap />
        <Ultraproductivity />
        {metafields.ultra_waterproof && <Ultrawaterproof ultra_waterproof={metafields.ultra_waterproof} />}
        <Ultrafeaturelast />
        {metafields.specifications && <SpecificationSection specifications={metafields.specifications} />}
        {/* {compareProducts && <CompareProducts compareProducts={compareProducts} />} */}
        {metafields.warrantySection && <WarrantySection warrantyData={metafields.warrantySection} />}
        {metafields.FAQ && <FAQSection FAQ={metafields.FAQ} />}
        {metafields.review && <ProductReview product={product} review={metafields.review} />}
        {metafields.SEODisclaimer  && <SEODisclaimerSection data={metafields.SEODisclaimer} />}
        {relatedProducts && relatedProducts.length > 0 && <RelatedProductsSection productList={relatedProducts} />}
        {metafields.SEOQuestions && <UltraSEOQuestions data={metafields.SEOQuestions} /> }
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  productData: state.product,
});
const mapDispatchToProps = dispatch => ({
  setVariant: variant => dispatch(setVariant(variant))
});
export default connect(mapStateToProps,mapDispatchToProps)(Ultra);
