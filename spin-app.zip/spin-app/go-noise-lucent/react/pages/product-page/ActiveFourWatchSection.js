import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import MediaQuery from "../../components/MediaQuery";
import Srcset from "../../components/SrcSet";
class ActiveFourWatchSection extends Component {
  render() {
    let { Active_Four_Watch } = this.props;
    if (Object.keys(Active_Four_Watch).length === 0) {
      return false;
    }
    let items = [];
    for (let i = 1; i < 20; i++) {
      let icon_image;
      if (Active_Four_Watch["icon_image_" + i]) {
        icon_image = Active_Four_Watch["icon_image_" + i].split(";");
      }
      let image_type = "left";
      if (Active_Four_Watch["image_type_" + i]) {
        image_type = Active_Four_Watch["image_type_" + i];
      }

      let padding = "";
      if (image_type == "left_full" || image_type == "right_full") {
        padding = "padding_none";
      }
      let title = Active_Four_Watch["title_" + i];
      let content_text = Active_Four_Watch["content_" + i];
      let image = Active_Four_Watch["image_" + i];
      let useTitle = Active_Four_Watch["paraextra_" + i];
      let useImage = Active_Four_Watch["extraimage_" + i];
      
      let bg_color = "#000";
      let font_color = "#fff";
      let classType = '';
      if (!cn(Active_Four_Watch["background_color_" + i])) {
        bg_color = Active_Four_Watch["background_color_" + i];
      }
      if (!cn(Active_Four_Watch["text_color_" + i])) {
        font_color = Active_Four_Watch["text_color_" + i];
      }
      let content_type = 'left';
      if(Active_Four_Watch['content_type_'+i]){
        content_type = Active_Four_Watch['content_type_'+i];
      }
      let Style = {
        backgroundColor: bg_color,
        color: font_color,
      };
      if (image_type === "banner") {
        let content = (
          <div className="image-text-section">
            <div className={`banner-type banner-type-${i}`}>
              <MediaQuery query="phone-and-tablet"><Srcset src={Active_Four_Watch["image_xs_" + i] ? Active_Four_Watch["image_xs_" + i] : image} /></MediaQuery>
              <MediaQuery query="lap-and-up"><Srcset src={image} /></MediaQuery> 
              <div className={`text-wrap ${content_type}`}>
                  <div className="container">
                    <div className="text">
                        {title && <h2 style={{color:font_color}} className="header-title">{HtmlParser(title)}</h2>}
                        {content_text && <p style={{color:font_color}} className="header-sub-title">{HtmlParser(content_text)}</p>}
                        <ul className="icon-text-wrap">
                          {Active_Four_Watch["icon_text_" + i] &&
                            Active_Four_Watch["icon_text_" + i]
                              .split(";")
                              .map((item, index) => {
                                return (
                                  <li className="icon-text-li" key={index}>
                                    {icon_image[index] && (
                                      <img src={icon_image[index]} alt={item} />
                                    )}
                                    <span>{HtmlParser(item)}</span>
                                  </li>
                                );
                              })}
                      </ul>
                    </div>
                  </div>
              </div>
            </div>
          </div>
        )
        items.push(content);
      }else if(image_type === "container_image") {
        let content = <div className="image container-image" style={Style}>
          <div className="container">
            <Srcset src={image} alt={title} />
          </div>
        </div>
        items.push(content);
      }
      else {
        
        if (image) {
          let content = (
            <div className={`image-text-section active-four-watch image-text-section-active-${i}`}>
              <div className="image-text-wrap">
                <div
                  className={`image-with-text-section ${padding}`}
                  key={i}
                >
                  <div className="container">
                    <div className={`${image_type} image-text-inner-wrap`}>
                      <div className="image-wrap">
                      <MediaQuery query="phone-and-tablet"><Srcset src={Active_Four_Watch["image_xs_" + i] ? Active_Four_Watch["image_xs_" + i] : image} /></MediaQuery>
                      <MediaQuery query="lap-and-up"><Srcset src={image} /></MediaQuery> 
                      </div>
                      <div className="text-wrap">
                        <h2 className="header-title">{HtmlParser(title)}</h2>
                        <p className="header-sub-title">{HtmlParser(content_text)}</p>
                        <ul className="icon-text-wrap">
                          {Active_Four_Watch["icon_text_" + i] &&
                            Active_Four_Watch["icon_text_" + i]
                              .split(";")
                              .map((item, index) => {
                                return (
                                  <li className="icon-text-li" key={index}>
                                    {icon_image[index] && (
                                      <img src={icon_image[index]} alt={item} />
                                    )}
                                    <span>{HtmlParser(item)}</span>
                                  </li>
                                );
                              })}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
          items.push(content);
        } 
      }
    }
    if (items.length > 0) {
      return <>{items}</>;
    }
    return null;
  }
}

export default ActiveFourWatchSection;
