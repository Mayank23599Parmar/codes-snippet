import React, { Component } from 'react'
import Slider from "react-slick";
import ProductDetails from './ProductDetails';
import {connect} from 'react-redux';
import SrcSet from '../../components/SrcSet'
import LazyLoad from 'react-lazyload';

export class ProductSlider extends Component {
  render() {
    const { product,variant,metaData } = this.props;
    let {media,images} = product;
    let currentVariantImages = [];
    if(cn(media)){
      return null;
    }
    for(let i=0; i < media.length; i++){
      let item = media[i];
      if(item.alt == variant.title){
        currentVariantImages.push(item.src);
      }
    };
    if(currentVariantImages.length <= 0){
      currentVariantImages = images;
    }
    let whiteBackground = product.tags.find((tag) => { return tag === 'white-bg' } )
    var settings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
      nextArrow:<span><img src="https://cdn.shopify.com/s/files/1/0997/6284/files/Asset_1_1.svg?v=1628501758" style={{width: '25px',margin: '7px 9px'}} alt='next-arrow'/></span>,
      prevArrow:<span><img src="https://cdn.shopify.com/s/files/1/0997/6284/files/Arrow_left.svg?v=1628501809" style={{width: '25px',margin: '7px 5px'}} alt='prev-arrow'/></span>
    };
    const sliderImages = currentVariantImages.map((item) => <div key={item} className="image"><LazyLoad height={200}><SrcSet key={item} src={item}/> </LazyLoad></div>)
    return (
      <>
      <div id='product-section' className={`product-section ${whiteBackground ? 'white-background':''}`} ref={this.myRef}>
        <div className='container'>
          <div className='product-slider'>
            <Slider {...settings}>
              {sliderImages.length > 0 ? sliderImages : ''}
            </Slider>    
          </div>
        </div>
        <ProductDetails metaData={metaData} />
      </div>
      </>
    )
  }
}

const mapStateToProps = state => (
  {
    product : state.product.product,
    variant : state.product.variant
  }
)

const mapDispatchToProps = dispatch => (
  {
    addToCart : data => dispatch(addToCart(data))
  }
)
export default connect(mapStateToProps,mapDispatchToProps)(ProductSlider);