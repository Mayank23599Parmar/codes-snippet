import React from "react";
/* Redux */
import { connect } from "react-redux";
/* Animation */
import gsap from "gsap";
import { TimelineMax, TweenMax, Linear ,TweenLite,TimelineLite} from 'gsap';
import * as ScrollMagic from 'scrollmagic';
//import { TweenMax, TimelineMax } from "gsap"; // What to import from gsap
import { ScrollMagicPluginGsap } from "scrollmagic-plugin-gsap";
 
ScrollMagicPluginGsap(ScrollMagic, TweenMax, TimelineMax,gsap,TweenLite,TimelineLite);
//import '../../../node_modules/scrollmagic/scrollmagic/uncompressed/plugins/animation.gsap.js';
/* Actions */
import {setVariant} from '../../redux/product/productAction';
/* helper */
import { queryString, queryStringVariant } from '../../components/Helper';
/* Comp imports */
import Loading from "../../components/loader/loader";
// import ErrorPage from "../errorpage/ErrorPage";
import ProductBanner from "./ProductBanner";
import FeaturedImage from "./FeaturedImage";
import ProductSlider from './ProductSlider';
// import CustomerReview from "./CustomerReview";
import ProductVideo from "./ProductVideo";
import ImageWithText from "./ImageWithText";
import InTheBoxSection from "./InTheBoxSection";
import SpecificationSection from "./SpecificationSection";
import FAQSection from './FAQSection';
import ProductReview from './ProductReview';
// import CompareProducts from './CompareProducts';
import ProductBar from './ProductBar';
import TextWithTitle from './TextWithTitle';
import WarrantySection from './WarrantySection';
import NoisfitappSlider from './NoisfitappSlider';
import SEODisclaimerSection from './SEODisclaimerSection';
import SEOQuestions from './SEOQuestions';
import RelatedProductsSection from './RelatedProductsSection'; 
import Offersimple from './Offersimple';
import MediaQuery from '../../components/MediaQuery';
class FlairNeckband extends React.Component {
  constructor(props) {
    super(props)
    this.prodRef = React.createRef();
    this.featureRef = React.createRef();
    this.state = {
      showBar: false
    }
    this.controller = new ScrollMagic.Controller();
    //this.init();
  }
  
  componentDidMount() {
    
    //console.log('flair products thissssss');

    window.addEventListener('scroll', this.handleScroll);
    const { setVariant, productData } = this.props;
    let queryStringsData = queryString(location.href);
    this.init();
    //const controller1 = new ScrollMagic.Controller();

    let screenWidth = window.screen.width 
    //console.log('width------->',screenWidth)
    if(screenWidth <= 767){
      let tween = gsap.timeline();
      let tl2 = gsap.timeline();
      let tl3 = gsap.timeline();
      let tl4 = gsap.timeline();

        const scene1 = new ScrollMagic.Scene({
          triggerHook: 0,
          triggerElement : '.image-text-section-1',
          duration: 1500 
          })  
        .setTween(tween)
        .setPin(".image-text-section-1") // pins the element for the the scene's duration
        .addTo(this.controller);
        scene1.offset(0);
        const scene2 = new ScrollMagic.Scene({
          triggerElement: ".image-text-section-2",
          duration: 1600 ,// scroll distance
          triggerHook:0.05
        })
        .setTween(tl2)
        .setPin(".image-text-section-2")
        .addTo(this.controller);

        const scene3 = new ScrollMagic.Scene({
          triggerElement: ".image-text-section-6",
          duration: 1600 ,// scroll distance
          triggerHook:0
        })
        // get the current offset
          

          // set a new offset
        
        .setTween(tl3)
        .setPin(".image-text-section-6")

        .addTo(this.controller);
        scene3.offset(140);

        const scene4 = new ScrollMagic.Scene({
          triggerElement: ".image-text-section-7",
          duration: 1000 ,// scroll distance
          triggerHook:1.5
        })
        .setTween(tl4)
        //.setPin(".image-text-section-7")
        .addTo(this.controller);


        // tl1
        // .set('.image-text-section-1 .text-wrap', {y:70,scale:0.5},0)
        // .to('.image-text-section-1 .text-wrap', 1.6, {y:0,opacity: 1,scale:1,ease: "Power4.easeInOut" })
        tween.to('.image-text-section-1 .header-title',4,{opacity:1})
          .to('.image-text-section-1 .header-sub-title',4,{opacity:1})
          .to('.image-text-section-1 .icon-text-wrap',4,{opacity:1},'-=4')
          .to('.image-text-section-1 .image-extra-wrapper',4,{opacity:1},'-=4')
          .to('.image-text-section-1 .header-sub-title',4,{opacity:0})
          .to('.image-text-section-1 .icon-text-wrap',4,{opacity:0},'-=4')
          .to('.image-text-section-1 .image-extra-wrapper',4,{opacity:0},'-=4')
          .to('.image-text-section-1 .para-extra',4,{opacity:1})
          .to('.image-text-section-1 .image-wrap img', 2, {className:"+=swing"},'-=3')
          //.to('.image-text-section-1 .image-wrap img', 1, {className:"+=swing"})
        tl2
          .to('.image-text-section-2 .header-title',4,{opacity:1})
          .to('.image-text-section-2 .header-sub-title',4,{opacity:1,color:"#555555"})
          .to('.image-text-section-2 .icon-text-wrap',4,{opacity:1,color:"#555555"},'-=4')
          .to('.image-text-section-2 .header-sub-title',4,{opacity:0})
          .to('.image-text-section-2 .icon-text-wrap',4,{opacity:0},'-=4')
          .to('.image-text-section-2 .para-extra',4,{opacity:0.8,y:-120,color:"#555555"})
          .to('.image-text-section-2 .para-extra',4,{opacity:1})

        tl3.to('.image-text-section-6 .header-title',4,{opacity:1})
        .to('.image-text-section-6 .header-sub-title',4,{opacity:1,color:"#ffffff"})
        .to('.image-text-section-6 .icon-text-wrap',4,{opacity:1,color:"#ffffff"},'-=4')
        .to('.image-text-section-6 .header-sub-title',4,{opacity:0})
        .to('.image-text-section-6 .icon-text-wrap',4,{opacity:0},'-=4')
        .to('.image-text-section-6 .para-extra',4,{opacity:0.8,y:-60,color:"#ffffff"})
        .to('.image-text-section-6 .para-extra',4,{opacity:1})

        tl4
        //.set('.image-text-section-7 .image-wrap img', {scale:1.6})
        .to('.image-text-section-7 .image-wrap img', 4, {scale:1,ease: "Power4.easeInOut" })

    }else if(screenWidth <= 420){
      let tween = gsap.timeline();
      let tl2 = gsap.timeline();
      let tl3 = gsap.timeline();
      let tl4 = gsap.timeline();

        const scene1 = new ScrollMagic.Scene({
          triggerHook: 0,
          triggerElement : '.image-text-section-1',
          duration: 1500 
          })  
        .setTween(tween)
        .setPin(".image-text-section-1") // pins the element for the the scene's duration
        .addTo(this.controller);
        scene1.offset(0);
        const scene2 = new ScrollMagic.Scene({
          triggerElement: ".image-text-section-2",
          duration: 1600 ,// scroll distance
          triggerHook:0.05
        })
        .setTween(tl2)
        .setPin(".image-text-section-2")
        .addTo(this.controller);

        const scene3 = new ScrollMagic.Scene({
          triggerElement: ".image-text-section-6",
          duration: 1600 ,// scroll distance
          triggerHook:0
        })
        // get the current offset
          

          // set a new offset
        
        .setTween(tl3)
        .setPin(".image-text-section-6")

        .addTo(this.controller);
        scene3.offset(140);

        const scene4 = new ScrollMagic.Scene({
          triggerElement: ".image-text-section-7",
          duration: 1000 ,// scroll distance
          triggerHook:1.5
        })
        .setTween(tl4)
        //.setPin(".image-text-section-7")
        .addTo(this.controller);


        // tl1
        // .set('.image-text-section-1 .text-wrap', {y:70,scale:0.5},0)
        // .to('.image-text-section-1 .text-wrap', 1.6, {y:0,opacity: 1,scale:1,ease: "Power4.easeInOut" })
        tween.to('.image-text-section-1 .header-title',4,{opacity:1})
          .to('.image-text-section-1 .header-sub-title',4,{opacity:1})
          .to('.image-text-section-1 .icon-text-wrap',4,{opacity:1},'-=4')
          .to('.image-text-section-1 .image-extra-wrapper',4,{opacity:1},'-=4')
          .to('.image-text-section-1 .header-sub-title',4,{opacity:0})
          .to('.image-text-section-1 .icon-text-wrap',4,{opacity:0},'-=4')
          .to('.image-text-section-1 .image-extra-wrapper',4,{opacity:0},'-=4')
          .to('.image-text-section-1 .para-extra',4,{opacity:1})
          .to('.image-text-section-1 .image-wrap img', 2, {className:"+=swing"},'-=3')
          //.to('.image-text-section-1 .image-wrap img', 1, {className:"+=swing"})
        tl2
          .to('.image-text-section-2 .header-title',4,{opacity:1})
          .to('.image-text-section-2 .header-sub-title',4,{opacity:1,color:"#555555"})
          .to('.image-text-section-2 .icon-text-wrap',4,{opacity:1,color:"#555555"},'-=4')
          .to('.image-text-section-2 .header-sub-title',4,{opacity:0})
          .to('.image-text-section-2 .icon-text-wrap',4,{opacity:0},'-=4')
          .to('.image-text-section-2 .para-extra',4,{opacity:0.8,y:-120,color:"#555555"})
          .to('.image-text-section-2 .para-extra',4,{opacity:1})

        tl3.to('.image-text-section-6 .header-title',4,{opacity:1})
        .to('.image-text-section-6 .header-sub-title',4,{opacity:1,color:"#ffffff"})
        .to('.image-text-section-6 .icon-text-wrap',4,{opacity:1,color:"#ffffff"},'-=4')
        .to('.image-text-section-6 .header-sub-title',4,{opacity:0})
        .to('.image-text-section-6 .icon-text-wrap',4,{opacity:0},'-=4')
        .to('.image-text-section-6 .para-extra',4,{opacity:0.8,y:-60,color:"#ffffff"})
        .to('.image-text-section-6 .para-extra',4,{opacity:1})

        tl4
        //.set('.image-text-section-7 .image-wrap img', {scale:1.6})
        .to('.image-text-section-7 .image-wrap img', 4, {scale:1,ease: "Power4.easeInOut" })
    }
      
        
      }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.handleScroll);
  }

  handleScroll = (event) => {
    
    let productSection = this.prodRef.current;
    let featureSection = this.featureRef.current;
    //if(window.pageYOffset <= featureSection.offsetTop && (window.pageYOffset + 100)  > productSection.offsetTop ){
      if(window.pageYOffset <= (featureSection.offsetTop - 500) && (window.pageYOffset + 200)  > productSection.offsetTop ){

      this.setState({showBar: false})
    }
    else{
      this.setState({showBar: true})
    }
  }
  
  
  

  init = () =>{
    console.log('flair init')
    //this.firstAnimation();
    //this.secondAnimation();
  }
  render() {
    
    const { metafields, loading, product, compareProducts, relatedProducts } = this.props.productData;
    const { showBar } = this.state;
    let offer2 = product.tags.includes("offer2") ? true : false;

    if (loading) {
      return <Loading />;
    }
    // const pageStatus = checkErrorPage(window.location.href);
    // if (pageStatus) {
    //   return <ErrorPage show={true} />;
    // }
    if(cn(metafields)){
      return(
        <div>
        {showBar && <ProductBar prodRef={(this.prodRef)} />}
        <div ref={this.prodRef}><ProductSlider metaData={metafields} /></div>
        <ProductReview product={product} />
        </div>
      )
    }

    return (
      <div>
        {offer2 &&
        <MediaQuery query="phone">
       {showBar &&<Offersimple product={product} prodRef={(this.prodRef)} />}
       </MediaQuery>
        }
        <ProductBar prodRef={(this.prodRef)} />
        {metafields.banner_section && <div><ProductBanner banner_section={metafields.banner_section}  /></div>}
        <div ref={this.prodRef}><ProductSlider metaData={metafields} /></div>
        {metafields.feature_section && <div ref={this.featureRef}><FeaturedImage feature_section={metafields.feature_section} /></div>}
        {/* {metafields.customer_review && <CustomerReview customer_review={metafields.customer_review} />} */}
        {metafields.video_section && <ProductVideo video_section={metafields.video_section} />}
        {metafields.text_with_title && <TextWithTitle text_with_title={metafields.text_with_title}/>}
        {metafields.image_with_text && <ImageWithText image_with_text={metafields.image_with_text} />}
        {metafields.box_section && <InTheBoxSection box_section={metafields.box_section} />}
        {metafields.noisefitSlider && <NoisfitappSlider noisefitSlider={metafields.noisefitSlider} />}
        {metafields.specifications && <SpecificationSection specifications={metafields.specifications} />}
        {/* {compareProducts && <CompareProducts compareProducts={compareProducts} />} */}
        {metafields.warrantySection && <WarrantySection warrantyData={metafields.warrantySection} />}
        {metafields.FAQ && <FAQSection FAQ={metafields.FAQ} />}
        {metafields.review && <ProductReview product={product} review={metafields.review} />}
        {metafields.SEODisclaimer  && <SEODisclaimerSection data={metafields.SEODisclaimer} />}
        {relatedProducts && relatedProducts.length > 0 && <RelatedProductsSection productList={relatedProducts} />}
        {metafields.SEOQuestions && <SEOQuestions data={metafields.SEOQuestions} /> }
      </div>
    );
  }

}

const mapStateToProps = (state) => ({
  productData: state.product,
});
const mapDispatchToProps = dispatch => ({
  setVariant: variant => dispatch(setVariant(variant))
});
export default connect(mapStateToProps,mapDispatchToProps)(FlairNeckband);
