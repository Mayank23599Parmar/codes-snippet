import React, { Component } from "react";
import { connect } from "react-redux";
import OtpInput from 'react-otp-input';
import SrcSet from "../../components/SrcSet";
import PreorderModalAddAddress from "./PreorderModalAddAddress";
import { handleize } from "../../components/Helper";
import { formatMoney, fetchProductTitle } from "../../components/Helper";
import { getPreOrder } from "../../redux/product/productAction";
import apiConfig from '../../components/api-config';
import HtmlParser from "react-html-parser";
import { fetchAccountInfo } from '../../redux/account/accountActions'
export class PreorderModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      number: "",
      btnLoader: false,
      phoneError:'',
      otp:'',
      otpSent: false,
      otpVerified: false,
      otpError:false,
      finalStep: false,
      resendOtpLoader:false,
      addAddress: false,
      selectedAddress:{
        key:'',
        address:'',
        personname:'',
      }
    };
  }
  componentDidMount() {
    if (!cn(simply.customerId)) {
      this.props.fetchAccountInfo(simply.customerId);
    }
  }
  checkVariantType = (name) => {
    let handleName = handleize(name);
    let type = "";
    if (handleName == "color" || handleName == "colour") {
      type = "color";
    } else {
      type = "normal";
    }
    return type;
  };
  findVariantImages = (title) => {
    if (this.props.variantImages) {
      let vimg = this.props.variantImages.filter(
        (image) => image.title == title
      );
      if (vimg.length > 0) {
        return vimg[0].vimg;
      } else {
        return null;
      }
    }
    return null;
  };
  handleSubmit = (e) => {
    e.preventDefault();
    const { number,otpSent, otpVerified, finalStep,selectedAddress } = this.state;
    if(!otpSent || !otpVerified || !finalStep){
      return false;
    } 
    const { selectedVariant, product } = this.props;
    let dataPass = {
      email: simply.customerEmail,
      phone: number,
      p_id: product.id,
      vId: selectedVariant.id,
      cust_id: simply.customerId,
      img_url: selectedVariant.featured_image.src,
      prod_title: product.title,
      address: selectedAddress.key
    };
    let query = `${apiConfig.baseUrl}${apiConfig.getPreorderData}?email=${simply.customerEmail}&phone=${number}&p_id=${product.id}&vId=${selectedVariant.id}&img_url=${selectedVariant.featured_image.src}&prod_title=${product.title}&cust_id=${simply.customerId}&address=${selectedAddress.key}`
    if(selectedAddress.key !== '' && selectedAddress.address !== '' && selectedAddress.personname !== '' ){
      this.setState({btnLoader:true},
        ()=>{
          this.props.getPreOrder({ query, dataPass, callbackFunc:()=>{
            this.setState({btnLoader:false})
            this.props.toggleModale(false)
          }})  
        } 
      )
    }
    else{
      this.setState({phoneError:'Please select a address.'});
    }
  };
  sentOtp = async () => {
    const { number }= this.state;
    let data = {'phone': number}
    try {
      const response = await fetch(`${apiConfig.baseUrl}${apiConfig.preOrderOTPSend}`, {
        method: "post",
        headers: {
          "Content-Type": "application/json",
          "x-auth-secret": `${apiConfig.key}`,
        },
        body: JSON.stringify(data),
      });
      const res = await response.json();
      this.setState({resendOtpLoader:false,btnLoader:false});
      return res;
    } catch (e) {
      return e;
    }
  }
  checkMobileNumber = async(e) => {
    const { number,selectedAddress }= this.state;
    if(number.length == 10){
      let numberValid = false;

      if(number[0] === '6' || number[0] === "7" || number[0] === "8" || number[0] === "9" )
        numberValid = true;
        
      if(numberValid){
        this.setState({otpSent:true,btnLoader:false});
        this.sentOtp();
      }
      else{
        this.setState({phoneError:'Please enter correct phone number starting from 6/7/8/9'});
      }
    }else{
      this.setState({phoneError:'Please enter a valid phone number'});
    }
  }
  sentOtpAgain = () => {
    this.setState({resendOtpLoader:true});
    this.sentOtp();
  }
  verifyOtp = async () => {
    this.setState({btnLoader:true});
    let { otp, number } = this.state; 
    let data = {
      'phone':number,
      'otp':otp
    }
    try{
      let res = await fetch(`${apiConfig.baseUrl}${apiConfig.preOrderOTPVerify}`,{
        headers: {
          "Content-Type": "application/json",
          "x-auth-secret": `${apiConfig.key}`,
        },
          body: JSON.stringify(data)
      })
      let response = res.json();
      if(response.data.status == '200'){
        this.setState({otpVerified:true,finalStep:true,btnLoader:false});
      }else{
        this.setState({otpError:true,btnLoader:false});
      }
    }
    catch(e){

    }
    
  }
  editOtpNumber = () => {
    this.setState({otpSent:false,otpError:false,otp:''});
  }

  addressSelectHandler = (index,addres,name) =>{
    // debugger
    let addressObj = this.state.selectedAddress.key === index ? {
      key:'',
      address:'',
      personname:''
    } : {
      key:index,
      address:addres,
      personname:name
    };
    this.setState({selectedAddress:addressObj,phoneError:''})
  }

  handleAddAddress = (val)=>{
    this.setState({addAddress:val,phoneError:''})
  }

  render() {
    const { selectedVariant, product, productName,toggleModale,addressArray } = this.props;
    const { number, btnLoader, phoneError,otpSent,otpVerified, otp, finalStep, resendOtpLoader, otpError, selectedAddress, addAddress } = this.state;
    const { options } = product;

    let vimg = this.findVariantImages(selectedVariant.title);
    let Style = {};
    let price = (selectedVariant.price * 25) / 100;
    if (this.checkVariantType(options[0]) === "color" && vimg) {
      Style = { backgroundImage: `url(${vimg})` };
    }
    // temprory code 
    let index=selectedAddress.key;
    let MyAddresses = addressArray ? addressArray.map((obj,i)=>{

      return <div className='single-address' key={obj.id}>
        <div className='add-info'>
          <h6 className='customer-name'>{obj.name}</h6>
          <p className='area-add'>
            {obj.address1}<br/>
            {obj.address2}<br/>
            {obj.city}, {obj.province}, {obj.zip}
          </p>
        </div>
        <span className={`address-checkbox ${index == obj.id ? 'selected':''}`} onClick={()=>this.addressSelectHandler(obj.id,'bb','aa')} > { index == obj.id &&  HtmlParser('&#10003;') }   </span>
      </div>
    }) : '';
    // end temprory code
    return (
      <div className="preorder-modal flex-view">
        <div className='img popup-logo'><SrcSet src={pwa.icons.popupLogo} /> </div>
        <div className='cross-sign' onClick={() => toggleModale(false)} >
          &#10005;
        </div>
        <div className="product-details-side col-sm-6">
          <div className="product-details">
            <SrcSet src={selectedVariant.featured_image.src} alt="" />
            <div className="price-part">
              <div className="product-name">
                <div className="flex-view space-between">
                  <h5 className='color-white col-sm-6 col-xs-6'>{productName}</h5>
                  <div className="product-price col-sm-6 col-xs-6">
                    <div className='pric-info'>
                      <h5 className="price">
                        {formatMoney(parseInt(selectedVariant.price))}
                      </h5>
                      {selectedVariant.compare_at_price &&
                        selectedVariant.compare_at_price > selectedVariant.price && (
                          <h5 className="compare">
                            {formatMoney(
                              parseInt(selectedVariant.compare_at_price)
                            )}
                          </h5>
                        )}
                    </div>
                  </div>

                </div>
                <div className="variants-details">
                  <div className="variant-color" style={Style}></div>
                </div>
                  <div className="variant-name">{selectedVariant.title}</div>
              </div>

            </div>
          </div>
        </div>
        <div className="product-form col-sm-6">
          <div className="details">
            {otpSent && otpVerified && finalStep && addAddress === false ? <div>
              <div>
                <h5>Shipping address: <span className='add-address' onClick={()=>{this.handleAddAddress(true)}}>+ Add</span> </h5>
                <div className='addresses'>
                  {MyAddresses}
                </div>  
              </div>
              
            </div> 
            : 
            <div>
              {addAddress && <div className='img back-add-address' onClick={()=>{this.handleAddAddress(false)}}> <SrcSet src={pwa.icons.preorderaddressback} /> </div>}
              <h5>{ addAddress ? 'Add a address:' : 'The Best Just Got Better' }</h5>
              {addAddress ? '':<p>Pre-book Buds solo and avail an additional <b> bonus of {formatMoney(parseInt(selectedVariant.price))} </b> on purchase.</p>}  
            </div>}
            <form onSubmit={(e) => this.handleSubmit(e)}>
              {phoneError !== '' && <label className='error-message' >{phoneError}</label>}
              {!otpSent && !otpVerified && !finalStep && addAddress === false &&
                <div>
                  <label className='mobile-label'>Mobile number</label>
                  <input
                    type="number"
                    id="phonenumber"
                    name="Phone number"
                    placeholder="Phone Number"
                    className="bop-fl"
                    value={number}
                    onChange={(e) => {
                      if(e.target.value.length<=10){
                        this.setState({ number: e.target.value,phoneError:'' });
                      }
                    }}
                  />
                </div>
              }
              <div className='preorder-submit'>
                {!otpSent && !otpVerified && !finalStep &&
                  <button className={`submit btn ${btnLoader ? 'loading':''}`} type="button" onClick={this.checkMobileNumber}>
                    Proceed and Pay {formatMoney(parseInt(selectedVariant.price))}
                  </button>
                }
                {otpSent && !finalStep &&
                  <>
                    <p className='otp-info'>We have sent an OTP on your registered mobile number {number} <span className="edit-number-btn" onClick={this.editOtpNumber}>Edit number</span></p>
                    <label className="otp-label">Enter the OTP</label>
                    <OtpInput
                      value={otp}
                      onChange={(e) => {this.setState({ otp: e,otpError: false });}}
                      numInputs={6}
                      separator={<span className='otp-seprator'></span>}
                      inputStyle="otp-input"
                      containerStyle="otp-container"
                      isInputNum={true}
                    />
                    {/* <input type="number" name="preorder-otp" value={otp} onChange={(e) => {if(e.target.value.length<=6){this.setState({ otp: e.target.value });}}}></input> */}
                    {otpError && <span className="error-otp-msg">OTP not matched</span>}
                    <button className={`btn bttn ${resendOtpLoader ? 'loading':''}`} onClick={this.sentOtpAgain} type="button">
                      Resend OTP
                    </button>
                    <button className={`btn bttn ${btnLoader ? 'loading':''}`} onClick={this.verifyOtp} type="button">
                      Verify OTP
                    </button>
                  </>
                }
                {otpSent && otpVerified && finalStep && addAddress === false && <div className='complete-order'><button className={`submit btn ${btnLoader ? 'loading':''}`} type="submit">
                  Complete Preorder
                </button></div>}
              </div>
            </form>
          
            {addAddress && <PreorderModalAddAddress handleAddAddress={this.handleAddAddress} />}
          </div>
        </div>
      </div>
    );
  }
}


const mapStateToProps = (state) => ({
  addressLoading: state.account.addressLoading,
  addressArray: state.account.profile.addresses,
});

const mapDispatchToProps = (dispatch) => ({
  getPreOrder: (data) => dispatch(getPreOrder(data)),
  fetchAccountInfo: (data) => dispatch(fetchAccountInfo(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(PreorderModal);
