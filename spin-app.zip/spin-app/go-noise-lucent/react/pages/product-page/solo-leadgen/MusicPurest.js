import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import MediaQuery from "../../../components/MediaQuery";
import Srcset from "../../../components/SrcSet";

export class MusicPurest extends Component {
  render() {
    const { metaData } = this.props;
    let {
      image_1,
			image_2,
			image_3,
      image_xs_1,
			image_xs_2,
      image_xs_3,
      title_1,
			title_2,
			title_3,
      content_1,
			content_2,
			content_3,
			icon_text_3,
      icon_image_1,
    } = metaData;
    let icondata1 = [];
    icon_image_1 = icon_image_1.split(';');
    let pushItem =
      metaData["icon_text_1"] &&
      metaData["icon_text_1"].split(";").map((item, index) => {
        return (
          <li className="icon-text-li" key={index}>
            {icon_image_1 && <img src={icon_image_1[index]} alt={item} />}
            <span>{HtmlParser(item)}</span>
          </li>
        );
      });
    icondata1.push(pushItem);

    let icondata2 = [];
    pushItem =
      metaData["icon_text_2"] &&
      metaData["icon_text_2"].split(";").map((item, index) => {
        return (
          <li className="icon-text-li" key={index}>
            <span>{HtmlParser(item)}</span>
          </li>
        );
      });
		icondata2.push(pushItem);
		
		let timeInfoHtml = icon_text_3.split('<>').map((ele,ind)=>{
			let timeAndInfo = ele.split(';');
			return <li key={ind}>
				<h1 className='time'>{timeAndInfo[0]}</h1>
				<h5 className='info'>{timeAndInfo[1]} </h5>
			</li>
		})
		
    return (
      <div className="custom-section">
        <MediaQuery query="lap-and-up">
          <div className="section-1">
            <div className="text-wrapper">
              <h1 className="title">{title_1}</h1>
              <p className="content">{content_1}</p>
              <ul className="icon-text-wrap">{icondata1}</ul>
            </div>
            <div className="img">
              <Srcset src={image_1} />
            </div>
          </div>
          <div className="section-2">
            <div className="text-wrapper">
              <h1 className="title">{title_2}</h1>
              <p className="content">{content_2}</p>
              <ul className="icon-text-wrap">{icondata2}</ul>
            </div>
          </div>
					<div className="section-3">
						<div className='custom-row flex-view-xs'>
							<div className='img'>
								<Srcset src={image_3} />
							</div>
							<div className='text-wrapper'>
								<h1 className='title'>{title_3}</h1>
								<p className='content'>{content_3}</p>
								<ul className='time-info'>
									{timeInfoHtml}
								</ul>
							</div>
						</div>
					</div>
				</MediaQuery>
        <MediaQuery query="phone-and-tablet">
          <div className="section-1">
            <div className="img">
              <Srcset src={image_xs_1} />
            </div>
            <div className="text-wrapper">
              <h1 className="title">{title_1}</h1>
              <p className="content">{content_1}</p>
              <ul className="icon-text-wrap">{icondata1}</ul>
            </div>
          </div>
          <div className="section-2">
            <div className="relative">
            <div className="text-wrapper">
              <h1 className="title">{title_2}</h1>
              <p className="content">{content_2}</p>
              <ul className="icon-text-wrap">{icondata2}</ul>
            </div>
            <div className="img">
              <Srcset src={image_xs_2} />
            </div>
            </div>
          </div>
					<div className="section-3">
						<div className='custom-row'>
							<div className='img'>
								<Srcset src={image_3} />
							</div>
							<div className='text-wrapper'>
								<h1 className='title'>{title_3}</h1>
								<p className='content'>{content_3}</p>
								<ul className='time-info'>
									{timeInfoHtml}
								</ul>
							</div>
						</div>
					</div>
				</MediaQuery>
      </div>
    );
  }
}

export default MusicPurest;
