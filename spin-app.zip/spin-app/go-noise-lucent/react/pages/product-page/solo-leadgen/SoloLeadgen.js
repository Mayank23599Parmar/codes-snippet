import React from "react";
import ReactModal from "react-modal";
/* Redux */
import { connect } from "react-redux";

import Loading from "../../../components/loader/loader";
import ErrorPage from "../../errorpage/ErrorPage";
import Srcset from "../../../components/SrcSet";
import NotifyPopup from "../Notifypopup";
import {fetchProductTitle} from '../../../components/Helper'

class SoloLeadgen extends React.Component {
	constructor(props) {
		super(props)
	
		this.state = {
			showNotifypop: false
		}
	}
	toggleModale = (value) => {
    this.setState({ showNotifypop :value });
  };
	
  render() {
		const { launchImages } = this.props.productData.metafields;
		let actual_title =  this.props.productData.product.title;
    let tagTitle = fetchProductTitle(this.props.productData.product.tags);
    if (tagTitle) {
      actual_title = tagTitle;
    }
    const {
      bannerimage_1,
      bannerimage_2,
      bannerimage_3,
      bannerimage_4,
      bannerimage_5,
      bannerimage_6,
      bannerimage_7,
      bannerimage_8,
		} = launchImages;
		const {showNotifypop} = this.state;
    return (
      <div className="leadgen-container">
        <Srcset src={bannerimage_1} />
        {showNotifypop && <NotifyPopup title={actual_title} head="AN OFFER YOU CAN’T REFUSE" subhead="Register your email address below to receive an exciting launch offer in your mailbox." message="Thanks. Your offer will be on its way soon."  variant="ab" toggleModale={this.toggleModale}   toggleModale={this.toggleModale} />}

        <Srcset src={bannerimage_2} />
        <div className="banner-image" onClick={(e)=>{
							e.preventDefault();
							this.toggleModale(true)
						}} >
          {/* <div className="btn-div cart-add-btn">
            <button className='btn' onClick={(e)=>{
							e.preventDefault();
							this.toggleModale(true)
						}} >Register Now</button>
          </div> */}
          <Srcset src={bannerimage_3} />
        </div>

        <Srcset src={bannerimage_4} />

        <Srcset src={bannerimage_5} />

        <Srcset src={bannerimage_6} />

        <Srcset src={bannerimage_7} />

        <Srcset src={bannerimage_8} />
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  productData: state.product,
});
export default connect(mapStateToProps, null)(SoloLeadgen);
