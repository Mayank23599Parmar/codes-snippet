import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import MediaQuery from "../../components/MediaQuery";
import Srcset from "../../components/SrcSet";
class PlayImageWithText extends Component {
  render() {
    let { play_image_with_text } = this.props;
    if (Object.keys(play_image_with_text).length === 0) {
      return false;
    }
    let items = [];
    for (let i = 1; i < 20; i++) {
      let icon_image;
      if (play_image_with_text["icon_image_" + i]) {
        icon_image = play_image_with_text["icon_image_" + i].split(";");
      }
      let image_type = "left";
      if (play_image_with_text["image_type_" + i]) {
        image_type = play_image_with_text["image_type_" + i];
      }

      let padding = "";
      if (image_type == "left_full" || image_type == "right_full") {
        padding = "padding_none";
      }
      let top_title = play_image_with_text["top_title_" + i];
      if(!top_title){
        top_title = '';
      }
      let title = play_image_with_text["title_" + i];
      let content_text = play_image_with_text["content_" + i];
      let image = play_image_with_text["image_" + i];
      let image_main_icon = play_image_with_text["image_main_icon_" + i];
      let bg_color = "#000";
      let font_color = "#fff";
      let classType = '';
      if (!cn(play_image_with_text["background_color_" + i])) {
        bg_color = play_image_with_text["background_color_" + i];
      }
      if (!cn(play_image_with_text["text_color_" + i])) {
        font_color = play_image_with_text["text_color_" + i];
      }
      let content_type = 'left';
      if(play_image_with_text['content_type_'+i]){
        content_type = play_image_with_text['content_type_'+i];
      }
      let Style = {
        backgroundColor: bg_color,
        color: font_color,
      };
      if (image_type === "banner") {
        let content = (
          <div className="image-text-section">
            <div className={`banner-type banner-type-${i}`}>
              <MediaQuery query="phone-and-tablet"><Srcset src={play_image_with_text["image_xs_" + i] ? play_image_with_text["image_xs_" + i] : image} /></MediaQuery>
              <MediaQuery query="lap-and-up"><Srcset src={image} /></MediaQuery> 
              <div className={`text-wrap ${content_type}`}>
                  <div className="container">
                    <div className="text">
                        {title && <h2 style={{color:font_color}} className="header-title">{HtmlParser(title)}</h2>}
                        {content_text && <p style={{color:font_color}} className="header-sub-title">{HtmlParser(content_text)}</p>}
                        <ul className="icon-text-wrap">
                          {play_image_with_text["icon_text_" + i] &&
                            play_image_with_text["icon_text_" + i]
                              .split(";")
                              .map((item, index) => {
                                return (
                                  <li className="icon-text-li" key={index}>
                                    {icon_image[index] && (
                                      <img src={icon_image[index]} alt={item} />
                                    )}
                                    <span>{HtmlParser(item)}</span>
                                  </li>
                                );
                              })}
                      </ul>
                    </div>
                  </div>
              </div>
            </div>
          </div>
        )
        items.push(content);
      }else if(image_type === "container_image") {
        let content = <div className="image container-image" style={Style}>
          <div className="container">
            <Srcset src={image} alt={title} />
          </div>
        </div>
        items.push(content);
      }
      else {
        
        if (image) {
          let content = (
            <div className={`image-text-section image-text-section-${i}`}>
              <div className="image-text-wrap">
                <div
                  className={`image-with-text-section ${padding}`}
                  key={i}
                  style={Style}
                >
                  <div className="container">
                    <div className={`${image_type} image-text-inner-wrap`}>
                      <div className="text-wrap">
                        <h3 className="header-top-title header-title">{HtmlParser(top_title)}</h3>
                        <h2 className="header-title">{HtmlParser(title)}</h2>
                        <p className="header-sub-title">{HtmlParser(content_text)}</p>
                        <ul className="icon-text-wrap">
                          {play_image_with_text["icon_text_" + i] &&
                            play_image_with_text["icon_text_" + i]
                              .split(";")
                              .map((item, index) => {
                                return (
                                  <li className="icon-text-li" key={index}>
                                    {icon_image[index] && (
                                      <img src={icon_image[index]} alt={item} />
                                    )}
                                    <span>{HtmlParser(item)}</span>
                                  </li>
                                );
                              })}
                        </ul>
                      </div>
                      <div className="image-wrap">
                        <MediaQuery query="phone-and-tablet"><Srcset src={play_image_with_text["image_xs_" + i] ? play_image_with_text["image_xs_" + i] : image} /></MediaQuery>
                        <MediaQuery query="lap-and-up"><Srcset src={image} /></MediaQuery>
                        {image_main_icon && <div className="sec-main-icon"><Srcset src={image_main_icon} /></div>}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
          items.push(content);
        } 
      }
    }
    if (items.length > 0) {
      return <>{items}</>;
    }
    return null;
  }
}

export default PlayImageWithText;
