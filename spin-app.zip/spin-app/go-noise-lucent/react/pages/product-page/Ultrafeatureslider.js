import React, { Component } from "react";
import Slider from 'react-slick';
import Srcset from "../../components/SrcSet";
import HtmlParser from "react-html-parser";


export class Ultrafeatureslider extends Component {
  render() {
    const { noisefitSlider } = this.props;
    let items = [];
    let settings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
      nextArrow:<span><img className="arrow-shift" src="https://cdn.shopify.com/s/files/1/0997/6284/files/Right_arrow.png?v=1626306149" style={{width: '20px',margin: '7px 9px'}} alt='next-arrow'/></span>,
      prevArrow:<span><img className="arrow-shift" src="https://cdn.shopify.com/s/files/1/0997/6284/files/Left_arrow.png?v=1626306149" style={{width: '20px',margin: '7px 5px'}} alt='prev-arrow'/></span>
    };
    for (let i = 1; i < 20; i++) {
        let feature_icon;
        let feature_text;
        let poster_image;
      let slider_image;
      let content;
      let title;
      let slider_static_image;
      
      if (noisefitSlider["video_" + i]) {
        slider_image = noisefitSlider["video_" + i];
      }
      if (noisefitSlider["feature_image_" + i]) {
        slider_static_image = noisefitSlider["feature_image_" + i];
      }
      if (noisefitSlider["poster_image_" + i]) {
        poster_image = noisefitSlider["poster_image_" + i];
      }
      if (noisefitSlider["feature_text_" + i]) {
        feature_text = noisefitSlider["feature_text_" + i];
      }
      if (noisefitSlider["feature_icon_" + i]) {
        feature_icon = noisefitSlider["feature_icon_" + i];
      }
      
      if (noisefitSlider["feature_content_" + i]) {
        content = noisefitSlider["feature_content_" + i];
      }
      if (noisefitSlider["feature_title_" + i]) {
        title = noisefitSlider["feature_title_" + i];
      }
      if (
        slider_static_image &&
        poster_image &&
        feature_text &&
        feature_icon &&
        slider_image &&
        content &&
        title 
      ) {
        items.push({
            slider_static_image:slider_static_image,
            poster_image: poster_image,
            feature_icon: feature_icon,
            feature_text: feature_text,
          slider_image: slider_image,
          content: content,
          title: title
        });
      }
    }
    let sliderElements = items.map((item, index) => {
      return (
        <div className="slider-element">
          <div className="flex-view">
            
            <div className='image-area col-sm-6'>
              <div className='img'>
              {/* <video
                        width="100%"
                        height="100%"
                        controls={false}
                        autoPlay="true"
                        className="video-container video-container-overlay"
                        autoPlay="true"
                        loop
                        playsInline
                        muted={true}
                        poster={item.poster_image}
                    >
                  <source src={item.slider_image} type="video/mp4"  />
                </video> */}
                <Srcset src={item.slider_static_image} />
              </div>
            </div>
            <div className='text-area col-sm-6'>
              <div className='text'>
                <h3 className='color-white'>{HtmlParser(item.title)}</h3>
                <p className='color-white'>{HtmlParser(item.content)}</p>
                <div className="line"></div>
                <div className="icon-wrapper"><span><Srcset src={item.feature_icon}  /> {HtmlParser(item.feature_text)}</span></div>
              </div>
            </div>
          </div>
        </div>
      );
    });
    if(items.length<1){
      return false;
    }

    //return null;

    return  (
    <div className='noisefit-silder ultra-feature-slider'>
			<div className='container'>
        {/* <h1 className='text-align-center color-white title'>{noisefitSlider.title}</h1> */}
				<Slider {...settings}>
					{sliderElements}
				</Slider>
			</div>
		</div>
    );
    
  }

}

export default Ultrafeatureslider;
