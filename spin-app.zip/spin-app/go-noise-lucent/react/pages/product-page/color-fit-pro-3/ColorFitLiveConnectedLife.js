import React from "react";
import MediaQuery from "../../../components/MediaQuery";
import Srcset from "../../../components/SrcSet";
import HtmlParser from "react-html-parser";

class ColorFitLiveConnectedLife extends React.Component {
  render() {
    const { settings } = this.props;
    // Live a connected life
    const {
      connected_life_left_img,
      connected_life_title,
      connected_life_content,
      connected_life_icon_with_text,
      connected_life_social_icon,
      connected_life_right_img,
      connected_life_img_mobile
    } = settings;
    
    
    return (
      <div className={`image-text-section`}>
        {connected_life_left_img && (
          <MediaQuery query="lap-and-up">
            <div className="image-left-side">
              <Srcset src={connected_life_left_img} alt={connected_life_title} />
            </div>
          </MediaQuery>
        )}
        <div className="text-wrap">
          {connected_life_title && <h2 className="title">{HtmlParser(connected_life_title)}</h2>}
          {connected_life_content && (
            <div className="content">{HtmlParser(connected_life_content)}</div>
          )}
          <ul className="icon-text-wrap">
            {connected_life_icon_with_text &&
              connected_life_icon_with_text.split(";").map((item, index) => {
                const itemDetails = item.split("<>");
                return (
                  <li className="icon-text-li" key={index}>
                    <img src={itemDetails[1]} alt={itemDetails[0]} />
                    <span>{HtmlParser(itemDetails[0])}</span>
                  </li>
                );
              })}
          </ul>
          {connected_life_social_icon && <div className="social-icon-img">
            <Srcset src={connected_life_social_icon} alt={connected_life_title} />
          </div>}
        </div>
        <div className="right-side-image">
          {connected_life_right_img && (
            <MediaQuery query="lap-and-up">
              <div className="image-wrap">
                <Srcset src={connected_life_right_img} alt={connected_life_title} />
              </div>
            </MediaQuery>
          )}
          {connected_life_img_mobile && (
            <MediaQuery query="phone-and-tablet">
              <div className="image-wrap">
                <Srcset src={connected_life_img_mobile} alt={connected_life_title} />
              </div>
            </MediaQuery>
          )}
        </div>
      </div>
    );
  }
}
export default ColorFitLiveConnectedLife;
