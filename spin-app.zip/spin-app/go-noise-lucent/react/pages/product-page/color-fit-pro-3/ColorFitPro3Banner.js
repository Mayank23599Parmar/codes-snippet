import React from 'react';
import MediaQuery from '../../../components/MediaQuery';
import SrcSet from '../../../components/SrcSet';

class ColorFitPro3Banner extends React.Component{
  render(){
    const {settings} = this.props;
    const {banner_image,banner_image_xs,banner_title,banner_sub_title} = settings;
    return(
      <div className="color-fit-pro3-banner">
        <div className="container">
          <div className="image">
              {banner_image && 
              <MediaQuery query="lap-and-up">
              <SrcSet alt="img" src={banner_image} /></MediaQuery>
              }          
              {banner_image_xs &&<MediaQuery query="phone-and-tablet">
              <SrcSet alt="img" src={banner_image_xs} /></MediaQuery>
              }
          </div>
          <div className="text">
            <h1 className="banner-title">{banner_title}</h1>
            <h3 className="banner-subtitle">{banner_sub_title}</h3>
          </div>
        </div>
      </div>
    )
  }
}
export default ColorFitPro3Banner;