import React from "react";
/* Redux */
import { connect } from "react-redux";
/* Actions */
import {setVariant} from '../../../redux/product/productAction';
/* helper */
// import { queryString, queryStringVariant } from '../../../components/Helper';
/* Comp imports */
import Loading from "../../../components/loader/loader";
import ErrorPage from "../../errorpage/ErrorPage";
import ProductSlider from '../ProductSlider';
import ProductVideo from "../ProductVideo";
import SpecificationSection from "../SpecificationSection";
import FAQSection from '../FAQSection';
import ProductReview from '../ProductReview';
import ProductBar from '../ProductBar';
import ColorFitPro3Banner from './ColorFitPro3Banner';
import ColorFitPro3Main from './ColorFitPro3Main';
import ColorFitPro3Features from "./ColorFitPro3Features";
import ColorFitPro3Last from './ColorFitPro3Last';
import SEODisclaimerSection from '../SEODisclaimerSection';
import SEOQuestions from '../SEOQuestions';
import RelatedProductsSection from '../RelatedProductsSection';
import Offersimple from '../Offersimple';
import MediaQuery from '../../../components/MediaQuery';
class ColorFitPro3Template extends React.Component {
  constructor(props) {
    super(props)
    this.prodRef = React.createRef();
    this.featureRef = React.createRef();
    this.state = {
      showBar: false
    }
  }

  componentDidMount() {
    window.addEventListener('scroll', this.handleScroll);
    // const { setVariant, productData } = this.props;
    // let queryStringsData = queryString(location.href);
    // if(queryStringsData.variant){
    //   let passVariant = productData.product.variants.find((vari)=>{
    //     return vari.id === parseInt(queryStringsData.variant.value);
    //   })
    //   if(passVariant){
    //     setVariant(passVariant);
    //   }
    // }
    // else{
    //   queryStringVariant(productData.variant);
    //   // this.props.history.push(`?variant=${}`)
    // }
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.handleScroll);
  }

  handleScroll = (event) => {
    let productSection = this.prodRef.current;
    let featureSection = this.featureRef.current;
    
   // if(window.pageYOffset <= featureSection.offsetTop && (window.pageYOffset + 100)  > productSection.offsetTop ){
    if(window.pageYOffset <= (featureSection.offsetTop - 500) && (window.pageYOffset + 200)  > productSection.offsetTop ){

      this.setState({showBar: false})
    }
    else{
      this.setState({showBar: true})
    }
  }

  render() {
    const {  loading, product, settings,metafields,relatedProducts } = this.props.productData;
    const { showBar } = this.state
    let settingsFound = false;
    let video_section = {url_desktop:'',video_url_mobile:'',youtube_video_url:'',video_text:'',video_subtext:''};
    let offer2 = product.tags.includes("offer2") ? true : false;
    let feature = {};
    if(!cn(settings)){
      settingsFound = true;
      // feature object
      const {watch_image,watch_image_mobile, watch_description} = settings; 
      feature = {title:'',content_text:'',image:watch_image,image_xs:watch_image_mobile,icon_text:watch_description,icon_image:''}
      // Video object
      const {video_url,video_url_mobile,youtube_video_url,video_text,video_subtext} = settings;
      video_section = {url_desktop:video_url,url_xs:video_url_mobile,youtube_video_url:youtube_video_url,title:video_text,sub_title:video_subtext};

    }
    if (loading) {
      return <Loading />;
    }
    if (!product) {
      return <ErrorPage show={true} />;
    }
    
    return (
      <div id="Color-fir-pro-3">
        {offer2 &&
        <MediaQuery query="phone">
       {showBar &&<Offersimple product={product} prodRef={(this.prodRef)} />}
       </MediaQuery>
        }
       <ProductBar prodRef={(this.prodRef)} />
        {settingsFound && <ColorFitPro3Banner settings={settings} />}
        <div className="color-fit-pro-3-product" ref={this.prodRef}><ProductSlider metaData={metafields} /></div>
        {settingsFound && <div className="color-fit-pro-3-features" ref={this.featureRef}><ColorFitPro3Features key='feature-section' image_with_text={feature}/></div>}
        {settingsFound && <ProductVideo video_section={video_section} />}
        {settingsFound && <ColorFitPro3Main settings={settings} />}

        <ColorFitPro3Last />
        {metafields.specifications && <SpecificationSection specifications={metafields.specifications} />}
        {metafields.FAQ && <FAQSection FAQ={metafields.FAQ} />}
        {metafields.review && <ProductReview product={product} review={metafields.review} />}
        {metafields.SEODisclaimer  && <SEODisclaimerSection data={metafields.SEODisclaimer} />}
        {relatedProducts && relatedProducts.length > 0 && <RelatedProductsSection productList={relatedProducts} />}
        {metafields.SEOQuestions && <SEOQuestions data={metafields.SEOQuestions} /> }
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  productData: state.product,
});

const mapDispatchToProps = dispatch => ({
  setVariant: variant => dispatch(setVariant(variant))
});

export default connect(mapStateToProps,mapDispatchToProps)(ColorFitPro3Template);
