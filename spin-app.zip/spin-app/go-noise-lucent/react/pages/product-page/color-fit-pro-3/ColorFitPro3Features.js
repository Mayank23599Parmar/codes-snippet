import React from 'react';
import MediaQuery from '../../../components/MediaQuery';
import Srcset from '../../../components/SrcSet';
import HtmlParser from "react-html-parser";

class ColorFitPro3Features extends React.Component{
  render(){
    const {image_with_text} = this.props;;
    const {title,image,image_xs,content_text} = image_with_text;
    return(
      <div className={`image-text-section`}>
        <div className="image-text-wrap">
          <div className={`image-with-text-section`}>
            <div className={`image-text-inner-wrap`}>
              {image && <MediaQuery query="lap-and-up">
                <div className="image-wrap">
                  <Srcset src={image} alt={title} />
                </div>
              </MediaQuery>}
              {image_xs && <MediaQuery query="phone-and-tablet">
                <div className="image-wrap">
                  <Srcset src={image_xs} alt={title} />
                </div>
              </MediaQuery>}
                <div className="text-wrap">
                  {title && <h2 className="title">{HtmlParser(title)}</h2>}
                  {content_text && <div className="content">{HtmlParser(content_text)}</div>}
                  <ul className="icon-text-wrap">
                    {image_with_text["icon_text"] &&
                      image_with_text["icon_text"].split(";").map((item, index) => {
                          const itemDetails = item.split('<>'); 
                          return (
                            <li className="icon-text-li" key={index}>  
                              <img src={itemDetails[1]} alt={itemDetails[0]} />
                              <span>{HtmlParser(itemDetails[0])}</span>
                            </li>
                          );
                        })}
                  </ul>
                </div>
              </div>
          </div>
        </div>
      </div>
    )
  }
}
export default ColorFitPro3Features;