import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import Srcset from "../../components/SrcSet";
import MediaQuery from "../../components/MediaQuery";

class Ultramainvideo extends Component {
    render() {
        //const { ultra_two_watch } = this.props;
        
    
        return (
          <div>
              
              <div className="two-watch desktop-staic main-video">
                  <div className="image-container">
                    {/* <video
                        playsInline
                        width="100%"
                        height="100%"
                        controls={false}
                        autoPlay="true"
                        className="video-container video-container-overlay"
                        autoPlay="true"
                        loop
                        playsinline
                        muted={true}
                        poster="https://cdn.shopify.com/s/files/1/0997/6284/files/watch_anim_solo.png?v=1626302342"
                    >
                  <source src="https://cdn.shopify.com/s/files/1/0997/6284/files/watch_anim_solo.mp4?v=1626291286" type="video/mp4"  />
                </video> */}
                <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/Untitled-2_50626d06-ef4a-4f56-af25-90c28139af4d.png?v=1626684756"  />
                  </div>
              </div>
             
          </div>
        );
      }
}

export default Ultramainvideo;
