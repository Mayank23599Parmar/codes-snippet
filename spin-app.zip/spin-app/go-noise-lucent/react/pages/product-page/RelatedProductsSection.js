import React, { Component } from "react";
import Slider from "react-slick";
import { connect } from 'react-redux';
import RelatedSimplyProduct from "./RelatedSimplyProduct";
import MediaQuery from '../../components/MediaQuery';


export class RelatedProductsSection extends Component {
  constructor(props) {
    super(props)

    this.state = {
      productsLimit: 4
    };
  }


  loadMoreProducts = () => {
    const { customRelatedProduct } = this.props;
    const { productsLimit } = this.state;
    let productsShow;
    if (customRelatedProduct) {
      productsShow = 11;
    }
    else {
      productsShow = 10;
    }
    this.setState({ productsLimit: productsShow });

  }

  render() {
    let settings = {
      dots: false,
      infinite: true,
      centerMode: false,
      speed: 500,
      slidesToShow: 4,
      slidesToScroll: 1,
      arrows: true,
      nextArrow: (
        <span className="right-arrow">
          <img
            src="https://cdn.shopify.com/s/files/1/0997/6284/files/icons8-more-than-48.png?v=1606242875"
            style={{ width: "45px", margin: "7px 9px" }}
            alt="next-arrow"
          />
        </span>
      ),
      prevArrow: (
        <span className="left-arrow">
          <img
            src="https://cdn.shopify.com/s/files/1/0997/6284/files/icons8-less-than-48.png?v=1606242875"
            style={{ width: "45px", margin: "7px 5px" }}
            alt="prev-arrow"
          />
        </span>
      ),
    };
    const { productList, customRelatedProduct } = this.props;
    const { productsLimit } = this.state;
    let allRelatedProdcuts = [];
    if (customRelatedProduct) {
      allRelatedProdcuts.push(customRelatedProduct);
      productList.forEach(x => {
        if (x.id !== customRelatedProduct.id) {
          allRelatedProdcuts.push(x);
        }
      })
    }
    else {
      allRelatedProdcuts = productList;
    }


    let ProductsHtml = allRelatedProdcuts.map((prod, i) => {
      if (window.innerWidth < 1025) {
        if (i < productsLimit) {
          return (
            <li key={i} className='product-item '>
              <RelatedSimplyProduct product={prod} />
            </li>
          );
        }
      }
      else {
        return (
          <li key={i} className='product-item '>
            <RelatedSimplyProduct product={prod} />
          </li>
        );
      }
    });
    return (
      <div id="related-products-section" className="related-products-section ">
        <div className='container'>
          <h2 className="main-title">You may also like:</h2>
          <div className='product-list'>
            <MediaQuery query="lap-and-up">
              <Slider {...settings}>{ProductsHtml}</Slider>
            </MediaQuery>
            <MediaQuery query="phone-and-tablet">
              <ul className="list flex-view-xs">
                {ProductsHtml}
              </ul>
              {productsLimit < 10 &&
                <div className='loadmore-btn'>
                  <button className='btn' onClick={this.loadMoreProducts}> See More </button>
                </div>
              }
            </MediaQuery>
          </div>

        </div>
      </div>
    );
  }
}
const mapStateToProps = state => ({
  customRelatedProduct: state.product.customRelatedProduct,
});

export default connect(mapStateToProps, null)(RelatedProductsSection);
