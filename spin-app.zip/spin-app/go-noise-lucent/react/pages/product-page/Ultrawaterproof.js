import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import Srcset from "../../components/SrcSet";
import MediaQuery from "../../components/MediaQuery";

class Ultrawaterproof extends Component {
    render() {
        const { ultra_waterproof} = this.props;
        
    
        return (
          <div>
             
              <div className="Ultra-app-slider ultra-menstural ultra-waterproof">
              <div className="containers">
              <div className="slider-element">
              <div className="flex-view">
              
                <MediaQuery query="lap-and-up">
                
                <div className='text-area col-sm-6'>
                  <div className='text'>
                    <h3>{HtmlParser(ultra_waterproof.content)}</h3>
                    <p className='color-white'>{HtmlParser(ultra_waterproof.para)}</p>
                    {/* <span>Up to 9-day battery<sup>*</sup></span>
                    <div className="iconimage"><span>IP68 waterproof</span></div> */}
                  </div>
                </div>
                <div className='image-area col-sm-6'>
                  <div className='img'>
                  {/* <video
                  playsInline
                  width="100%"
                  height="100%"
                  controls={false}
                  autoPlay="true"
                  className="video-container video-container-overlay"
                  autoPlay="true"
                  loop
                  poster="https://cdn.shopify.com/s/files/1/0997/6284/files/water_watch.jpg?v=1626309510"
                  muted={true}
                >
                  <source src={ultra_waterproof.video} type="video/mp4" />
                </video> */}
                <Srcset src={ultra_waterproof.image} />
                  </div>
                </div>
                </MediaQuery>
                <MediaQuery query="phone-and-tablet">
                <div className='text-area col-sm-6'>
                  <div className='text'>
                    <h3>{HtmlParser(ultra_waterproof.content)}</h3>
                    <p className='color-white'>{HtmlParser(ultra_waterproof.para)}</p>
                    <span>Up to 9-day battery<sup>*</sup></span>
                    <div className="iconimage"><span>IP68 waterproof</span></div>
                  </div>
                </div>
                <div className='image-area col-sm-6'>
                  <div className='img'>
                  {/* <video
                  width="100%"
                  height="100%"
                  controls={false}
                  autoPlay="true"
                  className="video-container video-container-overlay"
                  autoPlay="true"
                  loop
                  poster="https://cdn.shopify.com/s/files/1/0997/6284/files/water_watch.jpg?v=1626309510"
                  muted={true}
                >
                  <source src={ultra_waterproof.video} type="video/mp4" />
                </video> */}
                <Srcset src={ultra_waterproof.image} />
                  </div>
                </div>
                
                </MediaQuery>
                
                
              </div>
            </div>
              </div>
            </div>
                
              
          </div>
        );
      }
}

export default Ultrawaterproof;
