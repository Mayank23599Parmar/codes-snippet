import React, { Component } from "react";
// import HtmlParser from "react-html-parser";
import MediaQuery from "../../components/MediaQuery";
import Srcset from "../../components/SrcSet";
class ActiveRoundWatch extends Component {
  render() {
    let { active_round_image } = this.props;
    if (Object.keys(active_round_image).length === 0) {
      return false;
    }
    let items = [];
    for (let i = 1; i < 20; i++) {
      let icon_image;
      if (active_round_image["icon_image_" + i]) {
        icon_image = active_round_image["icon_image_" + i].split(";");
      }
      let image_type = "left";
      if (active_round_image["image_type_" + i]) {
        image_type = active_round_image["image_type_" + i];
      }

      let padding = "";
      if (image_type == "left_full" || image_type == "right_full") {
        padding = "padding_none";
      }
      let title = active_round_image["title_" + i];
      let content_text = active_round_image["content_" + i];
      let image = active_round_image["image_" + i];
      let image_round = active_round_image["image_round_" + i];
      let useTitle = active_round_image["paraextra_" + i];
      let useImage = active_round_image["extraimage_" + i];
      
      let bg_color = "#000";
      let font_color = "#fff";
      let classType = '';
      if (!cn(active_round_image["background_color_" + i])) {
        bg_color = active_round_image["background_color_" + i];
      }
      if (!cn(active_round_image["text_color_" + i])) {
        font_color = active_round_image["text_color_" + i];
      }
      let content_type = 'left';
      if(active_round_image['content_type_'+i]){
        content_type = active_round_image['content_type_'+i];
      }
      let Style = {
        backgroundColor: bg_color,
        color: font_color,
      };
      if (image_type === "banner") {
        let content = (
          <div className="image-text-section Active-round-watch">
            <div className={`banner-type banner-type-${i}`}>
                <div className="round-backround-image">
                <MediaQuery query="phone-and-tablet"><Srcset src={active_round_image["image_xs_" + i] ? active_round_image["image_xs_" + i] : image} /></MediaQuery>
                <MediaQuery query="lap-and-up"><Srcset src={image} /></MediaQuery> 
                </div>
                <div className="round-backround-image-watch">
                <MediaQuery query="phone-and-tablet"><Srcset src={active_round_image["image_round_xs_" + i] ? active_round_image["image_round_xs_" + i] : image_round} /></MediaQuery>
                <MediaQuery query="lap-and-up"><Srcset src={image_round} /></MediaQuery> 
                </div>
            </div>
          </div>
        )
        items.push(content);
      }
    }
    if (items.length > 0) {
      return <>{items}</>;
    }
    return null;
  }
}

export default ActiveRoundWatch;
