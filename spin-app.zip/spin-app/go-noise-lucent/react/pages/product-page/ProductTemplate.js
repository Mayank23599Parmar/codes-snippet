import React from "react";
/* Redux */
import { connect } from "react-redux";
/* Actions */
import {setVariant} from '../../redux/product/productAction';
/* helper */
// import { queryString, queryStringVariant } from '../../components/Helper';
/* Comp imports */
import Loading from "../../components/loader/loader";
// import ErrorPage from "../errorpage/ErrorPage";
import ProductBanner from "./ProductBanner";
import FeaturedImage from "./FeaturedImage";
import ProductSlider from './ProductSlider';
// import CustomerReview from "./CustomerReview";
import ProductVideo from "./ProductVideo";
import ImageWithText from "./ImageWithText";
import InTheBoxSection from "./InTheBoxSection";
import SpecificationSection from "./SpecificationSection";
import FAQSection from './FAQSection';
import ProductReview from './ProductReview';
// import CompareProducts from './CompareProducts';
import ProductBar from './ProductBar';
import TextWithTitle from './TextWithTitle';
import WarrantySection from './WarrantySection';
import NoisfitappSlider from './NoisfitappSlider';
import SEODisclaimerSection from './SEODisclaimerSection';
import SEOQuestions from './SEOQuestions';
import RelatedProductsSection from './RelatedProductsSection';
import StrapProductDesc from './StrapProductDesc';
import LazyLoad from 'react-lazyload';
import Offersimple from './Offersimple';
import MediaQuery from '../../components/MediaQuery';


class ProductTemplate extends React.Component {
  constructor(props) {
    super(props)
    this.prodRef = React.createRef();
    this.featureRef = React.createRef();
    this.state = {
      showBar: false
    }
  }

  componentDidMount() {
    window.addEventListener('scroll', this.handleScroll);
    // const { setVariant, productData } = this.props;
    // let queryStringsData = queryString(location.href);
    // if(productData.product){
    //   if(queryStringsData.variant){
    //     let passVariant = productData.product.variants.find((vari)=>{
    //       return vari.id === parseInt(queryStringsData.variant.value);
    //     })
    //     if(passVariant){
    //       setVariant(passVariant);
    //     }
    //   }
    //   else{
    //     queryStringVariant(productData.variant);
    //   }
    // }
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.handleScroll);
  }

  handleScroll = (event) => {
    let productSection = this.prodRef.current;
    let featureSection = this.featureRef.current;
    //if(window.pageYOffset <= (productSection.offsetTop + 200) && (window.pageYOffset + 100)  > productSection.offsetTop ){
    if(window.pageYOffset <= (featureSection.offsetTop - 500) && (window.pageYOffset + 200)  > productSection.offsetTop ){
      //console.log('scroll',window.pageYOffset,featureSection.offsetTop,productSection.offsetTop);
      this.setState({showBar: false})
    }
    else{
      this.setState({showBar: true})
    }
  }

  render() {
    const { metafields, loading, product, compareProducts, relatedProducts } = this.props.productData;
    const { showBar } = this.state
    //console.log(product.description);
    let prodDesc = product.description;
    let descproduct = product.tags.includes("strap-description") ? true : false;
    let offer2 = product.tags.includes("offer2") ? true : false;
    if (loading) {
      return <Loading />;
    }
    
    if(cn(metafields)){
      return(
        <div>
        <ProductBar prodRef={(this.prodRef)} />
        <div ref={this.prodRef}><ProductSlider metaData={metafields} /></div>
        </div>
      )
    }

    return (
      <div>
        {offer2 &&
        <MediaQuery query="phone">
       {showBar &&<Offersimple product={product} prodRef={(this.prodRef)} />}
       </MediaQuery>
        }
       <ProductBar prodRef={(this.prodRef)} />
        {metafields.banner_section && <div><ProductBanner banner_section={metafields.banner_section}  /></div>}
        <div ref={this.prodRef}><ProductSlider metaData={metafields} /></div>
        {prodDesc && descproduct && <div><StrapProductDesc product={product} /></div>}
        {metafields.feature_section && <div ref={this.featureRef}><FeaturedImage feature_section={metafields.feature_section} /></div>}
        {/* {metafields.customer_review && <CustomerReview customer_review={metafields.customer_review} />} */}
        <LazyLoad height={200}>
        {metafields.video_section && <ProductVideo video_section={metafields.video_section} />}
        </LazyLoad>
        {metafields.text_with_title && <TextWithTitle text_with_title={metafields.text_with_title}/>}
        {metafields.image_with_text && <ImageWithText image_with_text={metafields.image_with_text} />}
        {metafields.box_section && <InTheBoxSection box_section={metafields.box_section} />}
        {metafields.noisefitSlider && <NoisfitappSlider noisefitSlider={metafields.noisefitSlider} />}
        {metafields.specifications && <SpecificationSection specifications={metafields.specifications} />}
        {/* {compareProducts && <CompareProducts compareProducts={compareProducts} />} */}
        {metafields.warrantySection && <WarrantySection warrantyData={metafields.warrantySection} />}
        {metafields.FAQ && <FAQSection FAQ={metafields.FAQ} />}
        <LazyLoad height={200}>
        {metafields.review && <ProductReview product={product} review={metafields.review} />}
        </LazyLoad>
        {metafields.SEODisclaimer  && <SEODisclaimerSection data={metafields.SEODisclaimer} />}
        <LazyLoad height={200}>
        {relatedProducts && relatedProducts.length > 0 && <RelatedProductsSection productList={relatedProducts} />}
        </LazyLoad>
        {metafields.SEOQuestions && <SEOQuestions data={metafields.SEOQuestions} /> }
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  productData: state.product,
});
const mapDispatchToProps = dispatch => ({
  setVariant: variant => dispatch(setVariant(variant))
});
export default connect(mapStateToProps,mapDispatchToProps)(ProductTemplate);
