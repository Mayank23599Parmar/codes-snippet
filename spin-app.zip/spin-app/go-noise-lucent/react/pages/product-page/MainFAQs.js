import React, { Component } from "react";
import HtmlParser from 'react-html-parser';
import ReactModal from "react-modal";
export class MainFAQs extends Component {
  constructor(props) {
    super(props);
    this.customStyles = {
      overlay:{
        zIndex: 100
      },
      content: {
        top: "50%",
        left: "50%",
        right: "auto",
        bottom: "auto",
        marginRight: "-50%",
        transform: "translate(-50%, -50%)",
        position:"absolute",
        backgroundColor: "#000",
        maxWidth:'600px',
        padding: '0px',
        width: "calc(100% - 20px)"
      },
    };
    this.state = {
      showDropDown: false,
      showVideoModal: false,
    };
  }

  clickEvent = () => {
    if(document.querySelector(".product-youtube-popup")){
      document.querySelector(".product-youtube-popup").addEventListener("click",(e)=>{
        e.preventDefault();
        let url = e.currentTarget.getAttribute('href');
        let id = url.split('v=')[1].split('&')[0];
        let embedUrl = 'https://www.youtube.com/embed/'+id;
        this.setState({showVideoModal:true, video_url:embedUrl });
      });
    }
  }
  toggleModale = (value) => {
    this.setState({ showVideoModal: value });
  };
  toggleClass = () => {
    const { showDropDown } = this.state;
    this.setState({ showDropDown: !showDropDown },()=>{
      this.clickEvent();
    });
  }
  render() {
    const { title, eleArr } = this.props;
    const { showDropDown, video_url, showVideoModal  } = this.state;
    let liElements =
      eleArr &&
      eleArr.map((content, index) => {
        let contArray = content.split(" que#");
        let que = contArray[0];
        contArray = contArray[1].split(" ans#");
        let ans = contArray[0];
        return (
          <li key={index} className="inner-spec">
            <span className="bullet-point"><p className='color-white'><b>{que ? que : ""}</b></p></span>
            <span><p className='color-white'>{ans ? HtmlParser(ans) : ""}</p></span>
          </li>
        );
      });

    return (
      <>
        <li className="main-spec"
          onClick={this.toggleClass}
        >
          <p className={`color-white add-sign ${showDropDown ? "active" : ""}`}>{title}</p>
          <ul className="specifications-inner">{showDropDown && liElements}</ul>
        </li>
        <ReactModal
          isOpen={showVideoModal}
          contentLabel="onRequestClose Example"
          onRequestClose={() => this.toggleModale(false)}
          shouldCloseOnOverlayClick={true}
          style={this.customStyles}
      >
        <div className="video-popup-wrap">
        <iframe
          playsInline
          width="100%"
          height="100%"
          src={video_url}
          className="video-container video-container-overlay modal-video"
        >
        </iframe></div>
      </ReactModal>
      </>
    );
  }
}

export default MainFAQs;
