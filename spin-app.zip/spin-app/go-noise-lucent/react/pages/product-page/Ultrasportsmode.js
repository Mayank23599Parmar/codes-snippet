import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import Srcset from "../../components/SrcSet";
import MediaQuery from "../../components/MediaQuery";

class Ultrasportsmode extends Component {
    render() {
        const { ultra_sports_mode} = this.props;
        
    
        return (
          <div>
             
              <div className="Ultra-app-slider ultra-menstural ultra-sports-mode">
              <div className="containers">
              <div className="slider-element">
              <div className="flex-view">
              <div className='image-area col-sm-6'>
                  <div className='img'>
                  {/* <video
                  playsInline
                  width="100%"
                  height="100%"
                  controls={false}
                  autoPlay="true"
                  className="video-container video-container-overlay"
                  autoPlay="true"
                  loop
                  poster="https://cdn.shopify.com/s/files/1/0997/6284/files/anim_6.jpg?v=1626305585"
                  muted={true}
                >
                  <source src={ultra_sports_mode.video} type="video/mp4" />
                </video> */}
                <Srcset src={ultra_sports_mode.image} />
                  </div>
                </div>
                <MediaQuery query="lap-and-up">
                <div className='text-area col-sm-6'>
                  <div className='text'>
                    <h3>{HtmlParser(ultra_sports_mode.content)}</h3>
                    <p className='color-white'>{HtmlParser(ultra_sports_mode.para)}</p>
                    <div className="line"></div>
                    <div className="iconimage"><span><Srcset src={ultra_sports_mode.iconimage} /> {HtmlParser(ultra_sports_mode.title)}</span></div>
                  </div>
                </div>
                </MediaQuery>
                <MediaQuery query="phone-and-tablet">
                <div className='text-area col-sm-6'>
                  <div className='text'>
                    <h3>{HtmlParser(ultra_sports_mode.content)}</h3>
                    <p className='color-white'>{HtmlParser(ultra_sports_mode.para_xs)}</p>
                    <div className="iconimage"><span><Srcset src={ultra_sports_mode.iconimage} /> {HtmlParser(ultra_sports_mode.title)}</span></div>
                  </div>
                </div>
                </MediaQuery>
                
                
              </div>
            </div>
              </div>
            </div>
                
              
          </div>
        );
      }
}

export default Ultrasportsmode;
