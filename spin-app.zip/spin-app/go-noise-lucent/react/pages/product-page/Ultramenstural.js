import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import Srcset from "../../components/SrcSet";
import MediaQuery from "../../components/MediaQuery";

class Ultramenstural extends Component {
    render() {
        const { ultra_menstural } = this.props;
        
    
        return (
          <div>
              <MediaQuery query="lap-and-up">
              <div className="Ultra-app-slider ultra-menstural">
              <div className="containers">
              <div className="slider-element">
              <div className="flex-view">
              <div className='image-area col-sm-6'>
                  <div className='img'>
                  {/* <video
                  width="100%"
                  height="100%"
                  controls={false}
                  autoPlay="true"
                  playsInline
                  className="video-container video-container-overlay"
                  autoPlay="true"
                  loop
                  poster="https://cdn.shopify.com/s/files/1/0997/6284/files/anim_5.jpg?v=1626304882"
                  muted={true}
                >
                  <source src={ultra_menstural.video} type="video/mp4" />
                </video> */}
                <Srcset src={ultra_menstural.image} />
                  </div>
                </div>
                <div className='text-area col-sm-6'>
                  <div className='text'>
                    <h3>{HtmlParser(ultra_menstural.content)}</h3>
                    <p className='color-white'>{HtmlParser(ultra_menstural.para)}</p>
                    <div className="line"></div>
                    <div className="iconimage"><span><Srcset src={ultra_menstural.iconimage} /> {HtmlParser(ultra_menstural.title)}</span></div>
                  </div>
                </div>
                
              </div>
            </div>
              </div>
            </div>
                  </MediaQuery> 
              <MediaQuery query="phone-and-tablet">
              <div className="Ultra-app-slider ultra-menstural">
              <div className="containers container-mobile">
              <div className="slider-element">
              <div className="flex-view">
              <div className='image-area col-sm-6'>
                  <div className='img'>
                  {/* <video
                  width="100%"
                  height="100%"
                  controls={false}
                  autoPlay="true"
                  className="video-container video-container-overlay"
                  autoPlay="true"
                  loop
                  poster="https://cdn.shopify.com/s/files/1/0997/6284/files/anim_5.jpg?v=1626304882"
                  muted={true}
                >
                  <source src={ultra_menstural.video} type="video/mp4" />
                </video> */}
                <Srcset src={ultra_menstural.image} />
                  </div>
                </div>
                <div className='text-area col-sm-6'>
                  <div className='text'>
                    <h3 className="title">Say goodbye to guessing</h3>
                    <p className='color-white'>{HtmlParser(ultra_menstural.para)}</p>
                    <div className="icon-wrapper">
                        <span><Srcset src={ultra_menstural.iconimage} /> {HtmlParser(ultra_menstural.title)}</span>
                    </div>
                  </div>
                </div>
                
              </div>
            </div>
              </div>
            </div>
                </MediaQuery>
          </div>
        );
      }
}

export default Ultramenstural;
