import React, { Component } from 'react';
import HtmlParser from 'react-html-parser'
import Srcset from '../../components/SrcSet';
class FeaturedImage extends Component {
  render() {
    let { feature_section } = this.props;
    if (Object.keys(feature_section).length === 0) {
      return null;
    }

    if(!feature_section.icon_image){
      return null;
    }
    let icon_image = feature_section.icon_image.split(';');

    let bg_color = '#000';
    let font_color = '#fff';
    if (!cn(feature_section["background_color"])) {
      bg_color = feature_section["background_color"];
    }
    if (!cn(feature_section["text_color"])) {
      font_color = feature_section["text_color"];
    }
    let Style = {
      backgroundColor: bg_color,
      color: font_color,
    };
    if(feature_section.type == 'horizontal'){
      return(
        <div id='horizontal-feature-section' style={Style} className="horizontal-feature-section background-black">
          <div className="container">
          <ul className="flex-view center space-between">
            {feature_section.icon_text && feature_section.icon_text.split(';').map((item,index)=>{
                return(<li className="icon-text-li" style={Style} key={index}>
                  <div className="img"><img src={icon_image[index]} alt={item}/></div>
                  <span>{HtmlParser(item)}</span>
                </li>)
              })}
          </ul></div>
        </div>
      )  
    }
    return (
    <div id='feature-section' className="feature-section background-black">
      <div className="container">
        <div className="feature-image-text flex-view-xs space">
          {feature_section.image && <div className="col-sm-6 img-wrapper">
            <Srcset src={feature_section.image}/>
          </div>}
          <div className="col-sm-6 text-wrapper">
            {feature_section.title && <h2 className="header-title color-white">{HtmlParser(feature_section.title)}</h2>}
            {feature_section.sub_title && <h5 className="header-sub-title color-white">{feature_section.sub_title}</h5>}
            <ul className="icon-text-wrap">
              {feature_section.icon_text && feature_section.icon_text.split(';').map((item,index)=>{
                return(<li className="icon-text-li color-white" key={index}>
                  <img src={icon_image[index]} alt={item}/>
                  <span>{HtmlParser(item)}</span>
                </li>)
              })}
            </ul>
          </div>
        </div>	
      </div>
    </div>
    );
  }
}


export default FeaturedImage;