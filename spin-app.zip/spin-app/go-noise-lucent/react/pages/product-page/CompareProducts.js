import React, { Component } from 'react'
import Slider from "react-slick";
import SingleCompareProduct from './SingleCompareProduct';
export class CompareProducts extends Component {

  render() {
    const { compareProducts } = this.props;
    if(compareProducts.length === 0){
      return false;
    }
    let products = compareProducts.map((product,index)=>{
      return <SingleCompareProduct key={index} productData={product} />
    })
    let slidesToShow;
    let centerModeOn;
    if(screen.width < 768){
      slidesToShow = 1;
      centerModeOn = true;
    }
    else{
      slidesToShow = 3;
      centerModeOn = false 
    }
    let settings = {
      dots: false,
      infinite: true,
      centerMode: false,
      speed: 500,
      slidesToShow: 3,
      slidesToScroll: 1,
      arrows: true,
      nextArrow:<span className='right-arrow'><img src="https://cdn.shopify.com/s/files/1/0997/6284/files/icons8-more-than-48.png?v=1606242875" style={{width: '50px',margin: '7px 9px'}} alt='next-arrow'/></span>,
      prevArrow:<span className='left-arrow'><img src="https://cdn.shopify.com/s/files/1/0997/6284/files/icons8-less-than-48.png?v=1606242875" style={{width: '50px',margin: '7px 5px'}} alt='prev-arrow'/></span>,
      responsive: [
        {
          breakpoint: 767,
          settings: {
            slidesToShow: 1,
            centerMode: true
          }
        }
      ]
    };
    return (
      <div className='compare-product-section background-black' >
        <div className="container">
        <h2 className="header-title color-white">Compare Specifications</h2>
          <div className='compare-slider'>
            <Slider {...settings}>
              {products}
            </Slider>
          </div>
        </div>
      </div>
    )
  }
}

export default CompareProducts
