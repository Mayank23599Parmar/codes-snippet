import React, { Component } from "react";
import { connect } from "react-redux";
import {addAddress, setLoader } from '../../redux/account/accountActions'
export class PreorderModalAddAddress extends Component {
  constructor(props) {
    super(props)
  
    this.state = {
      first_name: '',
      last_name: '',
      phone: '',
      address1: '',
      address2: '',
      city: '',
      state: '',
      country: '',
      pincode: '',
      btnLoader: false,
      formError:'',
      formErrors: {
        first_name: '',
        last_name: '',
        phone: '',
        address1: '',
        address2: '',
        city: '',
        state: '',
        country: '',
        pincode: '',
      },
    }
  }

  handleOnChange = (e) =>{
    let error,value,name=e.target.name;
    console.log(e.target.value.length);
    if(name==='phone'){
      if(e.target.value.length<=10){
        value=e.target.value;
        this.setState({[e.target.name]:value});
      }
    }
    else if(name==='pincode'){
      if(e.target.value.length<=6){
        value=e.target.value;
        this.setState({[e.target.name]:value});
      }
    }
    else{
      value=e.target.value;
      this.setState({[e.target.name]:value});
    }
  }
  
  handleValidation = () =>{
    const { first_name,last_name,phone,address1,address2,city,state,country,pincode,btnLoader,formError } = this.state;
    let errors = '';
    if (first_name === "") {
      errors = "First name can't be blank";
    }
    else if (last_name === "") {
      errors = "Last name can't be blank";
    }
    else if (address1 === "") {
      errors = "Address 1 can't be blank";
    }
    else if (address2 === "") {
      errors = "Address 2 can't be blank";
    }
    else if (phone.length !== 10) {
      errors = "Enter valid Phone number";
    }
    else if (city === "") {
      errors = "City can't be blank";
    }
    else if (state === "") {
      errors = "State can't be blank";
    }
    else if (country === "") {
      errors = "Country can't be blank";
    }
    else if (pincode.length !== 6) {
      errors = "Enter valid Pincode";
    }
    return errors;
  }

  handleFormSubmit =(e) =>{
    e.preventDefault();
    let hasErrors = this.handleValidation();
    const reqObj = {
      first_name: this.state.first_name,
      last_name: this.state.last_name,
      phone: this.state.phone,
      address1: this.state.address1,
      address2: this.state.address2,
      city: this.state.city,
      state: this.state.state,
      country: this.state.country,
      pincode: this.state.pincode,
    };
    if(hasErrors.length>0){
      this.setState({formError:hasErrors})
    }
    else{
      this.props.addAddress(reqObj);
      this.props.handleAddAddress(false);
    }

  }
  render() {

    const { first_name,last_name,phone,address1,address2,city,state,country,pincode,btnLoader,formError } = this.state;


    return (
      <div className='add-newaddress'>
        <form onSubmit={this.handleFormSubmit}>
          <div className='add-newaddress-inputs '>
              <label>First name</label>
              <input 
                onChange={this.handleOnChange}
                placeholder='First name'
                value={first_name}
                name='first_name'
                type="text"
              />
              <label>Last name</label>
              <input 
                onChange={this.handleOnChange}
                placeholder='Last name'
                value={last_name}
                name='last_name'
                type="text"
              />
              <label>Phone Number</label>
              <input
                onChange={this.handleOnChange}
                placeholder='Phone number'
                value={phone}
                name='phone'
                type="number"
              />
              <label>Address Line 1</label>
              <input
                onChange={this.handleOnChange}
                placeholder='Enter your address'
                value={address1}
                name='address1'
                type="text"
              />
              <label>Address Line 2</label>
              <input 
                onChange={this.handleOnChange}
                placeholder='Enter your address'
                value={address2}
                name='address2'
                type="text"
              />
              <label>City</label>
              <input
                onChange={this.handleOnChange}
                placeholder='City'
                value={city}
                name='city'
                type="text"
              />
              <label>State / Province</label>
              <input
                onChange={this.handleOnChange}
                placeholder='State'
                value={state}
                name='state'
                type="text"
              />
              <label>Country</label>
              <input
                onChange={this.handleOnChange}
                placeholder='Country'
                value={country}
                name='country'
                type="text"
              />
              <label>Zip Code</label>
              <input
                onChange={this.handleOnChange}
                placeholder='Zip code'
                value={pincode}
                name='pincode'
                type="number"
              />
          </div>
          <div className='error'>{formError.length > 0 ? `${formError}` : ``}</div>
          <button className={`submit btn ${btnLoader ? 'loading':''}`} type="submit">Submit</button>
        </form>
      </div>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  addAddress: (data) => dispatch(addAddress(data)),
  setLoader: (data) => dispatch(setLoader(data)),
});

export default connect(null, mapDispatchToProps)(PreorderModalAddAddress);
