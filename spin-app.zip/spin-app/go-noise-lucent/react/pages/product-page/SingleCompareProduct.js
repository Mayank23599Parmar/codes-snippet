import React, { Component } from 'react'
import { connect } from 'react-redux';
import VariantSelector from '../../components/VariantSelector';
import { formatMoney, fetchProductTitle } from '../../components/Helper';
import { addToCart } from '../../redux/cart/cartAction';
export class SingleCompareProduct extends Component {
  constructor(props) {
    super(props)

    this.state = {
      selectedVariant: null
    }
  }

  updateSelectedVariant = (variant) => {
    this.setState({selectedVariant:variant})
  }

  buyNow =(selectedVariant) =>{
    const form = { id: parseInt(selectedVariant.id), quantity: 1 }
    const data = {
      "type": 'cart',
      form
    }
    this.props.addToCart(data);
  }

  render() {
    const { productData } = this.props;
    const { product, swatchImages, comparePerameters } = productData;
    const { variants, options } = product;
    const { selectedVariant } = this.state;
    let actual_title = product.title;
    let tagTitle = fetchProductTitle(product.tags);
    if(tagTitle){
      actual_title = tagTitle;
    }
    let variantPass
    if (selectedVariant)
      variantPass = selectedVariant;
    else {
      variantPass = product.selected_or_first_available_variant ? product.selected_or_first_available_variant : product.variants[0];
    }
    let perameters = comparePerameters.perameters.split(', ');
    let showPerameters = perameters.map((perameter,index) =>{
      return <p className='color-white' key={index} >{index+1}. {' '+perameter}</p>
    })
    return (
      <div className='compare-product' >
        <img className='prodtuct-img' src={variantPass.featured_image?variantPass.featured_image.src:''} alt={variantPass.featured_image?variantPass.featured_image.alt:''} />
        <h5 className='product-title' >{actual_title}</h5>
        <div className="product-price">
          <p className="price">{formatMoney(parseInt(variantPass.price))}</p>
          {variantPass.compare_at_price && variantPass.compare_at_price > variantPass.price &&
            <p className="compare">
              {formatMoney(parseInt(variantPass.compare_at_price)).substring(1)}
            </p>}
        </div>
        <div className={`variants-wrapper`}>
          {options.map((option, index) => {
            return (
              <ul key={index} className="swatch-wrap">
                {variants.map((variant) => {
                  return <VariantSelector
                    key={variant.id}
                    option={option}
                    selectedVariant={variantPass}
                    variant={variant}
                    variantImages={swatchImages}
                    setSelectedVariant={this.updateSelectedVariant}
                  />;
                })}
              </ul>
            );
          })}
        </div>
        <div className='compare-perameters'>
          <ol>
            {showPerameters}
          </ol>
        </div>
        <div className='cart-add-btn' name='cart'>
          <button type="button" onClick={()=>this.buyNow(variantPass)}>
            Buy Now
          </button>
        </div>
      </div>
    )
  }
}
const mapDispatchToProps = dispatch => (
  {
    addToCart: data => dispatch(addToCart(data))
  }
)
export default connect(null, mapDispatchToProps)(SingleCompareProduct)
