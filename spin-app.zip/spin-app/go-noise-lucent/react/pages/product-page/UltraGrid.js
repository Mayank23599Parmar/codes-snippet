import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import Srcset from "../../components/SrcSet";
import MediaQuery from "../../components/MediaQuery";

class UltraGrid extends Component {
  render() {
    const { ultra_grid } = this.props;
    //console.log(this.props);
    

    return (
      <div>
        <div className="Ultra-grid-section">
          <div className="containers">
          <MediaQuery query="lap-and-up">
            <div className="flex-container-desktop">
                {/* <div className="flex-div">
                    <div className="section-1">
                        <h3>{HtmlParser(ultra_grid.ultra_grid_text_1)}</h3>
                        <div className="image-container">
                        <Srcset src={ultra_grid.ultra_grid_image_1} alt={ultra_grid.ultra_grid_text_1} />
                        </div>
                    </div>
                    <div className="section-2">
                        <h3>{HtmlParser(ultra_grid.ultra_grid_text_2)}</h3>
                        <div className="image-container">
                        <Srcset src={ultra_grid.ultra_grid_image_2} alt={ultra_grid.ultra_grid_text_2} />
                        </div>
                    </div>

                </div>
                <div className="flex-div">
                <div className="section-3">
                        <h3>{HtmlParser(ultra_grid.ultra_grid_text_3)}</h3>
                        <div className="image-container">
                        <Srcset src={ultra_grid.ultra_grid_image_3} alt={ultra_grid.ultra_grid_text_3} />
                        </div>
                    </div>
                    <div className="section-4">
                        <h3>{HtmlParser(ultra_grid.ultra_grid_text_4)}</h3>
                        <div className="image-container">
                        <Srcset src={ultra_grid.ultra_grid_image_4} alt={ultra_grid.ultra_grid_text_4} />
                        </div>
                    </div>
                </div>
                <div className="flex-div">
                <div className="section-5">
                        <h3>{HtmlParser(ultra_grid.ultra_grid_text_5)}</h3>
                        <div className="image-container">
                        <Srcset src={ultra_grid.ultra_grid_image_5} alt={ultra_grid.ultra_grid_text_5} />
                        </div>
                    </div>
                </div>
                <div className="flex-full">
                <div className="section-6">
                        <h3>{HtmlParser(ultra_grid.ultra_grid_text_6)}</h3>
                        <div className="image-container">
                        <Srcset src={ultra_grid.ultra_grid_image_6} alt={ultra_grid.ultra_grid_text_6} />
                        </div>
                    </div>

                </div> */}
                <Srcset src={ultra_grid.desktop_main} alt={ultra_grid.ultra_grid_mobile_text_1} />
                {/* <p>*Some watch faces shown here<br/>will be available via OTA</p> */}
            </div>
          </MediaQuery>
          <MediaQuery query="phone-and-tablet">
            <div className="flex-container-mobile">
                <div className="flex-full">
                    <div className="section-1">
                            <h3>{HtmlParser(ultra_grid.ultra_grid_mobile_text_1)}</h3>
                            <div className="image-container">
                            <Srcset src={ultra_grid.ultra_grid_mobile_image_1} alt={ultra_grid.ultra_grid_mobile_text_1} />
                            </div>
                        </div>

                    </div>
                <div className="flex-div">
                    <div className="section-2">
                        <h3>{HtmlParser(ultra_grid.ultra_grid_mobile_text_2)}</h3>
                        <div className="image-container">
                        <Srcset src={ultra_grid.ultra_grid_mobile_image_2} alt={ultra_grid.ultra_grid_mobile_text_2} />
                        </div>
                    </div>
                    <div className="section-3">
                    <h3>{HtmlParser(ultra_grid.ultra_grid_mobile_text_4)}</h3>
                        <div className="image-container">
                        <Srcset src={ultra_grid.ultra_grid_mobile_image_4} alt={ultra_grid.ultra_grid_mobile_text_4} />
                        </div>
                    </div>

                </div>
                <div className="flex-div">
                <div className="section-4">
                       
                        <h3>{HtmlParser(ultra_grid.ultra_grid_mobile_text_3)}</h3>
                        <div className="image-container">
                        <Srcset src={ultra_grid.ultra_grid_mobile_image_3} alt={ultra_grid.ultra_grid_mobile_text_3} />
                        </div>
                    </div>
                    <div className="section-5">
                        <h3>{HtmlParser(ultra_grid.ultra_grid_text_5)}</h3>
                        <div className="image-container">
                        <Srcset src={ultra_grid.ultra_grid_mobile_image_5} alt={ultra_grid.ultra_grid_mobile_text_5} />
                        </div>
                    </div>
                </div>
                
                <div className="flex-full">
                <div className="section-6">
                        <h3>{HtmlParser(ultra_grid.ultra_grid_mobile_text_6)}</h3>
                        <div className="image-container">
                        <Srcset src={ultra_grid.ultra_grid_mobile_image_6} alt={ultra_grid.ultra_grid_mobile_text_6} />
                        </div>
                    </div>

                </div>
                <p>*Some watch faces shown here<br/>will be available via OTA</p>
            </div>
          </MediaQuery>
          </div>
        </div>
      </div>
    );
  }
}

export default UltraGrid;