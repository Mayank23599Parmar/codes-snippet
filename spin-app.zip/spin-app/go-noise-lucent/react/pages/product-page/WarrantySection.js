import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import Srcset from "../../components/SrcSet";
import MediaQuery from "../../components/MediaQuery"
export class WarrantySection extends Component {
  render() {
    const { warrantyData } = this.props;
    if (Object.keys(warrantyData).length === 0) {
      return false;
    }
    let image_type = "left";
    if (warrantyData.image_type) {
      image_type = warrantyData.image_type;
    }
    let bg_color = "#000";
    let font_color = "#fff";
    if (!cn(warrantyData.background_color)) {
      bg_color = warrantyData.background_color;
    }
    if (!cn(warrantyData.text_color)) {
      font_color = warrantyData.text_color;
    }
    let content_type = 'left';
    if(warrantyData.content_type){
      content_type = warrantyData.content_type;
    }
    let Style = {
      backgroundColor: bg_color,
      color: font_color,
    };
    let htmlContent;
    if (image_type === "banner-type") {
      htmlContent = (
        <div className="product-warranty-section" style={Style}>
          <div className="banner-warranty">
            <div className="banner-warranty-image">
              <MediaQuery query="phone-and-tablet"><Srcset src={warrantyData.image_xs ? warrantyData.image_xs : warrantyData.image} /></MediaQuery>
              <MediaQuery query="lap-and-up"><Srcset src={warrantyData.image} /></MediaQuery> 
            </div>
            <div className={`text-area ${content_type}`}>
              <div className="textarea-wrapper">
                <h3 style={{color:warrantyData.text_color}}>{HtmlParser(warrantyData.title)}</h3>
                <div className="content-wrap">
                  <p style={{color:warrantyData.text_color}}>{warrantyData.content}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    } else {
      htmlContent = (
        <div className="product-warranty-section" style={Style}>
          <div className="container">
            <div className={`flex-view ${image_type}`}>
              <div className="col-sm-6">
                <div className={`image-wrapper`}>
                  <Srcset src={warrantyData.image} />
                </div>
              </div>
              <div className="col-sm-6 text-area">
                <div className="textarea-wrapper">
                  <h3 style={Style}>{HtmlParser(warrantyData.title)}</h3>
                  <div className="content-wrap">
                    <p style={Style}>{warrantyData.content}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }
    return htmlContent;
  }
}

export default WarrantySection;
