import React, { Component } from "react";
// import HtmlParser from "react-html-parser";
import MediaQuery from "../../components/MediaQuery";
import Srcset from "../../components/SrcSet";
class ActiveSportsMode extends Component {
  render() {
    let { Active_Sports_Mode } = this.props;
    if (Object.keys(Active_Sports_Mode).length === 0) {
      return false;
    }
    let items = [];
    for (let i = 1; i < 20; i++) {
      let icon_image;
      if (Active_Sports_Mode["icon_image_" + i]) {
        icon_image = Active_Sports_Mode["icon_image_" + i].split(";");
      }
      let image_type = "left";
      if (Active_Sports_Mode["image_type_" + i]) {
        image_type = Active_Sports_Mode["image_type_" + i];
      }

      let padding = "";
      if (image_type == "left_full" || image_type == "right_full") {
        padding = "padding_none";
      }
      let title = Active_Sports_Mode["title_" + i];
      let content_text = Active_Sports_Mode["content_" + i];
      let image = Active_Sports_Mode["image_" + i];
      let image_round = Active_Sports_Mode["image_round_" + i];
      let useTitle = Active_Sports_Mode["paraextra_" + i];
      let useImage = Active_Sports_Mode["extraimage_" + i];
      
      let bg_color = "#000";
      let font_color = "#fff";
      let classType = '';
      if (!cn(Active_Sports_Mode["background_color_" + i])) {
        bg_color = Active_Sports_Mode["background_color_" + i];
      }
      if (!cn(Active_Sports_Mode["text_color_" + i])) {
        font_color = Active_Sports_Mode["text_color_" + i];
      }
      let content_type = 'left';
      if(Active_Sports_Mode['content_type_'+i]){
        content_type = Active_Sports_Mode['content_type_'+i];
      }
      let Style = {
        backgroundColor: bg_color,
        color: font_color,
      };
      if (image_type === "banner") {
        let content = (
          <div className="image-text-section active-sports-mode">
            <div className={`banner-type banner-type-${i}`}>
                <div className="round-backround-image">
                <MediaQuery query="phone-and-tablet"><Srcset src={Active_Sports_Mode["image_xs_" + i] ? Active_Sports_Mode["image_xs_" + i] : image} /></MediaQuery>
                <MediaQuery query="lap-and-up"><Srcset src={image} /></MediaQuery> 
                </div>
                <div className="round-backround-image-watch">
                <MediaQuery query="phone-and-tablet"><Srcset src={Active_Sports_Mode["image_round_xs_" + i] ? Active_Sports_Mode["image_round_xs_" + i] : image_round} /></MediaQuery>
                <MediaQuery query="lap-and-up"><Srcset src={image_round} /></MediaQuery> 
                </div>
            </div>
          </div>
        )
        items.push(content);
      }
    }
    if (items.length > 0) {
      return <>{items}</>;
    }
    return null;
  }
}

export default ActiveSportsMode;
