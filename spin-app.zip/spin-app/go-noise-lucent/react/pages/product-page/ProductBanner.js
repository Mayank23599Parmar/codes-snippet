import React, { Component } from 'react';
import HtmlParser from 'react-html-parser'
import Srcset from '../../components/SrcSet';
import MediaQuery from '../../components/MediaQuery';
class ProductPage extends Component {
    callBack = (e) =>{
        e.target.closest('.product-banner-img').style['min-height'] = "auto";
    }
  render() {
    let { banner_section } = this.props;
    if(cn(banner_section.image) || cn(banner_section.image_xs)){
        return null;
    }
    return (
      <div id='banner-section' className="banner-section">
        {banner_section.idc_image && 
        <div className="idc-section">
            <Srcset alt="idc-logo" src={banner_section.idc_image} />
        </div>}
        <div className="img product-banner-img">
        {banner_section.image && 
            <MediaQuery query="lap-and-up">
                <Srcset alt="img" src={banner_section.image} callBack={this.callBack}/>
            </MediaQuery>}
            {banner_section.image_xs &&
            <MediaQuery query="phone-and-tablet">
                <Srcset alt="img" src={banner_section.image_xs} callBack={this.callBack} />
            </MediaQuery>}
        </div>
        <div className="text-area">
                <div className="text-wrapper">
                {banner_section.title &&
                    <h3 className="color-white">{HtmlParser(banner_section.title)}</h3>
                }
                {banner_section.sub_title &&
                    <h1 className="color-white">{HtmlParser(banner_section.sub_title)}</h1>
                }
                {banner_section.text &&
                    <p className="color-white">{HtmlParser(banner_section.text)}</p>
                }
                </div>
        </div>
    </div>
    );
  }
}


export default ProductPage;
