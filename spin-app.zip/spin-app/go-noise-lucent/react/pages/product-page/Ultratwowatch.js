import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import Srcset from "../../components/SrcSet";
import MediaQuery from "../../components/MediaQuery";

class Ultratwowatch extends Component {
    render() {
        const { ultra_two_watch } = this.props;
        
    
        return (
          <div>
              
              <div className="two-watch">
                  <div className="image-container">
                  
                  <MediaQuery query='phone-and-tablet'>
                      <Srcset src={ultra_two_watch.image_xs} />
                </MediaQuery>
                 
                  {/* <MediaQuery query='lap-and-up'>
                   
                    <Srcset src={ultra_two_watch.image} />
                    
                  </MediaQuery> */}
                  </div>
                  <div className="text-container">
                      <h3>Crafted to perfection</h3>
                      <p>From the mighty TruView<sup>TM</sup> display to the<br/>aircraft-grade aluminium body, the ColorFit Ultra<br/>is more than what meets the eye. </p>
                      <span>1.75<sup>"</sup> TrueView<sup>TM</sup> display</span>
                      <div className="line"><span></span></div>
                      <span>320*385px resolution</span>
                  </div>
              </div>
             
          </div>
        );
      }
}

export default Ultratwowatch;
