import React, { Component } from "react";
import MainFAQs from "./MainFAQs";
export class FAQSection extends Component {
  render() {
    const { FAQ } = this.props;
    if(Object.keys(FAQ).length === 0){
      return false;
    }
    let sepcArr = FAQ.details.split("<>");
    let FAQDeatils = sepcArr.map((ele, index) => {
      let eleArr = ele.split(" title#");
      let title = eleArr[0];
      eleArr = eleArr[1].split("$$");
      return (
          <MainFAQs key={index} title={title} eleArr={eleArr} />
      );
    });

    return (
      <div>
        <div className="box-section background-black">
          <div className="container">
            <div className="flex-view-xs space product_detail_wrap">
              <div className="specification-wrap">
                <h3 className="header-title color-white">{FAQ.title}</h3>
                <ul className="specifications">{FAQDeatils}</ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default FAQSection;
