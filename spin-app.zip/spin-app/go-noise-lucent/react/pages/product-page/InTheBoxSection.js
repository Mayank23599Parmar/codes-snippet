import React, { Component } from 'react';
import HtmlParser from 'react-html-parser'
import Srcset from '../../components/SrcSet';
class InTheBoxSection extends Component {
  render() {
    let { box_section } = this.props;
    if(!box_section.title){
      return false;
    }
    return (
    <div className="box-section background-black">
      <div className="container">
        <div className="box-image-text flex-view-xs space">
          <div className="col-sm-6 text-wrapper">
            {box_section.title && <h2 className="header-title color-white">{HtmlParser(box_section.title)}</h2>}
            <ul className="text-wrap">
              {box_section.description && box_section.description.split(',').map((item,index)=>{
                return(<li className="text-li color-white" key={index}>
                  <span>{item}</span>
                </li>)
              })}
            </ul>
          </div>
          {box_section.image && <div className="col-sm-6 img-wrapper">
            <Srcset src={box_section.image}/>
          </div>}
        </div>	
      </div>
    </div>
    );
  }
}


export default InTheBoxSection;