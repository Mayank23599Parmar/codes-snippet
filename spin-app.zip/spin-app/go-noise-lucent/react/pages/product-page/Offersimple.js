import React from 'react';
import Countdown from "react-countdown";
import MediaQuery from "../../components/MediaQuery";
class Offersimple extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            offerShow : false,
            progress : 0,
            startDate: null,
            endDate: null,
            offerText: ''
        }
    }
    Completionist = () => <span>Limited stock left!</span>;
    renderer = (props) => {
        let {completed, formatted } = props;
        let { hours, minutes, seconds } = formatted;

        if (completed) {
            return this.Completionist();
        } else {
            // Render a countdown
            return (
                <span>
                <img alt="timer" src="https://cdn.shopify.com/s/files/1/0997/6284/files/Group_5ba6b522-b641-47c5-ba1f-7201a4e73f5b.svg?v=1625139863" /> Ends in {hours}h {minutes}m
            </span>
            );
        }
    };
    getTag = (tags,text) =>{
        let findText = tags.find((tag)=> tag.includes(text));
        if(findText){
            findText = findText.replace(text,'');
        }
        return findText;
    }
    // updateProgressBar = () =>{
    //     let {endDate,seconds,startDate} = this.state;
    //     let curDate = new Date();
    //     if(curDate >= endDate){
    //         seconds = `100%`;
    //         this.setState({seconds});
    //         clearInterval(this.interval);
    //     }else{
    //         let totalSeconds = Math.abs(endDate - startDate) / 1000;
    //         let newSeconds = Math.abs(endDate - curDate) / 1000;
    //         let seconds = (newSeconds * 100) / totalSeconds;
    //         seconds = `${100 - seconds}%`;
    //         this.setState({seconds});
    //     }
    // }
    componentWillUnmount() {
        clearInterval(this.interval);
    }
    componentDidMount(){
        let todayDate = new Date()
        let currentYear = todayDate.getFullYear().toString();
        let splitDate = todayDate.toString().split(currentYear)[0];
        let fullstartdate = splitDate+currentYear+' '+'00:00:01';
        let fullenddate = splitDate+currentYear+' '+'23:59:59';
        //console.log('fullstartdate------>',fullstartdate)
        //console.log('fullenddate------>',fullenddate)
        let {tags} = this.props.product;
        let offerShow = this.checkOfferShow(tags);
        let endDate = new Date(fullenddate);
        let startDate = new Date(fullstartdate);
        //console.log(endDate,startDate);
        let curDate = new Date();
        // let seconds = endDate.getTime() * 100 / startDate.getTime();
        // let seconds = `${(startDate.getTime() * 100) / endDate.getTime()}%`;
        let totalSeconds = Math.abs(endDate - startDate) / 1000;
        let newSeconds = Math.abs(endDate - curDate) / 1000;
        let seconds = (newSeconds * 100) / totalSeconds;
        seconds = `${100 - seconds}%`;
        let offerText = this.getTag(tags,'offer2text_')
        if(offerShow){
            this.setState({offerShow :  true,endDate,seconds,startDate,offerText},()=>{
                //this.interval = setInterval(() => this.updateProgressBar() , 1000);
            });
        }
    }
    getDate = (tags,text) =>{
        let date = tags.find((tag)=> tag.includes(text));
        if(date){
            date = date.replace(text,'');
        }
        return new Date(date);
    }
    checkOfferShow = tags =>{
        let textFound = false,offerFound = false, offerShouldShow= false;
        for(let i=0; i<tags.length; i++){
            let tag = tags[i];
            if(tag.includes('offer2text_')){
                textFound = true;
            }
            if(tag.includes('offer2')){
                offerFound = true;
            }
        }
        if(textFound && offerFound){
            offerShouldShow  = true;
        }
        return offerShouldShow;
    }
    render(){
        // let {tags} = this.props.product;
        // let offerShow = this.checkOfferShow(tags);
        // if(!offerShow){
        //     return null;
        // }
        // let date = this.getDate(tags);
        // let curDate = new Date();
        // let seconds = date.getTime() - curDate.getTime();
        let {offerShow,endDate,startDate,seconds,offerText} = this.state;
        if(!offerShow){
            return null;
        }
        return(

                <div id="offer-simple-mobile-showbar" className="offer-progress-bar offer-simple-mobile">
                    <div className="text-center">
                        <div className="flex-view-xs space-between mobile-space">
                            <MediaQuery query="phone">
                                <div className="date-remain">
                                    <Countdown daysInHours={true} date={endDate} renderer={this.renderer} />
                                </div>
                            </MediaQuery>
                            {offerText && <div className='discount-percentage offertext2'><p>{offerText}</p></div>}
                        </div>  
                    </div>
                </div>

        )
    }
}

export default Offersimple;