import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import Srcset from "../../components/SrcSet";
import MediaQuery from "../../components/MediaQuery";

class UltraAlluminiumBody extends Component {
    render() {
    
        return (
          <div>
              
              <div className="two-watch alluminium-body">
                  <div className="image-container"> 
                  <MediaQuery query="lap-and-up">               
                      <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/Upper.png?v=1626381607" />
                 </MediaQuery>
                 <MediaQuery query="phone-and-tablet">
                 <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/Upper_5d8ad3cb-1f74-40e4-9c61-8acb157de1ec.png?v=1626384553" />
                  </MediaQuery>
                  </div>
                  <div className="text-container">
                      <span>Aircraft-grade Aluminium Body</span>
                      <div className="line"><span></span></div>
                      <span>Light weight, strong build</span>
                  </div>
                  <div className="image-container">    
                  <MediaQuery query="lap-and-up">                
                  <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/1-keyshot-1223.png?v=1626378342" />
                  </MediaQuery>
                  <MediaQuery query="phone-and-tablet">
                  <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/Lower.png?v=1626384554" />
                  </MediaQuery>
                  </div>
              </div>
             
          </div>
        );
      }
}

export default UltraAlluminiumBody;
