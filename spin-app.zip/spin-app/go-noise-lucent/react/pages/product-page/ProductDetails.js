import React, { Component } from "react";
// import Slider from "react-slick";
import { connect } from "react-redux";
import ReactModal from "react-modal";
import { addToCart,updateCart } from "../../redux/cart/cartAction";
import VariantSelector from "../../components/VariantSelector";
import RecommendationModal from "../../components/RecommendationModal/RecommendationModal";
import { formatMoney, fetchProductTitle, discountCalculator,saveCalculator } from "../../components/Helper";
import { updateVariant,showRecommendationProducts,showProductDetailPopup } from "../../redux/product/productAction";
import PreorderModal from "./PreorderModal";
// import UrlSet from "../../components/UrlSet";
import Notifypopup from './Notifypopup'
// import NoisfitappSlider from "./NoisfitappSlider";
import {ctaBuyEvent} from '../../clever-tap-events/AddToCartEvent'
import OfferProgressBar from './OfferProgressBar';
import Offerdailyprogressbar from './Offerdailyprogressbar';
import Offersimpledesktop from './Offersimpledesktop';
import MediaQuery from "../../components/MediaQuery";
import HtmlParser from "react-html-parser";
import { Spinner } from '../../components/Form';
import RecommendationProductPopup from '../../components/RecommendationModal/RecommendationProductPopup';
import { showCollectionProductPopup } from '../../redux/collection/collectionAction';

export class ProductDetails extends Component {
  constructor(props) {
    super(props);
      
    this.customStyles = {
      content: {
        top: "50%",
        left: "50%",
        right: "auto",
        bottom: "auto",
        marginRight: "-50%",
        transform: "translate(-50%, -50%)",
      },
    };
    this.preOrderCustomStyles = {
      overlay: {
        zIndex: "10000",
        background: "rgba(0,0,0,0.4)",
        height: "100%",
      },
    };
    this.state = {
      showModal: false,
      emailenq: "",
      mobilenoenq: "",
      showPreorderModal: false,
      showNotifypop: false,
      //enabledCheckBox: false,
      quantity:1
    };
  }
  scrollToSection = () => {
    let scrollToElement = document.querySelectorAll(".review-section-wrap")[0];
    scroll({
      top: scrollToElement.offsetTop
    })
  };

  // onClick1 = () => {
  //   this.setState({ enabledCheckBox: !this.state.enabledCheckBox });
  // };
  
  buyNow = () => {
    ctaBuyEvent(this.props)
    const { variant,product,recommendationProducts } = this.props;
    const form = { id: parseInt(variant.id), quantity: this.state.quantity };
    let hasDiscount = product.tags.find((tag)=>tag.includes('coupon_'));
    let data = {}
    if(recommendationProducts.length !== 0 && screen.width <= 767 ){
      var root = document.getElementsByTagName( 'html' )[0];
      document.body.classList.add('overflow-hidden');
      root.classList.add('overflow-hidden');
      document.body.style.height = "100%";
      root.style.height = "100%";
      this.props.showRecommendationProductsAction(true);
    }
    else{
      if (hasDiscount) {
        let saleDiscountTag = hasDiscount.split("_");
        data = {
          type: "checkoutcoupon",
          code: saleDiscountTag[1],
          form,
        };
      } else {
        data = {
          type: "checkout",
          form,
        };
      }
      this.props.addToCart(data);
    }
  };

  buyNow1 = () => {
    ctaBuyEvent(this.props)
    const { variant,product,recommendationProducts } = this.props;
    const form = { id: [parseInt(variant.id), 39357298016343], quantity: [1, 1] };
    let hasDiscount = product.tags.find((tag)=>tag.includes('coupon_'));
    let data = {}
    if(recommendationProducts.length !== 0 && screen.width <= 767 ){
      var root = document.getElementsByTagName( 'html' )[0];
      document.body.classList.add('overflow-hidden');
      root.classList.add('overflow-hidden');
      document.body.style.height = "100%";
      root.style.height = "100%";
      this.props.showRecommendationProductsAction(true);
    }
    else{
      if (hasDiscount) {
        let saleDiscountTag = hasDiscount.split("_");
        data = {
          type: "checkoutcoupon",
          code: saleDiscountTag[1],
          form,
        };
      } else {
        data = {
          type: "checkout",
          form,
        };
      }
      this.props.addToCart(data);
    }
 
  };

  toggleModale = (value) => {
    if(value){
      document.body.classList.add('overflow-hidden');
    }
    else{
      document.body.classList.remove('overflow-hidden');
    }
    this.setState({ showPreorderModal: value, showNotifypop :value , emailenq: "", mobilenoenq: "" });
  };
  getTag = (tags,text) =>{
    let findText = product.tags.find((tag)=> tag.includes(text));
    if(findText){
        findText = findText.replace(text,'');
    }
    return findText;
  }
  // quantityChange = (event) =>{
  //   let { min, max } = event.target;
  //   quantity = Math.max(Number(min), Math.min(Number(max), Number(quantity)));

  //   this.setState({ quantity });
  // }
  //spinner change
  plus = () => {
    const qty = this.state.quantity;
    if(qty=== 5){
      return
    }
    this.setState({quantity:qty+1});
  }
  minus = () => {

    const qty = this.state.quantity;
    if(qty === 1){
      return
    }
    //this.myRef.current.value = qty;
    this.setState({quantity:qty-1});
  }
  closeProductPopup = () => {
    this.props.showProductDetailPopup(false);
    this.props.showCollectionProductPopupAction(false);
  }
  componentWillMount(){
    this.props.showRecommendationProductsAction(false);
    this.props.showProductDetailPopup(false);
    this.props.showCollectionProductPopupAction(false);
  }
  render() {
    const {
      product,
      variant,
      swatchesImagesDetails,
      updateVariant,
      metaData,
      showRecommendationProducts,
      setProductPopupContent,
      recommendationProducts,
      frequntlyContent
    } = this.props;
    const { variants, options, tags, handle } = product;
    const { swatchImages, bgSwatchImages } = swatchesImagesDetails;
    const { emiLink, emiText, showEMI, showWarranty, warrantyText } = metaData;
    let actual_title = product.title;
    let tagTitle = fetchProductTitle(product.tags);
    if (tagTitle) {
      actual_title = tagTitle;
    }
    let productReview = metaData.review.badge

    let productReviewCount = metaData.review.totalReview;
    
    let productReviewRating = metaData.review.avgRating
    let hasSalePrice = product.tags.find((tag)=>tag.includes('sale_'));
    let hasdiscount = product.tags.find((tag)=>tag.includes('coupon_'));
    let hasGiftWrap = product.tags.find((tag)=>tag.includes('gift_wrap'));
    let salePrice = 0 ;
    let variantPrice = variant.price;
    let variantComparePrice = variant.compare_at_price;
    if(hasSalePrice){
      let salePriceTag=hasSalePrice.split('_');
      if(salePriceTag.length === 2){
        salePrice = parseInt(salePriceTag[1]);
        variantPrice = salePrice;
      }
    }
    const { available } = variant;
    let productAvailablity = available === true ? true : false;
    let productIsPreorder = tags.includes("preorder") ? true : false;
    let customerLoggedIn = simply.customerLoggedin;
    let comingSoon = tags.includes("coming-soon") ? true : false;
    let phonePeImage = tags.includes("phonepe") ? true : false;
    let offerDaily = tags.includes("offerdaily") ? true : false;
    let offer2 = tags.includes("offer2") ? true : false;
    let Ultratitle = product.handle === "noise-colorfit-ultra-smart-watch" ? true : false;
    let offerText2show = product.tags.find((tag)=>tag.includes('offer2text_'));
    if(offerText2show){
      offerText2show = offerText2show.replace('offer2text_','');
    }
    
    const {
      modalIsOpen,
      mobilenoenq,
      emailenq,
      showPreorderModal,
      showNotifypop
    } = this.state;
    let defaultVariant = false;
    if(variants.length === 1){
      if(variants[0].title == 'Default Title'){
        defaultVariant = true;
      }
    }
    let noAddToBagTag=false;
    let noAddToBagTagCheck = product.tags.find((tag)=>tag.includes(simply.noAddToBagTag));
    if(noAddToBagTagCheck){
      noAddToBagTag=true
    }
    return (
      <div className="product-information">
        <MediaQuery query="tablet-and-up">
        <div className="product-detail-desktop">
        <h1 className="product-slider-title">{actual_title}</h1> 
        {productReviewRating && <div className="product-detail-review-new" onClick={this.scrollToSection}> <img alt="product-review-star" src="https://cdn.shopify.com/s/files/1/0997/6284/files/Asset_2_1.svg?v=1628501758"/> {HtmlParser(productReviewRating)} rating {productReviewCount && <span> ({HtmlParser(productReviewCount)}) </span>}</div>}
        <div className="product-price">
          <h5 className="price">{hasSalePrice && salePrice > 0 ? formatMoney(variantPrice * 100)  : formatMoney(parseInt(variantPrice))}</h5>
          {variantComparePrice &&
            variantComparePrice > variantPrice && (
              <>
              <h5 className="compare">
              {formatMoney(parseInt(variantComparePrice))}
              </h5>
              <div className="discount-percentage offer2-active"><p>Save {discountCalculator(variantPrice,variantComparePrice)}</p></div></>
              
            )}
            {offer2 && offerText2show &&
            <MediaQuery query="tablet-and-up">
              <div className='discount-percentage offertext2'><p>{offerText2show}</p></div>
            </MediaQuery>
            }
        </div>
        {offer2 &&
        <MediaQuery query="tablet-and-up">
          <Offersimpledesktop product={product}/>
        </MediaQuery>
        }
        {/* <MediaQuery query="tablet-and-up">
          <OfferProgressBar product={product}/>
        </MediaQuery>
        {offerDaily &&
        <MediaQuery query="tablet-and-up">
          <Offerdailyprogressbar product={product}/>
        </MediaQuery>
        } */}
        {defaultVariant === false && <>
        <div className={`variants-wrapper`}>
          {options.map((option, index) => {
            return (
              <ul key={index} className={`swatch-wrap${defaultVariant ? ' hide-swatch-wrap':''}`}>
                {variants.map((variant) => {
                  // if(variant.inventory_quantity>0)
                    return (
                      <VariantSelector
                        key={variant.id}
                        option={option}
                        selectedVariant={this.props.variant}
                        variant={variant}
                        variantImages={swatchImages}
                        setSelectedVariant={updateVariant}
                        changeUrl={true}
                      />
                    );
                })}
              </ul>
            );
          })}
        </div>
        <p className="variant-title"> {variant.title} </p></>}
        {/* <div className="product-detail-review" onClick={this.scrollToSection}>{HtmlParser(productReview)}</div> */}
        <div className="quantity-cart">
        <div className='qty-part'>
                  
                      <div className="qty-label">
                        <p>
                          Quantity
                        </p>
                        <div className='text-left qty'>
                        <div className="spinner">
                            <div className="min op-btn" onClick={(e) => this.minus(e)}>
                              <img src={pwa.icons.spinnerMinus} alt="Minus" />
                            </div>
                            <input
                              type="number"
                              id="product-cart-quantity"
                              className="form-control"
                              value={this.state.quantity}
                              min="1"
                              max="5"
                            
                            />
                            <div className="plus op-btn" onClick={(e) => this.plus(e)}>
                              <img src={pwa.icons.spinnerPlus} alt="Plus" />
                            </div>
                          </div>
                        </div>
                      </div>
                   
                </div>
        </div>
        
        {/* {phonePeImage && ( 
          <div className="phonepe-wrapper">
            <img src="https://cdn.shopify.com/s/files/1/0997/6284/files/PhonePetttttt.png?v=1621843165" />
          </div>
          )}
        {comingSoon ? 
        <div className="cart-add-btn" name="cart">
          <button type="button"  onClick={()=>{ this.setState({showNotifypop:true}) }}>
             Coming soon
           </button>
          </div>
        : 
         <div className="cart-add-btn" name="cart">
           {productAvailablity && (
             <>
            {this.state.enabledCheckBox ? (
              <button type="button" className="enabled" onClick={this.buyNow1}>
              Buy Now
              </button>
            )
            :
            (
              <button type="button" onClick={this.buyNow}>
              Buy Now
              </button>
            )}
           
           </>
         )}
         {!productAvailablity && !productIsPreorder && (
           <button onClick={()=>{ this.setState({showNotifypop:true}) }}>Notify Me</button>
         )}
         {!productAvailablity && !customerLoggedIn && productIsPreorder && (
           <a className="btn" href={`/account/login?checkout_url=/products/${handle}?variant=${variant.id}`}> Prebook </a>
         )}
         {!productAvailablity && customerLoggedIn && productIsPreorder && (
           <button
             onClick={(e) => {
               this.toggleModale(true);
             }}
           >
             Pre Order
           </button>
         )}
        { hasGiftWrap && (
         <div className="gift-wrapper">
           <label for='gift_wrap' onClick={this.onClick1}>
           <input
          type="checkbox"
          value={"gift wrap"}
          checked={this.state.enabledCheckBox}
          onChange={this.onClick1}
        />
               Add gift wrap for ₹30
           </label>
           
         </div>
        )}
       </div>
        } */}
        </div>
        </MediaQuery>



        <MediaQuery query="phone">
        <div className="product-detail-mobile">
        <div className="flex-wrap">
          <div className="first-fold">
          <h1 className="product-slider-title">{actual_title}</h1>           { productReviewRating && <div className="product-detail-review product-detail-review-new" onClick={this.scrollToSection}> <img alt="product-review-star" src="https://cdn.shopify.com/s/files/1/0997/6284/files/Asset_2_1.svg?v=1628501758"/> <p>{HtmlParser(productReviewRating)} rating {productReviewCount && <span> ({HtmlParser(productReviewCount)}) </span>}</p></div>}
          </div>
          <div className="first-fold first-fold-right">
          <div className="product-price">
          <h5 className="price">{hasSalePrice && salePrice > 0 ? formatMoney(variantPrice * 100)  : formatMoney(parseInt(variantPrice))}</h5>
          {variantComparePrice &&
            variantComparePrice > variantPrice && (
              <>
              <h5 className="compare">
              {formatMoney(parseInt(variantComparePrice))}
              </h5>
              </>
              
            )}
          </div>
          {variantComparePrice &&
            variantComparePrice > variantPrice && (
              <>
              <div className="discount-percentage"><p>Save {discountCalculator(variantPrice,variantComparePrice)}</p></div>
              </>
              
            )}
          </div>
        </div>
        <div className="flex-wrap">
          <div className="first-fold">
          <p className="fold-title">Colours</p>
          {defaultVariant === false && <>
            <div className={`variants-wrapper`}>
              {options.map((option, index) => {
                return (
                  <ul key={index} className={`swatch-wrap${defaultVariant ? ' hide-swatch-wrap':''}`}>
                    {variants.map((variant) => {
                      // if(variant.inventory_quantity>0)
                        return (
                          <VariantSelector
                            key={variant.id}
                            option={option}
                            selectedVariant={this.props.variant}
                            variant={variant}
                            variantImages={swatchImages}
                            setSelectedVariant={updateVariant}
                            changeUrl={true}
                          />
                        );
                    })}
                  </ul>
                );
              })}
            </div>
            <p className="variant-title"> {variant.title} </p></>
            }
          </div>
          <div className="first-fold first-fold-quantity">
          <p className="fold-title fold-title-right">
                          Quantity
                        </p>
          <div className="quantity-cart">
        <div className='qty-part'>
                  
                      <div className="qty-label">
                        <div className='text-left qty'>
                        <div className="spinner">
                            <div className="min op-btn" onClick={(e) => this.minus(e)}>
                              <img src={pwa.icons.spinnerMinus} alt="Minus" />
                            </div>
                            <input
                              type="number"
                              id="product-cart-quantity"
                              className="form-control"
                              value={this.state.quantity}
                              min="1"
                              max="5"
                            
                            />
                            <div className="plus op-btn" onClick={(e) => this.plus(e)}>
                              <img src={pwa.icons.spinnerPlus} alt="Plus" />
                            </div>
                          </div>
                        </div>
                      </div>
                   
                </div>
        </div>

          </div>
        </div>
        {/* <div className="sezzle-gateway">or 4 interest-free payments of 375 with </div> */}
        {/* <div className="product-detail-review" onClick={this.scrollToSection}>{HtmlParser(productReview)}</div> */}
        {/* {phonePeImage && ( 
          <div className="phonepe-wrapper">
            <img src="https://cdn.shopify.com/s/files/1/0997/6284/files/PhonePetttttt.png?v=1621843165" />
          </div>
          )} */}
        {/* {comingSoon ? 
        <div className="cart-add-btn" name="cart">
          <button type="button"  onClick={()=>{ this.setState({showNotifypop:true}) }}>
              Coming soon
            </button>
          </div>
        : 
          <div className="cart-add-btn" name="cart">
          {productAvailablity && (
            <button type="button" onClick={this.buyNow}>
              Buy Now
            </button>
          )}
          {!productAvailablity && !productIsPreorder && (
            <button onClick={()=>{ this.setState({showNotifypop:true}) }}>Notify Me</button>
          )}
          {!productAvailablity && !customerLoggedIn && productIsPreorder && (
            <a className="btn" href={`/account/login?checkout_url=/products/${handle}?variant=${variant.id}`}> Prebook </a>
          )}
          {!productAvailablity && customerLoggedIn && productIsPreorder && (
            <button
              onClick={(e) => {
                this.toggleModale(true);
              }}
            >
              Pre Order
            </button>
          )}
        </div>
        } */}
        </div>
        </MediaQuery>




        {showNotifypop && <Notifypopup title={actual_title} variant={variant} toggleModale={this.toggleModale}   toggleModale={this.toggleModale} />}
          
        {/* <MediaQuery query="phone"> */}
          <ReactModal
            isOpen={showRecommendationProducts}
            contentLabel="onRequestClose Example"
            onRequestClose={() => this.toggleModale(false)}
            shouldCloseOnOverlayClick={true}
            className="recommendation-modal-style"
            style={this.preOrderCustomStyles}
          >
            
            <RecommendationModal
              productsList={recommendationProducts}
              masterProductImg={product.featured_image}
              masterProductVariant={variant}
              masterProductTitle={actual_title}
              frequntlyContent={frequntlyContent}

            />
          </ReactModal>
        {/* </MediaQuery> */}
        <ReactModal
          isOpen={showPreorderModal}
          contentLabel="onRequestClose Example"
          onRequestClose={() => this.toggleModale(false)}
          shouldCloseOnOverlayClick={true}
          className="preorder-modal-style"
          style={this.preOrderCustomStyles}
        >
          <PreorderModal
            variantImages={swatchImages}
            toggleModale={this.toggleModale}
            productName={actual_title}
            product={product}
            selectedVariant={variant}
          />
        </ReactModal>
        <div className="extra-data">
        
          {showWarranty && warrantyText && (
            <p className="color-white">{warrantyText + " "}</p>
          )}
          {showEMI && emiLink && emiText && (
            <p className="color-white">
              {emiText}
              <span className="emi-link">
                <a href={emiLink} target="_blank">
                  EMI options <span className="arrow down"></span>
                </a>
              </span>
            </p>
          )}
        </div>
        <div className="extra-data-sezzle sezzle-price">{hasSalePrice && salePrice > 0 ? formatMoney(variantPrice * 100)  : formatMoney(parseInt(variantPrice))}</div>
        {this.props.showProductPopup &&
        <RecommendationProductPopup  closeProductPopup={this.closeProductPopup} product={setProductPopupContent} />}
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  product: state.product.product,
  variant: state.product.variant,
  swatchesImagesDetails: state.product.swatchesImagesDetails,
  showRecommendationProducts : state.product.showRecommendationProducts,
  recommendationProducts: state.product.recommendationProducts,
  showProductPopup: state.product.showProductPopup,
  setProductPopupContent: state.product.setProductPopupContent,
  frequntlyContent: state.product.frequntlyContent,

});
const mapDispatchToProps = (dispatch) => ({
  addToCart: (data) => dispatch(addToCart(data)),
  updateVariant: (variant) => dispatch(updateVariant(variant)),
  showRecommendationProductsAction :(data) => dispatch(showRecommendationProducts(data)),
  showProductDetailPopup: (data) => dispatch(showProductDetailPopup(data)),
  showCollectionProductPopupAction: data => dispatch(showCollectionProductPopup(data)),
});
export default connect(mapStateToProps, mapDispatchToProps)(ProductDetails);
