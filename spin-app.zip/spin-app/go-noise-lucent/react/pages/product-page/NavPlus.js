import React from "react";
/* Redux */
import { connect } from "react-redux";
/* Actions */
import {setVariant} from '../../redux/product/productAction';
/* helper */
// import { queryString, queryStringVariant } from '../../components/Helper';
/* Comp imports */
import Loading from "../../components/loader/loader";
// import ErrorPage from "../errorpage/ErrorPage";
import ProductBanner from "./ProductBanner";
import FeaturedImage from "./FeaturedImage";
import ProductSlider from './ProductSlider';
// import CustomerReview from "./CustomerReview";
// import ProductVideo from "./ProductVideo";
import NavVideo from "./NavVideo";
import ImageWithText from "./ImageWithText";
import InTheBoxSection from "./InTheBoxSection";
import SpecificationSection from "./SpecificationSection";
import FAQSection from './FAQSection';
import ProductReview from './ProductReview';
// import CompareProducts from './CompareProducts';
import ProductBar from './ProductBar';
// import TextWithTitle from './TextWithTitle';
import WarrantySection from './WarrantySection';
import NoisfitappSlider from './NoisfitappSlider';
import SEODisclaimerSection from './SEODisclaimerSection';
import SEOQuestions from './SEOQuestions';
import RelatedProductsSection from './RelatedProductsSection';
import Offersimple from './Offersimple';
import MediaQuery from '../../components/MediaQuery';

class NavPlus extends React.Component {
  constructor(props) {
    super(props)
    this.prodRef = React.createRef();
    this.featureRef = React.createRef();
    this.state = {
      showBar: false
    }
  }

  componentDidMount() {
    window.addEventListener('scroll', this.handleScroll);
    // const { setVariant, productData } = this.props;
    // let queryStringsData = queryString(location.href);
    // if(productData.product){
    //   if(queryStringsData.variant){
    //     let passVariant = productData.product.variants.find((vari)=>{
    //       return vari.id === parseInt(queryStringsData.variant.value);
    //     })
    //     if(passVariant){
    //       setVariant(passVariant);
    //     }
    //   }
    //   else{
    //     queryStringVariant(productData.variant);
    //   }
    // }
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.handleScroll);
  }

  handleScroll = (event) => {
    let productSection = this.prodRef.current;
    let featureSection = this.featureRef.current;
   // if(window.pageYOffset <= featureSection.offsetTop && (window.pageYOffset + 100)  > productSection.offsetTop ){
    if(window.pageYOffset <= (featureSection.offsetTop - 500) && (window.pageYOffset + 200)  > productSection.offsetTop ){

      this.setState({showBar: false})
    }
    else{
      this.setState({showBar: true})
    }
  }

  render() {
    const { metafields, loading, product, compareProducts,relatedProducts } = this.props.productData;
    const { showBar } = this.state;
    let offer2 = product.tags.includes("offer2") ? true : false;

    if (loading) {
      return <Loading />;
    }
    // const pageStatus = checkErrorPage(window.location.href);
    // if (pageStatus) {
    //   return <ErrorPage show={true} />;
    // }
    if(cn(metafields)){
      return(
        <div>
        {showBar && <ProductBar prodRef={(this.prodRef)} />}
        <div ref={this.prodRef}><ProductSlider metaData={metafields} /></div>
        <ProductReview product={product} />
        </div>
      )
    }

    return (
      <div>
        {offer2 &&
        <MediaQuery query="phone">
       {showBar &&<Offersimple product={product} prodRef={(this.prodRef)} />}
       </MediaQuery>
        }
        <ProductBar prodRef={(this.prodRef)} />
        {metafields.banner_section && <div><ProductBanner banner_section={metafields.banner_section}  /></div>}
        <div ref={this.prodRef}><ProductSlider metaData={metafields} /></div>
        {metafields.feature_section && <div ref={this.featureRef}><FeaturedImage feature_section={metafields.feature_section} /></div>}
        {/* {metafields.customer_review && <CustomerReview customer_review={metafields.customer_review} />} */}
        {/*metafields.text_with_title && <TextWithTitle text_with_title={metafields.text_with_title}/>*/}
        <div className="outer-wrapper">
        {metafields.video_section && <NavVideo video_section={metafields.video_section} />}
        {metafields.image_with_text && <ImageWithText image_with_text={metafields.image_with_text} />}   
        {metafields.noisefitSlider && <NoisfitappSlider noisefitSlider={metafields.noisefitSlider} />}
        </div>
        {metafields.box_section && <InTheBoxSection box_section={metafields.box_section} />}
        {metafields.specifications && <SpecificationSection specifications={metafields.specifications} />}
        {/* {compareProducts && <CompareProducts compareProducts={compareProducts} />} */}
        {metafields.warrantySection && <WarrantySection warrantyData={metafields.warrantySection} />}
        {metafields.FAQ && <FAQSection FAQ={metafields.FAQ} />}
        {metafields.review && <ProductReview product={product} review={metafields.review} />}
        {metafields.SEODisclaimer  && <SEODisclaimerSection data={metafields.SEODisclaimer} />}
        {relatedProducts && relatedProducts.length > 0 && <RelatedProductsSection productList={relatedProducts} />}
        {metafields.SEOQuestions && <SEOQuestions data={metafields.SEOQuestions} /> }
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  productData: state.product,
});
const mapDispatchToProps = dispatch => ({
  setVariant: variant => dispatch(setVariant(variant))
});
export default connect(mapStateToProps,mapDispatchToProps)(NavPlus);
