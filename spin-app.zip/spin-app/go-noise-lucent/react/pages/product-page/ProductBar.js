import React from "react";
import { connect } from "react-redux";
import VariantSelector from "../../components/VariantSelector";
import { formatMoney, fetchProductTitle, discountCalculator,scrollToElement,showCartPopUp } from "../../components/Helper";
import { addToCart } from "../../redux/cart/cartAction";
import { updateVariant,showRecommendationProducts } from "../../redux/product/productAction";
import Notifypopup from "./Notifypopup";
import { ctaBuyEvent } from "../../clever-tap-events/AddToCartEvent";
import OfferProgressBar from "./OfferProgressBar";
import Offerdailyprogressbar from './Offerdailyprogressbar';
import Offersimple from './Offersimple';
import MediaQuery from "../../components/MediaQuery";
import {notifyMeProductEvent} from '../../clever-tap-events/NotifyEvent'
import {AddToBag, BuyNowCT} from '../../clever-tap-events/AddToCartEvent'



class ProductBar extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showNotifypop: false,
      showMobileVariant: false,
      showAddtocartPopup:false
    };
  }
  
  addToCart = async (e) =>{
    const { variant, product, recommendationProducts } = this.props;
    let quantity  = 1;
    if(document.getElementById('product-cart-quantity')){
      quantity = parseInt(document.getElementById('product-cart-quantity').value);
    }
    
    const form = { id: parseInt(this.props.variant.id), quantity };
    let data = {};
    data = {
      "type":"cart",
      form
    }
    this.props.addToCart({"type":"cart",form,callback:()=>{
      if(recommendationProducts.length !== 0  && pwa.frequentlyEnable){
        var root = document.getElementsByTagName( 'html' )[0];
        document.body.classList.add('overflow-hidden');
        root.classList.add('overflow-hidden');
        document.body.style.height = "100%";
        root.style.height = "100%";
        this.props.showRecommendationProductsAction(true);
      }
    }});
    if(!pwa.frequentlyEnable){
      showCartPopUp(<div className="main-cart-pop-div"><div className="pop-up-image"><img src={variant.featured_image.src} alt="img" /></div><span className="pop-up-text">Added To Bag</span></div>, "top-right");
    }
    
    AddToBag({product, variant, quantity})
  };
  buyNowHandler = () => {
    // window.scrollTo(0,this.props.prodRef.current.offsetTop+70);
    const { variant, product, recommendationProducts } = this.props;
    let quantity  = 1;
    if(document.getElementById('product-cart-quantity')){
      quantity = parseInt(document.getElementById('product-cart-quantity').value);
    }
    const form = { id: parseInt(this.props.variant.id), quantity };
    let hasDiscount = product.tags.find((tag) => tag.includes("coupon_"));
    let data = {};
    BuyNowCT({product, variant, quantity})
      if (hasDiscount) {
        let saleDiscountTag = hasDiscount.split("_");
        data = {
          type: "checkoutcoupon",
          code: saleDiscountTag[1],
          form,
        };
      } else {
        data = {
          type: "checkout",
          form,
        };
      }
      this.props.addToCart(data);
  };
  variantCallback = () =>{

  }
  toggleModale = (value) => {
    this.setState({ showNotifypop: value });
  };
  
  toggleVariants = () =>{
    let showMobileVariant = true;
    if(this.state.showMobileVariant){
      showMobileVariant = false;
    }
    this.setState({showMobileVariant});
  }
  scrollToVariant = () =>{
    let scrollToElement = document.querySelectorAll("#product-section")[0];
    scroll({
      top: scrollToElement.offsetTop
    })
  }
  render() {
    const {
      product,
      variant,
      swatchesImagesDetails,
      updateVariant,
      setProductPopupContent
    } = this.props;
    const { variants, options, handle, title } = product;
    const { showNotifypop } = this.state;
    const { swatchImages, bgSwatchImages } = swatchesImagesDetails;
    const header = document.getElementById("mainHeader");
    const style = { top: header.offsetHeight };
    const { available } = variant;
    let productAvailablity = available === true ? true : false;
    let hasSalePrice = product.tags.find((tag) => tag.includes("sale_"));
    let hasDiscount = product.tags.find((tag) => tag.includes("coupon_"));
    let salePrice = 0;
    let variantPrice = variant.price;
    let variantComparePrice = variant.compare_at_price;
    let customerLoggedIn = simply.customerLoggedin;
    let productIsPreorder = product.tags.includes("preorder") ? true : false;
    let offerDaily = product.tags.includes("offerdaily") ? true : false;
    let offer2 = product.tags.includes("offer2") ? true : false;
    let offerText2show = product.tags.find((tag)=>tag.includes('offer2text_'));
    if (hasSalePrice) {
      let salePriceTag = hasSalePrice.split("_");
      if (salePriceTag.length === 2) {
        salePrice = parseInt(salePriceTag[1]);
        variantPrice = salePrice;
      }
    }
    let actual_title = product.title;
    let tagTitle = fetchProductTitle(product.tags);
    let comingSoon = product.tags.includes("coming-soon") ? true : false;
    if (tagTitle) {
      actual_title = tagTitle;
    }
    let defaultVariant = false;
    if(variants.length === 1){
      if(variants[0].title == 'Default Title'){
        defaultVariant = true;
      }
    }
    let noAddToBagTag=false;
    let noAddToBagTagCheck = product.tags.find((tag)=>tag.includes(simply.noAddToBagTag));
    if(noAddToBagTagCheck){
      noAddToBagTag=true
    }
    return (
      <>
        {showNotifypop && (
          <Notifypopup
            title={actual_title}
            variant={variant}
            toggleModale={this.toggleModale}
          />
        )}
        <div id="product-bar" className={`product-bar ${offer2 && offerText2show ? 'offer2-active-bar':''}`} style={style}>
        {/* {offer2 &&
            <MediaQuery query="phone">
              <Offersimple product={product} />
            </MediaQuery>
            } */}
          <div className="container ">
            {/* <MediaQuery query="phone">
              <OfferProgressBar product={product} />
            </MediaQuery>
            {offerDaily &&
            <MediaQuery query="phone">
              <Offerdailyprogressbar product={product} />
            </MediaQuery>
            } */}
            
            <div className="flex-view-xs middle space-between">
            <MediaQuery query="tablet-and-up">
              <h5 className="product-title">{actual_title}</h5>
            </MediaQuery>
              <div className="product-bar-details">
              <div className="flex-view-xs middle">
                {defaultVariant === false && 
                <div className={`variants-wrapper${this.state.showMobileVariant ? ' show-variants' : ''}`}>
                  {options.map((option, index) => {
                    return (
                      <ul key={index} className={`swatch-wrap${defaultVariant ? ' hide-swatch-wrap':''}`}>
                        {variants.map((variant) => {
                          return (
                            <VariantSelector
                              key={variant.id}
                              option={option}
                              selectedVariant={this.props.variant}
                              variant={variant}
                              variantImages={swatchImages}
                              setSelectedVariant={updateVariant}
                              changeUrl={true}
                              callback = {this.variantCallback}
                            />
                          );
                        })}
                      </ul>
                    );
                  })}
                </div>}
                <div className="product-price"><>
                  <h5 className="price">{hasSalePrice && salePrice > 0 ? formatMoney(variantPrice * 100)  : formatMoney(parseInt(variantPrice))}</h5>
                  {variantComparePrice &&
                    variantComparePrice > variantPrice && (<>
                      <h5 className="compare">
                      {formatMoney(parseInt(variantComparePrice))}
                      </h5>
                      <MediaQuery query="tablet-and-up">
                      <div className="discount-percentage offer2-active" ><p>Save {discountCalculator(variantPrice,variantComparePrice)}</p></div>
                      </MediaQuery></>
                    )}
                    <MediaQuery query="phone">
                      <div className="discount-percentage offer2-active"><p>Save {discountCalculator(variantPrice,variantComparePrice)}</p></div>
                      <div className="current-variant">
                        {/* <p onClick={this.toggleVariants}><span className="variant-static">Colour : </span><span className="current-variant-name">{variant.title}</span><span className={`current-variant-arrow${this.state.showMobileVariant ? ' up' : ''}`}></span></p> */}
                        <p onClick={this.scrollToVariant}><span className="variant-static">Colour : </span><span className="current-variant-name">{variant.title}</span></p>
                      </div>
                    </MediaQuery>
                  </>
                </div>
                {comingSoon ? (
                  <div className="cart-add-btn">
                    <button className="btn" type="button" onClick={() => { this.setState({ showNotifypop: true }); }}>
                      Coming Soon
                    </button>
                  </div>
                ) : (
                  <div className="cart-add-btn">
                    {productAvailablity && (<>
                     {
                       noAddToBagTag?null:<button className="btn add-to-cart" type="button" onClick={this.addToCart}> Add To Bag </button>
                    } 
                      <button className="btn" type="button" onClick={this.buyNowHandler}>Buy Now </button>
                    </>
                    )}
                    {!productAvailablity && !productIsPreorder && (
                      <button className="btn" onClick={() => { this.setState({ showNotifypop: true }), notifyMeProductEvent(this.props) }} >
                        Notify Me
                      </button>
                    )}
                    {!productAvailablity &&
                      !customerLoggedIn &&
                      productIsPreorder && (
                        <a className="btn" href={`/account/login?checkout_url=/products/${handle}?variant=${variant.id}`} >
                          Prebook
                        </a>
                      )}
                  </div>
                )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  product: state.product.product,
  variant: state.product.variant,
  showProductPopup: state.product.showProductPopup,
  swatchesImagesDetails: state.product.swatchesImagesDetails,
  setProductPopupContent: state.product.setProductPopupContent,
  recommendationProducts: state.product.recommendationProducts,
});
const mapDispatchToProps = (dispatch) => ({
  addToCart: (data) => dispatch(addToCart(data)),
  updateVariant: (variant) => dispatch(updateVariant(variant)),
  showRecommendationProductsAction :(data) => dispatch(showRecommendationProducts(data))
});
export default connect(mapStateToProps, mapDispatchToProps)(ProductBar);
