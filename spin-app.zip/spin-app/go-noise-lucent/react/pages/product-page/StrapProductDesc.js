import React, { Component } from "react";
import HtmlParser from "react-html-parser";

export class StrapProductDesc extends Component {
  render() {
    const {product} = this.props;
    let prody = product.description;
    console.log(prody)

    return (
      <div className='for-seo-content'>
        <div className="container">
          <div className='que-ans'>{HtmlParser(prody)}</div>
        </div>
      </div>
    );
  }
}

export default StrapProductDesc;
