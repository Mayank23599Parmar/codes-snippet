import React, { Component } from "react";
import MediaQuery from "../../components/MediaQuery";
import Srcset from "../../components/SrcSet";

export class Ultrafeaturelast extends Component {
  render() {
    return (
      <div className="smart-features-last">
        <h2 class="smart-feature-title">The mightiest has more</h2>
        <div className="last-image-container">
        <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Last-section.jpg?v=1626208481' />
        </div>
        <div className="smart-feature-mode">
          <div className="smart-feature-section">
            <div className="smart-feature-image-banner">
              {/* <img src="https://cdn.shopify.com/s/files/1/0997/6284/files/1-keyshot-111.png?v=1612521693" /> */}
            </div>
            <ul className="">
              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Hand_wash_reminder_bd89ef37-00a0-4f97-a17b-42a41ab04679.svg?v=1626301272' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Hand_wash_reminder_bd89ef37-00a0-4f97-a17b-42a41ab04679.svg?v=1626301272' />
                    </span>
                  </MediaQuery>
                  <span className="left-text">Hand wash reminder</span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Drink water reminder</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Drink_water.svg?v=1626301272' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Drink_water.svg?v=1626301272' />
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Vibration_control.svg?v=1626301271' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Vibration_control.svg?v=1626301271' />
                    </span>
                  </MediaQuery>
                  <span className="left-text">Vibration control</span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Wrist awake</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Wrist_awake.svg?v=1626301271' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Wrist_awake.svg?v=1626301271' />
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Music_control.svg?v=1626301272' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Music_control.svg?v=1626301272' />
                    </span>
                  </MediaQuery>
                  <span className="left-text">Remote music control</span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Do not disturb mode</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Do_not_disturb_mode.svg?v=1626301272' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Do_not_disturb_mode.svg?v=1626301272' />
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Screen_brightness_control.svg?v=1626301272' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Screen_brightness_control.svg?v=1626301272' />
                    </span>
                  </MediaQuery>
                  <span className="left-text">
                  Screen brightness<br/>control
                  </span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Weather<br/>forecast</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Weather_9d1c4ae2-6e44-41c0-a703-9fa0c9773dab.svg?v=1626301272' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Weather_9d1c4ae2-6e44-41c0-a703-9fa0c9773dab.svg?v=1626301272' />
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Find_my_phone.svg?v=1626301271' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Find_my_phone.svg?v=1626301271' />
                    </span>
                  </MediaQuery>
                  <span className="left-text">
                  Find my phone
                  </span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Call mute & rejection</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/call_rejection_d5e215e9-5d3d-4260-a1c2-0df84193c9c1.svg?v=1626301271' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/call_rejection_d5e215e9-5d3d-4260-a1c2-0df84193c9c1.svg?v=1626301271' />
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Idle_alert_stopwatch.svg?v=1626301271' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Idle_alert_stopwatch.svg?v=1626301271' />
                    </span>
                  </MediaQuery>
                  <span className="left-text">Idle alert & stopwatch</span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Alarm & timer</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Alarm_7b5b8864-35d2-4b91-a0d6-f7029101ed5b.svg?v=1626301272' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Alarm_7b5b8864-35d2-4b91-a0d6-f7029101ed5b.svg?v=1626301272' />
                    </span>
                  </MediaQuery>
                </div>
              </li>

              {/* <li class="flex_view_xs middle">
                <div class="feature-left col-xs-6 col-sm-6">
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/remote_music_8cee7e50-eaf4-48bd-abdb-4ad03ce3fc37.svg?v=1612523365' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/remote_music_7e70c355-03e9-4782-a026-392bd262c1fd.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                  <span class="left-text">
                    Remote music<br class="dw-mobile"></br>
                    control
                  </span>
                </div>
                <div class="feature-right">
                  <span class="right-text">Do not<br class="dw-mobile"></br> disturb mode</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/do_not_disturb.svg?v=1612512833' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/do_not_disturb_7fe2dad6-b5b4-4288-b42d-a98e73d75129.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li class="flex_view_xs middle">
                <div class="feature-left col-xs-6 col-sm-6">
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/sleep_montor_dfb054d8-8981-4045-87e1-3a8bd37b4da6.svg?v=1612523365' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/sleep_montor_1bef8cad-9aa1-4859-9db5-3afcf289cb49.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                  <span class="left-text">Sleep<br class="dw-mobile"></br> monitor</span>
                </div>
                <div class="feature-right">
                  <span class="right-text">Screen<br class="dw-mobile"></br> brightness</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/screen_brightness_8149bca5-536c-420c-80ad-9a99ec257c27.svg?v=1612523365' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/screen_brightness_54d71798-8c30-4734-91a4-47ac6a4487c1.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                </div>
              </li> */}

             

              {/* <li class="flex_view_xs middle">
                <div class="feature-left col-xs-6 col-sm-6">
                  
                </div>
              </li> */}
            </ul>
          </div>
        </div>
      </div>
    );
  }
}

export default Ultrafeaturelast;
