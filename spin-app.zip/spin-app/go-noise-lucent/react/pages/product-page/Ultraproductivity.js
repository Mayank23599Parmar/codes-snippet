import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import Srcset from "../../components/SrcSet";
import MediaQuery from "../../components/MediaQuery";

class Ultraproductivity extends Component {
    render() {
        //const { ultra_two_watch } = this.props;
        
    
        return (
          <div>
              <div className="Ultra-productivity">
                  <h2>Your partner in productivity</h2>
                  <div className="text-wrapper text-wrapper-2">
                        <div className="text">
                            <h4>Loaded with smart utility features like never before, ColorFit Ultra is here to keep you productive and up to date.</h4>
                        </div>
                  </div>
                  <div className="video-wrapper">
                  <MediaQuery query="lap-and-up">
                  {/* <video
                  width="100%"
                  height="100%"
                  controls={false}
                  autoPlay="true"
                  className="video-container video-container-overlay"
                  autoPlay="true"
                  loop
                  playsInline
                  poster="https://cdn.shopify.com/s/files/1/0997/6284/files/watch_anim_dtop.jpg?v=1626308522"
                  muted={true}
                >
                  <source src="https://cdn.shopify.com/s/files/1/0997/6284/files/watch_anim_dtop.mp4?v=1626249591" type="video/mp4" />
                </video> */}
                    <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/Group_1865_1.png?v=1632154898" />
                  </MediaQuery>
                  <MediaQuery query="phone-and-tablet">
                  {/* <video
                  width="100%"
                  height="100%"
                  controls={false}
                  autoPlay="true"
                  className="video-container video-container-overlay"
                  autoPlay="true"
                  loop
                  poster="https://cdn.shopify.com/s/files/1/0997/6284/files/watch_anim.jpg?v=1626308522"
                  muted={true}
                  muted={true}
                >
                  <source src="https://cdn.shopify.com/s/files/1/0997/6284/files/watch_anim.mp4?v=1626249591" type="video/mp4" />
                </video> */}
                    <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/Group_1866_1.png?v=1632154899" />
                  </MediaQuery>
                  </div>
                  
                  <div className="text-wrapper">
                        <div className="text">
                            <h4>Calls & SMS quick reply<br/>World clock <br/> Camera controls<br/>Watch screen lock<br/>Stock market info<sup>*</sup><br/>Flashlight</h4>
                        </div>
                  </div>
                  <div className="image-wrappper">
                  <MediaQuery query="lap-and-up">
                  <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/17_6fe2d67f-cfa7-4bdd-a144-81c402b66c68.png?v=1626249510" />

                  </MediaQuery>
                  <MediaQuery query="phone-and-tablet">
                  <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/Filler-image.jpg?v=1626249539" />
                  </MediaQuery>
                  </div>
                  

              </div>
              
          </div>
        );
      }
}

export default Ultraproductivity;
