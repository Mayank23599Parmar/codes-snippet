import React from "react";
import HtmlParser from 'react-html-parser'
class ActiveLiveMindfully extends React.Component {
    render(){
        let { Active_Live_Mind } = this.props;
        if(Object.keys(Active_Live_Mind).length === 0){
        return false;
        }
        let items = [];
        for(let i = 1 ; i < 20 ; i++ ){
            let title = Active_Live_Mind["title_"+i];
            let content_text = Active_Live_Mind["text_"+i];
            let content_text_extra = Active_Live_Mind["extra_text_"+i];

            let bg_color = '#000';
            let font_color = '#fff';
            if(!cn(Active_Live_Mind["background_color_"+i])){
                bg_color = Active_Live_Mind["background_color_"+i];
            }
            if(!cn(Active_Live_Mind["text_color_"+i])){
                font_color = Active_Live_Mind["text_color_"+i];
            }
            let Style = {
                'backgroundColor': bg_color,
                'color':font_color
            }
            if(title){
                let content = <div className="text-with-title-item active-live-mindfully" key={i}>
                    <div className="container">
                        <div className="text-with-title-item-content">
                            <h2>{HtmlParser(title)}</h2>
                            <p>{HtmlParser(content_text)}</p>
                            <p className="extra-text">{HtmlParser(content_text_extra)}</p>
                        </div>
                    </div>
                </div>;
                items.push(content);
            }
        }
        if(items.length > 0){
            return (
            <div className="text-with-title">
                    {items}
            </div>
            );
        }
        return null;
    }
}
export default ActiveLiveMindfully;