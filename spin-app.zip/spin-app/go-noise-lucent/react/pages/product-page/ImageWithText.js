import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import MediaQuery from "../../components/MediaQuery";
import Srcset from "../../components/SrcSet";
import LazyLoad from 'react-lazyload';

class ImageWithText extends Component {
  render() {
    let { image_with_text } = this.props;
    if (Object.keys(image_with_text).length === 0) {
      return false;
    }
    let items = [];
    for (let i = 1; i < 20; i++) {
      let icon_image;
      if (image_with_text["icon_image_" + i]) {
        icon_image = image_with_text["icon_image_" + i].split(";");
      }
      let image_type = "left";
      if (image_with_text["image_type_" + i]) {
        image_type = image_with_text["image_type_" + i];
      }

      let padding = "";
      if (image_type == "left_full" || image_type == "right_full") {
        padding = "padding_none";
      }
      let title = image_with_text["title_" + i];
      let content_text = image_with_text["content_" + i];
      let image = image_with_text["image_" + i];
      let useTitle = image_with_text["paraextra_" + i];
      let useImage = image_with_text["extraimage_" + i];
      
      let bg_color = "#000";
      let font_color = "#fff";
      let classType = '';
      if (!cn(image_with_text["background_color_" + i])) {
        bg_color = image_with_text["background_color_" + i];
      }
      if (!cn(image_with_text["text_color_" + i])) {
        font_color = image_with_text["text_color_" + i];
      }
      let content_type = 'left';
      if(image_with_text['content_type_'+i]){
        content_type = image_with_text['content_type_'+i];
      }
      let Style = {
        backgroundColor: bg_color,
        color: font_color,
      };
      if (image_type === "banner") {
        let content = (
          <div className="image-text-section">
            <div className={`banner-type banner-type-${i}`}>
            <LazyLoad height={200}><MediaQuery query="phone-and-tablet"><Srcset src={image_with_text["image_xs_" + i] ? image_with_text["image_xs_" + i] : image} /></MediaQuery></LazyLoad>
            <LazyLoad height={200}><MediaQuery query="lap-and-up"><Srcset src={image} /></MediaQuery> </LazyLoad>
              <div className={`text-wrap ${content_type}`}>
                  <div className="container">
                    <div className="text">
                        {title && <h2 style={{color:font_color}} className="header-title">{HtmlParser(title)}</h2>}
                        {content_text && <p style={{color:font_color}} className="header-sub-title">{HtmlParser(content_text)}</p>}
                        <ul className="icon-text-wrap">
                          {image_with_text["icon_text_" + i] &&
                            image_with_text["icon_text_" + i]
                              .split(";")
                              .map((item, index) => {
                                return (
                                  <li className="icon-text-li" key={index}>
                                    {icon_image[index] && (
                                      <img src={icon_image[index]} alt={item} />
                                    )}
                                    <span>{HtmlParser(item)}</span>
                                  </li>
                                );
                              })}
                      </ul>
                    </div>
                  </div>
              </div>
            </div>
          </div>
        )
        items.push(content);
      }else if(image_type === "container_image") {
        let content = <div className="image container-image" style={Style}>
          <div className="container">
          <LazyLoad height={200}><Srcset src={image} alt={title} /></LazyLoad>
          </div>
        </div>
        items.push(content);
      }
      else {
        
        if (image) {
          let content = (
            <div className={`image-text-section image-text-section-${i}`}>
              <div className="image-text-wrap">
                <div
                  className={`image-with-text-section ${padding}`}
                  key={i}
                  style={Style}
                >
                  <div className="container">
                    <div className={`${image_type} image-text-inner-wrap`}>
                      <div className="image-wrap">
                      <MediaQuery query="phone-and-tablet"><LazyLoad height={200}><Srcset src={image_with_text["image_xs_" + i] ? image_with_text["image_xs_" + i] : image} /></LazyLoad></MediaQuery>
                      <MediaQuery query="lap-and-up"><LazyLoad height={200}><Srcset src={image} /></LazyLoad></MediaQuery> 
                      </div>
                      <div className="text-wrap">
                        <h2 className="header-title">{HtmlParser(title)}</h2>
                        <p className="header-sub-title">{HtmlParser(content_text)}</p>
                        {useTitle && <p className="para-extra">{HtmlParser(useTitle)}</p>}
                        {useImage && <div className="image-extra-wrapper"><LazyLoad height={200}><Srcset className="image-extra" src={useImage} /></LazyLoad></div>}
                        <ul className="icon-text-wrap">
                          {image_with_text["icon_text_" + i] &&
                            image_with_text["icon_text_" + i]
                              .split(";")
                              .map((item, index) => {
                                return (
                                  <li className="icon-text-li" key={index+1}>
                                    {icon_image[index] && (
                                      <img src={icon_image[index]} alt={item} />
                                    )}
                                    <span>{HtmlParser(item)}</span>
                                  </li>
                                );
                              })}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
          items.push(content);
        } 
      }
    }
    if (items.length > 0) {
      return <>{items}</>;
    }
    return null;
  }
}

export default ImageWithText;
