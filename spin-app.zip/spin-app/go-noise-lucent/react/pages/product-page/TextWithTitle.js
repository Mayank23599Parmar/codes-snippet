import React from "react";
import HtmlParser from 'react-html-parser'
class TextWithTitle extends React.Component {
    render(){
        let { text_with_title } = this.props;
        if(Object.keys(text_with_title).length === 0){
        return false;
        }
        let items = [];
        for(let i = 1 ; i < 20 ; i++ ){
            let title = text_with_title["title_"+i];
            let content_text = text_with_title["text_"+i];
            let bg_color = '#000';
            let font_color = '#fff';
            if(!cn(text_with_title["background_color_"+i])){
                bg_color = text_with_title["background_color_"+i];
            }
            if(!cn(text_with_title["text_color_"+i])){
                font_color = text_with_title["text_color_"+i];
            }
            let Style = {
                'backgroundColor': bg_color,
                'color':font_color
            }
            if(title){
                let content = <div className="text-with-title-item" key={i}>
                    <div className="container">
                        <div className="text-with-title-item-content">
                            <h2>{HtmlParser(title)}</h2>
                            <p>{HtmlParser(content_text)}</p>
                        </div>
                    </div>
                </div>;
                items.push(content);
            }
        }
        if(items.length > 0){
            return (
            <div className="text-with-title">
                    {items}
            </div>
            );
        }
        return null;
    }
}
export default TextWithTitle;