import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import Srcset from "../../components/SrcSet";
import MediaQuery from "../../components/MediaQuery";

class Ultrahealthassistant extends Component {
  render() {
    const { ultra_health_assist } = this.props;
    

    return (
      <div>
        <div className="Ultra-health-assistant">
          <div className="containers">
            <div className="image-area">
            <MediaQuery query="phone-and-tablet"><Srcset src={ultra_health_assist.image_xs} /></MediaQuery>
              <MediaQuery query="lap-and-up"><Srcset src={ultra_health_assist.image} /></MediaQuery> 
            </div>
            <div className="text-area">
                 <MediaQuery query="lap-and-up">
                 <h3>{HtmlParser(ultra_health_assist.text1)}</h3>
                </MediaQuery>
                <MediaQuery query="phone-and-tablet">
                 <h3>Your personal <br/>health assistant</h3>
                </MediaQuery>
                {/* <h2>{HtmlParser(ultra_health_assist.text1)}</h2> */}
                <p>{HtmlParser(ultra_health_assist.text2)}</p>
                <MediaQuery query="phone-and-tablet"><h4>{HtmlParser(ultra_health_assist.text3)}</h4></MediaQuery> 
                <MediaQuery query="lap-and-up"><h4>Track your blood oxygen levels regularly and stay safe</h4></MediaQuery>
                <div className="line"></div>
                <div className="icon-wrapper">
                    <span><Srcset src={ultra_health_assist.icon_image} /> {HtmlParser(ultra_health_assist.icon_text)}</span>
                </div>

            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Ultrahealthassistant;
