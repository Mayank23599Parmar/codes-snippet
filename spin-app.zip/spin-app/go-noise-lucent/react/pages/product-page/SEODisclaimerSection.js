import React, { Component } from 'react'

export class SEODisclaimerSection extends Component {
	render() {
	const {content} = this.props.data;
	if(cn(content)){
		return null;
	}
	let lists = content.split('##')
	let liHtmls = lists.map((item,index)=>{
		return<li key={index}>{item}</li>
	})
		return (
			<div className='for-seo-content'>
				<div className='container'>
					<div className='seo-wrapper'>
						<h3>Disclaimer</h3>
						<ul>
							{liHtmls}
						</ul>
					</div>
				</div>
			</div>
		)
	}
}

export default SEODisclaimerSection
