import React from "react";
import MediaQuery from "../../../components/MediaQuery";
import Srcset from "../../../components/SrcSet";
import HtmlParser from "react-html-parser";
import Slider from "react-slick";
class ColorFitPro3AssistApp extends React.Component {
  render() {
    const { settings } = this.props;
    if(!cn(settings)){
      return null;
    }
    const icon_text = settings.get_fitter_sub_title.split("<>");
    const icon_text_first = settings.get_fitter_sub_title_first.split("<>");
    const icon_text_second = settings.get_fitter_sub_title_second.split("<>");
    let sliderSetting = {
      autoPlay: true,
      infinite: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
      dots: true,
      arrows: false,
    };
    const ColorFitApp = [
      {
        image: `${settings.get_fitter_prod_one_img}`,
        image_xs: `${settings.get_fitter_prod_one_img_mobile}`,
        content: `${settings.get_fitter_prod_one_content}`,
      },
      {
        image: `${settings.get_fitter_prod_two_img}`,
        image_xs: `${settings.get_fitter_prod_two_img_mobile}`,
        content: `${settings.get_fitter_prod_two_content}`,
      },
      {
        image: `${settings.get_fitter_prod_three_img}`,
        image_xs: `${settings.get_fitter_prod_three_img_mobile}`,
        content: `${settings.get_fitter_prod_three_content}`,
      },
      {
        image: `${settings.get_fitter_prod_fourth_img}`,
        image_xs: `${settings.get_fitter_prod_fourth_img_mobile}`,
        content: `${settings.get_fitter_prod_fourth_content}`,
      },
    ];
    return (
      <div className="get-fitter-get-better">
        <h2 className="title">{settings.get_fitter_title}</h2>
        <div className="icon-text-wrap">
          <div className="icon-text-li">
            <img alt={settings.get_fitter_title} src={icon_text[1]} />
            <span>{HtmlParser(icon_text[0])}</span>
          </div>
          <div className="icon-text-li">
            <img alt={settings.get_fitter_title} src={icon_text_first[1]} />
            <span>{HtmlParser(icon_text_first[0])}</span>
          </div>
          <div className="icon-text-li">
            <img alt={settings.get_fitter_title} src={icon_text_second[1]} />
            <span>{HtmlParser(icon_text_second[0])}</span>
          </div>
        </div>
        <div className="product-app-block">
          <MediaQuery query="lap-and-up">
            {ColorFitApp.map((item) => {
              return (
                <div className="image-wrap">
                  <Srcset src={item.image} alt="prod image" />
                  <div className="image-content">{item.content}</div>
                </div>
              );
            })}
          </MediaQuery>
          <MediaQuery query="phone-and-tablet">
            <div className="slickSlider">
              <Slider {...sliderSetting}>
                {ColorFitApp.map((item) => {
                  return (
                    <div className="image-wrap">
                      <Srcset src={item.image_xs} alt="prod image" />
                      <div className="image-content">{item.content}</div>
                    </div>
                  );
                })}{" "}
              </Slider>
            </div>
          </MediaQuery>
        </div>

      </div>
    );
  }
}

export default ColorFitPro3AssistApp;
