import React from 'react';
import MediaQuery from '../../../components/MediaQuery';
import Slider from 'react-slick';
import Srcset from '../../../components/SrcSet';
import HtmlParser from "react-html-parser";

class ColorFitPro3AssistSlider extends React.Component{
    render(){
        const {slider_images} = this.props;
        const {image} = slider_images;
        let items = [];
        let settings = {
          dots: true,
          infinite: true,
          arrows: true,
          speed: 400,
          slidesToShow: 1,
          slidesToScroll: 1,
          autoplay: true,
          nextArrow:<span><img src="https://cdn.shopify.com/s/files/1/0997/6284/files/right-arrow-black.png?v=1621528147" style={{width: '50px'}} alt='next-arrow'/></span>,
          prevArrow:<span><img src="https://cdn.shopify.com/s/files/1/0997/6284/files/left-arrow-black.png?v=1621528147" style={{width: '50px'}} alt='prev-arrow'/></span>,
        };
       
        return(
          <div className='assist-slider'>
           <Slider {...settings}>
                {slider_images["image"] &&
                      slider_images["image"].split(";").map((item, index) => {
                          return (
                              <Srcset src={item} />
                          );
                        })}
			</Slider>
          </div>
        )
      }
}
export default ColorFitPro3AssistSlider;