import React from "react";
// import HtmlParser from "react-html-parser";
// import MediaQuery from "../../../components/MediaQuery";
// import SrcSet from "../../../components/SrcSet";
import ColorFitPro3AssistFeature from "./ColorFitPro3AssistFeature";
import ColorFitPro3AssistSlider from "./ColorFitPro3AssistSlider";
import ColorFitPro3AssistApp from "./ColorFitPro3AssistApp";
import ColorFitLiveConnectedLife from "./ColorFitLiveConnectedLife";
class ColorFitPro3AssistMain extends React.Component {
  render() {
    const { settings } = this.props;

    // What is it
    const {
      what_is_it_title,
      what_is_it_content,
      what_is_it_image,
      what_need_image_mobile,
      what_is_it_icon,
    } = settings;
    let sectionWhat = {
      title: what_is_it_title,
      content_text: what_is_it_content,
      image: what_is_it_image,
      image_xs: what_need_image_mobile,
      icon_text: what_is_it_icon,
    };
    const {
      slider_images,
    } = settings;
    let sliderImages = {
      image : slider_images,
    }
    // Bigger and better
    const {
      bigger_block_title,
      bigger_block_content1,
      bigger_block_image,
      bigger_block_image_mobile,
      bigger_block_icon_with_text,
    } = settings;
    let biggerBetter = {
      title: bigger_block_title,
      content_text: bigger_block_content1,
      image: bigger_block_image,
      image_xs: bigger_block_image_mobile,
      icon_text: bigger_block_icon_with_text,
    };

    // Wear your style
    const {
      wear_style_title,
      wear_style_image,
      wear_style_image_mobile,
      wear_style_content,
    } = settings;
    let wear_your_style = {
      title: wear_style_title,
      image: wear_style_image,
      image_xs: wear_style_image_mobile,
      content_text: wear_style_content,
    };

    // Don a new look
    const {
      don_a_new_image,
      don_a_new_image_mobile,
      don_a_new_title,
      don_a_new_content,
      don_a_new_icon_with_text,
    } = settings;
    let don_new_look = {
      image: don_a_new_image,
      image_xs: don_a_new_image_mobile,
      title: don_a_new_title,
      content_text: don_a_new_content,
      icon_text: don_a_new_icon_with_text,
    };

    // Be in the know of your health
    const {
      your_health_image,
      your_health_image_mobile,
      your_health_title,
      your_health_content,
      your_health_icon_with_text,
    } = settings;
    let your_health = {
      image: your_health_image,
      image_xs: your_health_image_mobile,
      title: your_health_title,
      content_text: your_health_content,
      icon_text: your_health_icon_with_text,
    };

    // Take it easy
    const {
      take_it_easy_title,
      take_it_easy_image,
      take_it_easy_image_mobile,
      take_it_easy_content,
      take_it_easy_icon_with_text,
    } = settings;
    let take_it_easy = {
      title: take_it_easy_title,
      image: take_it_easy_image,
      image_xs: take_it_easy_image_mobile,
      content_text: take_it_easy_content,
      icon_text: take_it_easy_icon_with_text,
    };

    // every_beat_matters_image
    const {
      every_beat_matters_image,
      every_beat_matters_image_mobile,
      every_beat_matters_title,
      every_beat_matters_content,
      every_beat_matters_icon_with_text,
    } = settings;
    let every_beat_matters = {
      image: every_beat_matters_image,
      image_xs: every_beat_matters_image_mobile,
      title: every_beat_matters_title,
      content_text: every_beat_matters_content,
      icon_text: every_beat_matters_icon_with_text,
    };

    // Good night’s sleep
    const {
      good_night_sleep_image,
      good_night_sleep_image_mobile,
      good_night_sleep_title,
      good_night_sleep_content,
      good_night_sleep_icon_with_text,
    } = settings;
    let good_night_sleep = {
      image: good_night_sleep_image,
      image_xs: good_night_sleep_image_mobile,
      title: good_night_sleep_title,
      content_text: good_night_sleep_content,
      icon_text: good_night_sleep_icon_with_text,
    };

    // FULL BANNER IMAGE
    const { full_banner_image, full_banner_image_mobile } = settings;
    let full_banner = {
      image: full_banner_image,
      image_xs: full_banner_image_mobile,
      title: "",
      content_text: "",
      icon_text: "",
    };

    // Push yourself further
    const {
      push_yourself_further_image,
      push_yourself_further_image_mobile,
      push_yourself_further_title,
      push_yourself_further_content,
      push_yourself_further_icon_with_text,
    } = settings;
    let push_yourself_further = {
      image: push_yourself_further_image,
      image_xs: push_yourself_further_image_mobile,
      title: push_yourself_further_title,
      content_text: push_yourself_further_content,
      icon_text: push_yourself_further_icon_with_text,
    };

    // Sports features banner image
    const {
      sport_features_banner_image,
      sport_features_banner_image_mobile,
    } = settings;
    let sport_features = {
      image: sport_features_banner_image,
      image_xs: sport_features_banner_image_mobile,
      title: "",
      content_text: "",
      icon_text: "",
    };
    // Make most of it
    const {
      make_most_of_it_image,
      make_most_of_it_title,
      make_most_of_it_content,
      make_most_of_it_icon_with_text,
			make_most_of_it_image_xs      
    } = settings;
    let make_most_of_it ={
      image: make_most_of_it_image,     
      image_xs : make_most_of_it_image_xs,
      title: make_most_of_it_title,
      content_text: make_most_of_it_content,
      icon_text: make_most_of_it_icon_with_text
    }
    // Just drive in 
    const {
      just_dive_in_image,
      just_dive_in_image_xs,
      just_dive_in_title,
      just_dive_in_content,
      just_dive_in_icon_with_text
    } = settings;
    let just_dive_in ={
      image: just_dive_in_image,
      image_xs : just_dive_in_image_xs,
      title: just_dive_in_title,
      content_text: just_dive_in_content,
      icon_text: just_dive_in_icon_with_text
    }

    //  Battery quit image 
    const {
      battery_quit_image,
      battery_quit_image_xs,
      battery_quit_title,
      battery_quit_content,
      battery_quit_icon_with_text
    } = settings;
    let battery_quit ={
      image: battery_quit_image,
      image_xs : battery_quit_image_xs,
      title: battery_quit_title,
      content_text: battery_quit_content,
      icon_text: battery_quit_icon_with_text
    }

    return (
      <div className="color-fit-pro3-main-seciton">    
        <div className="section-what-wrapper">
          <ColorFitPro3AssistFeature image_with_text={sectionWhat} />
        </div>
        <div className="slider-infographics">
          <ColorFitPro3AssistSlider slider_images={sliderImages} />
        </div>
        <div className="bigger-better-wrapper">
          <ColorFitPro3AssistFeature image_with_text={biggerBetter} />
        </div>
        <div className="wear-your-style-wrapper">
          <ColorFitPro3AssistFeature image_with_text={wear_your_style} />
        </div>
        <div className="don-new-look-wrapper">
          <ColorFitPro3AssistFeature image_with_text={don_new_look} />
        </div>
        <div className="your-health-wrapper">
          <ColorFitPro3AssistFeature image_with_text={your_health} />
        </div>
        <div className="take-it-easy-wrapper">
          <ColorFitPro3AssistFeature image_with_text={take_it_easy} />
        </div>
        <div className="every-beat-matters-wrapper">
          <ColorFitPro3AssistFeature image_with_text={every_beat_matters} />
        </div>
        <div className="good-night-sleep-wrapper">
          <ColorFitPro3AssistFeature image_with_text={good_night_sleep} />
        </div>
        <div className="full-banner-image-wrapper">
          <ColorFitPro3AssistFeature image_with_text={full_banner} />
        </div>
        <div className="push-yourself-further-wrapper">
          <ColorFitPro3AssistFeature image_with_text={push_yourself_further} />
        </div>
        <ColorFitPro3AssistApp settings={settings} />
        <div className="sports-features-banner-wrapper">
          <ColorFitPro3AssistFeature image_with_text={sport_features} />
        </div>
        <div className="live-connected-life-wrapper">
          <ColorFitLiveConnectedLife settings={settings} />
        </div>
        <div className='make-most-of-it'>
          <ColorFitPro3AssistFeature image_with_text={ make_most_of_it} />
        </div>
        <div className='every-beat-matters-wrapper just-dial-wrapper'>
          <ColorFitPro3AssistFeature image_with_text={just_dive_in} />
        </div>
        <div className='battery-quit'>
          <ColorFitPro3AssistFeature image_with_text={battery_quit} />
        </div>
      </div>
    );
  }
}
export default ColorFitPro3AssistMain;
