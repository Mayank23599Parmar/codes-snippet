import React, { Component } from "react";
import MediaQuery from "../../../components/MediaQuery";
import Srcset from "../../../components/SrcSet";

export class ColorFitPro3AssistLast extends Component {
  render() {
    return (
      <div className="smart-features-last">
        <h2 className="smart-feature-title xs-hide">And a lot more </h2>
        <div className="smart-feature-mode">
          <div className="smart-feature-section">
            <div className="smart-feature-image-banner">
              <img src="https://cdn.shopify.com/s/files/1/0997/6284/files/1-keyshot-111.png?v=1612521693" />
            </div>
            <ul className="">
              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/weather_8825e39c-fd6b-4f3b-8198-562f599494eb.svg?v=1612512833' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/weather_38b2e980-8fae-4ea2-870f-64885048de36.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                  <span className="left-text">Weather<br className="dw-mobile"></br> forecast</span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Reminder</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/reminder_9554f30c-eb80-4a27-9773-57ed5f545ac8.svg?v=1612523365' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/reminder_32b94021-95bb-4960-8277-15d361f1149d.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/call_rejection_a44679a9-36c8-41c4-9947-b268daf9a17b.svg?v=1612523365' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/call_rejection_649931a8-5081-432c-abcb-9af65a064156.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                  <span className="left-text">Call<br className="dw-mobile"></br> rejection</span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Alarm</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/alarm_2dda9449-ae6b-4cd9-8dbe-b1eaae549359.svg?v=1612523365' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/alarm_fc7d55c2-b8ef-4fb4-acc0-41487d32ed45.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/find_my_phonw_b0ee6067-d68c-47b5-9ccc-dfc9b0daf675.svg?v=1612523365' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/find_my_phonw_5c4c450c-2cb9-4c93-a03f-95e0fc903dbe.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                  <span className="left-text">Find my<br className="dw-mobile"></br> phone</span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Timer</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/timer.svg?v=1612512832' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/timer_5bfaf812-4704-4a99-88ed-70422f0ada64.svg?v=1612591273'/>
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/hand_wash_reminder_a2340e6e-1216-4a95-ad41-bed2b283b7a7.svg?v=1612523365' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/hand_wash_reminder_9668fa89-60f3-4b95-b8a3-6fc0b4c17065.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                  <span className="left-text">
                    Hand wash
                    <br />
                    reminder
                  </span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Stopwatch</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/stop_watch_ebc8c459-d259-496d-b837-9b2d6e283ac6.svg?v=1612523365' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/stop_watch_d5efa381-8423-43ea-8201-57d98dc6f422.svg?v=1612591273'/>
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/sedentary_67a8b90c-c4b3-4ab8-82bb-652251dc7b6a.svg?v=1612523365' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/sedentary_044e61ff-8243-4284-8427-bdfdb88da793.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                  <span className="left-text">
                    Sedentary
                    <br />
                    reminder
                  </span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Wake<br className="dw-mobile"></br> gesture</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/wake.svg?v=1612512832' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/wake_7ad7064e-1a43-4f56-94cc-2bbc2965e7b3.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/calendar_fd2b665e-f607-4ebf-ac46-fffca17c53c2.svg?v=1612523365' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/calendar_a842bc4e-54ec-4b94-a576-642c1927aa40.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                  <span className="left-text">Calender<br className="dw-mobile"></br> reminder</span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Vibration<br className="dw-mobile"></br> alert</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/vibration_3ca42b03-4d57-4f40-95e8-93a569bf236b.svg?v=1612523365' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/vibration_410d0842-8677-461e-8ae0-33dd358d500c.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/remote_music_8cee7e50-eaf4-48bd-abdb-4ad03ce3fc37.svg?v=1612523365' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/remote_music_7e70c355-03e9-4782-a026-392bd262c1fd.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                  <span className="left-text">
                    Remote music<br className="dw-mobile"></br>
                    control
                  </span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Do not<br className="dw-mobile"></br> disturb mode</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/do_not_disturb.svg?v=1612512833' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/do_not_disturb_7fe2dad6-b5b4-4288-b42d-a98e73d75129.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/sleep_montor_dfb054d8-8981-4045-87e1-3a8bd37b4da6.svg?v=1612523365' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/sleep_montor_1bef8cad-9aa1-4859-9db5-3afcf289cb49.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                  <span className="left-text">Sleep<br className="dw-mobile"></br> monitor</span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Screen<br className="dw-mobile"></br> brightness</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/screen_brightness_8149bca5-536c-420c-80ad-9a99ec257c27.svg?v=1612523365' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/screen_brightness_54d71798-8c30-4734-91a4-47ac6a4487c1.svg?v=1612591272'/>
                    </span>
                  </MediaQuery>
                </div>
              </li>

             

              {/* <li class="flex_view_xs middle">
                <div class="feature-left col-xs-6 col-sm-6">
                  
                </div>
              </li> */}
            </ul>
          </div>
        </div>
      </div>
    );
  }
}

export default ColorFitPro3AssistLast;
