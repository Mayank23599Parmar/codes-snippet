import React, { Component } from "react";
import MediaQuery from "../../components/MediaQuery";
import Srcset from "../../components/SrcSet";

export class Pulsefeaturesection extends Component {
  render() {
    return (
      <div className="smart-features-last">
          <MediaQuery query='phone-and-tablet'>
            <div className="feature-image">
                <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/3-2-2.jpg?v=1628762795'/>
            </div>
        </MediaQuery>
        <div className="title-image">                      
            <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/9_1_c5e5f05f-39cf-42ac-a208-ae270a5a13ba.png?v=1627039207' />
        </div>
        
        <div className="smart-feature-mode">
          <div className="smart-feature-section">
            {/* <div class="smart-feature-image-banner">
              <img src="https://cdn.shopify.com/s/files/1/0997/6284/files/1-keyshot-111.png?v=1612521693" />
            </div> */}
            <ul className="">
              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/weather_6905667d-3c93-4a32-81f1-6611c9d48971.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/weather_6905667d-3c93-4a32-81f1-6611c9d48971.svg?v=1627040679'/>
                    </span>
                  </MediaQuery>
                  <span className="left-text">Weather forecast</span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Wake gesture</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/wake_deb3c69f-8c5d-4433-a895-1dbc9857ddca.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/wake_deb3c69f-8c5d-4433-a895-1dbc9857ddca.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/call-pulse.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/call-pulse.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <span className="left-text">Call rejection</span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Calendar reminder</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/calender.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/calender.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/alarm-pul.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/alarm-pul.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <span className="left-text">Alarm</span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Vibration alert</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/vibration-alert.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/vibration-alert.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/find-my-phone.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/find-my-phone.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <span className="left-text">
                  Find my phone
                  </span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Remote music control</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Remote-control.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Remote-control.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/timer_bf27bec6-9d8e-4a4a-9783-40520da0d944.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/timer_bf27bec6-9d8e-4a4a-9783-40520da0d944.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <span className="left-text">
                  Timer
                  </span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Do not disturb mode</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/dnd.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/dnd.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                <MediaQuery query='phone-and-tablet'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/stopwatch.svg?v=1627040679'/>
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/stopwatch.svg?v=1627040679'/>
                    </span>
                  </MediaQuery>
                  <span className="left-text">Stopwatch</span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Sleep monitor</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/sleep-monitor_a0a6ac85-07d3-4c01-a12e-a22af8284baa.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/sleep-monitor_a0a6ac85-07d3-4c01-a12e-a22af8284baa.svg?v=1627040679'/>
                    </span>
                  </MediaQuery>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/walk.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/walk.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <span className="left-text">
                  Walk reminder
                  </span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Screen brightness control</span>
                  <MediaQuery query='phone-and-tablet'>
                    <span>
                      <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/screen.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                  <MediaQuery query='lap-and-up'>
                    <span>
                    <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/screen.svg?v=1627040679' />
                    </span>
                  </MediaQuery>
                </div>
              </li>

              

             

              {/* <li class="flex_view_xs middle">
                <div class="feature-left col-xs-6 col-sm-6">
                  
                </div>
              </li> */}
            </ul>
          </div>
        </div>
        <MediaQuery query='lap-and-up'>
            <div className="feature-image">
                <Srcset src='https://cdn.shopify.com/s/files/1/0997/6284/files/Akashdeep_Desk.jpg?v=1628763164'/>
            </div>
        </MediaQuery>
      </div>
    );
  }
}

export default Pulsefeaturesection;
