import React, { Component } from "react";
import MediaQuery from "../../../components/MediaQuery";
import Srcset from "../../../components/SrcSet";

export class LiveFearless extends Component {
  render() {
    const { livefearless_section } = this.props;
    if (Object.keys(livefearless_section).length === 0) {
          return null;
    }
    return (
      <div className='livefearless-section'>
        <div className='img'>
					<MediaQuery query="lap-and-up" >
						<Srcset src={livefearless_section.image} />
					</MediaQuery>
					<MediaQuery query="phone-and-tablet" >
						<Srcset src={livefearless_section.image_xs} />
					</MediaQuery>
        </div>
				<div className='content'>
					<h1 className='title'>{livefearless_section.title}</h1>
					<h3 className='desc'>{livefearless_section.desc}</h3>
          <ul className="live-fearless-icons">
					<li className="flex-view-xs center middle">
						<span><img src="https://cdn.shopify.com/s/files/1/0997/6284/files/5ATM_Water_resistant.svg?v=1621577533"/></span>
						<p className="text">5ATM water-resistant</p>
					</li>
				</ul>
				</div>
      </div>
    );
  }
}

export default LiveFearless;
