import React, { Component } from 'react'
import MediaQuery from '../../../components/MediaQuery';
import Srcset from '../../../components/SrcSet';

export class NoisfitLiveStylish extends Component {
	render() {
		const { livestylish_section } = this.props;
		if (Object.keys(livestylish_section).length === 0) {
      		return null;
		}
		const { 
			title,
			sub_title,
			content,
			image,
			image_xs
		} =livestylish_section;
		return (
			<div className="noise-active-live-stylish">
				{title && <h1 className='title'>{title}</h1>}
				{sub_title && <h3 className='sub-title'>{sub_title}</h3>}
				<div className='img'>
					<MediaQuery query="lap-and-up" >
					 { image &&	<Srcset src={image} />}
					</MediaQuery>
					<MediaQuery query="phone-and-tablet">
						{image_xs && <Srcset src={image_xs} />}
					</MediaQuery>
				</div>
				<div className='content'>
					{content && <h3 className='desc'>{content}</h3>}
					<ul className="live-stylish-icons">
					<li className="flex-view-xs center middle">
						<span><img src="https://cdn.shopify.com/s/files/1/0997/6284/files/cloudbased_watchface.svg?v=1621578023"/></span>
						<p className="text"> Cloud-based watch faces</p>
						</li>
					</ul>
				</div>
			</div>
		)
	}
}

export default NoisfitLiveStylish
