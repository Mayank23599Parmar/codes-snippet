import React, { Component } from "react";
import MediaQuery from "../../../components/MediaQuery";
import Srcset from "../../../components/SrcSet";

export class LiveWellSection extends Component {
  render() {
		const { livewell_section } = this.props;
		if (Object.keys(livewell_section).length === 0) {
      		return null;
		}
		
    return (
      <div className="nosie-active-live-well">
        {livewell_section.title && <h1 className="title">{livewell_section.title}</h1>}
				<div className="img">
					<MediaQuery query="lap-and-up">
						{livewell_section.image && 
							<Srcset src={livewell_section.image} />
						}
					</MediaQuery>
					<MediaQuery query="phone-and-tablet" >
						{livewell_section.image_xs && 
							<Srcset src={livewell_section.image_xs} />
						}
					</MediaQuery>
				</div>
				<div className="content">
					{livewell_section.sub_head &&	<h2 className="sub-head"> {livewell_section.sub_head} </h2>}
					{livewell_section.content && <p className="desc">{livewell_section.content}</p> } 
					<div className='icon-and-text'>
						<div> <span className='img'> <Srcset src={livewell_section.icon_1} /> </span> <p className="text">{livewell_section.text_1}</p> </div>
					</div>
				</div>
      </div>
    );
  }
}

export default LiveWellSection;
