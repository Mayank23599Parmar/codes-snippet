import React, { Component } from "react";
import Srcset from "../../../components/SrcSet";

export class LiveSmartActive extends Component {
  render() {
    return (
      <div className="smart-features-last">
        <div className="smart-feature-mode">
          <div className="smart-feature-section">
            <div className="smart-feature-image-banner">
              <img src="https://cdn.shopify.com/s/files/1/0997/6284/files/livesmartImage.png?v=1621327117" />
            </div>
            <ul className="">
              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <span>
                    <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/weather_38b2e980-8fae-4ea2-870f-64885048de36.svg?v=1612591272" />
                  </span>

                  <span className="left-text">
                    Weather<br className="dw-mobile"></br> forecast
                  </span>
                </div>
                <div className="feature-right">
                  <span className="right-text">
                    Screen<br className="dw-mobile"></br> brightness
                  </span>
                  <span>
                    <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/screen_brightness_54d71798-8c30-4734-91a4-47ac6a4487c1.svg?v=1612591272" />
                  </span>
                </div>
              </li>

              <li className="flex_view_xs middle">
              <div className="feature-left col-xs-6 col-sm-6 moon-img">
                  <span>
                    <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/do_not_disturb_7fe2dad6-b5b4-4288-b42d-a98e73d75129.svg?v=1612591272" />
                  </span>

                  <span className="left-text">
                    Do not disturb
                    <br/> mode
                  </span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Alarm</span>
                  <span>
                    <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/alarm_fc7d55c2-b8ef-4fb4-acc0-41487d32ed45.svg?v=1612591272" />
                  </span>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <span>
                    <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/find_my_phonw_5c4c450c-2cb9-4c93-a03f-95e0fc903dbe.svg?v=1612591272" />
                  </span>

                  <span className="left-text">
                    Find my<br className="dw-mobile"></br> phone
                  </span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Timer</span>
                  <span>
                    <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/timer_5bfaf812-4704-4a99-88ed-70422f0ada64.svg?v=1612591273" />
                  </span>
                </div>
              </li>

              <li className="flex_view_xs middle">
                
                <div className="feature-left col-xs-6 col-sm-6">
                  <span>
                    <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/call_rejection_649931a8-5081-432c-abcb-9af65a064156.svg?v=1612591272" />
                  </span>

                  <span className="left-text">
                    Call<br className="dw-mobile"></br> rejection
                  </span>
                </div>
                <div className="feature-right">
                  <span className="right-text">Stopwatch</span>
                  <span>
                    <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/stop_watch_d5efa381-8423-43ea-8201-57d98dc6f422.svg?v=1612591273" />
                  </span>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <span>
                    <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/sedentary_044e61ff-8243-4284-8427-bdfdb88da793.svg?v=1612591272" />
                  </span>

                  <span className="left-text">
                    Sedentary
                    <br />
                    reminder
                  </span>
                </div>
                <div className="feature-right">
                  <span className="right-text">
                    Wake<br className="dw-mobile"></br> gesture
                  </span>
                  <span>
                    <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/wake_7ad7064e-1a43-4f56-94cc-2bbc2965e7b3.svg?v=1612591272" />
                  </span>
                </div>
              </li>

              <li className="flex_view_xs middle">
                <div className="feature-left col-xs-6 col-sm-6">
                  <span>
                    <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/remote_music_7e70c355-03e9-4782-a026-392bd262c1fd.svg?v=1612591272" />
                  </span>

                  <span className="left-text">
                    Remote music<br className="dw-mobile"></br>
                    control
                  </span>
                </div>
                <div className="feature-right">
                  <span className="right-text">
                    Vibration<br className="dw-mobile"></br> alert
                  </span>
                  <span>
                    <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/vibration_410d0842-8677-461e-8ae0-33dd358d500c.svg?v=1612591272" />
                  </span>
                </div>
              </li>
            </ul>
          </div>
        </div>
        <h1 className="smart-feature-title">Live smart</h1>
        <div className="content">
          <h3 className="desc">
            Get more and live your best life with NoiseFit Active.
          </h3>
        </div>
      </div>
    );
  }
}

export default LiveSmartActive;
