import React, { Component } from "react";
import Slider from 'react-slick';
import MediaQuery from "../../../components/MediaQuery";
import Srcset from '../../../components/SrcSet';

export class NoiseFitActiveSlider extends Component {
  render() {
		const { noisefitSlider } = this.props;
    let items = [];
    let settings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
      nextArrow:<span><img src="https://cdn.shopify.com/s/files/1/0997/6284/files/right-arrow-black.png?v=1621528147"  alt='next-arrow'/></span>,
      prevArrow:<span><img src="https://cdn.shopify.com/s/files/1/0997/6284/files/left-arrow-black.png?v=1621528147" alt='prev-arrow'/></span>,
			responsive: [
        {
          breakpoint: 1025,
          settings: {
            arrows: true,
						slidesToShow: 1,
            // centerMode: true
          }
        }
      ]
		};
    for (let i = 1; i < 20; i++) {
      let slider_image;
      let content;
      let title;
      
      if (noisefitSlider["image_" + i]) {
        slider_image = noisefitSlider["image_" + i];
      }
      
      if (noisefitSlider["content_" + i]) {
        content = noisefitSlider["content_" + i];
      }
      if (noisefitSlider["title_" + i]) {
        title = noisefitSlider["title_" + i];
      }
      if (
        slider_image &&
        content 
        // title 
      ) {
        items.push({
          slider_image: slider_image,
          content: content,
          // title: title
        });
      }
    }
    let sliderElements = items.map((item, index) => {
      return (
        <div className="slider-element">
          <div className="flex-view">
            <div className='text-area col-md-6'>
              <div className='text'>
                <h1 className='color-black title'>{noisefitSlider.title}</h1>
                	<h5 className='color-black sub-title'>{item.content}</h5>
								<MediaQuery query="lap-and-up">
                  <div className='icon-with-text'>
                    <div className='single-line'>
                      <span className='img'> <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/noiseactive-slider-logo.png?v=1621495531" /> </span>
                      <p className='icon-text'>NoiseFit app </p>
                    </div>
                    <div className='single-line'>
                      <span className='img'> <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/noiseactive-slider-heartlogo.png?v=1621495531" /> </span>
                      <p className='icon-text' >Google Fit </p>
                    </div>
                  </div>
                </MediaQuery>
              </div>
            </div>
            <div className='image-area col-md-6'>
              <div className='img'>
                <Srcset src={item.slider_image} />
              </div>
							<MediaQuery query="phone-and-tablet">
								<h3 className='content'>{item.content}</h3>
							</MediaQuery>
            </div>
          </div>
        </div>
      );
    });
    if(items.length<1){
      return false;
    }
    return (
			<div className='noisefit-silder '>
				<div className='container'>
					{/* <h1 className='text-align-center color-white xs-show title'>{noisefitSlider.sub_title}</h1> */}
					<Slider {...settings}>
						{sliderElements}
					</Slider>
				</div>
			</div>
    );
  }
}

export default NoiseFitActiveSlider;
