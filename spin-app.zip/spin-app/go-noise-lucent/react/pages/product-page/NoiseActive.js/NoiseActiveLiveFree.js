import React, { Component } from "react";
import Srcset from "../../../components/SrcSet";
import MediaQuery from "../../../components/MediaQuery";
export class NoiseActiveLiveFree extends Component {
  render() {
	const {data} = this.props;
    return (
		<div className="active-live-free-section-container">
		<div className="active-live-free-section">
			<div className="flex-view-xs middle">
				<div className="col-sm-3 col-xs-6">
					<div className="left-img">
						<Srcset src={data.left_img} />
					</div>
				</div>
				<MediaQuery query="tablet-and-up">
					<div className="col-sm-6">
				<div className="live-free-text-content">
				<h2>
				{data.title}
				</h2>
				<h3>
				{data.text}
				</h3>
				<ul className="live-free-icons">
					<li className="flex-view-xs center middle">
						<span><img src="https://cdn.shopify.com/s/files/1/0997/6284/files/ssssss_30x.png?v=1621247706"/></span>
						<p className="text">{data.icon_text}</p>
					</li>
				</ul>
		</div></div>
				</MediaQuery>
				<div className="col-sm-3 col-xs-6">
					<div className="right-img">
						<Srcset src={data.right_img}  />
					</div>
				</div>
			</div>
			<div className="live-free-days-text">
				<h2>{data.day1}</h2>
				<h2>{data.day2}</h2>
			</div>
		</div>
		<MediaQuery query="phone">
		<div className="live-free-text-content">
				<h2>
				{data.title}
				</h2>
				<h3>
				{data.text}
				</h3>
				<ul className="live-free-icons">
					<li className="flex-view-xs center middle">
						<span><img src="https://cdn.shopify.com/s/files/1/0997/6284/files/ssssss_30x.png?v=1621247706"/></span>
						<p className="text">{data.icon_text}</p>
					</li>
				</ul>
		</div>
		</MediaQuery>
	</div>
    );
  }
}

export default NoiseActiveLiveFree;
