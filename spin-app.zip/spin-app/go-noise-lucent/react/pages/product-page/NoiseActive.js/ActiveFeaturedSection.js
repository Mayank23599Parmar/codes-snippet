import React, { Component } from "react";
import MediaQuery from "../../../components/MediaQuery";
import Srcset from "../../../components/SrcSet";

export class ActiveFeaturedSection extends Component {
  render() {
    let { feature_section } = this.props;
    if (Object.keys(feature_section).length === 0) {
      return null;
    }
    
    return (
      <div className="features-section">
        <MediaQuery query="lap-and-up" >
            <div className="main-div">
                <div className='single-line'>
                    <div className='blank-part'>

                    </div>
                    <div className='icon-part'>
                        <div>
                            <div className='img'>
                                <Srcset src={feature_section.icon_1} />
                            </div>
                            <p className='icon-text'>{feature_section.text_1}</p>
                        </div>
                    </div>
                    <div className='blank-part'>

                    </div>
                    <div className='icon-part'>
                        <div>
                            <div className='img'>
                                <Srcset src={feature_section.icon_2} />
                            </div>
                            <p className='icon-text'>{feature_section.text_2}</p>
                        </div>
                    </div>
                    <div className='blank-part'>

                    </div>
                    <div className='icon-part'>
                        <div>
                            <div className='img'>
                                <Srcset src={feature_section.icon_3} />
                            </div>
                            <p className='icon-text'>{feature_section.text_3}</p>
                        </div>
                    </div>
                    <div className='blank-part'>

                    </div>
                    <div className='icon-part'>
                        <div>
                            <div className='img'>
                                <Srcset src={feature_section.icon_4} />
                            </div>
                            <p className='icon-text'>{feature_section.text_4}</p>
                        </div>
                    </div>
                </div>
                <div className='single-line' > 
                    <div className='icon-part'>
                        <div>
                            <div className='img'>
                                <Srcset src={feature_section.icon_5} />
                            </div>
                            <p className='icon-text'>{feature_section.text_5}</p>
                        </div>
                    </div>
                    <div className='blank-part'>
                        
                    </div>
                    <div className='icon-part'>
                        <div>
                            <div className='img'>
                                <Srcset src={feature_section.icon_6} />
                            </div>
                            <p className='icon-text'>{feature_section.text_6}</p>
                        </div>
                    </div>
                    <div className='blank-part'>

                    </div>
                    <div className='icon-part'>
                        <div>
                            <div className='img'>
                                <Srcset src={feature_section.icon_7} />
                            </div>
                            <p className='icon-text'>{feature_section.text_7}</p>
                        </div>
                    </div>
                    <div className='blank-part'>

                    </div>
                    <div className='icon-part'>
                        <div>
                            <div className='img'>
                                <Srcset src={feature_section.icon_8} />
                            </div>
                            <p className='icon-text'>{feature_section.text_8}</p>
                        </div>
                    </div>
                    <div className='blank-part'>

                    </div>

                </div>
            </div>

        </MediaQuery>
        <MediaQuery query="phone-and-tablet" >
            <div className='main-div'>
                <div className='single-line'>
                    <div className='icon-part'>
                        <div>
                            <div className='img'>
                                <Srcset src={feature_section.icon_1} />
                            </div>
                            <p className='icon-text'>{feature_section.text_1}</p>
                        </div>
                    </div>
                    <div className='icon-part'>
                        <div>
                            <div className='img'>
                                <Srcset src={feature_section.icon_2} />
                            </div>
                            <p className='icon-text'>{feature_section.text_2}</p>
                        </div>
                    </div>
                    <div className='icon-part'>
                        <div>
                            <div className='img'>
                                <Srcset src={feature_section.icon_3} />
                            </div>
                            <p className='icon-text'>{feature_section.text_3}</p>
                        </div>
                    </div>
                    <div className='icon-part'>
                        <div>
                            <div className='img'>
                                <Srcset src={feature_section.icon_4} />
                            </div>
                            <p className='icon-text'>{feature_section.text_4}</p>
                        </div>
                    </div>
                </div>
                <div className='single-line'>
                    <div className='icon-part'>
                        <div>
                            <div className='img'>
                                <Srcset src={feature_section.icon_5} />
                            </div>
                            <p className='icon-text'>{feature_section.text_5}</p>
                        </div>
                    </div>
                    <div className='icon-part'>
                        <div>
                            <div className='img'>
                                <Srcset src={feature_section.icon_6} />
                            </div>
                            <p className='icon-text'>{feature_section.text_6}</p>
                        </div>
                    </div>
                    <div className='icon-part'>
                        <div>
                            <div className='img'>
                                <Srcset src={feature_section.icon_7} />
                            </div>
                            <p className='icon-text'>{feature_section.text_7}</p>
                        </div>
                    </div>
                    <div className='icon-part'>
                        <div>
                            <div className='img'>
                                <Srcset src={feature_section.icon_8} />
                            </div>
                            <p className='icon-text'>{feature_section.text_8}</p>
                        </div>
                    </div>

                </div>
            </div>

        </MediaQuery>
      </div>
    );
  }
}

export default ActiveFeaturedSection;
