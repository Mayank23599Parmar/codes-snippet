import React from "react";
/* Redux */
import { connect } from "react-redux";
/* Actions */
import {setVariant} from '../../../redux/product/productAction';
/* helper */
import { queryString, queryStringVariant } from '../../../components/Helper';
/* Comp imports */
import Loading from "../../../components/loader/loader";
import ProductBanner from "../ProductBanner";
import ProductSlider from '../ProductSlider';
import SpecificationSection from "../SpecificationSection";
import FAQSection from '../FAQSection';
import ProductReview from '../ProductReview';
import ProductBar from '../ProductBar';
import WarrantySection from '../WarrantySection';
import SEODisclaimerSection from '../SEODisclaimerSection';
import SEOQuestions from '../SEOQuestions';
import ActiveFeaturedSection from './ActiveFeaturedSection';
import LiveWellSection from './LiveWellSection';
import NoisfitLiveStylish from './NoisfitLiveStylish';
import LiveFearless from './LiveFearless';
import LiveSmartActive from './LiveSmartActive';
import NoiseFitActiveSlider from './NoiseFitActiveSlider';
import ActiveRoundWatch from '../ActiveRoundWatch';
import ActiveFourWatchSection from '../ActiveFourWatchSection';
import ActiveSportsMode from '../ActiveSportsMode';
import ActiveLiveMindfully from '../ActiveLiveMindfully';
import ActiveLiveConnected from '../ActiveLiveConnected';
import NoiseActiveLiveFree from './NoiseActiveLiveFree';
import RelatedProductsSection from '../RelatedProductsSection';
import Offersimple from '../Offersimple';
import MediaQuery from '../../../components/MediaQuery';
class NoiseActiveProductMain extends React.Component {
  constructor(props) {
    super(props)
    this.prodRef = React.createRef();
    this.featureRef = React.createRef();
    this.state = {
      showBar: false
    }
  }

  componentDidMount() {
    window.addEventListener('scroll', this.handleScroll);
    // const { setVariant, productData } = this.props;
    // let queryStringsData = queryString(location.href);
    // if(productData.product){
    //   if(queryStringsData.variant){
    //     let passVariant = productData.product.variants.find((vari)=>{
    //       return vari.id === parseInt(queryStringsData.variant.value);
    //     })
    //     if(passVariant){
    //       setVariant(passVariant);
    //     }
    //   }
    //   else{
    //     queryStringVariant(productData.variant);
    //   }
    // }
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.handleScroll);
  }

  handleScroll = (event) => {
    let productSection = this.prodRef.current;
    let featureSection = this.featureRef.current;
    //if(window.pageYOffset <= featureSection.offsetTop && (window.pageYOffset + 100)  > productSection.offsetTop ){
  if(window.pageYOffset <= (featureSection.offsetTop - 500) && (window.pageYOffset + 200)  > productSection.offsetTop ){

      this.setState({showBar: false})
    }
    else{
      this.setState({showBar: true})
    }
  }

  render() {
    const { metafields, loading, product, compareProducts, relatedProducts } = this.props.productData;
    const { showBar } = this.state
    let offer2 = product.tags.includes("offer2") ? true : false;
    if (loading) {
      return <Loading />;
    }
    // const pageStatus = checkErrorPage(window.location.href);
    // if (pageStatus) {
    //   return <ErrorPage show={true} />;
    // }
    if(cn(metafields)){
      return(
        <div>
        {showBar && <ProductBar prodRef={(this.prodRef)} />}
        <div ref={this.prodRef}><ProductSlider metaData={metafields} /></div>
        <ProductReview product={product} />
        </div>
      )
    }

    return (
      <div id="NoiseFitActive">
        {offer2 &&
        <MediaQuery query="phone">
       {showBar &&<Offersimple product={product} prodRef={(this.prodRef)} />}
       </MediaQuery>
        }
        <ProductBar prodRef={(this.prodRef)} />
        {metafields.banner_section && <div><ProductBanner banner_section={metafields.banner_section}  /></div>}
        <div ref={this.prodRef}><ProductSlider metaData={metafields} /></div>
        {/* <ActiveFeaturedSection  /> */}
        {metafields.feature_section && <div ref={this.featureRef}><ActiveFeaturedSection feature_section={metafields.feature_section} /></div>}
        {metafields.active_round_image && <ActiveRoundWatch active_round_image={metafields.active_round_image} />}
        {metafields.livewell_section && <LiveWellSection livewell_section={metafields.livewell_section} /> }
        {metafields.Active_Four_Watch && <ActiveFourWatchSection Active_Four_Watch={metafields.Active_Four_Watch} />}
        {metafields.Active_Sports_Mode && <ActiveSportsMode Active_Sports_Mode={metafields.Active_Sports_Mode} />}
        {metafields.Active_Live_Mind && <ActiveLiveMindfully Active_Live_Mind={metafields.Active_Live_Mind} />}
        {metafields.noisefitSlider && <NoiseFitActiveSlider noisefitSlider={metafields.noisefitSlider} />}
        {metafields.Active_Live_Connect && <ActiveLiveConnected Active_Live_Connect={metafields.Active_Live_Connect} />}
        {metafields.livestylish_section && <NoisfitLiveStylish livestylish_section={metafields.livestylish_section} />}
        {metafields.live_free &&<NoiseActiveLiveFree data={metafields.live_free} />}
        {metafields.livefearless_section && <LiveFearless livefearless_section={metafields.livefearless_section} />}
        <LiveSmartActive />
        {metafields.specifications && <SpecificationSection specifications={metafields.specifications} />}
        {/* {compareProducts && <CompareProducts compareProducts={compareProducts} />} */}
        {metafields.warrantySection && <WarrantySection warrantyData={metafields.warrantySection} />}
        {metafields.FAQ && <FAQSection FAQ={metafields.FAQ} />}
        {metafields.review && <ProductReview product={product} review={metafields.review} />}
        {metafields.SEODisclaimer  && <SEODisclaimerSection data={metafields.SEODisclaimer} />}
        {relatedProducts && relatedProducts.length > 0 && <RelatedProductsSection productList={relatedProducts} />}
        {metafields.SEOQuestions && <SEOQuestions data={metafields.SEOQuestions} /> }
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  productData: state.product,
});
const mapDispatchToProps = dispatch => ({
  setVariant: variant => dispatch(setVariant(variant))
});
export default connect(mapStateToProps,mapDispatchToProps)(NoiseActiveProductMain);
