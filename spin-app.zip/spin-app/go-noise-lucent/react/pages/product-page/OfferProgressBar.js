import React from 'react';
import Countdown from "react-countdown";
import MediaQuery from "../../components/MediaQuery";
class OfferProgressBar extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            offerShow : false,
            progress : 0,
            startDate: null,
            endDate: null,
            offerText: ''
        }
    }
    Completionist = () => <span>Limited stock left!</span>;
    renderer = (props) => {
        let {completed, formatted } = props;
        let { hours, minutes, seconds } = formatted;

        if (completed) {
            return this.Completionist();
        } else {
            // Render a countdown
            return (
            <span>
                {hours}h:{minutes}m:{seconds}s
            </span>
            );
        }
    };
    getTag = (tags,text) =>{
        let findText = tags.find((tag)=> tag.includes(text));
        if(findText){
            findText = findText.replace(text,'');
        }
        return findText;
    }
    updateProgressBar = () =>{
        let {offerShow,endDate,seconds,startDate} = this.state;
        let curDate = new Date();
        if(curDate >= endDate){
            seconds = `100%`;
            this.setState({seconds});
            clearInterval(this.interval);
        }else{
            let totalSeconds = Math.abs(endDate - startDate) / 1000;
            let newSeconds = Math.abs(endDate - curDate) / 1000;
            let seconds = (newSeconds * 100) / totalSeconds;
            seconds = `${100 - seconds}%`;
            this.setState({seconds});
        }
    }
    componentWillUnmount() {
        clearInterval(this.interval);
    }
    componentDidMount(){
        let {tags} = this.props.product;
        let offerShow = this.checkOfferShow(tags);
        let endDate = this.getDate(tags,'offerends_');
        let startDate = this.getDate(tags,'offerstart_');
        let curDate = new Date();
        // let seconds = endDate.getTime() * 100 / startDate.getTime();
        // let seconds = `${(startDate.getTime() * 100) / endDate.getTime()}%`;
        let totalSeconds = Math.abs(endDate - startDate) / 1000;
        let newSeconds = Math.abs(endDate - curDate) / 1000;
        let seconds = (newSeconds * 100) / totalSeconds;
        seconds = `${100 - seconds}%`;
        let offerText = this.getTag(tags,'offertext_')
        if(offerShow){
            this.setState({offerShow :  true,endDate,seconds,startDate,offerText},()=>{
                this.interval = setInterval(() => this.updateProgressBar() , 1000);
            });
        }
    }
    getDate = (tags,text) =>{
        let date = tags.find((tag)=> tag.includes(text));
        if(date){
            date = date.replace(text,'');
        }
        return new Date(date);
    }
    checkOfferShow = tags =>{
        let textFound = false, dateEndFound = false, dateStartFound = false, offerFound = false, offerShouldShow= false;
        for(let i=0; i<tags.length; i++){
            let tag = tags[i];
            if(tag.includes('offertext_')){
                textFound = true;
            }
            if(tag.includes('offerends_')){
                dateEndFound = true;
            }
            if(tag.includes('offerstart_')){
                dateStartFound = true;
            }
            if(tag.includes('offeractive')){
                offerFound = true;
            }
        }
        if(textFound && dateEndFound && offerFound && dateStartFound){
            offerShouldShow  = true;
        }
        return offerShouldShow;
    }
    render(){
        // let {tags} = this.props.product;
        // let offerShow = this.checkOfferShow(tags);
        // if(!offerShow){
        //     return null;
        // }
        // let date = this.getDate(tags);
        // let curDate = new Date();
        // let seconds = date.getTime() - curDate.getTime();
        let {offerShow,endDate,startDate,seconds,offerText} = this.state;
        if(!offerShow){
            return null;
        }
        return(
            <div className="offer-progress-bar">
                <div className="text-center">
                    <div className="flex-view-xs space-between">
                        {offerText && <span className="offer-text">{offerText}</span>}
                        <MediaQuery query="phone">
                            <div className="date-remain">
                                <Countdown daysInHours={true} date={endDate} renderer={this.renderer} />
                            </div>
                        </MediaQuery>
                    </div>
                    <div className="progress-bar-main">
                        <div className="progress-bar">
                        </div>
                        <div className="progress-bar-inner" style={{'width':seconds}}>
                        </div>
                    </div>
                    <MediaQuery query="tablet-and-up">
                        <div className="date-remain text-right">
                            <Countdown daysInHours={true} date={endDate} renderer={this.renderer}/>
                        </div>
                    </MediaQuery>
                </div>
            </div>
        )
    }
}

export default OfferProgressBar;