import React from "react";
import LazyLoad from 'react-lazyload';
class ProductReview extends React.Component {
  constructor(props) {
    super(props);
    this.myRef = React.createRef();
    this.state = {
      loaded : false
    }
  }
  componentDidMount(){
    window.addEventListener('scroll', this.handleScroll);
  }

  componentWillUnmount(){
      window.removeEventListener('scroll', this.handleScroll);
  }
  handleScroll = () =>{
    if(!this.state.loaded){
      this.reviewInit()
    }
  }
  reviewInit = () =>{
    if(window.jdgmCacheServer){
      this.setState({loaded:true});
      this.myRef.current.innerHTML = '';
        // setTimeout(()=>{
        if(window.jdgm){  
          if(jdgm.$){
              if(this.myRef.current){
                console.log('Review loaded');
                this.myRef.current.innerHTML = '';
                this.myRef.current.style.display = 'block';
                jdgmCacheServer.reloadAll(); 
              }
            }
        }
        // }, 8000);
    }
  }
  render() {
    const { product,review } = this.props;
    const {id,title} = product;
    if(!product){
      return false;
    }
    return (
        <div className='review-section-wrap'>
          <div className="container">
            <div ref={this.myRef} className='jdgm-widget jdgm-review-widget jdgm-outside-widget' style={{'display':'none'}} data-product-title={title} data-id={id}></div>
          </div>
        </div>
    );
  }
}
export default ProductReview;
