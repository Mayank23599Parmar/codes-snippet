import React from "react";
import MediaQuery from "../../components/MediaQuery";
import ReactModal from "react-modal";

class ProductVideo extends React.Component {
  constructor(props) {
    super(props);

    this.customStyles = {
      overlay: {
        zIndex: 6,
      },
      content: {
        top: "50%",
        left: "50%",
        right: "auto",
        bottom: "auto",
        marginRight: "-50%",
        transform: "translate(-50%, -32%)",
        position: "absolute",
        backgroundColor: "#000",
        maxWidth: "600px",
        padding: "0px",
        width: "calc(100% - 20px)",
      },
    };
    this.state = {
      showVideoModal: false,
    };

    this.handleCloseVideo = this.handleCloseVideo.bind(this);

  }

  handleCloseVideo() {
    this.setState({ showVideoModal: false });
    };
    
  toggleModale = (value) => {
    this.setState({ showVideoModal: value });
  };
  render() {
    let { video_section } = this.props;
    const { showVideoModal } = this.state;
    let { url_desktop, url_xs, youtube_video_url,title,sub_title } = video_section;
    if (cn(video_section.url_desktop) && cn(video_section.url_xs)) {
      return null;
    }
    return (
      <div className="product-video-wrapper">
        <div className="bg-black">
        <div className="text-area">
            {title && <p>{title}</p>}
            {sub_title && <h3>{sub_title}</h3>}

          {youtube_video_url && (
            <button
              className="btn"
              onClick={(e) => {
                e.preventDefault();
                this.toggleModale(true);
              }}  
            >
              Watch Now
            </button>
          )}
          </div>
        </div>
        {url_desktop && (
          <MediaQuery query="tablet-and-up">
            <video
              width="100%"
              height="100%"
              controls="true"
              autoPlay="true"
              className="video-container video-container-overlay"
              autoPlay="true"
              loop
              muted={true}
            >
              <source src={video_section.url_desktop} type="video/mp4" />
            </video>
          </MediaQuery>
        )}
        {url_xs && (
          <MediaQuery query="phone">
            <video
              playsInline
              width="100%"
              height="100%"
              controls="true"
              className="video-container video-container-overlay"
              autoPlay="true"
              loop
              muted={true}
            >
              <source src={video_section.url_xs} type="video/mp4" />
            </video>
          </MediaQuery>
        )}
        <ReactModal
          isOpen={showVideoModal}
          contentLabel="onRequestClose Example"
          onRequestClose={() => this.toggleModale(false)}
          shouldCloseOnOverlayClick={true}
          style={this.customStyles}
        >
          {youtube_video_url && (
            <div className="video-wrapper">
              <iframe
                playsInline
                className="video-container video-container-overlay modal-video"
                width="100%"
                height="100%"
                frameborder="0"
                webkitallowfullscreen
                mozallowfullscreen
                src={`${youtube_video_url}?autoplay=1`}
                allow="autoplay"
                allowfullscreen
              ></iframe>
             <div className="_close-video-btn" onClick={this.handleCloseVideo}>
                <img src="https://cdn.shopify.com/s/files/1/0997/6284/files/close-icon_ef5f4e33-c281-440d-9f5d-70a73071fec1.png?v=1618205494"/>
              </div>
            </div>
          )}
        </ReactModal>
      </div>
    );
  }
}
export default ProductVideo;
