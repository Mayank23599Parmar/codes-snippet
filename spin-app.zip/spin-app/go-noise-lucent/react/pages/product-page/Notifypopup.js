import React, { Component } from "react";
// import { pageView } from "react-facebook-pixel";
import { connect } from "react-redux";
import { submitNotifyForm } from "../../redux/product/productAction";
import {emailValidate} from '././../../components/Helper';
export class Notifypopup extends Component {
  constructor(props) {
    super(props);

    this.state = {
      emailenq: "",
      mobilenoenq: "",
      emailError:"",
      mobileError:"",
      showBtnLoading: false,
      submitted : false
    };
  }
  handleSubmit = async (e) => {
    e.preventDefault();
    let formData = new FormData(e.target);
    let {emailenq,mobilenoenq} = this.state;
    let emailError = '';
    let mobileError = '';
    if(cn(emailenq)){
      emailError = "Email address can't be blank"
    }else{
      if(!emailValidate(emailenq)){
        emailError = "Enter valid email address"
      }
    }
    // if(cn(mobilenoenq)){
    //   mobileError = "Mobile number can't be blank"
    // }else{
    //   if(mobilenoenq.length !== 10){
    //     mobileError = "Enter valid mobile number"
    //   }
    // }

    let phoneError = false;
    let first_char = mobilenoenq.charAt(0);
    let msg = '';
    let phoneFormatMatch = false;
    if (first_char == "6" || first_char == "7" || first_char == "8" || first_char == "9") {
      phoneFormatMatch = true;
    }
    if (!phoneFormatMatch) {

      phoneError = true;
      msg = 'Please enter correct phone number starting from 6/7/8/9';
    }
    if (cn(mobilenoenq) || mobilenoenq.length !== 10) {

      phoneError = true;
      msg = 'Please enter your 10 digit phone number to proceed!';
    }
    if(phoneError || emailError !== ''){
      this.setState({ emailError,mobileError:msg })
    }else{
      this.setState({ showBtnLoading: true }, () => {
        this.props.submitNotifyForm({
          formData,
          callBackFunction: () => {
            this.setState({ showBtnLoading: false,submitted: true });
          },
        });
      });
    }
  };

  digitValidate=(e)=>{
    var arr = [];
    var kk = e.which;
 
    for (i = 48; i < 58; i++)
        arr.push(i);
 
    if (!(arr.indexOf(kk)>=0))
        e.preventDefault();
  }

  render() {
    const { emailenq, mobilenoenq, showBtnLoading,emailError,mobileError} = this.state;
    const {title,variant,toggleModale,head, subhead, message} = this.props;
    return (
      <div className="notify-me-popup">
        <div className="notify-me-popup-inner-wrapper">
        <div className="notify-me-popup-inner">
          <h3 className="title">{head ? head : 'EMAIL WHEN AVAILABLE'}
          <span className="close" onClick={()=>toggleModale(false)}><img src={pwa.icons.close} alt="close notify"/></span>
          </h3>
          <p>
            {subhead ? subhead: 'Register your email address below to receive an email as soon as this becomes available again.'}
          </p>
          <h3 className="p-title">{title} - {variant.title}</h3>
          
          <form onSubmit={this.handleSubmit} className="">
            <input
              type="email"
              id="email"
              name="email"
              placeholder="E-Mail Address"
              className="bop-full"
              value={emailenq}
              onChange={(e) => {
                this.setState({ emailenq: e.target.value, emailError:'' });
              }}
            />
            <input
              hidden
              name='product'
              className='hide'
              value={this.props.title}
            />
            {emailError && <p className="error">{emailError}</p>}
            <input
              type="number"
              id="phone"
              name="phone"
              placeholder="Mobile"
              className="bop-full"
              value={mobilenoenq}
              maxLength="10"
              onKeyPress={(e)=>this.digitValidate(e)}  
              onChange={(e) => {
                if (e.target.value.length <= 10) {
                  this.setState({ mobilenoenq: e.target.value , mobileError:''});
                }
              }}
            />
            {mobileError && <p className="error">{mobileError}</p>}
            {this.state.submitted ? 
              <div className="register-text">{message ? message : 'Your notification has been registered.'} <span onClick={()=>toggleModale(false)}>Close</span></div>
            : 
              <button className={`btn${showBtnLoading ? " loading" : ""}`} type="submit">
              Submit
              </button>
            }
          </form>
        </div>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  submitNotifyForm: (data) => dispatch(submitNotifyForm(data)),
});

export default connect(null, mapDispatchToProps)(Notifypopup);
