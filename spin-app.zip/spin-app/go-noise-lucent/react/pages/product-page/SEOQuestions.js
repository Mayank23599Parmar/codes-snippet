import React, { Component } from "react";
import HtmlParser from "react-html-parser";

export class SEOQuestions extends Component {
  render() {
    const { queans } = this.props.data;
		if(!this.props.data){
			return false;
		}
    if(cn(queans)){
      return null;
    }
		let QnAs = queans.split("<>");

    let QnAHtml = QnAs.map((ele,index) => {
      let contArray = ele.split(" que#");
      let que = contArray[0];
      contArray = contArray[1].split(" ans#");
      let ans = contArray[0];
      return (<div key={index}>
				<h2 className='que'>{HtmlParser(que)}</h2>
				<p className='ans'>{HtmlParser(ans)}</p>
			</div>);
    });

    return (
      <div className='for-seo-content'>
        <div className="container">
          <div className='seo-wrapper'>
            <div className='que-ans'>{QnAHtml}</div>
          </div>
        </div>
      </div>
    );
  }
}

export default SEOQuestions;
