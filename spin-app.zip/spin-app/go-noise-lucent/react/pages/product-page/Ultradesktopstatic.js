import React, { Component } from "react";
import HtmlParser from "react-html-parser";
import Srcset from "../../components/SrcSet";
import MediaQuery from "../../components/MediaQuery";

class Ultradesktopstatic extends Component {
    render() {
        const { ultra_two_watch } = this.props;
        
    
        return (
          <div>
              <MediaQuery query='lap-and-up'>
              <div className="two-watch desktop-staic">
                  <div className="image-container">
                  
                   
                      <Srcset src="https://cdn.shopify.com/s/files/1/0997/6284/files/Filler-section.png?v=1626305829" />
                   
                 
                  {/* <MediaQuery query='lap-and-up'>
                   
                    <Srcset src={ultra_two_watch.image} />
                    
                  </MediaQuery> */}
                  </div>
              </div>
              </MediaQuery>
          </div>
        );
      }
}

export default Ultradesktopstatic;
