import React, { Component } from "react";
import { connect } from "react-redux";
import SingleBlog from "./SingleBlog";
import Loader from "../../components/loader/loader";
// import UrlSet from "../../components/UrlSet";
export class BlogTemplate extends Component {
  constructor(props) {
    super(props);

    this.state = {
      blogstoShow: 10,
    };
  }

  handleViewMore = (e) => {
    const { blogstoShow } = this.state;
    const { blogData } = this.props;
    let blogcount = blogstoShow + 10;
    if (blogData.articles.length < blogcount) {
      blogcount = blogData.articles.length;
    }
    this.setState({ blogstoShow: blogcount });
  };
  render() {
    const { blogData, loading } = this.props;
    const { articles } = blogData;
    const { blogstoShow } = this.state;
    
    if (loading) {
      return <Loader />;
    }
    if (Object.keys(blogData).length === 0) {
      return false;
    }
    let articlesPritnt = articles.map((article, index) => {
      if (index < blogstoShow)
        return (
          <li key={index}>
            <SingleBlog articleInfo={article} />
          </li>
        );
    });
    return (
      <div className="blog-template">
        <div className="blog-title">
          <h1>Articles</h1>
        </div>
        <ul className="blog-list">{articlesPritnt}</ul>
        {articles.length > blogstoShow && (
          <div className="view-more">
            <span onClick={(e) => this.handleViewMore(e)}>
              View More <span className="arrow down"></span>
            </span>
          </div>
        )}
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  blogData: state.blog.blogData,
  loading: state.blog.blogLoading,
});

export default connect(mapStateToProps, null)(BlogTemplate);
