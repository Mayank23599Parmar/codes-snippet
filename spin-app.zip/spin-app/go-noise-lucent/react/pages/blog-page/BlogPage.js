import React, { Component } from "react";
import { connect } from "react-redux";
import BlogTemplate from "./BlogTemplate";
import { fetchBlog } from "../../redux/blog/blogActions";
import UrlSet from '../../components/UrlSet';
export class BlogPage extends Component {
  componentDidMount() {
    this.props.fetchBlog();
  }
  render() {
    return (
      <div id="blog-page">
        <div className="container">
          <div className="normal-support-head">
            <div className="container">
              <div className="normal-support-head-container">
                <UrlSet href="/">Home</UrlSet>
                <span>
                  <span className="arrow down"></span>
                  <UrlSet href="/">Stories</UrlSet>
                  <span>
                    <span className="arrow down"></span>
                    <span>Articles</span>
                  </span>
                </span>
              </div>
            </div>
          </div>
          <BlogTemplate />
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  fetchBlog: (handle) => dispatch(fetchBlog(handle)),
});
export default connect(null, mapDispatchToProps)(BlogPage);
