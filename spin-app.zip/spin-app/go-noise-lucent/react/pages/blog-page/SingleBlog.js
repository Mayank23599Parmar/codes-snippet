import React, { Component } from "react";
import Srcset from "../../components/SrcSet";
import UrlSet from "../../components/UrlSet";
import { dateFormatter } from "../../components/Helper";

export class SingleBlog extends Component {
  render() {
    const { articleData, description, articleUrl } = this.props.articleInfo;
    const { title, published_at, image } = articleData;
    let src = "";
    if(image){
      if(image.src){
        src = image.src;
      }
    }
    return (
      <div className="single-blog flex-view">
        <div className="blog-image col-sm-3">
          <Srcset src={src} alt={title} />
        </div>
        <div className="blog-info col-sm-9">
          <UrlSet href={articleUrl}>
            <div className="fetaure-date">
              <span>Feature</span>{" "}
              <span className="date">{dateFormatter(published_at)}</span>{" "}
            </div>
            <h5 className="title font-weight-bold">{title}</h5>
            <div className="blog-description">
              <p>{description}</p>
            </div>
          </UrlSet>
        </div>
      </div>
    );
  }
}

export default SingleBlog;
