import React, { Component } from 'react'
import HtmlParser from 'react-html-parser'
import Srcset from '../../../components/SrcSet';

export class ShippingDetails extends Component {
	render() {
		const { data } = this.props;
		let pageContent = data.data;
		pageContent = pageContent.replace('"data":"','')
		pageContent = pageContent.substring(0,pageContent.length-2);
		return (
			<div className='shipping-details'>
				<div className='container'>
				<h4 className='text-align-center font-weight-bold'><span className='image'><Srcset src={pwa.icons.supportIcons.shippingPolicy} /></span> Shipping Details </h4>
					{HtmlParser(pageContent)}
				</div>
			</div>
		)
	}
}

export default ShippingDetails
