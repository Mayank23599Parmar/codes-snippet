import React, { Component } from 'react';
import ErrorPage from '../../errorpage/ErrorPage';
import HtmlParser from 'react-html-parser';
import Questmainvideo from './Questmainvideo';
import QuestPlayers from './QuestPlayers';

export class Questforthebest extends Component {
	
	render() {
        
        //console.log('this.props.data----->',this.props.data);
        const quest = this.props.data.quest;
		const questPlayer = this.props.data.quest_player;
        //console.log('quest--->',questPlayer);
        //debugger;
		if (!this.props.data) {
			return <ErrorPage show={true} />
		}
		return (
			<div className={this.props.data.handle}>
				<div className="main-video-section ">
					<Questmainvideo mainvideo={quest } />
				</div>
				<div className="Players-section">
					<QuestPlayers players={questPlayer} />
				</div>

			</div>
		)
	}
}

export default Questforthebest
