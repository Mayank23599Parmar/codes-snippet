import React, { Component } from 'react';
import ErrorPage from '../../errorpage/ErrorPage';
import HtmlParser from 'react-html-parser';
import MediaQuery from "../../../components/MediaQuery";
import LazyLoad from 'react-lazyload';
import Srcset from "../../../components/SrcSet";
import UrlSet from "../../../components/UrlSet";
import Slider from "react-slick";



export class AnniversarySale extends Component {
	
	render() {
        
        let anniversarySale = this.props.data.presale;
		if (Object.keys(anniversarySale).length === 0) {
            return false;
        }
        let items = [];
        for (let i = 1; i < 20; i++) {
            //section first (Top Banner)
            let mainBanner = anniversarySale["sec_first_" + i];
            let mainBannerBGcolor = '#ffffff00';
            if (!cn(anniversarySale["sec_first_bg_" + i])) {
                mainBannerBGcolor = anniversarySale["sec_first_bg_" + i];
            }
            let StyleSecFirst = {
                backgroundColor: mainBannerBGcolor,
              };
            
            // Video Section
            let mainvideo = anniversarySale["video_" + i];
            let mainvideoXs = anniversarySale["video_xs_" + i];
            let mainVideoBGcolor = '#ffffff00';
            if (!cn(anniversarySale["video_bg_" + i])) {
                mainVideoBGcolor = anniversarySale["video_bg_" + i];
            }
            let StyleVideoFirst = {
                backgroundColor: mainVideoBGcolor,
              };



            //Title Image First
            let titleFirst = anniversarySale["title_first_" + i];
            let titleFirstBg = '#ffffff00';
            if (!cn(anniversarySale["title_first_bg_" + i])) {
                titleFirstBg = anniversarySale["title_first_bg_" + i];
            }
            let StyleTitleFirst = {
                backgroundColor: titleFirstBg,
              };

            
            //Title image second
            let titleSecond = anniversarySale["title_second_" + i];
            let titleSecondBg = '#ffffff00';
            if (!cn(anniversarySale["title_second_bg_" + i])) {
                titleSecondBg = anniversarySale["title_second_bg_" + i];
            }
            let StyleTitleSecond = {
                backgroundColor: titleSecondBg,
              };
            

            //Title image third
            let titleThird = anniversarySale["title_third_" + i];
            let titleThirdBg = '#ffffff00';
            if (!cn(anniversarySale["title_third_bg_" + i])) {
                titleThirdBg = anniversarySale["title_third_bg_" + i];
            }
            let StyleTitleThird = {
                backgroundColor: titleThirdBg,
              };
            
            //Title image Fourth
            let titleFourth = anniversarySale["title_fourth_" + i];
            let titleFourthBg = '#ffffff00';
            if (!cn(anniversarySale["title_fourth_bg_" + i])) {
                titleFourthBg = anniversarySale["title_fourth_bg_" + i];
            }
            let StyleTitleFourth = {
                backgroundColor: titleFourthBg,
              };

            //Title image Fifth
            let titleFifth = anniversarySale["title_fifth_" + i];
            let titleFifthBg = '#ffffff00';
            if (!cn(anniversarySale["title_fifth_bg_" + i])) {
                titleFifthBg = anniversarySale["title_fifth_bg_" + i];
            }
            let StyleTitleFifth = {
                backgroundColor: titleFifthBg,
              };
            

            // Image Grid 1x1
            let onexone = anniversarySale["onexone_" + i];
            let onexoneBg = '#ffffff00';
            if (!cn(anniversarySale["onexone_bg_" + i])) {
                onexoneBg = anniversarySale["onexone_bg_" + i];
            }
            let StyleonexoneBg = {
                backgroundColor: onexoneBg,
              };
            
            // Image Grid 2x2
            let twoxtwo = anniversarySale["twoxtwo_" + i];
            let twoxtwoBg = '#ffffff00';
            if (!cn(anniversarySale["twoxtwo_bg_" + i])) {
                twoxtwoBg = anniversarySale["twoxtwo_bg_" + i];
            }
            let StyletwoxtwoBg = {
                backgroundColor: twoxtwoBg,
              };

            
            //Slider First
              let sliderfirstMeta = anniversarySale["slider_first_" + i];
              let sliderfirstbg = '#ffffff00';
              let sliderfirstwrap = [];
              if(sliderfirstMeta){
                sliderfirstMeta.slider.map((item,index)=>{
                    sliderfirstwrap.push(
                        <div key={item.img} className="image"><UrlSet className="product-link" href={item.link}><Srcset key={item.img} src={item.img}/></UrlSet></div> 
                    )
                });
              }


              if (!cn(anniversarySale["slider_first_bg_" + i])) {
                sliderfirstbg = anniversarySale["slider_first_bg_" + i];
              }

              let StyleSliderFirst = {
                backgroundColor: sliderfirstbg,
              };
              let sliderfirstarrowprev = anniversarySale["slider_first_prev_" + i];
              let sliderfirstarrownext = anniversarySale["slider_first_next_" + i];
              var settingsSliderFirst = {
                dots: false,
                infinite: false,
                speed: 500,
                slidesToShow: 2.5,
                slidesToScroll: 1,
                draggable: true,
                swipeToSlide: true,
                nextArrow:<span><img src={sliderfirstarrownext}  alt='next-arrow'/></span>,
                prevArrow:<span><img src={sliderfirstarrowprev}  alt='prev-arrow'/></span>
              };
              var settingsSliderFirstDesk = {
                dots: false,
                infinite: false,
                speed: 500,
                slidesToShow: 3.5,
                slidesToScroll: 1,
                draggable: true,
                swipeToSlide: true,
                accessibility: true,
                edgeFriction: 1,
                nextArrow:<span><img src={sliderfirstarrownext}  alt='next-arrow'/></span>,
                prevArrow:<span><img src={sliderfirstarrowprev}  alt='prev-arrow'/></span>
              };


            

            
            //Slider second
            let slidersecondMeta = anniversarySale["slider_second_" + i];
            let slidersecondbg = '#ffffff00';
            let slidersecondwrap = [];
            if(slidersecondMeta){
                slidersecondMeta.slider.map((item,index)=>{
                    slidersecondwrap.push(
                        <div key={item.img} className="image"><UrlSet className="product-link" href={item.link}><Srcset key={item.img} src={item.img}/></UrlSet></div> 
                    )
                });
            }


            if (!cn(anniversarySale["slider_second_bg_" + i])) {
                slidersecondbg = anniversarySale["slider_second_bg_" + i];
            }

            let StyleSliderSecond = {
                backgroundColor: slidersecondbg,
            };
            let sliderSecondrowprev = anniversarySale["slider_second_prev_" + i];
            let sliderSecondarrownext = anniversarySale["slider_second_next_" + i];
            var settingsSliderSecond = {
                dots: false,
                infinite: false,
                speed: 500,
                slidesToShow: 2.5,
                slidesToScroll: 1,
                draggable: true,
                swipeToSlide: true,
                accessibility: true,
                edgeFriction: 1,
                nextArrow:<span><img src={sliderSecondarrownext}  alt='next-arrow'/></span>,
                prevArrow:<span><img src={sliderSecondrowprev}  alt='prev-arrow'/></span>
            };
            var settingsSliderSecondDesk = {
                dots: false,
                infinite: false,
                speed: 500,
                slidesToShow: 3.5,
                slidesToScroll: 1,
                draggable: true,
                swipeToSlide: true,
                accessibility: true,
                edgeFriction: 1,
                nextArrow:<span><img src={sliderSecondarrownext}  alt='next-arrow '/></span>,
                prevArrow:<span><img src={sliderSecondrowprev}  alt='prev-arrow'/></span>
            };


            // spin URL
            let spinUrl = anniversarySale["spin_url_" + i];

            if (anniversarySale) {
                let content = (
                        <div className={`image-section image-section-${i}`}>
                            {mainBanner &&
                                
                                    <div className="image-wrap image-main-banner" style={StyleSecFirst}>
                                    <MediaQuery query="phone-and-tablet"><LazyLoad height={200}><Srcset src={anniversarySale["sec_first_xs_" + i] ? anniversarySale["sec_first_xs_" + i] : mainBanner} /></LazyLoad></MediaQuery>
                                    <MediaQuery query="lap-and-up"><LazyLoad height={200}><Srcset src={mainBanner} /></LazyLoad></MediaQuery> 
                                    </div>
                            }
                            {mainvideo && mainvideoXs &&
                            <div className="main-video" style={StyleVideoFirst}>
                                <MediaQuery query="tablet-and-up">
                                <video
                                  playsInline
                                  width="100%"
                                  height="100%"
                                  controls={false}
                                  autoPlay={true}
                                  className="video-container video-container-overlay"
                                  loop
                                  muted={true}
                                >
                                  <source src={mainvideo} type="video/mp4" />
                                </video>
                              </MediaQuery> 
                               <MediaQuery query="phone">
                               <video
                                 playsInline
                                 width="100%"
                                 height="100%"
                                 controls={false}
                                 autoPlay={true}
                                 className="video-container video-container-overlay"
                                 loop
                                 muted={true}
                               >
                                 <source src={mainvideoXs} type="video/mp4" />
                               </video>
                             </MediaQuery>
                            </div>
                            }
                            {spinUrl &&
                            <div className="spin-iframe">
                                <MediaQuery query="phone-and-tablet"><LazyLoad height={200}><iframe width="100%" height="620" src={spinUrl} frameborder="0"></iframe></LazyLoad></MediaQuery>
                                <MediaQuery query="lap-and-up"><LazyLoad height={200}><iframe width="100%" height="800" src={spinUrl} frameborder="0"></iframe></LazyLoad></MediaQuery>
                            </div>
                            }
                            {titleFirst &&
                                    <div className="image-wrap image-title image-title-first" style={StyleTitleFirst}>
                                    <MediaQuery query="phone-and-tablet"><LazyLoad height={200}><Srcset src={anniversarySale["title_first_xs_" + i] ? anniversarySale["title_first_xs_" + i] : titleFirst} /></LazyLoad></MediaQuery>
                                    <MediaQuery query="lap-and-up"><LazyLoad height={200}><Srcset src={titleFirst} /></LazyLoad></MediaQuery> 
                                    </div>
                            }
                            {titleSecond &&
                                    <div className="image-wrap image-title image-title-second" style={StyleTitleSecond}>
                                    <MediaQuery query="phone-and-tablet"><LazyLoad height={200}><Srcset src={anniversarySale["title_second_xs_" + i] ? anniversarySale["title_second_xs_" + i] : titleSecond} /></LazyLoad></MediaQuery>
                                    <MediaQuery query="lap-and-up"><LazyLoad height={200}><Srcset src={titleSecond} /></LazyLoad></MediaQuery> 
                                    </div>
                            }
                            {onexone && 
                                <div className="image-wrap image-title one-x-one" style={StyleonexoneBg}>
                                {onexone.onexone
                                    .map((item, index) => {
                                        return (<>
                                        <div className="image-wrap">
                                        <div className="image-wrap-inside ">
                                        <MediaQuery query="phone-and-tablet">
                                            <LazyLoad height={200}><UrlSet className="product-link" href={item.link}><Srcset src={item.img_xs} /></UrlSet></LazyLoad>
                                        </MediaQuery>
                                        <MediaQuery query="lap-and-up">
                                        <LazyLoad height={200}><UrlSet className="product-link" href={item.link}><Srcset src={item.img} /></UrlSet></LazyLoad>
                                        </MediaQuery>
                                        </div>
                                        </div>
                                            </>
                                        );
                                    })}
                                </div>
                            }
                            {titleThird &&
                                    <div className="image-wrap image-title image-title-third" style={StyleTitleThird}>
                                    <MediaQuery query="phone-and-tablet"><LazyLoad height={200}><Srcset src={anniversarySale["title_third_xs_" + i] ? anniversarySale["title_third_xs_" + i] : titleThird} /></LazyLoad></MediaQuery>
                                    <MediaQuery query="lap-and-up"><LazyLoad height={200}><Srcset src={titleThird} /></LazyLoad></MediaQuery> 
                                    </div>
                            }
                            {sliderfirstMeta &&
                                <div className='product-slider' style={StyleSliderFirst} >
                                
                                <MediaQuery query="lap-and-up">
                                 <Slider {...settingsSliderFirstDesk}>
                                   {sliderfirstwrap.length > 0 ? sliderfirstwrap : ''}
                                 </Slider>
                                 </MediaQuery>  

                                 <MediaQuery query="phone-and-tablet">
                                 <Slider {...settingsSliderFirst}>
                                   {sliderfirstwrap.length > 0 ? sliderfirstwrap : ''}
                                 </Slider>
                                 </MediaQuery>   
  
                               </div>
                            }
                            {titleFourth &&
                                    <div className="image-wrap image-title image-title-fourth" style={StyleTitleFourth}>
                                    <MediaQuery query="phone-and-tablet"><LazyLoad height={200}><Srcset src={anniversarySale["title_fourth_xs_" + i] ? anniversarySale["title_fourth_xs_" + i] : titleFourth} /></LazyLoad></MediaQuery>
                                    <MediaQuery query="lap-and-up"><LazyLoad height={200}><Srcset src={titleFourth} /></LazyLoad></MediaQuery> 
                                    </div>
                            }
                            {slidersecondMeta &&
                                <div className='product-slider' style={StyleSliderSecond} >
                                <MediaQuery query="lap-and-up">
                                 <Slider {...settingsSliderSecondDesk}>
                                   {slidersecondwrap.length > 0 ? slidersecondwrap : ''}
                                 </Slider>
                                </MediaQuery>
                                <MediaQuery query="phone-and-tablet">
                                <Slider {...settingsSliderSecond}>
                                   {slidersecondwrap.length > 0 ? slidersecondwrap : ''}
                                 </Slider>
                                </MediaQuery>
                               </div>
                            }
                            {titleFifth &&
                                    <div className="image-wrap image-title image-title-fifth" style={StyleTitleFifth}>
                                    <MediaQuery query="phone-and-tablet"><LazyLoad height={200}><Srcset src={anniversarySale["title_fifth_xs_" + i] ? anniversarySale["title_fifth_xs_" + i] : titleFifth} /></LazyLoad></MediaQuery>
                                    <MediaQuery query="lap-and-up"><LazyLoad height={200}><Srcset src={titleFifth} /></LazyLoad></MediaQuery> 
                                    </div>
                            }
                            {twoxtwo && 
                                <div className="image-wrap image-title two-x-two" style={StyletwoxtwoBg}>
                                {twoxtwo.twoxtwo
                                    .map((item, index) => {
                                        return (<>
                                        <div className="image-wrap">
                                        <div className="image-wrap-inside ">
                                        <MediaQuery query="phone-and-tablet">
                                            <LazyLoad height={200}><UrlSet className="product-link" href={item.link}><Srcset src={item.img_xs} /></UrlSet></LazyLoad>
                                        </MediaQuery>
                                        <MediaQuery query="lap-and-up">
                                        <LazyLoad height={200}><UrlSet className="product-link" href={item.link}><Srcset src={item.img} /></UrlSet></LazyLoad>
                                        </MediaQuery>
                                        </div>
                                        </div>
                                            </>
                                        );
                                    })}
                                </div>
                            }
                        </div>
                );
                items.push(content);
                
            }
        }
        if (items.length > 0) {
            return <>
                 <div className={this.props.data.handle}>
                    {items}
                </div>
                </>;
        }
        return null;
	}
}

export default AnniversarySale
