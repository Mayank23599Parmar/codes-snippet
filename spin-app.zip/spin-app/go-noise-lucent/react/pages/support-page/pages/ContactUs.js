import React, { Component } from "react";
import { connect } from "react-redux";
import Srcset from "../../../components/SrcSet";
import { submitContactForm } from "../../../redux/support/supportAction";
import { emailValidate } from '../../../components/Helper';

export class ContactUs extends Component {
  constructor(props) {
    super(props);

    this.state = {
      full_name: "",
      email: "",
      phone: "",
      message: "",
      subject: "",
      showLoading: false,
      formErrors: {
        full_name: "",
        email: "",
        phone: "",
        message: "",
        subject: ""
      },
    };
  }

  changeHandle = (e) => {
    const { name, value } = e.target;
    const { formErrors } = this.state;
    let Errors = formErrors;
    Errors[name] = "";
    if (name === 'phone') {
      if (value.length <= 10) {
        this.setState({ [name]: value, formErrors: Errors });
      }
    }
    else {
      this.setState({ [name]: value, formErrors: Errors });

    }
  };

  handleSubmit = (e) => {
    e.preventDefault();
    // const {  } = this.props;
    const { formErrors, email, full_name, message, subject, phone } = this.state;
    let submitform = true;
    if (email === "" || !emailValidate(email)) {
      if (email === "") {
        formErrors.email = "Email address can't be blank";
      }
      else if (!emailValidate(email)) {
        formErrors.email = "Please enter valid email address";
      }
      submitform = false;
    }
    if (full_name === "") {
      formErrors.full_name = "Name can't be empty";
      submitform = false;
    }
    if (message === "") {
      formErrors.message = "Message can't be blank";
      submitform = false;
    }
    if (subject === "") {
      formErrors.subject = "Subject can't be blank";
      submitform = false;
    }

    let first_char = phone.charAt(0);
    let phoneFormatMatch = false;
    if (first_char == "6" || first_char == "7" || first_char == "8" || first_char == "9") {
      phoneFormatMatch = true;
    }
    if (!phoneFormatMatch) {
      formErrors.phone = 'Please enter correct phone number starting from 6/7/8/9';
      submitform = false;
    }
    if (cn(phone) || phone.length !== 10) {

      submitform = false;
      formErrors.phone = 'Please enter your 10 digit phone number to proceed!';
    }
    let formData = { full_name, email, message, subject, phone }
    this.setState({ formErrors });
    if (submitform) {
      this.setState({ showLoading: true }, () => {
        this.props.submitContactForm({
          formData,
          callbackFunc: () => {
            this.setState({ showLoading: false, phone: '', message: '', email: '', full_name: '', subject: '' });
          },
        });
      });
    }
  };

  render() {
    const {
      full_name,
      email,
      message,
      phone,
      showLoading,
      subject,
      formErrors,
    } = this.state;
    const { data } = this.props;
    const { settings } = data.data;
    return (
      <div className="contact-details">
        <div className="container">
          <div className="contact-container">
            <div className="head-top">
              <h4 className="text-align-center font-weight-bold">
                <span className="image">
                  <Srcset src={pwa.icons.supportIcons.contactUs} />
                </span>
                Contact Us
              </h4>
            </div>
            <div className="contact-form flex-view">
              <div className="form-part col-sm-6">
                <form onSubmit={(e) => this.handleSubmit(e)}>
                  <label>Full Name</label>
                  <div className="input-error">
                    <input
                      name="full_name"
                      placeholder="Full Name"
                      value={full_name}
                      onChange={(e) => this.changeHandle(e)}
                      type="text"
                    />
                    {formErrors.full_name.length > 0 && (
                      <label>{formErrors.full_name}</label>
                    )}
                  </div>

                  <label>E-mail address</label>
                  <div className="input-error">
                    <input
                      name="email"
                      placeholder="E-mail address"
                      value={email}
                      onChange={(e) => this.changeHandle(e)}
                      type="email"
                    />
                    {formErrors.email.length > 0 && (
                      <label>{formErrors.email}</label>
                    )}
                  </div>

                  <label>Mobile number</label>
                  <div className="input-error">
                    <input
                      name="phone"
                      placeholder="Mobile number"
                      value={phone}
                      onChange={(e) => this.changeHandle(e)}
                      type="number"
                    />
                    {formErrors.phone.length > 0 && (
                      <label>{formErrors.phone}</label>
                    )}
                  </div>

                  <label>Subject</label>
                  <div className="input-error">
                    <input
                      name="subject"
                      placeholder="Subject"
                      value={subject}
                      onChange={(e) => this.changeHandle(e)}
                      type="text"
                    />
                    {formErrors.subject.length > 0 && (
                      <label>{formErrors.subject}</label>
                    )}
                  </div>


                  <label>Message</label>
                  <div className="input-error">
                    <textarea
                      name="message"
                      placeholder="Message"
                      value={message}
                      onChange={(e) => this.changeHandle(e)}
                      type="text"
                    />
                    {formErrors.message.length > 0 && (
                      <label>{formErrors.message}</label>
                    )}
                  </div>

                  <button
                    type="submit"
                    className={` btn ${showLoading ? "loading" : ""}`}
                  >
                    Submit
                  </button>
                </form>
              </div>
              <div className="info-part col-sm-6">
                {settings.map_location_image && settings.map_location &&
                  <div className="map">
                    <Srcset src={settings.map_location_image} />
                    <a href={settings.map_location} target='_blank'>Open in google maps</a>
                  </div>
                }
                <div className="offices-info flex-view">
                  <div className="office col-sm-6">
                    <p className="head font-weight-bold">Location</p>
                    <p className="info">
                      {settings.address}
                    </p>
                  </div>
                  <div className="office col-sm-6">
                    <p className="head font-weight-bold">Contact us</p>
                    <p className="info">
                      <a href={`tel:${settings.phone_number}`} > {settings.phone_number_text} </a>
                      <br />
                      <br />
                      <a href={`mailto:${settings.contact_email}`}> {settings.contact_email} </a>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  submitContactForm: (handle) => dispatch(submitContactForm(handle)),
});
export default connect(null, mapDispatchToProps)(ContactUs);
