import React, { Component } from 'react'
import HtmlParser from 'react-html-parser';
import Srcset from '../../../components/SrcSet';

export class TermsAndConditions extends Component {
	render() {
		const {data} = this.props;
		let pageContent12 = data.data;
		let pageContent = pageContent12.replace('"data":"','');
		pageContent = pageContent.substring(0,pageContent.length-2)
		return (
			<div className='terms-and-conditions'>
				<div className='container'>
					<h4 className='text-align-center font-weight-bold'>
						<span className='image'><Srcset src={pwa.icons.supportIcons.termsConditions} /></span>
						Terms and Conditions
					</h4>
					{HtmlParser(pageContent)}
				</div>
			</div>
		)
	}
}

export default TermsAndConditions
