import React from "react";
import { connect } from "react-redux";
import HtmlParser from "react-html-parser";
import Srcset from "../../../components/SrcSet";
import Urlset from '../../../components/UrlSet'

class Faq extends React.Component {
  render() {
    const { faqData } = this.props;

    if (faqData === undefined) {
      return <div></div>;
    }

    const { blocks, settings } = faqData;

    let Payments = [];
    let Returns = [];
    let Cancellations = [];
    let Shippings = [];

    blocks.forEach((block) => {
      if (block.type === "payments") Payments.push(block.data);
      if (block.type === "returns-and-replacements") Returns.push(block.data);
      if (block.type === "cancellations") Cancellations.push(block.data);
      if (block.type === "shipping") Shippings.push(block.data);
    });
    <input type="text" placeholder="Your Concern" />;

    return (
      <div className="container">
        <div className="faq_section">
          <div className="header-wrapper">
            <div className="faq-title">
              <h4 className="font-weight-bold">
                
                {settings.faq_title}
              </h4>
            </div>
            <div className="faq-description">
              <h6>{settings.faq_description}</h6>
            </div>
            <div className="faq-subtitle">
              <h4>
              <span className="image">
                  <Srcset src={pwa.icons.supportIcons.faqIcon} />
                </span>
                {settings.faq_subtitle}</h4>
            </div>
          </div>
          <div className="qna-section">
            <div className="faq-qna">
              <h4>PAYMENTS:</h4>
              {Payments.map((payment) => {
                return (
                  <>
                    <div className="que">{HtmlParser(payment.que)}</div>
                    <div className="ans">{HtmlParser(payment.ans)}</div>
                  </>
                );
              })}
            </div>
            <div className="faq-qna">
              <h4>RETURNS & REPLACEMENTS:</h4>
              {Returns.map((return_replace) => {
                return (
                  <>
                    <div className="que">{HtmlParser(return_replace.que)}</div>
                    <div className="ans">{HtmlParser(return_replace.ans)}</div>
                  </>
                );
              })}
            </div>
            <div className="faq-qna">
              <h4>CANCELLATIONS:</h4>
              {Cancellations.map((cancellation) => {
                return (
                  <>
                    <div className="que">{HtmlParser(cancellation.que)}</div>
                    <div className="ans">{HtmlParser(cancellation.ans)}</div>
                  </>
                );
              })}
            </div>
            <div className="faq-qna">
              <h4>SHIPPING:</h4>
              {Shippings.map((shipping) => {
                return (
                  <>
                    <div className="que">{HtmlParser(shipping.que)}</div>
                    <div className="ans">{HtmlParser(shipping.ans)}</div>
                  </>
                );
              })}
            </div>
          </div>
          <div className="que-form-submit">
            <h3>{settings.faq_quetion}</h3>
            <div className="desc">
              <p>{settings.faq_quetion_description}</p>
            </div>
						{
							settings.contactus_pagelink &&
							<div className='contact-btn'>
								<Urlset href={settings.contactus_pagelink}>
									Contact Us
								</Urlset>
							</div>
						}
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  faqData: state.support.supportData.faqJson.data,
});

export default connect(mapStateToProps)(Faq);
