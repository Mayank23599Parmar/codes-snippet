import React, { Component } from 'react';
import ErrorPage from '../../errorpage/ErrorPage';
import ReactModal from "react-modal";
import HtmlParser from 'react-html-parser';
import Srcset from '../../../components/SrcSet';
import UrlSet from '../../../components/UrlSet';
import MediaQuery from '../../../components/MediaQuery';
import Modal from 'react-modal';
import CampusNoisemakerFaq from '../../../components/CampusNoisemakerFaq';
import Campuscollection from '../../../components/Campuscollection';
import axios from 'axios';
import { nodeName } from 'jquery';

export class CampusNoisemaker extends Component {
	constructor(props) {
		super(props);
		this.state = {
			name: "",
			vouchercode: '',
			university: '',
			courseName: '',
			courseYear: '',
			showOthers: false,
			mobileNumber: '',
			idCard: [],
			universityError: '',
			courseNameError: '',
			courseNameOther:'',
			courseYearError: '',
			mobileNumberError: '',
			idCardError: '',
			statusflag1: false,//state1 - to show register form
			statusflag2: false,//state2 - to show discount code in processing
			statusflag3: false,//state3 - to show discount code
			statusflag4: false,//state4 - to reshow the register form
			ismodalOpen: false,
			showModal: false,
			fileExtenstion:""
		};
		this.otherStyle = {
			display: "none"
		};
		this.cuorseStyle = {
			display: "block"
		};
		this.customStyles = {
			overlay: {
				zIndex: 100,
				backgroundColor: "rgb(202 202 202 / 33%)"
			},
			content: {
				top: "50%",
				left: "50%",
				right: "auto",
				bottom: "auto",
				marginRight: "-50%",
				transform: "translate(-50%, -50%)",
				position: "absolute",
				maxWidth: '800px',
				padding: '30px',
				width: "calc(100% - 20px)",
				borderRadius: "10px",
				height: 'auto'
			},
		};
		this.handleOpenModal = this.handleOpenModal.bind(this);
	}

	componentDidMount() {
		if (simply.customerLoggedin) {
			//debugger
			this.checkCampusNoisemakerStatus();
		}
		//this.init();
		//console.log(this.props,this.props.data.meta)
	}
	handleOpenModal = () => {
		this.setState({
			showModal: true
			
		});
	}
	handleCloseModal = () => {
		this.setState({
			showModal: false

		});
	}
	// unsubscribeErrorMsgCampus = (e) =>{
	// e.preventDefault();
	// if(e.target.value === ''){

	// }


	// }
	// init = () =>{
	// 	this.unsubscribeErrorMsgCampus();
	// }
	checkCampusNoisemakerStatus = () => {

		//debugger
		let custId = simply.customerId;
		let custEmail = simply.customerEmail;
		let baseUrl='https://pre-order.gonoise.in';
		if(process.env.NODE_ENV === "development"){
			baseUrl="http://stage-pre-order.gonoise.in"
		}
		let posturl = `${baseUrl}/student/status/${custId}/${custEmail}`
		axios({
			async: true,
			crossDomain: true,
			method: 'get',
			url: posturl,
			headers: {
				"Access-Control-Allow-Origin": "*",
				"Content-Type": "application/json",
				"x-auth-secret": "0329b8ad3bce0bcfdda8ca65c37143c3ccc1e8ae0545da19898ca08bba8ed1a5"
			},
			cache: false
		})

			.then(res => {
				if (res.data.status === "401") {
					this.setState({
						statusflag1: true

					});

				} else if (res.data.status === "200" && res.data.data.flag === 0) {
					this.setState({
						statusflag2: true

					});
				} else if (res.data.status === "200" && res.data.data.flag === 1) {

					this.setState({
						statusflag3: true,
						vouchercode: res.data.data.coupon
					});

				} else if (res.data.status === "200" && res.data.data.flag === 2) {

					this.setState({
						statusflag4: true,
					});

				}


			})
			.catch(error => {
				console.log(error);
			})
	}
	inputHanlde = async () => {
			if (this.state.university === '') {

			this.setState({
				universityError: 'Please enter a valid university name'
			})
			//alert('this is fuck')

		}
		if (this.state.courseName === '') {

			this.setState({
				courseNameError: 'Please enter a valid course name'
			})
			//alert('this is fuck')

		}
		if (this.state.courseName === 'other') {

			this.setState({
				courseNameOther: 'Please enter a valid course name'
			})
			//alert('this is fuck')

		}
		
		if (this.state.courseYear === '') {

			this.setState({
				courseYearError: 'Please enter a valid course year'
			})
			//alert('this is fuck')

		}
		if(this.state.courseYear > 6 || /^[A-Za-z]+$/.test(this.state.courseYear )){
			this.setState({
				courseYearError: 'Please enter a valid course year'
			})
		}
			//alert('this is fuck')
			let phoneErrorCheck = false;
			let first_char = this.state.mobileNumber.charAt(0);
			let msg = '';
			let phoneFormatMatch = false;
			if (first_char == "6" || first_char == "7" || first_char == "8" || first_char == "9") {
			  phoneFormatMatch = true;
			}
			if (!phoneFormatMatch) {
		
				phoneErrorCheck = true;
			  msg = 'Please enter correct phone number starting from 6/7/8/9';
			}
			if (cn(this.state.mobileNumber) || this.state.mobileNumber.length !== 10) {
		
				phoneErrorCheck = true;
			  msg = 'Please enter your 10 digit phone number to proceed!';
			}
			if (phoneErrorCheck) {

			  this.setState((prevState) => ({
				...prevState,
				mobileNumberError: msg
			  }));
			}

		 if(this.state.idCard.length === 0 || this.state.idCard.size >=  307200){
			
				this.setState({
					idCardError : 'Please upload a valid ID proof under 300kb'
				})
				//alert('this is fuck'idCardError)
			}
		  if (!this.state.idCard.name.match(/\.(jpg|jpeg|png|tiff)$/)) {
			this.setState({
				idCardError: 'Please upload only image type'
			})
		
		  }
		
	}
	register = async () => {
		this.setState({
			universityError: '',
			courseNameError: '',
			courseNameOther:'',
			courseYearError: '',
			mobileNumberError: '',
			idCardError: ''

		})
		let checkInput = await this.inputHanlde()
		const { universityError, courseNameError, courseNameOther, courseYearError, idCardError, mobileNumberError } = this.state;
		if (universityError !== '' || courseNameError !== '' || courseNameOther !== '' || courseYearError !== '' || idCardError !== '' || mobileNumberError != '') {
			return (
				console.log('Enter Valid Form Inputs')
			);
		}
		const campusData = await new FormData();
		campusData.append("email", simply.customerEmail)
		campusData.append("c_id", simply.customerId)
		campusData.append("university", this.state.university.trim())
		campusData.append("course", this.state.courseName.trim())
		campusData.append("year", this.state.courseYear)
		campusData.append("phone", this.state.mobileNumber)
		campusData.append("id-card", this.state.idCard)
		let baseUrl='https://pre-order.gonoise.in';
		
		if(process.env.NODE_ENV === "development"){
			baseUrl="http://stage-pre-order.gonoise.in"
		}
		// console.log(simply.customerEmail,simply.customerId,this.state.university,this.state.courseName,this.state.courseYear,this.state.mobileNumber,this.state.idCard)
		// console.log('file size',this.state.idCard.size)
		axios({
			async: true,
			crossDomain: true,
			method: 'post',
			url: `${baseUrl}/student/register`,
			headers: {
				"Access-Control-Allow-Origin": "*",
				"x-auth-secret": "0329b8ad3bce0bcfdda8ca65c37143c3ccc1e8ae0545da19898ca08bba8ed1a5"
			},
			data: campusData,
			cache: false
		})
			.then(res => {
				//console.log(res)
				this.setState({ statusflag1: false, statusflag4: false })

				if (res.data.status === "200") {
					this.setState({ showModal: false });
					this.checkCampusNoisemakerStatus();
				} else {
					console.log('State Not Matched')
				}
			})
			.catch(error => {
				console.log(error)
			})
	}
	onPastHandeler=(e)=>{
		let regex = /^[a-zA-Z0-9%()#@_& -]+$/;
		let key = String.fromCharCode(e.charCode || e.which);
		if (!regex.test(key)) {
			this.setState({mobileNumber:"e"});
		   return false;
		}
	}
	
	render() {
		if (this.state.courseName === 'other') {
			this.otherStyle = {
				display: "block"
			};
			
			this.cuorseStyle = {
				display: "none"
			};
			}

		const meta = this.props.data.meta;
		//console.log(this.props.data.customRelatedProduct);

		let customerLoggedIn = simply.customerLoggedin;
		if (!this.props.data) {
			return <ErrorPage show={true} />
		}

		//courseNameOptions
		const courseNameOptions = [

			{
				label: "Course name",
				value: ""
			},
			{
				label: "B.Tech",
				value: "B.Tech"
			},
			{
				label: "B.Arch",
				value: "B.Arch"
			},
			{
				label: "BE",
				value: "BE"
			},
			{
				label: "BCA",
				value: "BCA"
			},
			{
				label: "Journalism",
				value: "Journalism"
			},
			{
				label: "Hotel Management",
				value: "Hotel Management"
			},
			{
				label: "MBBS",
				value: "MBBS"
			},
			{
				label: "B.Com",
				value: "B.Com"
			},
			{
				label: "BA",
				value: "BA"
			},
			{
				label: "LLB",
				value: "LLB"
			},
			{
				label: "M.Tech",
				value: "M.Tech"
			},
			{
				label: "ME",
				value: "ME"
			},
			{
				label: "MCA",
				value: "MCA"
			},
			{
				label: "MBA",
				value: "MBA"
			},
			{
				label: "Other",
				value: "other"
			}
		]

		// course year array
		const courseYearsOptions = [

			{
				label: "Course year(1st,2nd,3rd ....)",
				value: ""
			},
			{
				label: "1st",
				value: 1
			},
			{
				label: "2nd",
				value: 2
			},
			{
				label: "3rd",
				value: 3
			},
			{
				label: "4th",
				value: 4
			},
			{
				label: "5th",
				value: 5
			},
			{
				label: "6th",
				value: 6
			}
		]
	
			  
		return (
			<div className='campusnoisemaker-page'>
				<div className={`container ${this.props.data.handle}`}>
					<div className="banner-section">
						<div className="text-area">
							<div className="text-wrapper">
								<h1 className="color-white">Campus Noisemakers</h1>
								<p className="color-white">Furthering efforts to empower students countrywide, Noise is offering exclusive student discounts on our range of wearables. </p>
								{/* <p className="color-white btn-wrapper"><span>Register</span></p> */}
							</div>
						</div>
						<div className="collection_img">

							<MediaQuery query="tablet-and-up">
								<div className="img">
									<Srcset alt="banner" src="https://cdn.shopify.com/s/files/1/0997/6284/files/BG.png?v=1623133545" />
								</div>
							</MediaQuery>


							<MediaQuery query="phone">
								<div className="mobile-img">
									<Srcset alt="banner" src="https://cdn.shopify.com/s/files/1/0997/6284/files/Group_5393.png?v=1623133570" />
								</div>
							</MediaQuery>

						</div>
					</div>
					<div className="form-section">
						<div className="text-area">
							<div className="text-wrapper">
								<h1 className="color-white">How do you avail the student discount? </h1>
								<p className="color-white"><span>All you have to do is submit your valid college identification to enrol<br /> in the student discount scheme.</span> </p>
							</div>
						</div>
						<div className="form-factor">
							<div className='image-text-inner-wrap'>

								<div className="text-wrap">
									<div className="icon-sec">
										<p className="left-text">Step -1 <br /><p>Fill the form</p></p>
										<Srcset alt="icon" src="https://cdn.shopify.com/s/files/1/0997/6284/files/Mask_Group_2_1a8e48d1-21b2-444b-b0eb-b47e9ba8e593.svg?v=1623218594" />
									</div>
									<div className="icon-sec icon-sec-2">
										<p className="left-text">Step -2 <br /><p>Submit College/School ID</p></p>
										<Srcset alt="icon" src="https://cdn.shopify.com/s/files/1/0997/6284/files/Mask_Group_3_b6ea10b1-a37d-4147-afc2-dbfb8dab8e42.svg?v=1623220081" />
									</div>
									<div className="icon-sec">
										<p className="left-text">Step -3 <br /><p>Avail discount</p></p>
										<Srcset alt="icon" src="https://cdn.shopify.com/s/files/1/0997/6284/files/Group_5381.svg?v=1623220100" />
									</div>

								</div>
								<div className="image-wrap">
									<MediaQuery query="phone-and-tablet"><Srcset alt="banner" src="https://cdn.shopify.com/s/files/1/0997/6284/files/Mask_Group_166b0a1d-b56d-4bb8-bf6c-2077a516a3ad.png?v=1623145770" /></MediaQuery>
									<MediaQuery query="lap-and-up"><Srcset alt="banner" src="https://cdn.shopify.com/s/files/1/0997/6284/files/Mask_Group_166b0a1d-b56d-4bb8-bf6c-2077a516a3ad.png?v=1623145770" /></MediaQuery>
								</div>
							</div>
						</div>
					</div>
					<div className="dynamic-section">
						{!customerLoggedIn && (
							<a className="btn" href={`/account/login?checkout_url=/pages/campus-noisemakers?path=redirect`}>Register</a>
						)}
						{customerLoggedIn && this.state.statusflag1 && (
							<button className="btn" onClick={this.handleOpenModal}>Register</button>
						)}
						{customerLoggedIn && this.state.statusflag2 && (
							<p className="btns">Your Discount code is in process.</p>
						)}
						{customerLoggedIn && this.state.statusflag3 && (
							<p className="btns">Discount code : {this.state.vouchercode}</p>
						)}
						{customerLoggedIn && this.state.statusflag4 && (
							<button className="btn" onClick={this.handleOpenModal}>Register</button>
						)}
					</div>
					<div className="faq-section">
						<CampusNoisemakerFaq specifications={{ details: meta }} />
					</div>
					<div className="campus-collection">
						<Campuscollection />
					</div>

					{/* <h1 className='text-align-center'>{this.props.data.title}</h1>
					<button onClick={this.handleOpenModal}>Open Modal</button> */}

					{/* {((customerLoggedIn  && (this.state.statusflag1 === false)) || (customerLoggedIn  && (this.state.statusflag2 === false))  || (customerLoggedIn  && (this.state.statusflag3 === false))  || (customerLoggedIn && (this.state.statusflag4 === false)) ) &&(
						<ErrorPage show={true} />
					  	
					)} */}

					<ReactModal
						isOpen={this.state.showModal}
						contentLabel="Modal #1 Global Style Override Example"
						onRequestClose={this.handleCloseModal}
						shouldCloseOnOverlayClick={true}
						className="preorder-modal-style"
						style={this.customStyles}
					>
						<div className="form-wrap">
							<div className="close-wrap">
								<button className="wrap" onClick={this.handleCloseModal}><img src="https://cdn.shopify.com/s/files/1/0997/6284/t/610/assets/close-icon-react.svg?v=3163925600636919895" alt="close" /></button>
							</div>

							<div className="form-input">
								<div className="text">
									<h4>Verify your student ID</h4>
									<p>Please provide these details to help you with verification</p>
								</div>
								<div className="form-section">
									{/* <input type="email" id="email_id" name="email" value={simply.customerEmail} readOnly></input> */}
									<input type="text" id="university-name" name="name" placeholder="University name" value={this.state.university} onChange={(e) => {
										 let value=e.target.value.replace(/\s\s+/g, ' ');
										this.setState({ university: value,universityError:"" })} }></input>
									{this.state.universityError && (
										<p className="error">{this.state.universityError}</p>
									)}
									{/* <input type="text" id="course-name" name="course name" placeholder="Course name" value={this.state.courseName} onChange={(e) => {
											 let value=e.target.value.replace(/\s\s+/g, ' ');
										this.setState({ courseName: value,courseNameError:"" })}} ></input>
									*/}
  
								    <input required style={this.otherStyle} type="text" id="others" name="others" placeholder="Mention Course Name" onChange={(e) => {
											 let value=e.target.value.replace(/\s\s+/g, ' ');
										this.setState({ courseName: value,courseNameOther:"" })}} ></input>

                                    {this.state.courseNameOther && (
										<p className="error">{this.state.courseNameOther}</p>
									)}

                                    <select style={this.cuorseStyle} value={this.state.courseName} onChange={this.handleChange} id="course-name" name="course name" placeholder="Course name" onChange={(e) => this.setState({ courseName: e.target.value,courseNameError:"" })}>
										{courseNameOptions.map((option) => (
											<option value={option.value}>{option.label}</option>
										))}
									</select>
								
								    {this.state.courseNameError && (
										<p className="error">{this.state.courseNameError}</p>
									)}

									{/* use this commented code when select input is not require */}
									{/* <input type="text" id="course-year" name="course year" placeholder="Course year(1st,2nd,3rd ....)" onChange={(e)=>this.setState({courseYear:e.target.value})} ></input> */}

									<select value={this.state.courseYear} onChange={this.handleChange} id="course-year" name="course year" placeholder="Course year(1st,2nd,3rd ....)" onChange={(e) => this.setState({ courseYear: e.target.value ,courseYearError:""})}>
										{courseYearsOptions.map((option) => (
											<option value={option.value}>{option.label}</option>
										))}
									</select>
									{this.state.courseYearError && (
										<p className="error">{this.state.courseYearError}</p>
									)}
									<input type="number" id="course-year" name="Mobile number" value={this.state.mobileNumber} placeholder="+91 Mobile number"
										onChange={(e) => {
											if (e.target.value.length <= 10) {
												this.setState({
													mobileNumber: e.target.value,
													mobileNumberError: "",
												});
											}
										}}
                                        onPaste={this.onPastHandeler}
									></input>
									{this.state.mobileNumberError && (
										<p className="error">{this.state.mobileNumberError}</p>
									)}
									<input type="file" id="idCard" name="id card" placeholder="id card" accept="image/*" onChange={(e) => this.setState({ idCard: e.target.files[0],idCardError:"" })} ></input>
									<p className="id-label">Upload your valid student ID.</p>
									{this.state.idCardError && (
										<p className="error">{this.state.idCardError}</p>
									)}
									<div className="btn-wrapper">
										<button onClick={() => this.register()}>Submit</button>
									</div>
								</div>
							</div>
						</div>
					</ReactModal>


				</div>
			</div>
		)
	}
}

export default CampusNoisemaker
