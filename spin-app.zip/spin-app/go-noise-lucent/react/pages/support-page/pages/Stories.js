import React, { Component } from "react";
// import { useHistory } from "react-router-dom";
import Slider from "react-slick";
import { dateFormatter } from "../../../components/Helper";
import UrlSet from "../../../components/UrlSet";
import Srcset from "../../../components/SrcSet";

export class Stories extends Component {
  clickHandler = () => {
    this.props.history.push(
      `/blogs/${this.props.data.data.sectionSettings.selected_blog}`
    );
  };

  render() {
    const { sectionSettings, allArticles, blocks } = this.props.data.data;
    let settings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: false,
    };

    let featureStories = blocks.map((block, index) => {
      const { type, articleUrl, data } = block;
      if (block.type === "sliderarticles")
        return (
          <div key={index}>
            <UrlSet href={articleUrl}>
              <div className="slider-article">
                <div className="img">
                  <Srcset src={data.image.src} />
                </div>
                <div className="text-wrapper">
                  <div className='text'>
                    <p>
                      Feature <span> {dateFormatter(data.published_at)} </span>{" "}
                    </p>
                    <h3>{data.title}</h3>
                  </div>
                </div>
              </div>
            </UrlSet>
          </div>
        );
    });

    let viewMoreArticles = allArticles.map((article, index) => {
      const { articleUrl, articleJson } = article;
      if (index < 6)
        return (
          <li key={index} className="col-sm-4 col-xs-12">
            <UrlSet href={articleUrl}>
              <div className="story">
                <div className="image">
                  {articleJson.image ? <Srcset src={articleJson.image.src} /> : <Srcset src="" /> }
                </div>
                <div className="info">
                  <p className="feature">Feature</p>
                  <p className="more-title">{articleJson.title}</p>
                  <p className="date">
                    {dateFormatter(articleJson.published_at)}
                  </p>
                </div>
              </div>
            </UrlSet>
          </li>
        );
    });
    return (
      <div id="stories-page">
        <div className="container">
          <div className="support-page-container">
            <h1>{sectionSettings.page_head}</h1>
            <div className="featured-stories">
              <Slider {...settings}>{featureStories}</Slider>
            </div>
            <div className="more-stories">
              <div className="head flex-view space-between">
                <h3>Articles</h3>
                <div>
                  <button className='phone' onClick={() => this.clickHandler()}>
                    View More <span className="arrow down"></span>
                  </button>
                </div>
              </div>
              <ul className="stories flex-view">{viewMoreArticles}</ul>
              <div className='mobile-view-more'>
								<button className='desktop' onClick={() => this.clickHandler()}>
									View More <span className="arrow down"></span>
								</button>
							</div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Stories;
