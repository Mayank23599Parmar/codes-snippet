import React, { Component } from "react";
import { emailValidate } from "../../../components/Helper";
export class CortporatePopup extends Component {
  constructor(props) {
    super(props);

    this.state = {
      emailenq: "",
      mobilenoenq: "",
      showBtnLoading: false,
      emailError: "",
      mobileError: "",
      submitSuccess: false,
      submitError: false
    };
  }
  handleSubmit = async (e) => {
    e.preventDefault();
    let formData = new FormData(e.target);
    let url =
      "https://script.google.com/macros/s/AKfycbzDCwWeYlzV7mYcQ1K-PlPB-CNL0b9ziygLqk03w5641vYRdcs/exec?";
    let method = "POST";
    let phoneError = false;
    let first_char = this.state.mobilenoenq.charAt(0);
    let msg = '';
    let phoneFormatMatch = false;
    if (first_char == "6" || first_char == "7" || first_char == "8" || first_char == "9") {
      phoneFormatMatch = true;
    }
    if (!phoneFormatMatch) {

      phoneError = true;
      msg = 'Please enter correct phone number starting from 6/7/8/9';
    }
    if (cn(this.state.mobilenoenq) || this.state.mobilenoenq.length !== 10) {

      phoneError = true;
      msg = 'Please enter your 10 digit phone number to proceed!';
    }
    if (this.state.emailenq.length != 0 && this.state.mobilenoenq.length != 0) {
      if (
        !emailValidate(this.state.emailenq) ||
        phoneError
      ) {
        if (!emailValidate(this.state.emailenq))
          this.setState({ emailError: "Enter valid email address" });
        if (phoneError) {
          this.setState({ mobileError: msg });
        }
      } else {
        this.setState(
          { showBtnLoading: true, emailError: "", mobileError: "" },
          async () => {
            let data = await fetch(url, {
              method: method,
              body: formData,
            }).then((res) => {
              if (res.status === 200) {
                this.setState({ showBtnLoading: false, submitSuccess: true });
              }
              else {
                this.setState({ showBtnLoading: false, submitError: true });
              }
            });
          }
        );
      }
    } else {
      if (cn(this.state.emailenq)) {
        this.setState({ emailError: "Email address can't be blank" });
      }
      if (phoneError) {
        this.setState({ mobileError:msg });
      }
    }
  };

  render() {
    const { emailenq, mobilenoenq, showBtnLoading } = this.state;
    return (
      <div>
        <form onSubmit={this.handleSubmit} className="enquery-form">
          <div>
            <h4 className="text-align-center title">
              Enquiry now
              <span className="close" onClick={() => this.props.closePopup()}>
                <img src={pwa.icons.close} alt="close notify" />
              </span>
            </h4>
            <input
              type="email"
              id="email"
              name="email"
              placeholder="E-Mail Address"
              className="bop-full "
              value={emailenq}
              onChange={(e) => {
                this.setState({ emailenq: e.target.value, emailError: "" });
              }}
            />
            {this.state.emailError.length > 0 && (
              <div className="error">{this.state.emailError}</div>
            )}
          </div>
          <div>
            <input
              type="number"
              id="phone"
              name="phone"
              placeholder="Mobile"
              className="bop-full"
              value={mobilenoenq}
              onChange={(e) => {
                if (e.target.value.length <= 10) {
                  this.setState({
                    mobilenoenq: e.target.value,
                    mobileError: "",
                  });
                }
              }}
            />
            {this.state.mobileError.length > 0 && (
              <div className="error">{this.state.mobileError}</div>
            )}
          </div>
          <button
            className={`btn ${showBtnLoading ? "loading" : ""}`}
            type="submit"
          >
            Submit
          </button>
          {
            this.state.submitSuccess ? <div>
              <div className='success'>Registered Successfully</div>
            </div> : ''
          }
          {
            this.state.submitError ? <div>
              <div className='error' >Something went wrong</div>
            </div> : ''
          }
        </form>
      </div>
    );
  }
}

export default CortporatePopup;
