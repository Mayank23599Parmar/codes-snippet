import React, { Component } from "react";
import Srcset from "../../../components/SrcSet";
import MediaQuery from '../../../components/MediaQuery';
import TnCSection from '../../../components/TnCSection';
import UrlSet from '../../../components/UrlSet';

export class BecomeAffiliate extends Component {
  constructor(props) {
    super(props);

    this.state = {
      email: "",
      password: "",
      full_name: "",
      confirm_password: "",
      formErrors: {
        email: "",
        password: "",
        full_name: "",
        confirm_password: "",
      },
    };
  }

  // handleChange = (e) => {
  //   const { name, value } = e.target;
  // };
  render() {
    const {join_now,banner_1,banner_xs_1,image_1,image_2,image_3,image_xs_1,image_xs_2,image_xs_3, terms_condition_title, terms_condition_detail } = this.props.data.data;
    return (
      <div id='affiliate-page'>
        <div className="container">
          <div className="">
            {/* <div className='iframe-section'>
              <iframe className="affiliate-form" src="https://nexxbase.trackier.com/register.html" frameBorder="0"></iframe>
            </div> */}
            <div className='img section'>
              <MediaQuery query='tablet-and-up'>
              <UrlSet className="page-link" href={join_now}><Srcset src={banner_1} /></UrlSet>
              </MediaQuery>
              <MediaQuery query='phone' >
              <UrlSet className="page-link" href={join_now}><Srcset src={banner_xs_1} /></UrlSet>
              </MediaQuery>
            </div>
            <div className='img section'>
              <MediaQuery query='tablet-and-up'>
                <Srcset src={image_1} />
              </MediaQuery>
              <MediaQuery query='phone' >
                <Srcset src={image_xs_1} />
              </MediaQuery>
              <div className="cta"><UrlSet className="page-link" href={join_now}><span>Join Now</span></UrlSet></div>
            </div>
            <div className='img section'>
              <MediaQuery query='tablet-and-up'>
                <Srcset src={image_2} />
              </MediaQuery>
              <MediaQuery query='phone' >
                <Srcset src={image_xs_2} />
              </MediaQuery>
            </div>
            <div className='img section'>
              <MediaQuery query='tablet-and-up'>
                <Srcset src={image_3} />
              </MediaQuery>
              <MediaQuery query='phone' >
                <Srcset src={image_xs_3} />
              </MediaQuery>
            </div>
          </div>
          {terms_condition_detail ? <TnCSection specifications={{ details: terms_condition_detail, title: terms_condition_title }} /> : null}
        </div>
      </div>
    );
  }
}

export default BecomeAffiliate;
