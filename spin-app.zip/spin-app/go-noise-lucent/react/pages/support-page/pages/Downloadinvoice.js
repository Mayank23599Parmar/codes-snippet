import React, { Component } from 'react';
import ErrorPage from '../../errorpage/ErrorPage';
import HtmlParser from 'react-html-parser';
import axios from 'axios';
import { emailValidate } from "../../../components/Helper";
export class Downloadinvoice extends Component {
	constructor(props) {
		super(props)
		this.state = {
			orderid: '',
			mobileNumber: '',
			orderidError: '',
			mobileNumberError: ''
		}
	}

	checkErrors = () => {
		let orderidError = "",
			mobileNumberError = "";
		if (this.state.orderid === '') {
			orderidError = 'Please enter a valid Order ID';
		}
		let phoneError = false;
		let first_char = this.state.mobileNumber.charAt(0);
		let msg = '';
		let phoneFormatMatch = false;
		if (first_char == "6" || first_char == "7" || first_char == "8" || first_char == "9") {
			phoneFormatMatch = true;
		}
		if (!phoneFormatMatch) {

			phoneError = true;
			msg = 'Please enter correct phone number starting from 6/7/8/9';
		}
		if (cn(this.state.mobileNumber) || this.state.mobileNumber.length !== 10) {

			phoneError = true;
			msg = 'Please enter your 10 digit phone number to proceed!';
		}
		if (orderidError != '' || phoneError) {
			this.setState({ mobileNumberError: msg, orderidError })
		} else {
			this.downloadInvoice();
		}
	}
	submitForm = () => {
		this.setState({
			orderidError: '',
			mobileNumberError: ''
		}, () => {
			this.checkErrors();
		})
	}
	downloadInvoice = async () => {
		let orderId = this.state.orderid
		let mobileNumber = this.state.mobileNumber
		let downloadInvoice = {
			"order_id": orderId,
			"phone": mobileNumber
		}
		try {
			let res = await fetch('https://pre-order.gonoise.in/account/invoice', {
				method: 'POST',
				headers: {
					"Access-Control-Allow-Origin": "*",
					"Content-Type": "application/json",
					"x-auth-secret": "0329b8ad3bce0bcfdda8ca65c37143c3ccc1e8ae0545da19898ca08bba8ed1a5"
				},
				body: JSON.stringify(downloadInvoice),
			})

			let response = await res.json();
			if (response.status === "200") {
				window.open(response.data, '_blank');
			} else if (response.status === "401") {
				document.getElementById("download-invalid-detail").innerHTML = 'Invalid order id.';
				document.getElementById("download-invalid-detail").style.display = "block";
				setTimeout(function () {
					document.getElementById("download-invalid-detail").style.display = "none";
					document.getElementById("download-invalid-detail").innerHTML = '';
				}, 5000);
			}
			else if (response.status === "402") {
				document.getElementById("download-invalid-detail").innerHTML = 'Invalid phone no.';
				document.getElementById("download-invalid-detail").style.display = "block";
				setTimeout(function () {
					document.getElementById("download-invalid-detail").style.display = "none";
					document.getElementById("download-invalid-detail").innerHTML = '';
				}, 5000);
			}
			else if (response.status === "408") {
				document.getElementById("download-invalid-detail").innerHTML = 'Order cancelled by customer';
				document.getElementById("download-invalid-detail").style.display = "block";
				setTimeout(function () {
					document.getElementById("download-invalid-detail").style.display = "none";
					document.getElementById("download-invalid-detail").innerHTML = '';
				}, 5000);
			}
			else if (response.status === "409") {
				document.getElementById("download-invalid-detail").innerHTML = 'Your order has not been shipped yet. Please check again in 48 hours.';
				document.getElementById("download-invalid-detail").style.display = "block";
				setTimeout(function () {
					document.getElementById("download-invalid-detail").style.display = "none";
					document.getElementById("download-invalid-detail").innerHTML = '';
				}, 5000);
			}
		}
		catch (e) {
			console.log(e);
		}
	}


	render() {

		if (!this.props.data) {
			return <ErrorPage show={true} />
		}
		return (
			<div className='download-invoice-page '>
				<div className={`container ${this.props.data.handle}`}>
					<h1 className='text-align-center'>{this.props.data.title}</h1>
					<div className="download-form-wrapper">
						<div className="input-container">
							<input type="text" id="order-id" name="Order id" placeholder="Please enter your Order ID" onChange={(e) => this.setState({ orderid: e.target.value })} ></input>
							{this.state.orderidError && (
								<p className="error">{this.state.orderidError}</p>
							)}
						</div>
						<div className="input-container">
							<input type="number" id="mobile-number" name="Mobile number" placeholder="Please enter your 10 digit Mobile Number"
								onChange={(e) => {
									if (e.target.value.length <= 10) {
										this.setState({
											mobileNumber: e.target.value,

										});
									}
								}}
								value={this.state.mobileNumber}
							></input>
							{this.state.mobileNumberError && (
								<p className="error">{this.state.mobileNumberError}</p>
							)}
						</div>
						<div className="btn-wrapper">
							<button onClick={() => this.submitForm()}>Download Invoice</button>
						</div>

						<p id="download-invalid-detail"></p>
					</div>
				</div>
			</div>
		)
	}
}

export default Downloadinvoice
