import React, { Component } from "react";
import HtmlParser from 'react-html-parser';

export class EWasteMgt extends Component {
  render() {
		const { data } = this.props;
		let pageContent12 = data.data;
		let pageContent = pageContent12.replace('"data":"','');
		pageContent = pageContent.substring(0,pageContent.length-2)
		
    return (
      <div className="ewaste-mgt">
        <div className="container">
          <div className='ewaste-container'>
					  {HtmlParser(pageContent)}
          </div>
        </div>
      </div>
    );
  }
}

export default EWasteMgt;
