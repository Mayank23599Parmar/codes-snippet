import React, { Component } from "react";
import LazyLoad from 'react-lazyload';
import MediaQuery from "../../../components/MediaQuery";
import Srcset from "../../../components/SrcSet";
import ReactModal from "react-modal";


class QuestPlayers extends Component {	
    constructor(props) {
        super(props);
        this.customStyles = {
          overlay:{
            zIndex: 100
          },
          content: {
            top: "50%",
            left: "50%",
            right: "auto",
            bottom: "auto",
            marginRight: "-50%",
            transform: "translate(-50%, -50%)",
            position:"absolute",
            backgroundColor: "#000",
            maxWidth:'600px',
            padding: '0px',
            width: "calc(100% - 20px)"
          },
        };
        this.state = {
          showVideoModal: false,
          video_url:''
        };
        this.handleCloseVideo = this.handleCloseVideo.bind(this);
      }
      

      clickEvent = (url) => {
         // console.log('url----->',url)
            this.setState({ video_url:url , showVideoModal:true});
        
      }

      handleCloseVideo() {
        this.setState({ showVideoModal: false });
        };

      toggleModale = (value) => {
        this.setState({ showVideoModal: value });
      };

	render() {
        let { players } = this.props;
        const { showVideoModal,video_url } = this.state;
    
    if (Object.keys(players).length === 0) {
        return false;
    }
      let items = [];
      for (let i = 1; i < 20; i++) {
        let image = players["image_" + i];
        let embed_url = players["youtube_url_" + i];
        if(image){
            let content = (
                <div className="player-embed-url player"  onClick={()=>this.clickEvent(embed_url)} >
                     <LazyLoad height={200}><Srcset src={image} /></LazyLoad>
			    </div>
            );
            items.push(content);
        }
      }
      if (items.length > 0) {
        return <>
        <div className="players-main">
            <div className="players-main-container">
                {items}
            </div>

        </div>
        <ReactModal
          isOpen={showVideoModal}
          contentLabel="onRequestClose Example"
          onRequestClose={() => this.toggleModale(false)}
          shouldCloseOnOverlayClick={true}
          style={this.customStyles}
      >
        <div className="video-popup-wrap">
        <iframe
          playsInline
          width="100%"
          height="100%"
          src={video_url}
          className="video-container video-container-overlay modal-video"
        >
        </iframe>
        <div className="_close-video-btn" onClick={this.handleCloseVideo}>
                <img src="https://cdn.shopify.com/s/files/1/0997/6284/files/close-icon_ef5f4e33-c281-440d-9f5d-70a73071fec1.png?v=1618205494"/>
              </div>
        </div>
      </ReactModal>
        </>;
      }
      return null;
	}
}

export default QuestPlayers
