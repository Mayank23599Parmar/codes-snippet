import React, { Component } from "react";
import ReactModal from "react-modal";
import Srcset from "../../../components/SrcSet";
import CortporatePopup from "./CortporatePopup";

ReactModal.setAppElement("#my-react");
export class CorporateImageWithText extends Component {
  constructor(props) {
    super(props);

    this.customStyles = {
      overlay:{
        backgroundColor:'rgba(0, 0, 0,0.5)',
      },
      content: {
        top: "50%",
        left: "50%",
        right: "auto",
        bottom: "auto",
        marginRight: "-50%",
        transform: "translate(-50%, -50%)",
        padding: "40px 30px",
        maxWidth:"450px",
        width:"95%"
      },
    };
    this.state = {
      showModal: false,
      emailenq: "",
      mobilenoenq: "",
    };

  }

  handleOpenModal = () => {
    this.setState({ showModal: true });
  }

  handleCloseModal = () => {
    this.setState({ showModal: false, emailenq: "", mobilenoenq: "" });
  }
  handleSubmit(e) {
    e.preventDefault();
  }

  render() {
    const {
      sec3_image1,
      sec3_head1,
      sec3_desc1,
      sec3_image2,
      sec3_head2,
      sec3_desc2,
    } = this.props;
    return (
      <div className="image-with-text">
        <div className="container">
          <div className="corporate-container">
            <div className="comp-1 flex-view">
              <div className="col-sm-6">
                <div className="image">
                  <Srcset src={sec3_image1} />
                </div>
              </div>
              <div className="col-sm-6 text-area">
                <div>
                  <h3>{sec3_head1}</h3>
                  <p>{sec3_desc1}</p>
                  <div className="button">
                    <button className='btn ' onClick={this.handleOpenModal}>Enquire Now</button>
                  </div>
                  <ReactModal
                    isOpen={this.state.showModal}
                    contentLabel="onRequestClose Example"
                    onRequestClose={this.handleCloseModal}
                    shouldCloseOnOverlayClick={true}
                    style={this.customStyles}
                  >
                    <CortporatePopup closePopup={this.handleCloseModal} />
                  </ReactModal>
                </div>
              </div>
            </div>
            <div className="comp-2 flex-view-xs right">
              <div className="col-sm-6 text-area">
                <div>
                  <h3>{sec3_head2}</h3>
                  <p>{sec3_desc2}</p>
                  <div className="button">
                    <button className='btn ' onClick={this.handleOpenModal}>Enquire Now</button>
                  </div>
                  <ReactModal
                    isOpen={this.state.showModal}
                    contentLabel="onRequestClose Example"
                    onRequestClose={this.handleCloseModal}
                    shouldCloseOnOverlayClick={true}
                    style={this.customStyles}
                  >
                    <CortporatePopup closePopup={this.handleCloseModal} />
                  </ReactModal>
                </div>
              </div>
              <div className="col-sm-6">
                <div className="image">
                  <Srcset src={sec3_image2} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CorporateImageWithText;
