import React from "react";
import { connect } from "react-redux";
import { fetchProductTitle, manageHeight, queryString } from "../../../components/Helper";
import CompareItem from "./CompareItem";
class Compare extends React.Component {
  state = {
    currentProductsData: { data: [] },
    leftProduct: null,
    rightProduct: null,
    swatchHeight: 0,
  };
  setSwatchHeight = () => {
    let selector = document.querySelectorAll(
      ".compare-specifications .swatch-wrap"
    );
    if (!cn(selector)) {
      let swatchHeight = manageHeight(selector);
      this.setState({ swatchHeight });
    }
  };
  findCurrentType = (compare, currentProduct) => {
    const { data } = compare;
    let productData = { data: [] };
    for (let i = 0; i < data.length; i++) {
      let fondCollection = false;
      let collection = data[i];
      for (let j = 0; j < collection.data.length; j++) {
        let product = collection.data[j];
        if (product.id == currentProduct) {
          fondCollection = true;
          break;
        }
      }
      if (fondCollection) {
        productData = collection;
        break;
      }
    }
    return productData;
  };
  findProduct = (currentProductsData, currentProduct) => {
    // const { currentProduct } = compare;
    if (cn(currentProductsData.data)) {
      return null;
    }
    let product = currentProductsData.data.find(
      (item) => currentProduct === item.id
    );
    if (cn(product)) {
      return null;
    } else {
      return product;
    }
  };

  // componentWillReceiveProps(new_props) {
  //   let { currentProduct} = this.props.data;
  //   if(new_props.data.currentProduct != currentProduct ){
  //     let currentProductsData = {data:[]};
  //     if (!cn(new_props.data.currentProduct)) {
  //       currentProductsData = this.findCurrentType(new_props.data);
  //       let leftProduct = this.findProduct(currentProductsData,new_props.data);
  //       this.setState({currentProductsData,leftProduct});
  //     } else {
  //       if(data.length > 0 ){
  //         currentProductsData = data[0];
  //         this.setState({currentProductsData,leftProduct: currentProductsData.data[0]});
  //       }
  //     }
  //   }
  // }
  componentDidMount() {
    const compare = this.props.data; 
    // let { currentProduct, data } = compare;
    let { data } = compare;
    let currentProductsData = { data: [] };
    let queryData = queryString().product;
    let currentProduct = '';
    if(!cn(queryData)){
      currentProduct = queryData.value;
    }
    if (!cn(currentProduct)) {
      currentProductsData = this.findCurrentType(compare,currentProduct);
      let leftProduct = this.findProduct(currentProductsData, currentProduct);
      this.setState({ currentProductsData, leftProduct });
    } else {
      if (data.length > 0) {
        currentProductsData = data[0];
        this.setState({
          currentProductsData,
          leftProduct: currentProductsData.data[0],
        });
      }
    }
  }
  changeProduct = (e, column) => {
    let title = e.target.value;
    let { currentProductsData } = this.state;
    let productData = currentProductsData.data.find(
      (item) => item.title == title
    );

    if (column == "left") {
      if (cn(title)) {
        this.setState({ leftProduct: null });
      } else {
        this.setState({ leftProduct: productData });
      }
    } else {
      if (cn(title)) {
        this.setState({ rightProduct: null });
      } else {
        this.setState({ rightProduct: productData });
      }
    }
  };
  render() {
    const {
      currentProductsData,
      leftProduct,
      rightProduct,
      swatchHeight,
    } = this.state;
    let leftTitle = "";
    let rightTitle = "";
    if (!cn(leftProduct)) {
      leftTitle = leftProduct.title;
    }
    if (!cn(rightProduct)) {
      rightTitle = rightProduct.title;
    }
    const selectStyle = { backgroundImage: `url(${pwa.icons.greyDownArrow})` };
    return (
      <div className="compare-specifications">
        <div className="">
          <h1 className="compare-page-title">
          Compare Specifications
          </h1>
          <div className="flex-view-xs space">
            <div className="col-sm-6 col-xs-6 no-padding">
              <div className="product-specification-left">
                <div className="product-specification">
                  <div className="compare-wrapper">
                  <select
                    style={selectStyle}
                    value={leftTitle}
                    onChange={(e) => {
                      this.changeProduct(e, "left");
                    }}
                  >
                    <option value="">Select product</option>
                    {currentProductsData.data.map((product) => {
                      let title = product.title;
                      if(cn(title)){
                        return null;
                       }
                      let tagTitle = fetchProductTitle(product.tags);
                      if (!cn(tagTitle)) {
                        title = tagTitle;
                      }
                      if (!cn(rightProduct)) {
                        if (rightProduct.title === product.title) {
                          return "";
                        }
                      }
                      return <option value={product.title}>{title}</option>;
                    })}
                  </select>
                  </div>
                  {leftProduct !== null && (
                    <CompareItem
                      setSwatchHeight={this.setSwatchHeight}
                      swatchHeight={swatchHeight}
                      product={leftProduct}
                    />
                  )}
                </div>
              </div>
            </div>
            <div className="col-sm-6 col-xs-6 no-padding">
              <div className="product-specification-right">
                <div className="product-specification">
                <div className="compare-wrapper">
                  <select
                    style={selectStyle}
                    value={rightTitle}
                    onChange={(e) => {
                      this.changeProduct(e, "right");
                    }}
                  >
                    <option value="">Select product</option>
                    {currentProductsData.data.map((product) => {
                      let title = product.title;
                      if(cn(title)){
                        return null;
                       }
                      let tagTitle = fetchProductTitle(product.tags);
                      if (!cn(tagTitle)) {
                        title = tagTitle;
                      }
                      if (!cn(leftProduct)) {
                        if (leftProduct.title === product.title) {
                          return "";
                        }
                      }
                      return <option value={product.title}>{title}</option>;
                    })}
                  </select></div>
                  {rightProduct !== null && (
                    <CompareItem
                      swatchHeight={swatchHeight}
                      setSwatchHeight={this.setSwatchHeight}
                      product={rightProduct}
                    />
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  data: state.support.supportData.compare,
});
export default connect(mapStateToProps, null)(Compare);
