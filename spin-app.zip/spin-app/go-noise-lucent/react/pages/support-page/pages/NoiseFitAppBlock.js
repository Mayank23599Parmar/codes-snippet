import React, { Component } from "react";
import Srcset from "../../../components/SrcSet";

export class NoiseFitAppBlock extends Component {
  constructor(props) {
    super(props);

    this.state = {
      selectedScreen: 0,
    };
  }
	clickHandler=(index)=>{
		this.setState({selectedScreen:index})
	}
  render() {
    const { blockData } = this.props;
    const { selectedScreen } = this.state;
    let ImageSection = blockData.map((singleImage, index) => {
      if (selectedScreen === index) {
        return (
          <div key={index} className="">
            <div className="image-text flex-view-xs">
              <div className='img col-sm-6'>
                <Srcset src={singleImage.image} />
              </div>
							<div className='text col-sm-6'>
								<h3>{ singleImage.title }</h3>
								<p>{ singleImage.description}</p>
							</div>
            </div>
          </div>
        );
      }
		});
		let iconSection = blockData.map((singleIcon,index)=>{
			
			return <div className={`icon-text ${selectedScreen === index ? 'selected':''}`}   key={index} onClick={()=>{this.clickHandler(index)}}>
				<div className='img'>
					<Srcset src={singleIcon.icon} />
				</div>
				<p>{singleIcon.icon_text}</p>
			</div>
		})
    return (
      <div className="mobile-app-section flex-view">
        <div className="image-section col-sm-9">{ImageSection}</div>
        <div className='icon-section col-sm-3'>{iconSection}</div>
      </div>
    );
  }
}

export default NoiseFitAppBlock;
