import React from 'react';
import { connect } from 'react-redux';
import HtmlParser from 'react-html-parser';
import Srcset from '../../../components/SrcSet';
class RegisterComplaint extends React.Component {
 render() {
  const { description } = this.props;

  return (
   <div className='register-complaint-page'>
    <div className='container'>
     <h4 className='rc-title font-weight-bold'><span className='image'><Srcset src={pwa.icons.supportIcons.registerComplaint} /></span> Register complaint</h4>
     <div className='rc-details'>
      <div className='flex-view rc-details space-between'>
       <div className='col-sm-6 page-content-area'>{HtmlParser(description)}</div>
       <div className='col-sm-6 btn-area'>
         <div>
            <div>
               <a href='https://support.gonoise.in/service-centre' target='_blank' className='rc-button'>Check service centre</a>
            </div>
            <div className='resolution'>
               <p className='rc-button-subtitle'>(Average resolution is 6-7 working days)</p>
            </div>
         </div>
         <div>
            <div>
               <a href='https://support.gonoise.in/complaintregistration' target='_blank' className='rc-button'>Register an online complaint</a>
            </div>
            <div className='resolution'>
               <p className='rc-button-subtitle'>(Average resolution is 12-15 working days)</p>
            </div>
         </div>
         <a href='https://support.gonoise.in' target='_blank' className='rc-button'>Check Status of ticket</a>
       </div>
      </div>
     </div>
    </div>
   </div>
  );
 }
}

const mapStateToProps = state => ({
 description:
  state.support.supportData.registerComplaint.data.settings
   .register_complaint_description,
});

export default connect(mapStateToProps)(RegisterComplaint);
