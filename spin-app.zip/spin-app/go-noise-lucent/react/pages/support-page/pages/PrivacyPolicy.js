import React, { Component } from "react";
import HtmlParser from "react-html-parser";

export class PrivacyPolicy extends Component {
  render() {
    const { data } = this.props;
    let pageContent12 = data.data;
    let pageContent = pageContent12.replace('"data":"', "");
    pageContent = pageContent.substring(0, pageContent.length - 2);
    return (
      <div className="privacy-policy-page">
        <div className="container">
          <div className="privacy-policy-container">
            {HtmlParser(pageContent)}
          </div>
        </div>
      </div>
    );
  }
}

export default PrivacyPolicy;
