// import { cssNumber } from "jquery";
import React, { Component } from "react";
import Srcset from "../../../components/SrcSet";

export class InThePress extends Component {
  render() {
    let { data } = this.props;
    if (cn(data.data)) {
      return null;
    }
    let section = data.data;
    let { sectionId, blocks, settings } = section;
    let { text, title } = settings;
    return (
      <div id="press-section" className={sectionId}>
        <div className="container">
          <div>
            <div className="title">
              {title && <h1 className="text-align-center">{title}</h1>}
            </div>
            {text && <h5 className="text-align-center">{text}</h5>}
            <div className="images-section flex-view-xs center">
              {blocks.map((block) => {
                return (
                  <div className="image col-sm-4 col-xs-12">
                    <Srcset src={block.image} alt="pressImage" />
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default InThePress;
