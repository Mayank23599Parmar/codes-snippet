import React, { Component } from 'react';
import Srcset from '../../../components/SrcSet';
import { connect } from 'react-redux';
import { setCurrentTab } from '../../../redux/support/supportAction';
import CurrentOpeningModal from '../modals/CurrentOpeningModal';

class Careers extends Component {
 state = {
  openCurrentOpeningModal: false,
  currentOpeningDesc: '',
 };

 handleCurrentOpening = data => {
  this.setState(prevState => ({
   ...prevState,
   currentOpeningDesc: data,
   openCurrentOpeningModal: true,
  }));
 };

 handleCurrentOpeningModal = bool => {
  this.setState(prevState => ({
   ...prevState,
   openCurrentOpeningModal: bool,
  }));
 };

 render() {
  const { data } = this.props;
  if (cn(data.data)) {
   return null;
  }
  const { settings, blocks } = data.data;
  return (
   <div className='careers'>
    <div className='container'>
     {this.state.openCurrentOpeningModal && (
      <CurrentOpeningModal
       handleCurrentOpeningModal={this.handleCurrentOpeningModal}
       data={this.state.currentOpeningDesc}
      />
     )}
     <div className='careers-container'>
      <h1 className='text-center'>{settings.careers_title}</h1>
      <h4 className='text-center'>{settings.careers_subtitle}</h4>
      <div className='index-section flex-view-xs'>
       <div className='col-sm-6 col-xs-12'>
        <div className='index-content'>
         <p>{settings.index_content}</p>
        </div>
        <button
         className='btn'
         onClick={() => this.props.setCurrentTab('current-openings')}>
         Openings
        </button>
       </div>
       <div className='col-sm-6 col-xs-12'>
        <Srcset alt='img' src={settings.index_image} />
       </div>
      </div>
     </div>
    </div>
    <div className='motto-section'>
     <div className='container'>
      <div className='motto-content flex-view-xs'>
       {blocks.map(
        (block, index) =>
         block.type === 'motto' && (
          <div className='col-xs-4 text-center' key={index}>
           <Srcset alt='img' src={block.data.motto_logo} />
           <h5 className='motto-title'>{block.data.motto_title}</h5>
           <div className='motto-description'>
            <p>{block.data.motto_description}</p>
           </div>
          </div>
         )
       )}
      </div>
     </div>
    </div>
    <div className='perks-section'>
     <div className='container'>
      <div className='perks-content'>
       <h1 className='text-center'>Our Perks</h1>
       {blocks.map(
        (block, index) =>
         block.type === 'perks' && (
          <div className='col-sm-6 col-xs-12' key={index}>
           <div className='perk-point'>
            <h4 className='font-weight-bold'>{block.data.perk_title}</h4>
            <p>{block.data.perk_description}</p>
           </div>
          </div>
         )
       )}
      </div>
     </div>
    </div>
    <div className='current-openings-section'>
     <div className='container'>
      <div className='current-openings-content'>
       <h1 className='text-center'>Current Openings</h1>
       <div className='flex-view middle'>
        {blocks.map(
         (block, index) =>
          block.type === 'current_openings' && (
           <div className='col-sm-3 col-xs-6 current-opening-block' key={index}>
            <div
             className='current-opening'
             onClick={() =>
              this.handleCurrentOpening(block.data.current_opening_description)
             }>
             <Srcset alt='img' src={block.data.current_opening_logo} />
             <p>{block.data.current_opening_title}</p>
            </div>
           </div>
          )
        )}
       </div>
      </div>
     </div>
    </div>
    <div className='noise-lifestyle-section'>
     <div className='container'>
      <div className='noise-lifestyle-content text-center'>
       <div className='title-container'>
        <h1>
         <span>Life at </span>
         <span className='noise-lifestyle-logo'>
          <Srcset alt='img' src={settings.noise_lifestyle_logo} />
         </span>
         <span className='noise-text-logo'>
          <Srcset alt='img' src={settings.noise_text_logo} />
         </span>
        </h1>
       </div>
       <div className='noise-lifestyle-subsections flex-view-xs'>
        <div className='col-sm-6 col-xs-12 noise-lifestyle-section-description '>
         <h3>{settings.noise_lifestyle_one_title}</h3>
         <p>{settings.noise_lifestyle_one_description}</p>
        </div>
        <div className='col-sm-6 col-xs-12 noise-lifestyle-section-image'>
         <Srcset alt='img' src={settings.noise_lifestyle_image_one} />
        </div>
       </div>
       <div className='noise-lifestyle-subsections flex-view-xs'>
        <div className='col-sm-6 col-xs-12 noise-lifestyle-section-image'>
         <Srcset alt='img' src={settings.noise_lifestyle_image_two} />
        </div>
        <div className='col-sm-6 col-xs-12 noise-lifestyle-section-description-right'>
         <h3>{settings.noise_lifestyle_two_title}</h3>
         <p>{settings.noise_lifestyle_two_description}</p>
        </div>
       </div>
       <div className='noise-lifestyle-subsections flex-view-xs'>
        <div className='col-sm-6 col-xs-12 noise-lifestyle-section-description '>
         <h3>{settings.noise_lifestyle_three_title}</h3>
         <p>{settings.noise_lifestyle_three_description}</p>
        </div>
        <div className='col-sm-6 col-xs-12 noise-lifestyle-section-image'>
         <Srcset alt='img' src={settings.noise_lifestyle_image_three} />
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  );
 }
}

const mapDispatchToProps = dispatch => ({
 setCurrentTab: data => dispatch(setCurrentTab(data)),
});

export default connect(null, mapDispatchToProps)(Careers);
