import React, { Component } from 'react'
import ChildLinks from './ChildLinks';
export class SiteMap extends Component {
	render() {
		const { data } = this.props;
		const { siteLinks } = data.data; 
		
		let mainComp = siteLinks.map((ele,index)=>{
			return <div className='single-comp' key={index}>
				<h2>{ele.title}</h2>
				<ChildLinks links={ele.childlinks} />
			</div>
		}) 
		
		return (
			<div className='site-map'>
				<div className='container'>
					<div className='site-map-container'>
						{mainComp}
					</div>
				</div>
			</div>
		)
	}
}

export default SiteMap
