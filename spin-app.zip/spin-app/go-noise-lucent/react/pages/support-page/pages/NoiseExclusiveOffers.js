import React, { Component } from 'react'
import HtmlParser from 'react-html-parser';

export class NoiseExclusiveOffers extends Component {
	render() {
		const { data } = this.props;
		let pageContent12 = data.data;
		let pageContent = pageContent12.replace('"data":"','');
		pageContent = pageContent.substring(0,pageContent.length-2)
		return (
			<div className='exclusive-offers' >
				<div className='container'>
					<div className='exclusive-offer-container'>
						<div className='header'>
							<h2>Nosie Exclusive Offers:</h2>
							<h4>Terms and Conditions</h4>
						</div>
						<div className='page-content'>
							{HtmlParser(pageContent)}
						</div>
					</div>
				</div>
			</div>
		)
	}
}

export default NoiseExclusiveOffers
