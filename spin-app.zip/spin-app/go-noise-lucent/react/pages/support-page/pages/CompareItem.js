import React from "react";
import HtmlParser from 'react-html-parser'
import Srcset from "../../../components/SrcSet";
import UrlSet from "../../../components/UrlSet";
import VariantSelector from "../../../components/VariantSelector";
import { connect } from "react-redux";
import { addToCart } from "../../../redux/cart/cartAction";
import {
  formatMoney,
} from "../../../components/Helper";

class CompareItem extends React.Component{
  constructor(props) {
    super(props);
    this.ref = React.createRef();
    this.state = {
      product:{},
      selectedVariant: null,
    };
  }
  addToCart = (e) => {
    if (this.state.selectedVariant.available === false) {
      return;
    }
    const form = { id: parseInt(this.state.selectedVariant.id), quantity: 1 };
    const data = {
      type: e.currentTarget.name,
      form,
    };
    this.props.addToCart(data);
  };
  setSelectedVariant = (selectedVariant) => {
    this.setState({ selectedVariant });
  };
  componentDidMount() {
    const { product } = this.props;
    const selectedVariant = product.selected_or_first_available_variant;
    const {setSwatchHeight} = this.props;
    this.setState({ selectedVariant,product },()=>{
      setSwatchHeight();
    });
  }
  componentDidUpdate(prevProps,prevState) {
    const { product } = this.props;
    if(!cn(product)){
      let update = false;
      if(cn(prevProps.product)){
        update = true;
      }else if(prevProps.product.id !== product.id){
        update = true;
      } 
      if(update){
        const {setSwatchHeight} = this.props;
        const selectedVariant = product.selected_or_first_available_variant;
        this.setState({ selectedVariant,product },()=>{
          setSwatchHeight();
        });
      }
    }
  }
  render() {
    const { selectedVariant,product } = this.state;
    const {swatchHeight} = this.props;
    const selectStyle = { backgroundImage : `url(${pwa.icons.greyDownArrow})`}
    if(cn(product)){
      return null;
    }
    const { variants, options, variantImages, features, handle } = product;
    let swatchTitleShow = false;
    if(cn(selectedVariant)){
        return null;
    }
    let url = `/products/${handle}?variant=${selectedVariant.id}`;
    let featured_image = product.featured_image; 
    if(!cn(selectedVariant.featured_image)){
        featured_image = selectedVariant.featured_image.src;
    }
    if(this.ref.current){
        let image = this.ref.current.querySelector('.product-img');
        image.setAttribute("srcset",featured_image);
    }
    let Style= {'height':'auto'}
    if(swatchHeight > 0){
      Style= {'height':swatchHeight};
    }
    return (
      <div className="compare-product">
        <div className="compare-wrapper">
          <div className="image" ref={this.ref}><Srcset className="product-img" alt={product.title} src={featured_image} className="product-img" /></div>
        </div>
        <div className={`variants-wrapper`}>
          {options.map((option, index) => {
            return (
              <ul className="swatch-wrap" style={Style}>
                {swatchTitleShow ? (
                  <h3 className="swatch-title">{option}</h3>
                ) : null}
                {variants.map((variant) => {
                  return (
                    <VariantSelector
                      option={option}
                      selectedVariant={selectedVariant}
                      variantImages={pwa.variantImages}
                      variant={variant}
                      setSelectedVariant={() =>
                        this.setSelectedVariant(variant)
                      }
                    />
                  );
                })}
              </ul>
            );
          })}
        </div>
        <div className="compare-wrapper">
        <div className="product-basic-info">
          <div className="price-wrapper">
            <h5 className="price">{formatMoney(selectedVariant.price)}</h5>
            {selectedVariant.compare_at_price && selectedVariant.compare_at_price > selectedVariant.price &&
            <p className="compare-price">{formatMoney(selectedVariant.compare_at_price)}</p>}
          </div>
          <div className='btn-wrapper'>
            <UrlSet className="btn" href={url}>Shop now</UrlSet>
          </div>
        </div>
        </div>
        {features.length > 0 && < div className="featured-wrapper">
        <div className="compare-wrapper">
        <h3 className="specification-title text-center">Specifications</h3>
        </div>
        <ul className="features">
            {features.map((item)=>{
                return <li>
                    <div className="icon-image">
                    <Srcset alt={item.text} src={item.image}/>
                    </div>
                    <p className="text"> {HtmlParser(item.text)} </p>
                </li>
            })}
        </ul><div className='btn-wrapper'>
          <UrlSet className="btn" href={url}>Shop now</UrlSet>
          </div></div>
        }
      </div>
    );
  }
}
const mapDispatchToProps = (dispatch) => ({
  startCartFetch: (value) => dispatch(setCartStart(value)),
  addToCart: (data) => dispatch(addToCart(data)),
});
export default connect(null, mapDispatchToProps)(CompareItem);
