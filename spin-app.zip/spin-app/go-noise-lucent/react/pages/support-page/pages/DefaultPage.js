import React, { Component } from 'react';
import ErrorPage from '../../errorpage/ErrorPage';
import axios from 'axios';
//import CampusNoisemaker from './CampusNoisemaker';

import HtmlParser from 'react-html-parser';
export class DefaultPage extends Component {
	constructor(props){
		super(props)
		this.state = {
			showClass: false
		}
	}
	
	componentDidMount(){
		console.log(this.props)
		if(window.location.href.includes('giveaway')){
			
			if(window.location.hash!='#gleam'&&(''+document.cookie).match(/(^|;)\s*GleamlIWQo=X($|;)/)){return;}
			var s = document.createElement('script');
			s.type = 'text/javascript';
			s.async = true;
			s.src = "https://widget.gleamjs.io/e.js";
			var x = document.getElementsByTagName('script')[0];
			x.parentNode.insertBefore(s, x);
			this.setState({showClass:true})	
		  } 
		  
		  this.init();
	}
	checkUnsubscribePage = () =>{
		if(window.location.href.includes('email-unsubscribe')){
			
			let input_url = window.location.search;
			input_url = input_url.replace('?email=', '')
			document.getElementById("email-unsubscribe").setAttribute('value', input_url);
			let emailId = document.getElementById("email-unsubscribe").value

			document.getElementById("email-unsubscribe-btn").addEventListener('click',function (){ 
				//console.log('------>',emailId)
				let unsubsEmail = { 
					"type": "email", 
				"value": emailId, 
				"status": "Unsubscribe"
				}
            
			if(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(emailId)){
				axios({
					async: true,
					crossDomain: true,
					method: 'post',
					url: 'https://pre-order.gonoise.in/contact/unsubscribe',
					headers:{
						"Access-Control-Allow-Origin" : "*",
						"Content-Type": "application/json",
						"x-auth-secret":"0329b8ad3bce0bcfdda8ca65c37143c3ccc1e8ae0545da19898ca08bba8ed1a5"
					},
					data:unsubsEmail,
					cache:false
				  })
					.then(function (response) {
						console.log(response);
						if (response.data.status === "401") {
							window.history.replaceState({}, document.title, "/" + "pages/email-unsubscribe");
							document.getElementById("email-unsubscribe").value = '';
							document.getElementById("email-unsubscribe-msg").innerHTML = 'Email not registered with us..';
							document.getElementById("email-unsubscribe-msg").style.display = "block";
							setTimeout(function () {
								document.getElementById("email-unsubscribe-msg").style.display = "none";
								document.getElementById("email-unsubscribe-msg").innerHTML = '';
							}, 5000);

						} else if (response.data.status === "200") {
							window.history.replaceState({}, document.title, "/" + "pages/email-unsubscribe");
							document.getElementById("email-unsubscribe").value = '';
							document.getElementById("email-unsubscribe-msg").innerHTML = 'You have been unsubscribed from our email campaign list.';
							document.getElementById("email-unsubscribe-msg").style.display = "block";
							setTimeout(function () {
								document.getElementById("email-unsubscribe-msg").style.display = "none";
								document.getElementById("email-unsubscribe-msg").innerHTML = '';
							}, 5000);
						}
						else if (response.data.status === "402") {
							window.history.replaceState({}, document.title, "/" + "pages/email-unsubscribe");
							document.getElementById("email-unsubscribe").value = '';
							document.getElementById("email-unsubscribe-msg").innerHTML = 'Email already unsubscribed!';
							document.getElementById("email-unsubscribe-msg").style.display = "block";
							setTimeout(function () {
								document.getElementById("email-unsubscribe-msg").style.display = "none";
								document.getElementById("email-unsubscribe-msg").innerHTML = '';
							}, 5000);
						}
						else if (response.data.data.status === "success") {
							document.getElementById("email-unsubscribe").value = '';
							document.getElementById("email-unsubscribe-msg").innerHTML = 'You have been unsubscribed from our email campaign list.';
							document.getElementById("email-unsubscribe-msg").style.display = "block";
							setTimeout(function(){
								document.getElementById("email-unsubscribe-msg").style.display = "none";
								document.getElementById("email-unsubscribe-msg").innerHTML = '';
							}, 5000);
						}else if(response.data.data.status === "fail"){
							document.getElementById("email-unsubscribe").value = '';
							document.getElementById("email-unsubscribe-msg").innerHTML = 'Please try again with valid email.';
							document.getElementById("email-unsubscribe-msg").style.display = "block";
							setTimeout(function(){
								document.getElementById("email-unsubscribe-msg").style.display = "none";
								document.getElementById("email-unsubscribe-msg").innerHTML = '';
							}, 5000);
						}
					})
					.catch(function (error) {
						console.log(error);
					})
			}else{
				document.getElementById("email-unsubscribe-errormsg").style.display = "block";

			}

				}  ); 
		  }
	}
	
	unsubscribeErrorMsg = () =>{
		if(window.location.href.includes('email-unsubscribe')){
		document.getElementById("email-unsubscribe").onfocus = () => {
			document.getElementById("email-unsubscribe-errormsg").style.display = "none";
		};
		}
	}
	init = () => {
		this.checkUnsubscribePage();
		this.unsubscribeErrorMsg();
	}
	render() {
		
		if(!this.props.data){
			return <ErrorPage show={true} />
		}
		return (
			<div className='default-page'>
				<div className={`container ${this.props.data.handle}`}>
				{!this.state.showClass && (
				<h1 className='text-align-center'>{this.props.data.title}</h1>
				)}
					{/* <h1 className={`text-align-center${showClass ? ' title-hide':''}`}>{this.props.data.title}</h1> */}
					<div className='content'>
						{HtmlParser(this.props.data.data)}
					</div>
					<div id="gleam-script-page">
					</div>					
				</div>
			</div>
		)
	}
}

export default DefaultPage
