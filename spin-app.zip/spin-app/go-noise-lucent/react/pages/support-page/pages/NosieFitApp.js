import React, { Component } from "react";
import MediaQuery from "../../../components/MediaQuery";
import Srcset from "../../../components/SrcSet";
import UrlSet from "../../../components/UrlSet";
import NoiseFitAppBlock from "./NoiseFitAppBlock";
// import TrustBatches from '../../../components/TrustBatches';
import Newsletter from '../../../components/Newsletter';
export class NosieFitApp extends Component {
  render() {
    const { blocks, sectionSettings } = this.props.data.data;
    let sectionBlocks = blocks.map((singleBLock, index) => {
      return (
        <div key={index} className="single-block">
          <div className="head-part flex-view center">
            <h1 className="col-sm-6">{singleBLock.section_title}</h1>
            <div className="subheads col-sm-6">
              <p>{singleBLock.section_subtitle}</p>
              <h5>{singleBLock.section_description}</h5>
            </div>
          </div>
          <NoiseFitAppBlock blockData={singleBLock.data} />
        </div>
      );
    });
    return (
      <div id="noisfitapp-page">
        <div className="banner-section">
          <div className="banner">
            <div className="img">
              <MediaQuery query="tablet-and-up">
                <Srcset src={sectionSettings.banner_desktop} />
              </MediaQuery>
              <MediaQuery query="phone">
                <Srcset alt="img" src={sectionSettings.banner_xs} />
              </MediaQuery>
            </div>
						<div className='text-area'>
							<h1>{sectionSettings.banner_title}</h1>
							<h5>{sectionSettings.banner_subtitle}</h5>
							<div className='icons flex-view'>
								<div className='col-sm-6'>
									<UrlSet href={sectionSettings.appstore_link}>
										<Srcset src={pwa.icons.storeIcons.appStore} />
									</UrlSet>
								</div>
								<div className='col-sm-6'>
									<UrlSet href={sectionSettings.playstore_link}>
										<Srcset src={pwa.icons.storeIcons.playStore} />
									</UrlSet>
								</div>
							</div>
						</div>
          </div>
        </div>
        <div className="container">
          <div className="block-section">{sectionBlocks}</div>
          <Newsletter />
        </div>
      </div>
    );
  }
}

export default NosieFitApp;
