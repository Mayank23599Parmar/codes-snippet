import React, { Component } from 'react'
import Srcset from '../../../components/SrcSet'
import HtmlParser from "react-html-parser"
export class WarrantyGuide extends Component {

	render() {
		const { data } = this.props;
		const { settings, blocks } = data.data;
		let pera1 = settings.wgl_pera1.replace('<p>', '');
		pera1 = pera1.split('</p><p>');
		pera1[pera1.length - 1] = pera1[pera1.length - 1].replace('</p>', '');

		let peraData1 = pera1.map((ele, index) => {
			return <div key={index} className='flex-view-xs pera-line'><div className='color-dot-black'></div><p>{HtmlParser(ele)}</p></div>
		})

		let pera2 = settings.wgl_pera2.replace('<p>', '');
		pera2 = pera2.split('</p><p>');
		pera2[pera2.length - 1] = pera2[pera2.length - 1].replace('</p>', '');

		let peraData2 = pera2.map((ele, index) => {
			return <div key={index} className='flex-view-xs pera-line'><div className='color-dot-black'></div><p>{HtmlParser(ele)}</p></div>
		})

		let tableData = blocks.map((item, index) => {
			return <>
					<tr>
						<td className='font-weight-bold row-head first-cell' rowSpan='2'>{item.category}</td>
						<td className='second-cell'>{item.desc1}</td>
						<td className='third-cell'>{item.wp1}</td>
					</tr>
					{item.desc2 &&<tr>
						<td className='second-cell'>{item.desc2}</td>
						<td className='third-cell'>{item.wp2}</td>
					</tr>}
				</>
		});
		return (
			<div className='warranty-guideline'>
				<div className='container'>
					<div className='warranty-policy' >
						<h4 className='text-align-center font-weight-bold'>{settings.wgl_title}</h4>
						<p className='text-align-center'>{settings.wgl_description}</p>
						<div className='warranty-table'>
							<table>
								<tbody>
									<tr>
										<th className='first-cell'>Category</th>
										<th className='second-cell'>Description</th>
										<th className='third-cell'>Warranty Period</th>
									</tr>
									{tableData}
								</tbody>
							</table>
						</div>
					</div>
					<div className='warranty-guide'>
						<h3 className='text-align-center'><span className='image'><Srcset alt='guide-line-icon' src={pwa.icons.supportIcons.warrantyGuidelines} /></span>{settings.wgl_title2}</h3>
						<p className=''>{settings.wgl_description2}</p>
						<div className='subguide-lines'>
							<h4 className='font-bold font-weight-bold'>{settings.wgl_subtitle1}</h4>
							<div className='pera-data'>
								{peraData1}
							</div>
						</div>
						<div className='subguide-lines'>
							<h4 className='font-bold font-weight-bold'>{settings.wgl_subtitle2}</h4>
							<div className='pera-data'>
								{peraData2}
							</div>
						</div>
					</div>
				</div>
			</div>
		)
	}
}

export default WarrantyGuide
