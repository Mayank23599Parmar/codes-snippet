import React, { Component } from "react";
import MediaQuery from "../../../components/MediaQuery";
import Srcset from "../../../components/SrcSet";
import UrlSet from "../../../components/UrlSet";

export class Pro3PridePage extends Component {
  render() {
    const {
      sectionimage_desktop_1,
      sectionimage_mobile_1,
      sectionimage_desktop_2,
      sectionimage_mobile_2,
      sectionimage_desktop_3,
      sectionimage_mobile_3,
      product_variant_url
    } = this.props.data.data.settings;
    let proudctHandle;
    if(product_variant_url){
      proudctHandle = product_variant_url.replace('https://www.gonoise.com','');
    }
    else{
      proudctHandle = "/products/noise-colorfit-pro-3-full-touch-control-smart-watch?variant=32491074355287";
    }
    return (
      <div className="pro3-pride">
        <div>
          <MediaQuery query="phone-and-tablet">
            {sectionimage_desktop_1 && (
              <UrlSet href={`${proudctHandle}`}>
                <Srcset src={sectionimage_mobile_1} />
              </UrlSet>
            )}
          </MediaQuery>
          <MediaQuery query="lap-and-up">
            {sectionimage_mobile_1 && (
              <UrlSet href={`${proudctHandle}`}>
                <Srcset src={sectionimage_desktop_1} />
              </UrlSet>
            )}
          </MediaQuery>
        </div>
        <div>
          <MediaQuery query="phone-and-tablet">
            {sectionimage_desktop_2 && (
              <UrlSet href={`${proudctHandle}`}>
                <Srcset src={sectionimage_desktop_2} />
              </UrlSet>
            )}
          </MediaQuery>
          <MediaQuery query="lap-and-up">
            {sectionimage_mobile_2 && (
              <UrlSet href={`${proudctHandle}`}>
                <Srcset src={sectionimage_mobile_2} />
              </UrlSet>
            )}
          </MediaQuery>
        </div>
        <div>
          <MediaQuery query="phone-and-tablet">
            {sectionimage_mobile_3 && (
              <UrlSet href={`${proudctHandle}`}>
                <Srcset src={sectionimage_mobile_3} />
              </UrlSet>
            )}
          </MediaQuery>
          <MediaQuery query="lap-and-up">
            {sectionimage_desktop_3 && (
              <UrlSet href={`${proudctHandle}`}>
                <Srcset src={sectionimage_desktop_3} />
              </UrlSet>
            )}
          </MediaQuery>
        </div>
        <div>
          <MediaQuery query="phone-and-tablet">
            {sectionimage_desktop_2 && (
              <UrlSet href={`${proudctHandle}`}>
                <Srcset src={sectionimage_desktop_2} />
              </UrlSet>
            )}
          </MediaQuery>
          <MediaQuery query="lap-and-up">
            {sectionimage_mobile_2 && (
              <UrlSet href={`${proudctHandle}`}>
                <Srcset src={sectionimage_mobile_2} />
              </UrlSet>
            )}
          </MediaQuery>
        </div>
      </div>
    );
  }
}

export default Pro3PridePage;
