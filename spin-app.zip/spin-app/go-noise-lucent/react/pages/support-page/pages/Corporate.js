import React, { Component } from "react";
import ReactModal from "react-modal";

import Srcset from "../../../components/SrcSet";
import CorporateImageWithText from "./CorporateImageWithText";
import CorporateInfoPart from "./CorporateInfoPart";
import CortporatePopup from './CortporatePopup';
ReactModal.setAppElement("#my-react");
export class Corporate extends Component {
  constructor(props) {
    super(props);

    this.customStyles = {
      overlay:{
        backgroundColor:'rgba(0, 0, 0,0.5)',
      },
      content: {
        top: "50%",
        left: "50%",
        right: "auto",
        bottom: "auto",
        marginRight: "-50%",
        transform: "translate(-50%, -50%)",
        maxWidth:"450px",
        width:"95%"
      },
    };

    this.state = {
      showModal: false,
      emailenq:'',
      mobilenoenq:''
    };

  }

  handleOpenModal = () => {
    this.setState({ showModal: true });
  }

  handleCloseModal = () => {
    this.setState({ showModal: false, emailenq: '', mobilenoenq: '' });
  }

  render() {
    const { data } = this.props;
    const {
      head_about,
      image_main,
      page_head,
      sec2_desc1,
      sec2_desc2,
      sec2_desc3,
      sec2_desc4,
      sec2_head1,
      sec2_head2,
      sec2_head3,
      sec2_head4,
      sec3_desc1,
      sec3_desc2,
      sec3_head1,
      sec3_head2,
      sec3_image1,
      sec3_image2,
    } = data.data.settings;
    return (
      <div className="corporate-page">
        <div className="container">
          <div className="corporate-container">
            <div className="head-wrapper">
              <h2 className="text-align-center">{page_head}</h2>
              <div className="image">
                <Srcset src={image_main} />
              </div>
              <p>{head_about}</p>
              <div className="button">
                <button className='btn ' onClick={this.handleOpenModal}>Enquire Now</button>
              </div>
              <ReactModal
                isOpen={this.state.showModal}
                contentLabel="onRequestClose Example"
                onRequestClose={this.handleCloseModal}
                shouldCloseOnOverlayClick={true}
                style={this.customStyles}
              >
                <CortporatePopup closePopup={this.handleCloseModal} />
              </ReactModal>
            </div>
          </div>
        </div>
        <CorporateInfoPart
          sec2_head1={sec2_head1}
          sec2_desc1={sec2_desc1}
          sec2_head2={sec2_head2}
          sec2_desc2={sec2_desc2}
          sec2_head3={sec2_head3}
          sec2_desc3={sec2_desc3}
          sec2_head4={sec2_head4}
          sec2_desc4={sec2_desc4}
        />
        <CorporateImageWithText
          sec3_image1={sec3_image1}
          sec3_head1={sec3_head1}
          sec3_desc1={sec3_desc1}
          sec3_image2={sec3_image2}
          sec3_head2={sec3_head2}
          sec3_desc2={sec3_desc2}
        />
      </div>
    );
  }
}

export default Corporate;
