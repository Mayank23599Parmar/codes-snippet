import React, { Component } from "react";
import Srcset from "../../../components/SrcSet";

export class CorporateInfoPart extends Component {
  render() {
		const {
			sec2_head1,
			sec2_desc1,
			sec2_head2,
			sec2_desc2,
			sec2_head3,
			sec2_desc3,
			sec2_head4,
			sec2_desc4,
		} = this.props;
    return (
      <div className="info-part">
        <div className="corporate-container">
          <div className="flex-view">
            <div className="line">
              <div className="col-sm-6">
                <div className="component">
                  <div className="icon-image">
                    <Srcset src={pwa.icons.supportIcons.competitvePricing} />
                  </div>
                  <h5 className="font-weight-bold">{sec2_head1}</h5>
                  <p>{sec2_desc1}</p>
                </div>
              </div>
              <div className="col-sm-6">
                <div className="component">
                  <div className="icon-image">
                    <Srcset src={pwa.icons.supportIcons.greatNoiseQuality} />
                  </div>
                  <h5 className="font-weight-bold">{sec2_head2}</h5>
                  <p>{sec2_desc2}</p>
                </div>
              </div>
            </div>
            <div className="line">
              <div className="col-sm-6">
                <div>
                  <div className="icon-image">
                    <Srcset src={pwa.icons.supportIcons.priorityShipment} />
                  </div>
                  <h5 className="font-weight-bold">{sec2_head3}</h5>
                  <p>{sec2_desc3}</p>
                </div>
              </div>
              <div className="col-sm-6">
                <div>
                  <div className="icon-image">
                    <Srcset src={pwa.icons.supportIcons.wideRangeProduct} />
                  </div>
                  <h5 className="font-weight-bold">{sec2_head4}</h5>
                  <p>{sec2_desc4}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CorporateInfoPart;
