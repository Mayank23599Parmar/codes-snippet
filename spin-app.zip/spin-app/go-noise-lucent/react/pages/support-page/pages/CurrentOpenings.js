import React, { Component } from "react";
// import Icons from "../../../components/Icons";
import UrlSet from "../../../components/UrlSet";
class CurrentOpenings extends Component {
  state = {
    currentPage: 1,
  };

  handlePagination = (event) => {
    this.setState({
      currentPage: Number(event.target.id),
    });
  };

  handlePrevious = () => {
    if (this.state.currentPage !== 0) {
      this.setState((prevState) => ({
        currentPage: prevState.currentPage - 1,
      }));
    }
  };

  handleNext = () => {
    this.setState((prevState) => ({
      currentPage: prevState.currentPage + 1,
    }));
  };

  render() {
    const { data } = this.props;
    if (cn(data.data)) {
      return null;
    }
    const { blocks } = data.data;

    const jobOpeningsArray = blocks.filter(
      (block) => block.type === "job_openings"
    );
    /* Pagination */

    /* Slicing array based on the pagination */
    const indexOfLastCurrentOpening = this.state.currentPage * 4;
    const indexOfFirstCurrentOpening = indexOfLastCurrentOpening - 4;
    const paginatedCurrentOpeningsArray = jobOpeningsArray.slice(
      indexOfFirstCurrentOpening,
      indexOfLastCurrentOpening
    );

    /* Render openings based on pagination */
    const renderCurrentOpenings = paginatedCurrentOpeningsArray.map(
      (currentOpening, index) => (
        <div className="col-sm-6 col-xs-12 current-openings-block" key={index}>
          <div className="block-wrapper">
            <h5 className="text-center">
              {currentOpening.data.job_opening_title}
            </h5>
            <div>
              <div className="location-wrapper col-sm-6 col-xs-6">
                <span>Location</span>
                <p>{currentOpening.data.job_opening_location}</p>
              </div>
              <div className="work-type-wrapper col-sm-6 col-xs-6 text-right">
                <span>Work type</span>
                <p>{currentOpening.data.work_type}</p>
              </div>
            </div>
            <UrlSet href={currentOpening.data.job_opening_link}>
              <div className="btn">Apply Now</div>
            </UrlSet>
          </div>
        </div>
      )
    );

    /* Render Pagination */
    const paginateNumbers = [];
    for (let i = 1; i <= Math.ceil(jobOpeningsArray.length / 4); i++) {
      paginateNumbers.push(i);
    }
    const renderPaginateNumbers = paginateNumbers.map((number, index) => {
      if (number === this.state.currentPage) {
        return (
          <span
            key={index}
            className="paginate-number selected-page"
            id={number}
            onClick={this.handlePagination}
          >
            {number}
          </span>
        );
      } else
        return (
          <span
            key={index}
            className="paginate-number"
            id={number}
            onClick={this.handlePagination}
          >
            {number}
          </span>
        );
    });

    return (
      <div className="current-openings">
        <div className="container">
          <div className="current-openings-container">
            <h1 className="text-center">Current Openings</h1>
            <div className="filter-container flex-view hide">
              <div className="col-sm-9">
                <input />
              </div>
              <div className="col-sm-3">
                <p>Current Openings:</p>
              </div>
            </div>
            <div className="flex-view-xs current-openings-content">
              {renderCurrentOpenings}
            </div>
            <div className="current-openings-pagination text-center">
              <div className="arrow-container">
                <span className="arrow left"></span>
              </div>
              <span
                className="paginate-previous"
                onClick={() => {
                  this.state.currentPage > 1 && this.handlePrevious();
                }}
              >
                Previous
              </span>
              {renderPaginateNumbers}
              <span
                className="paginate-next"
                onClick={() => {
                  this.state.currentPage <
                    Math.ceil(jobOpeningsArray.length / 4) && this.handleNext();
                }}
              >
                Next
              </span>
              <div className="arrow-container">
                <span className="arrow right"></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CurrentOpenings;
