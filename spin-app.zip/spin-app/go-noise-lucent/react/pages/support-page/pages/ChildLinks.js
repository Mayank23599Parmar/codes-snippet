import React, { Component } from 'react'
import UrlSet from "../../../components/UrlSet";

export class ChildLinks extends Component {
	render() {
		const { links } = this.props;
		let mainComp = links.map((ele,index)=>{
			return <div key={index} className='col-sm-4'>
				<p className='font-weight-bold link-head' >{ele.childtitle}</p>
				{
					ele.subchildlinks.map((element,ind)=>{
						return <div key={ind}>
							<UrlSet href={element.subchildlink}>
								<p>{element.subchildtitle}</p>
							</UrlSet>
						</div>
					})
				}
			</div>
		}) 
		return (
			<div className='flex-view'>
				{mainComp}
			</div>
		)
	}
}

export default ChildLinks
