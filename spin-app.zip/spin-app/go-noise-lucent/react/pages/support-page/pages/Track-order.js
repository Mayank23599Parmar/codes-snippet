import React, { Component } from 'react';
import Srcset from '../../../components/SrcSet'

class TrackPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      waybill: '',
      order_id: '',
      error: false,
      errorText: '',
    };
  }

  render() {
    const checkOrderTrack = () => {
      if (cn(this.state.waybill) && cn(this.state.order_id)) {
        this.setState(prevState => ({
          ...prevState,
          error: true,
          errorText: 'Please enter either Order ID or Tracking ID to proceed!',
        }));
        return false;
      }

      if (this.state.order_id && !cn(this.state.order_id)) {
        window.location.href =
          'https://gonoise.clickpost.in/?order_id=' + this.state.order_id;
      }
      if (this.state.waybill && !cn(this.state.waybill)) {
        window.location.href =
          'https://gonoise.clickpost.in/?waybill=' + this.state.waybill;
      }
    };

    return (
      <div className='track-page'>
        <div className='container'>
          <h4 className='text-center font-weight-bold'><span className='image'><Srcset src={pwa.icons.supportIcons.trackOrder} /></span>Track Your Order</h4>
          <p className='subtitle text-center'>
            Please feed in either your Order ID or Tracking ID to know your order
            status.
     </p>
          <div className='flex-view-xs'>
            <div className='col-md-5 col-xs-12'>
              <input
                type='text'
                placeholder='Enter Tracking ID'
                name='waybill'
                value={this.state.waybill}
                onChange={e => {
                  let id = e.target.value;
                  this.setState(prevState => ({
                    ...prevState,
                    waybill: id,
                    error: false,
                    errorText: '',
                  }));
                }}
              />
            </div>
            <div className='col-md-2 col-xs-12'>
              <p className='text-center OR'>OR</p>
            </div>
            <div className='col-md-5 col-xs-12'>
              <input
                type='text'
                placeholder='Enter Order ID'
                name='order_id'
                value={this.state.order_id}
                onChange={e => {
                  let id = e.target.value;
                  this.setState(prevState => ({
                    ...prevState,
                    order_id: id,
                    error: false,
                    errorText: '',
                  }));
                }}
              />
            </div>
            <div className='text-center track-area'>
              {this.state.error && (
                <p className='text-danger'>{this.state.errorText}</p>
              )}
              <button
                className='track-btn'
                onClick={() => {
                  checkOrderTrack();
                }}>
                Track Order
       </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default TrackPage;
