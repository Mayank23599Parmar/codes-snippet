import React from "react";
import ReactSelectSearch from "react-select-search";
import { connect } from "react-redux";
import {
  sendOTP,
  setLoading,
  submitRegisterWarranty,
  fetchWarrantyProducts,
} from "../../../redux/support/supportAction";
import OtpModal from "../modals/OtpModal";
import Srcset from "../../../components/SrcSet";
import { emailValidate } from "../../../components/Helper";
import {RegisterEvent} from "../../../clever-tap-events/WarrantyEvent"

class WarrantyRegister extends React.Component {
  state = {
    name: "",
    nameError: "",
    email: "",
    emailError: "",
    phoneNumber: "",
    phoneNumberError: "",
    distributor: "",
    distributorError: "",
    product: {},
    productError: "",
    orderNumber: "",
    orderNumberError: "",
    serialNumber: "",
    serialNumberError: "",
    showBtnLoading: false,
    hasErrors: false,
    registeredSuccesfully: false,
    registerError: false
  };

  constructor(props) {
    super(props);
    this.handlePhoneNumber = this.handlePhoneNumber.bind(this);
  }

  componentDidMount() {
    this.props.fetchWarrantyProducts(this.props.data.data.warrantyDataFile);
  }

  handlePhoneNumber(phoneNumber) {
    this.setState((prevState) => ({
      ...prevState,
      phoneNumber,
    }));
  }

  handleRegister = (e) => {
    e.preventDefault();
    const { submitRegisterWarranty } = this.props;
    const { product, name, email, phoneNumber, distributor, orderNumber, serialNumber, } = this.state;
    // error variables
    let productError = "",nameError = "", emailError="",phoneNumberError="",distributorError="",orderNumberError="",serialNumberError="";
    if(cn(product.product_id)){
      productError = 'Please select Product!'
    }
    if(cn(name)){
      nameError = 'Please enter full name'
    }
    if(cn(email)){
      emailError = "Please enter email address!"
    }else{
      if(!emailValidate(email)){
        emailError = "Please enter valid email address!"
      }
    }
    // if(cn(phoneNumber)){
    //   phoneNumberError = "Please enter mobile number!"
    // }else{
    //   if(phoneNumber.length !== 10){
    //     phoneNumberError = "Please enter valid mobile number!"
    //   }
    // }
    let phoneError = false;
    let first_char = this.state.phoneNumber.charAt(0); 
    let msg = '';
    let phoneFormatMatch = false;
    if(first_char == "6" || first_char == "7" || first_char == "8" || first_char == "9"){
      phoneFormatMatch = true;
    }
    if(!phoneFormatMatch){

      phoneError = true;
      msg = 'Please enter correct phone number starting from 6/7/8/9';
    }
    if(cn(this.state.phoneNumber) || this.state.phoneNumber.length !== 10){
 
      phoneError = true;
      msg = 'Please enter your 10 digit phone number to proceed!';
    }
    if (phoneError) {
      phoneNumberError=msg
    }
    if(cn(distributor)){
      distributorError = "Please select distributor!"
    }
    if(cn(orderNumber)){
      orderNumberError = "Please enter order number!"
    }
    if(cn(serialNumber)){
      serialNumberError = "Please enter serial number!"
    }
    if (nameError !== '' || emailError !== '' || phoneNumberError !== '' || distributorError !== '' || productError !== '' || orderNumberError !== '' || serialNumberError !== ''){
      this.setState({nameError,emailError,phoneNumberError,distributorError,productError,orderNumberError,serialNumberError, registeredSuccesfully:false})
    } else{
       this.sendOTP(e.target.value);
      //this.registerWarranty();
    } 
  };
  handleOTPClosePopup = () =>{
    this.setState({
      registeredSuccesfully:false,
      name:'',email:'',distributor:'',product:{},orderNumber:'',serialNumber:'',phoneNumber:''
    })
  }
  registerWarranty = () =>{
    const { product, name, email, phoneNumber, distributor, orderNumber, serialNumber, } = this.state;
    let currentdate = new Date();
    let formdatapas = {
      "name":  name.trim(),
      "email":  email.trim(),
      "mobile_no":  phoneNumber,
      "registration_time":  currentdate,
      "unique_id":  product.product_id,
      "source":  "web",
      "platform":  distributor,
      "order_number":  orderNumber.trim(),
      "serial_number":  serialNumber.trim(),
    }
    let eventObj = {
      "name":  name.trim(),
      "email":  email.trim(),
      "phone":  phoneNumber,
      "title":  product.product_name,
      "supplier":  distributor,
      "orderId":  orderNumber.trim(),
      "sno":  serialNumber.trim(),
    }
    this.setState({ showBtnLoading: true }, () => {
        this.props.submitRegisterWarranty({
          datapass: formdatapas,
          callBackFunction: () => {
            RegisterEvent(eventObj)
            this.setState({ showBtnLoading: false, registeredSuccesfully: true,
              name: "",
              email:"",
              phoneNumber:"",
              distributor:"",
              product: {},
              orderNumber:"",
              serialNumber:""
            });
          },
          errorCallback :() =>{
            this.setState({ registerError: true })
          }
        });
      });
  }
  sendOTP = () => {
    let {phoneNumber} = this.state;
    this.props.sendOTPAction(phoneNumber);
  };
  
  handleProductSelect = (prod, actual_title) => {
    let productJson = { ...prod };
    productJson.actual_title = actual_title;
    this.setState({
      product: productJson,
    });
  };
  handleSelectChange = (e, data) => {
    this.setState({ product: data.productJson,productError: '', registeredSuccesfully:false });
  };

  digitValidate=(e)=>
  {
    var arr = [];
    var kk = e.which;
 
    for (let i = 48; i < 58; i++)
        arr.push(i);
 
    if (!(arr.indexOf(kk)>=0))
        e.preventDefault();
  }
  phoneNumberHandler=(e)=>{
    this.setState({phoneNumberError:""});
    let temp = e.target.value;
    let withoutSpaces = temp.substring(0, 10);
    let withoutSpaces1 = withoutSpaces.replace(/\s+/g, "");
    let withoutSpaces2 = withoutSpaces1.replace(/[^0-9]/g, "");
      this.setState((prevState) => ({
        ...prevState,
        registeredSuccesfully: false,
        phoneNumber: withoutSpaces2,
      
      }));
    
  }

  render() {
    const {
      warrantyRegisterData,
      sendOTPAction,
      setLoading,
      openOtpModal,
      list,
      warrantyProducts,
    } = this.props;
    const { product, registeredSuccesfully, registerError, showBtnLoading } = this.state;
    const { settings, collectionData } = warrantyRegisterData;
    let distributorsShow = settings.distributors.split(", ");
    let options = [];
    if (warrantyProducts) {
      Object.values(warrantyProducts).forEach((group, index) => {
        let items = [];
        Object.values(warrantyProducts[index]).forEach((products, ind) => {
          products.forEach((prod) => {
            items.push({
              name: prod.product_name,
              value: prod.product_name,
              productJson: prod,
            });
          });
        });
        options.push({
          type: "group",
          name: Object.keys(group)[0],
          items: items,
        });
      });
     
    }
 
    return (
      <div className="warranty-register-page">
        <div className="container">
          {openOtpModal && (
            <OtpModal registeredSuccesfully={this.state.registeredSuccesfully} handleOTPClosePopup={this.handleOTPClosePopup} registerWarranty={this.registerWarranty} showBtnLoading={showBtnLoading} sendOTP={this.sendOTP} handlePhoneNumber={this.handlePhoneNumber} />
          )}
          <div className="warranty_register_section">
            <h4 className="wr-title font-weight-bold">
              <span className="image">
                <Srcset src={pwa.icons.supportIcons.warrantyRegistration} />
              </span>
              {settings.wr_title}
            </h4>
            <h5 className="wr-subtitle">{settings.wr_subtitle}</h5>
            <div className="wr-form">
              <form
                method="POST"
                onSubmit={(e) => {
                  this.handleRegister(e);
                }}
              >
                <div>
                  <div className="col-sm-12  item-wrapper">
                    <label>Full Name</label>
                    <input
                      placeholder="First name"
                      className="bg-color"
                      name="name"
                      value={this.state.name}
                      onChange={(e) => {
                        let temp = e.target.value;
                        this.setState((prevState) => ({
                          ...prevState,
                          registeredSuccesfully:false,
                          name: temp,
                          nameError: ""
                        }));
                        
                      }}
                    />
                    {this.state.nameError && (
                      <p className="error">{this.state.nameError }</p>
                    )}
                  </div>
                </div>
                <div>
                  <div className="col-sm-6 item-wrapper">
                    <label>E-mail address</label>
                    <input
                      placeholder="Enter e-mail"
                      className="bg-color"
                      value={this.state.email}
                      name="email"
                      onChange={(e) => {
                        let temp = e.target.value;
                        this.setState((prevState) => ({
                          ...prevState,
                          registeredSuccesfully:false,
                          email: temp,
                          emailError: "",
                        }));
                      }}
                    />
                    {this.state.emailError && (
                      <p className="error">{this.state.emailError}</p>
                    )}
                  </div>
                  <div className="col-sm-6 item-wrapper">
                    <label>Mobile number</label>
                    <input
                      className="bg-color"
                      value={this.state.phoneNumber}
                      type="text"
                      placeholder="+91   |"
                      maxLength="10"
                      onKeyPress={(e)=>this.digitValidate(e)}
                      onPaste={(e) => this.phoneNumberHandler(e)}
                      onChange={(e) => this.phoneNumberHandler(e)}
                    />
                    {this.state.phoneNumberError && (
                      <p className="error">{this.state.phoneNumberError}</p>
                    )}
                  </div>
                </div>
                <div>
                  <div className="col-sm-6 item-wrapper ">
                    <label>Where did you Buy from</label>
                    <select
                      className="bg-color"
                      value={this.state.distributor}
                      name="source"
                      onChange={(e) => {
                        let temp = e.target.value;
                        this.setState((prevState) => ({
                          ...prevState,
                          registeredSuccesfully:false,
                          distributor: temp,
                          distributorError: "",
                        }));
                      }}
                    >
                      <option disabled defaultValue hidden value="">
                        Select a distributor
                      </option>
                      {distributorsShow.map((distributor, key) => {
                        return <option key={key}>{distributor}</option>;
                      })}
                    </select>
                    {this.state.distributorError && (
                      <p className="error">{this.state.distributorError}</p>
                    )}
                  </div>
                  <div className="col-sm-6 item-wrapper ">
                    <div className="product-select">
                      <div className="product-select-label">
                        <label>Select Your Product</label>
                      </div>
                      <ReactSelectSearch
                        search={true}
                        onChange={(e, data) => {
                          this.handleSelectChange(e, data);
                        }}
                        value={product.product_name ? product.product_name : ""}
                        options={options}
                        placeholder="Search for a product"
                        autoComplete="new-password"
                      />
                    </div>
                    {this.state.productError && (
                      <p className="error">{this.state.productError}</p>
                    )}
                  </div>
                </div>
                <div>
                  <div className="col-sm-6 item-wrapper ">
                    <label>Order Number</label>
                    <input
                      placeholder="Enter your Order Number"
                      className="bg-color"
                      value={this.state.orderNumber}
                      name="order_number"
                      type="text"
                      maxLength="20"
                      onChange={(e) => {
                        let temp = e.target.value;
                        this.setState((prevState) => ({
                          ...prevState,
                          registeredSuccesfully:false,
                          orderNumber: temp,
                          orderNumberError: "",
                        }));
                      }}
                    />
                    {this.state.orderNumberError && (
                      <p className="error">{this.state.orderNumberError}</p>
                    )}
                  </div>
                  <div className="col-sm-6 item-wrapper ">
                    <label>Serial Number</label>
                    <input
                      placeholder="Enter your Serial Number"
                      className="bg-color"
                      type="text"
                      value={this.state.serialNumber}
                      name="serial_number"
                      maxLength="20"
                      onChange={(e) => {
                        let temp = e.target.value;
                        this.setState((prevState) => ({
                          ...prevState,
                          registeredSuccesfully:false,
                          serialNumber: temp,
                          serialNumberError: ""
                        }));
                      }}
                    />
                    {this.state.serialNumberError && (
                      <p className="error">{this.state.serialNumberError}</p>
                    )}
                  </div>
                </div>
                <div>
                  <div className="col-sm-12 text-center wr-register ">
                    <button
                      className="register-btn btn">
                      Register Now
                    </button>
                    {
                      registeredSuccesfully ? <div>
                          <div className='success'>Registered Successfully</div>
                        </div> : ''
                    }
                    {
                      registerError ? <div>
                          <div className='error' >Something went wrong</div>
                        </div> : ''
                    }
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  setLoading: (data) => dispatch(setLoading(data)),
  sendOTPAction: (data) => dispatch(sendOTP(data)),
  submitRegisterWarranty: (data) => dispatch(submitRegisterWarranty(data)),
  fetchWarrantyProducts: (data) => dispatch(fetchWarrantyProducts(data)),
});

const mapStateToProps = (state) => ({
  warrantyRegisterData: state.support.supportData.warrantyRegister.data,
  openOtpModal: state.support.supportData.warrantyRegister.openOtpModal,
  warrantyProducts: state.support.warrantyProducts,
});

export default connect(mapStateToProps, mapDispatchToProps)(WarrantyRegister);
