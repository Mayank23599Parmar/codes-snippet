import React, { Component } from 'react'
import Srcset from '../../../components/SrcSet'


export class Troubleshoot extends Component {
  constructor(props) {
    super(props)
  
    this.state = {
      show1: false,
      show2: false
    }
  }
  
  render() {
    const { data } = this.props;
    const { show1, show2} = this.state;
    let collection1ProductList = data.data.collection1Products.map((product, index) => {
      return <div className='others-option' key={index}> <h5 value={product} >{product}</h5> </div>
    })

    let collection2ProductList = data.data.collection2Products.map((product, index) => {
      return <div className='others-option' key={index}> <h5 value={product} >{product}</h5> </div>
    })

    return (
      <div className='troubleshoot-page'>
        <div className='container'>
          <div className='trouble-shoot-container'>
            <div className='head-top'>
              <h4 className='text-align-center font-weight-bold'>
                <span className='image'><Srcset src={pwa.icons.supportIcons.troubleShooting} /></span>
                Troubleshoot your Products
              </h4>
            </div>
            <div className='products-section flex-view space-between'>
              <div className='col-sm-6 content-area'>
                <div className='image-part'>
                  <div className='image'>
                    <Srcset src={data.data.collection1Image} />
                  </div>
                </div>
                <h4 className='text-align-center font-weight-bold'>{data.data.collecion1}</h4>
                <div className='product-select'>
                  <div>
                    <div className='default-selected' onClick={()=>{this.setState({show1:!this.state.show1})}} ><h4> Select Model <span className='arrow down'></span> </h4></div>
                    {show1 &&  <div className='option-elments'>
                      {collection1ProductList}
                    </div>}
                  </div>
                </div>
              </div>
              <div className='col-sm-6 content-area'>
                <div className='image-part'>
                  <div className='image'>
                    <Srcset src={data.data.collection2Image} />
                  </div>
                </div>
                <h4 className='text-align-center font-weight-bold'>{data.data.collecion2}</h4>
                <div className='product-select'>
                  <div className='default-selected' onClick={()=>{this.setState({show2:!this.state.show2})}} ><h4> Select Model <span className='arrow down'></span> </h4></div>
                  {show2 && <div className='option-elments'>
                    {collection2ProductList}
                  </div>}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default Troubleshoot;
