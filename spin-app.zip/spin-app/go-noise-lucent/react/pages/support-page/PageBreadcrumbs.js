import React, { Component } from "react";
import UrlSet from '../../components/UrlSet';
export class PageBreadcrumbs extends Component {
  constructor(props) {
    super(props)
    this.pagesName={
      'noise-exclusive-offers':'Exclusive Offers',
      'e-waste-management':'E-waste Management',
      'site-map':'Site Map',
      'stories': 'Stories',
      'compare' : 'Compare Specifications'
    }
  }
  
  render() {
    const { currentTab } = this.props
    return (
      <div className='normal-support-head'>
        <div className='container'>
          <div className='normal-support-head-container'>
            <UrlSet href='/'>
              Home
            </UrlSet>
            <span>
              <span className='arrow down'></span> 
              <span>{this.pagesName[currentTab]}</span>
            </span>
          </div>
        </div>
      </div>
    );
  }
}

export default PageBreadcrumbs;
