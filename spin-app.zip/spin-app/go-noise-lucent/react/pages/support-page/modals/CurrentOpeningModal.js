import React, { Component } from 'react';
import Icons from '../../../components/Icons';
import ReactHtmlParser from 'react-html-parser';

class CurrentOpeningModal extends Component {
 render() {
  return (
   <div className='current-opening-modal'>
    <div className='modal-body'>
     <div className='modal-header'>
      <h3 className='title'>Current Opening</h3>
      <div
       className='close-modal'
       onClick={() => this.props.handleCurrentOpeningModal(false)}>
       <Icons icon='close' />
      </div>
     </div>
     <div className='modal-content'>{ReactHtmlParser(this.props.data)}</div>
    </div>
   </div>
  );
 }
}

export default CurrentOpeningModal;
