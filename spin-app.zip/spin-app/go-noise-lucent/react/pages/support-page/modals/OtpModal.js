import React, { useState, useEffect } from 'react';
import Icons from '../../../components/Icons';
import { connect } from 'react-redux';
import { closeOtpModal, varifyOtp } from '../../../redux/support/supportAction';

const OtpModal = (props) => {
    const [enteredOtp, setEnteredOtp] = useState('');
    const [error, setError] = useState('')
    const [seconds, setSeconds] = useState(60)

    useEffect(() => {
        if (seconds >= 0) {
           const time = setTimeout(() => setSeconds(seconds - 1), 1000);
            return () => clearTimeout(time);
        }
    }, [seconds])
    const { phoneNumber, closeOtpModal, registeredSuccesfully ,registerWarranty} = props;


    //handle verification
    const handleVerify = () => {
        if (cn(enteredOtp)) {
            setError('Please enter OTP!')
   
        } else {
            let datapass = {
                phone: phoneNumber, otp: enteredOtp
            }
            props.varifyOtp({
                data: datapass, matchotpcallback: () => {
                    registerWarranty();
                }, errorotpcallback: () => {
                    setError('OTP not matched!')
                }
            })
        }
    };

    // close event
    const handleClose = () => {
        //close modal
        closeOtpModal(false);
        if (registeredSuccesfully) {
            props.handleOTPClosePopup();
        }
    };
    const sendOpt = () => {
        setSeconds(60);
        props.sendOTP()
    }
   
    return (
        <div className='otp-modal'>
            <div className='modal-body'>
                <div className='modal-header'>
                    <h3 className='title'>Please Verify Your Mobile Number !</h3>
                    <div
                        className='close-modal'
                        onClick={() => {
                            handleClose();
                        }}>
                        <Icons icon='close' />
                    </div>
                </div>
                <div className='modal-content'>
                    <p>We have sent an OTP on your registered mobile number {phoneNumber} <span className="change-phone" onClick={() => handleClose()}>Edit number</span></p>
                    <input
                        type='text'
                        placeholder='Enter OTP'
                        onChange={e => {
                            let temp = e.target.value;
                            setError('')
                            setEnteredOtp(temp,)
                        }}
                        value={enteredOtp}
                    />
                    {registeredSuccesfully ?
                        <div className="registered-successfully-text">You have successfully registered <span onClick={() => handleClose()}>Close</span></div>
                        :
                        <div className="btn-wrapper">
                            {
                                seconds >= 0 ? <span>Resend OTP in {seconds}s</span> : <button className='text-center rended-otp-button btn' onClick={() => sendOpt()}>
                                    Resend OTP
                                </button>
                            }

                            <button className={`text-center verify-button btn${props.showBtnLoading ? " loading" : ""}`}
                                onClick={() =>handleVerify() }>
                                Verify OTP
                            </button>
                        </div>}
                    {error && <p className='error'>{error}</p>}
                </div>
            </div>
        </div>
    );

}

const mapStateToProps = state => ({
    otp: state.support.supportData.warrantyRegister.otp,
    phoneNumber: state.support.supportData.warrantyRegister.phoneNumber,
});

const mapDispatchToProps = dispatch => ({
    closeOtpModal: data => dispatch(closeOtpModal(data)),
    varifyOtp: data => dispatch(varifyOtp(data))
});

export default connect(mapStateToProps, mapDispatchToProps)(OtpModal);
