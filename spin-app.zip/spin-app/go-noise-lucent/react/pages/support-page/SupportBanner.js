import React from 'react';
import { connect } from 'react-redux';
import Srcset from '../../components/SrcSet';
import MediaQuery from '../../components/MediaQuery';

const SupportHeader = props => {
 const { bannerData } = props;

 if (JSON.stringify(bannerData) === '{}') {
  return <div></div>;
 }
 return (
  <div className='support-banner'>
   <MediaQuery query='lap-and-up'>
    <Srcset alt='img' src={bannerData.data.settings.image} />
   </MediaQuery>
   <MediaQuery query='phone-and-tablet'>
    <Srcset alt='img' src={bannerData.data.settings.image_mob} />
   </MediaQuery>
   <div className='banner-text'>
    <div className='container'>
     <div className='text-wrapper'>
      <h2>{bannerData.data.settings.title}</h2>
      <h5>{bannerData.data.settings.subtitle}</h5>
     </div>
    </div>
   </div>
  </div>
 );
};

const mapStateToProps = state => ({
 bannerData: state.support.supportData.banner,
});

export default connect(mapStateToProps)(SupportHeader);
