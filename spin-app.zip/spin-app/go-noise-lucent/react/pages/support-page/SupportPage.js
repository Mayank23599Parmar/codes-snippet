import React from "react";
import { connect } from "react-redux";
import {
  setSupportPageData,
  setCurrentTab,
  fetchWarrantyProducts,
} from "../../redux/support/supportAction";
import SupportBanner from "./SupportBanner";
import SupportTabs from "./SupportTabs";
import PageBreadcrumbs from "./PageBreadcrumbs";
import Loader from "../../components/loader/loader";
import {getHeaderHeight} from '../../components/Helper';
/* subpages */
import Faq from "./pages/Faq";
import WarrantyGuide from "./pages/WarrantyGuide";
import Troubleshoot from "./pages/Troubleshoot";
import ContactUs from "./pages/ContactUs";
import WarrantyRegister from "./pages/WarrantyRegister";
import ShippingDetails from "./pages/ShippingDetails";
import TermsAndConditions from "./pages/TermsAndConditions";
import TrackOrder from "./pages/Track-order";
import RegisterComplaint from "./pages/RegisterComplaint";
import NoiseExclusiveOffers from "./pages/NoiseExclusiveOffers";
import EWasteManagment from "./pages/EWasteMgt";
import SiteMap from "./pages/SiteMap";
import AboutUs from "./pages/AboutUs";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import Corporate from "./pages/Corporate";
import InThePress from "./pages/InThePress";
import Careers from "./pages/Careers";
import CurrentOpenings from "./pages/CurrentOpenings";
import BecomeAffiliate from "./pages/BecomeAffiliate";
import Stories from "./pages/Stories";
import NosieFitApp from "./pages/NosieFitApp";
import Compare from "./pages/Compare";
import Pro3PridePage from "./pages/Pro3PridePage";
// import HtmlParser from "react-html-parser";
import ErrorPage from '../errorpage/ErrorPage';
import DefaultPage from '../support-page/pages/DefaultPage';
import CampusNoisemaker from '../support-page/pages/CampusNoisemaker';
import Questforthebest from '../support-page/pages/Questforthebest';
import Downloadinvoice from '../support-page/pages/Downloadinvoice';
import AnniversarySale from '../support-page/pages/AnniversarySale';
class SupportPage extends React.Component {
  constructor(props) {
    super(props);
    this.normalPages = [
      "noise-exclusive-offers",
      "e-waste-management",
      "site-map",
      "stories",
      "compare",
    ];
    this.tabPages = [
      "warranty-register",
      "contact-us",
      "register-complaint",
      "track-order",
      "shipping-details",
      "faq",
      "warranty-guide",
      "terms-and-condition",
      "troubleshoot",
    ];
    this.supportMainDiv = React.createRef() 
  }

  //Tab switching
  renderTabSwitch = (param) => {
    const { supportPageData } = this.props;
    switch (param) {
      case "faq":
        return <Faq />;
      case "warranty-guide":
        return <WarrantyGuide data={supportPageData.warrantyJson} />;
      case "troubleshoot":
        return <Troubleshoot data={supportPageData.troubleshootJson.data} />;
      case "contact-us":
        return <ContactUs data={supportPageData.contactUsJson} />;
      case "warranty-register":
        return <WarrantyRegister data={supportPageData.warrantyRegister} />;
      case "shipping-details":
        return <ShippingDetails data={supportPageData.shippingDetailsJson} />;
      case "terms-and-condition":
        return <TermsAndConditions data={supportPageData.termsConditionJson} />;
      case "track-order":
        return <TrackOrder />;
      case "register-complaint":
        return <RegisterComplaint />;
      case "noise-exclusive-offers":
        return (
          <NoiseExclusiveOffers data={supportPageData.exclusiveOffersJson} />
        );
      case "e-waste-management":
        return <EWasteManagment data={supportPageData.eWasteJson} />;
      case "site-map":
        return <SiteMap data={supportPageData.siteMapJson} />;
      case "about-us":
        return <AboutUs data={supportPageData.aboutUsJson} />;
      case "privacy-policy":
        return <PrivacyPolicy data={supportPageData.privacyPolicyJson} />;
      case "corporate-enquiry":
        return <Corporate data={supportPageData.corporateEnquiryJson} />;
      case "in-the-press":
        return <InThePress data={supportPageData.inThePressJson} />;
      case "career":
        return <Careers data={supportPageData.careerJson} />;
      case "current-openings":
        return <CurrentOpenings data={supportPageData.careerJson} />;
      case "become-an-affiliate":
        return <BecomeAffiliate data={supportPageData.becomeAffiliateJson} />;
      case "compare":
        return <Compare data={supportPageData.compare} />;
      case "stories":
        return (
          <Stories
            data={supportPageData.storiesJson}
            history={this.props.history}
          />
        );
      case "app-page":
        return <NosieFitApp data={supportPageData.appJson} />;
      case "noise-colorfit-pro-3-pride-edition":
        return <Pro3PridePage data={supportPageData.pro3prideJson} />;
      case "campus-noisemakers":
        return <CampusNoisemaker data={supportPageData.campusNoiseMaker.data} />;
      case "download-your-purchase-invoice":
        return <Downloadinvoice data={supportPageData.defaultPage.data} />;
      case "noise-quest-for-the-best":
        return <Questforthebest data={supportPageData.questfortheBest.data} />;
      case "noise-anniversary-days-sale":
        return <AnniversarySale data={supportPageData.AnniversarySale.data} />;
      default:
        return <DefaultPage data={supportPageData.defaultPage.data} />
    }
  };

  updateCurrentTab = (pageHandle) =>{
    const { setCurrentTab, fetchWarrantyProducts } = this.props;
    // fetchWarrantyProducts();
    let newTab = pageHandle
    switch (pageHandle) {
      case "warranty-registration":
        // setCurrentTab("warranty-register");
        newTab = 'warranty-register';
        break;
      case "faq":
        // setCurrentTab("faq");
        newTab = 'faq';
        break;
      case "warranty-guidelines":
        // setCurrentTab("warranty-guide");
        newTab = 'warranty-guide';
        break;
      case "contact-us":
        // setCurrentTab("contact-us");
        newTab = "contact-us";

        break;
      case "register-your-complaint":
        // setCurrentTab("register-complaint");
        newTab = "register-complaint";
        break;
      case "track-your-order":
        // setCurrentTab("track-order");
        newTab = "track-order";
        break;
      case "shipping-policy-and-return-policy":
        // setCurrentTab("shipping-details");
        newTab = "shipping-details";
        break;
      case "noise-exclusive-offers":
        // setCurrentTab("noise-exclusive-offers");
        newTab = "noise-exclusive-offers";
        break;
      case "terms-of-use":
        // setCurrentTab("terms-and-condition");
        newTab = "terms-and-condition";
        break;
      case "e-waster-management":
        // setCurrentTab("e-waste-management");
        newTab = "e-waste-management";
        break;
      case "site-map":
        // setCurrentTab("site-map");
        newTab = "site-map";
        break;
      case "about-us":
        // setCurrentTab("about-us");
        newTab = "about-us";
        break;
      case "privacy-policy":
        // setCurrentTab("privacy-policy");
        newTab = "privacy-policy";
        break;
      case "corporate-enquiry":
        setCurrentTab("corporate-enquiry");
        // newTab = "corporate-enquiry";
        break;
      case "in-the-press":
        // setCurrentTab("in-the-press");
        newTab = "in-the-press";
        break;
      case "career":
        // setCurrentTab("career");
        newTab = "career";
        break;
      case "become-an-affiliate":
        // setCurrentTab("become-an-affiliate");
        newTab = "become-an-affiliate";
        break;
      case "stories":
        // setCurrentTab("stories");
        newTab = "stories";
        break;
      case "app-page":
        // setCurrentTab("app-page");
        newTab = "app-page";
        break;
      case "compare":
        // setCurrentTab("compare");
        newTab = "compare";
        break;
      case "noise-colorfit-pro-3-pride-edition":
        // setCurrentTab("noise-colorfit-pro-3-pride-edition");
        newTab = "noise-colorfit-pro-3-pride-edition";
        break;
      default:
        // setCurrentTab(pageHandle);
        newTab = pageHandle;
        break;
    }
    return newTab;
  }

  //fetch data of section settings
  
  componentDidMount() {
    window.scrollTo(0,0);
    let newTab = this.updateCurrentTab(this.props.match.params.pageHandle);
    this.props.setSupportPageData(newTab);
  
    
  }
  componentWillReceiveProps(nextProps, prevProps) {
    const { setCurrentTab, tabChange } = this.props;
    let update =
      nextProps.match.params.pageHandle != this.props.match.params.pageHandle
        ? true
        : false;

    if (update) {
      let newTab = this.updateCurrentTab(nextProps.match.params.pageHandle);
      this.props.setSupportPageData(newTab);
    }
  }

  render() {
    const { loading, setSupportData, currentTab, supportPageData } = this.props;
    let Style = {};
    let {pageNotFound} = supportPageData; 
    const headerHeight = getHeaderHeight();
    if(loading){
      Style={
        display: "block",
        position: "relative",
        top:"51px",
        width:"100%",
        height:"calc(100vh - 50px)"
       // minHeight: "300px"
      }
      return <div className="page-loader" style={Style}><Loader /></div>;
    
    }
    if(pageNotFound){
      return <ErrorPage show={true} />;
    }
    return (
      <div className="support-page" ref={this.supportMainDiv}>
        {this.tabPages.includes(currentTab) && <SupportBanner />}
        {this.tabPages.includes(currentTab) && (
          <SupportTabs pageHandle={this.props.match.params.pageHandle} />
        )}
        {this.normalPages.includes(currentTab) && (
          <PageBreadcrumbs currentTab={currentTab} />
        )}

        {this.renderTabSwitch(currentTab)}
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  loading: state.support.loading,
  supportPageData: state.support.supportData,
  currentTab: state.support.currentTab,
  tabChanged: state.support.tabChange,
});

const mapDispatchToProps = (dispatch) => ({
  setSupportPageData: (data) => dispatch(setSupportPageData(data)),
  setCurrentTab: (data) => dispatch(setCurrentTab(data)),
  fetchWarrantyProducts: (data) => dispatch(fetchWarrantyProducts(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(SupportPage);
