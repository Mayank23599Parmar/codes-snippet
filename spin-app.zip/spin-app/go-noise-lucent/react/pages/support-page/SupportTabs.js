import React, { Component } from "react";
import { connect } from "react-redux";
import Slider from "react-slick";

import {
  setCurrentTab,
  currentTabChange,
} from "../../redux/support/supportAction";
import Srcset from "../../components/SrcSet";

export class SupportTabs extends Component {
  constructor(props) {
    super(props);
    
    this.slidesWithIndex ={
      'faq':0,
      'warranty-guide':1,
      'contact-us':2,
      'register-complaint':3,
      'track-order':4,
      'warranty-register':5,
      'shipping-details':6,
      'terms-and-condition':7,
    }
  }
  
  componentDidMount(){
    const { currentTab, } = this.props;
    this.slider.slickGoTo(this.slidesWithIndex[currentTab],true);
  }
  componentDidUpdate(prevProps){
    const { currentTab, } = this.props;
    if( prevProps.pageHandle != this.props.pageHandle)
      this.slider.slickGoTo(this.slidesWithIndex[currentTab],true);
  }
  render() {
    const { setCurrentTab, currentTab, setChangeTab } = this.props;
    let settings = {
      dots: false,
      infinite: true,
      speed: 500,
      slidesToShow: 4,
      slidesToScroll: 1,
      responsive: [
        {
          breakpoint: 767,
          settings: {
            swipe: true,
            slidesToShow: 2,
            swipeToSlide: true,
          }
        }
      ],
    };
    return (
      <div className="support-tabs">
        <div className="container support-tabs-phone">
          <Slider ref={slider => (this.slider = slider)} {...settings} className="tabs">
            <div
              className={`slider-element ${
                currentTab === "faq" ? " active" : ""
              }`}
              onClick={() => {
                setChangeTab(true);
                setCurrentTab("faq");
              }}
            >
              <div className="inner-text">
                <div className="image">
                  <Srcset src={pwa.icons.supportIcons.faqIcon} alt="Faq" />
                </div>
                <h5 className="tab-heading">FAQs</h5>
              </div>
            </div>
            <div
              className={`slider-element ${
                currentTab === "warranty-guide" ? " active" : ""
              }`}
              onClick={() => {
                setChangeTab(true);
                setCurrentTab("warranty-guide");
              }}
            >
              <div className="inner-text">
                <div className="image">
                  <Srcset
                    src={pwa.icons.supportIcons.warrantyGuidelines}
                    alt="Faq"
                  />
                </div>
                <h5 className="tab-heading">
                  Warranty
                  <br />
                  Guidelines
                </h5>
              </div>
            </div>
            <div
              className={`slider-element ${
                currentTab === "contact-us" ? " active" : ""
              }`}
              onClick={() => {
                setChangeTab(true);
                setCurrentTab("contact-us");
              }}
            >
              <div className="inner-text">
                <div className="image">
                  <Srcset src={pwa.icons.supportIcons.contactUs} alt="Faq" />
                </div>
                <h5 className="tab-heading">
                  Contact Us
                </h5>
              </div>
            </div>
            <div
              className={`slider-element ${
                currentTab === "register-complaint" ? " active" : ""
              }`}
              onClick={() => {
                setChangeTab(true);
                setCurrentTab("register-complaint");
              }}
            >
              <div className="inner-text">
                <div className="image">
                  <Srcset
                    src={pwa.icons.supportIcons.registerComplaint}
                    alt="Faq"
                  />
                </div>
                <h5 className="tab-heading">
                  Register
                  <br />
                  Complaint
                </h5>
              </div>
            </div>
            <div
              className={`slider-element ${
                currentTab === "track-order" ? " active" : ""
              }`}
              onClick={() => {
                setChangeTab(true);
                setCurrentTab("track-order");
              }}
            >
              <div className="inner-text">
                <div className="image">
                  <Srcset src={pwa.icons.supportIcons.trackOrder} alt="Faq" />
                </div>
                <h5 className="tab-heading">
                  Track Your
                  <br />
                  Order
                </h5>
              </div>
            </div>
            <div
              className={`slider-element ${
                currentTab === "warranty-register" ? " active" : ""
              }`}
              onClick={() => {
                setChangeTab(true);
                setCurrentTab("warranty-register");
              }}
            >
              <div className="inner-text">
                <div className="image">
                  <Srcset
                    src={pwa.icons.supportIcons.warrantyRegistration}
                    alt="Faq"
                  />
                </div>
                <h5 className="tab-heading">
                  Warranty
                  <br />
                  Registration
                </h5>
              </div>
            </div>
            <div
              className={`slider-element ${
                currentTab === "shipping-details" ? " active" : ""
              }`}
              onClick={() => {
                setChangeTab(true);
                setCurrentTab("shipping-details");
              }}
            >
              <div className="inner-text">
                <div className="image">
                  <Srcset
                    src={pwa.icons.supportIcons.shippingPolicy}
                    alt="Faq"
                  />
                </div>
                <h5 className="tab-heading">
                  Shipping
                  <br />
                  Details
                </h5>
              </div>
            </div>
            <div
              className={`slider-element ${
                currentTab === "terms-and-condition" ? " active" : ""
              }`}
              onClick={() => {
                setChangeTab(true);
                setCurrentTab("terms-and-condition");
              }}
            >
              <div className="inner-text">
                <div className="image">
                  <Srcset
                    src={pwa.icons.supportIcons.termsConditions}
                    alt="Faq"
                  />
                </div>
                <h5 className="tab-heading">
                  Terms and
                  <br />
                  Conditions
                </h5>
              </div>
            </div>
          </Slider>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  setCurrentTab: (data) => dispatch(setCurrentTab(data)),
  setChangeTab: (change) => dispatch(currentTabChange(change)),
});
const mapStateToProps = (state) => ({ currentTab: state.support.currentTab });
export default connect(mapStateToProps, mapDispatchToProps)(SupportTabs);
