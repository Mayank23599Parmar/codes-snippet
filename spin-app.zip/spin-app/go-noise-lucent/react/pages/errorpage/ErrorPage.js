import React, { Component } from 'react'
import Srcset from '../../components/SrcSet';

class ErrorPage extends Component {
  render() {
    let currentUrl = window.location.href;
    let hideError = currentUrl.includes('account') || currentUrl.includes('blogs') || currentUrl.includes('cart');
    if(!this.props.show || simply.errorPage || hideError ){
      return false;
    }
    return (
      <>
      <div className="error-page-wrapper">
        <div className="container">
          {/* <div className="error-page-content text-center">
            <h1>Looks like you are lost ?</h1>
            <p>Let us guide you on the right path</p>
            <a href="/">Go Home</a>
          </div> */}
          <a className="error-image" href="/">
                 <Srcset className="dw-desktop" alt="error-page-desktop" src="https://cdn.shopify.com/s/files/1/0997/6284/files/web-image_2x_aa9144d2-8f73-43e9-ba6e-8c398589074d.png?v=1618230398" />
                <Srcset className="dw-mobile" alt="error-page-desktop" src="https://cdn.shopify.com/s/files/1/0997/6284/files/mobile-image.png?v=1618230398" />
          </a>

        </div>
      </div>
      </>
    )
  }
}

export default ErrorPage