import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
// import { updateCart } from '../../shopify/CartApi';
import { formatMoney, fetchProductTitle, isGift } from '../../components/Helper';
import { Spinner } from '../../components/Form';
// import Srcset from '../../components/SrcSet';
import { updateCart, clearCart1, updateCart1 } from '../../redux/cart/cartAction';

class CartPageItem extends Component {
 getQtyArray = qty => {
  const { index } = this.props;
  let cartData = this.props.cart;
  let items = cartData.cart.items;
  let twoItem = false;
  if(items.length == 2){
    twoItem = true;
  }
  let qtyArray = items.map((item, item_index) => {
   if (item_index === index) {
    //  if(twoItem){
    //    if (qty == 0){
    //     this.props.clearCart1();
    //     return;
    //    }
    //  }
    return qty;
   }
   return item.item.quantity;
  });
  return qtyArray;
 };
 removeItem = () => {
  let cartData = this.props.cart;
  let items = cartData.cart.items;
  let countItem = false;
  if (items.length === 2){
    items.map((item) => {
    if(parseInt(item.item.id) === 39357298016343 ){
      countItem = true;
      }
    });
  }
  else{
    countItem = false;
  }
if (countItem){
   this.props.clearCart1();
}
else{
   const qtyArray = this.getQtyArray(0);
   this.props.updateCart(qtyArray);
}
 };
 changeQty = qty => {
    let cartData = this.props.cart;
    let items = cartData.cart.items;
    let found = false;
    items.map((item) => {
      if(parseInt(item.item.id) === 39357298016343 ){
        found = true;
      }
    });
      if (found){
       if(items.length === 2){
         if (qty === 0){
          this.props.clearCart1();
         }
         else{
          const qtyArray = this.getQtyArray(qty);
          this.props.updateCart(qtyArray);          
         }
       }
       else{
        if (qty === 0){
          const qtyArray = this.getQtyArray(0);
          this.props.updateCart(qtyArray);          
        }
        else{
          const qtyArray = this.getQtyArray(qty);
          this.props.updateCart(qtyArray);
        }
       }
      }
      else{
        if (qty === 0){
          const qtyArray = this.getQtyArray(0);
          this.props.updateCart(qtyArray);          
        }
       else{
         const qtyArray = this.getQtyArray(qty);
         this.props.updateCart(qtyArray);
        }
      }
};

 render() {
  const { item, tags } = this.props.item;

  let { key, variant_id, url, image, line_price, quantity } = item;
  let actual_title = item.title;
  let tagTitle = fetchProductTitle(tags);
  if (tagTitle) {
   actual_title = tagTitle;
  }
  
  let showSpinner = true;
  let removeGift = false;
  if(parseInt(item.id) === 39357298016343 ){
    removeGift = true;
  }

  return (   
   <div
    data-vid={variant_id}
    className='cart-items'
    data-product-type={item.product_type}>
    <div className='flex-view-xs middle space'>
     <div className='col-xs-12 col-sm-3'>
      <div className='cart-item-image img'>
       <Link to={url} className='cart-image'>
        <img alt={actual_title} src={image} className='lazyload' />
       </Link>
      </div>
     </div>

     <div className='col-xs-12 col-sm-9'>
      <div>
       <div className='text-wrap'>
        <div className='cart-item-name'>
         <div className='flex-view-xs space-between'>
          <Link to={url}>
           <h5>{actual_title}</h5>
          </Link>
          <h5 className='product-price original-price'>{formatMoney(line_price)}</h5>
         </div>
        </div>
        {item.variant_title && (
         <span className='variant-title'>{item.variant_title}</span>
        )}

       {!removeGift &&
        <div className='qty-part'>
         {showSpinner && (
          <div className='qty-label'>
           <p>Quantity</p>
           <div className='text-left qty'>
            <Spinner
             id={`updates-${key}`}
             label='Quantity'
             name='updates[]'
             value={quantity}
             callbackFun={this.changeQty}
            />
                <p className='item-remove' onClick={this.removeItem}>Remove</p>
           </div>
          </div>
         )}
        </div>
        }
       </div>
      </div>
     </div>
    </div>
   </div>
  );
 }
}

const mapStateToProps = state => {
 return {
  cart: state.cart,
 };
};
const mapDispatchToProps = dispatch => {
 return {
  setCartStart: () => dispatch(setCartStart()),
  updateCart: qtyArray => dispatch(updateCart(qtyArray)),
  updateCart1: qtyArray => dispatch(updateCart1(qtyArray)),
  clearCart1: () => dispatch(clearCart1()),
 };
};
export default connect(mapStateToProps, mapDispatchToProps)(CartPageItem);
