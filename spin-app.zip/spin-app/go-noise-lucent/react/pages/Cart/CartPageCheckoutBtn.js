import React from 'react';
import { setCartGst } from '../../redux/cart/cartAction';
import { connect } from 'react-redux';
import { checkGSTNumber } from "../../redux/cart/cartAction";
class CartPageCheckoutBtn extends React.Component {
    render() {
        const { GST } = this.props;
        const data = { attributes: { gst: GST } };
        const handleCheckout = e => {
            if (GST === '') window.location = '/checkout';
            else {
                let regxGST = /\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1}/.test(GST)
                if (regxGST) {
                    this.props.setCartGst(GST);
                }
                else {
                    this.props.checkGSTNumber(true)
                }

            }
        };
        return (
            <div className={`text-center checkout-cart-wrapper${!pwa.frequentlyEnable?' normal-checkout-wrapper' :''}`}>
            {!pwa.frequentlyEnable ?
                        <button className='checkout-btn btn' onClick={element => handleCheckout(element)}>Proceed to checkout</button>
                     :
                     <>
                     <div className="gokwik-container btn-right">
                            <button className="gokwikpay checkout-btn btn " data-type="cod" data-theme='{"primaryClr":"#505AF0"}'>
                            Pay via UPI/COD
                            </button>
                     </div>
                    <button
                        className='checkout-btn btn'
                        onClick={element => handleCheckout(element)}>Pay via Card/Wallet
                    </button>
                    </>
                    }
            </div>
           
        );
    }
} 
const mapDispatchToProps = dispatch => {
    return {
        checkGSTNumber: data => dispatch(checkGSTNumber(data)),
        setCartGst: data => dispatch(setCartGst(data))

    };
};
export default connect(null, mapDispatchToProps)(CartPageCheckoutBtn);