import React from 'react';
import { connect } from 'react-redux';
import Loader from '../../components/loader/loader';
import CartPageItem from './CartPageItem';
import { isGift, needWrapper } from '../../components/Helper';
// import GiftWrap from './GiftWrap';
import TrustBatches from '../../components/TrustBatches';
import Newsletter from '../../components/Newsletter';
import UrlSet from '../../components/UrlSet';
import { formatMoney } from '../../components/Helper';
import CartPageCheckoutBtn from './CartPageCheckoutBtn';
import ContactDetails from '../../components/ContactDetails';
import { cart_addition } from '../../clever-tap-events/CartEvent'
import MediaQuery from '../../components/MediaQuery';
import { checkGSTNumber } from "../../redux/cart/cartAction";
class CartPage extends React.Component {
  state = {
    GST: '',
    GSTErrorMessage: ''
  };
  handleGSTNumber=()=>{
    let regxGST = /\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1}/.test(this.state.GST)
    if(this.state.GST===""){
      this.setState({ GSTErrorMessage: false })
    }
    
    if(!regxGST && this.state.GST!==""){
     this.setState({GSTErrorMessage:true})
    }
    else{
      this.setState({GSTErrorMessage:false})
    }
  }
  comparePrice = items => {
    let price = 0;
    items.map(data => {
      let item = data.item;
      if (data.compare_at_price > item.price) {
        price = price + (data.compare_at_price - item.price);
      } else {
        price = price + item.price;
      }
    });
    return price;
  };
  componentDidUpdate(prevProps) {
    // Typical usage (don't forget to compare props):
    if (this.props.cartData.gstError !== prevProps.cartData.gstError) {
      this.setState({ GSTErrorMessage: true })
    }
  }
  render() {
    const { cartData } = this.props;
    cart_addition(cartData.cart)
    const loading = cartData.loading;
    if (loading) {
      return (
        <div className='cart-page-loading'>
          <Loader />;
        </div>
      );
    }
    let total_price = 0;
    let original_total_price = 0;
    if (cartData.cart.total_price) {
      total_price = cartData.cart.total_price;
      original_total_price = cartData.cart.original_total_price;
    }
    let shipping_msg = '';
    try {
      shipping_msg = window.pwaSettings.cart.shipping_msg;
    } catch (e) {
      console.log('Shipping message react issue');
    }
    const cartItems = cartData.cart;
    //   var active = this.props.isactive ? 'active' : '';

    if (!cartData.cart.items) {
      return <Loader />;
    }

    if (cartItems.item_count === 0) {
      return (
        <div className='empty-cart-page'>
          <div className='container'>
            <div className='empty-cart-msg'>Your cart is empty</div>
          </div>
        </div>
      );
    }

    return (
      <div className='cart-page'>
        <MediaQuery query="phone">
          <CartPageCheckoutBtn GST={this.state.GST} />
        </MediaQuery>
        {cartData.cart ? (
          <>
            <div className='container'>
              <div className='breadcrumb'>
                <UrlSet href='/'>Home</UrlSet>
                <span className='separator'>
                  <img src={pwa.icons.blackRightArrow} alt='arrow' />
                </span>
                <span className='sub-title'>Shopping Cart</span>
              </div>
              {/*<h2 className='cart-title'>Shopping Cart</h2>*/}
              <div className='cart-data'>
                <div className='flex-view-xs'>
                  <div className='col-sm-8 col-xs-12'>
                    <div className='cart-page-items'>
                      <form>
                        <input type='hidden' name='update' value='' />
                        <div className='cart-data-wrap'>
                          {cartItems.items.map((item, index) => (
                            <CartPageItem item={item} key={item.id} index={index} />
                          ))}
                        </div>
                      </form>
                    </div>
                  </div>
                  <div className='col-sm-4 col-xs-12'>
                    <div className='cart-page-detail'>
                      <div className='cart-page-form'>
                      {/* <div className="giftWrapper">           
                        <GiftWrap cartItems={cartItems} />
                      </div> */}
                        <p className='cart-details-header'>Order Summary</p>
                        <div className='cart--subtotal'>
                          <div className='flex-view-xs space-between'>
                            <span className='label'>Item Subtotal</span>
                            <span className='value'>
                              {formatMoney(cartData.cart.original_total_price)}
                            </span>
                          </div>
                        </div>
                        <div className='shipping-handling'>
                          <div className='flex-view-xs space-between'>
                            <span className='label'>Shipping & Handling</span>
                            <span className='value extra'>Free</span>
                          </div>
                        </div>
                        {cartData.cart.total_discount > 0 &&
                          <div className='saved-price'>
                            <div className='flex-view-xs space-between'>
                              <span className='label'>You Saved</span>
                              <span className='value extra'>
                                - {formatMoney(cartData.cart.total_discount)}
                              </span>
                            </div>
                          </div>}
                        <h5 className='total-price'>
                          <div className='flex-view-xs space-between'>
                            <span>Total</span>
                            <span>{formatMoney(cartData.cart.total_price)}</span>
                          </div>
                        </h5>
                        <div className='gst-optional'>
                          <input
                            type='text'
                            name='attributes[GST]'
                            id='gstinput'
                            placeholder='GST(Optional)'
                            value={this.state.GST}
                            onChange={element => {
                              this.props.checkGSTNumber(false)
                              this.setState({ GSTErrorMessage: false })
                       
                              let gst = element.target.value.replace(/\s/g, "");
                             
                              this.setState(() => ({ GST: gst.toUpperCase() }));
                            }}
                            maxLength="15"
                            onBlur={this.handleGSTNumber}
                          />
                          {this.state.GSTErrorMessage ? <p className="GST-error">You enter wrong GST number</p> : ""}
                        </div>
                        <MediaQuery query="tablet-and-up">
                          <CartPageCheckoutBtn GST={this.state.GST.trim()} />
                        </MediaQuery>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* <ContactDetails /> */}
          </>
        ) : (
          <Loader />
        )}
        <TrustBatches />
        <Newsletter />
      </div>
    );
  }
}

const mapStateToProps = state => ({
  cartData: state.cart,
});
const mapDispatchToProps = dispatch => {
  return {
    checkGSTNumber: data => dispatch(checkGSTNumber(data)),

  };
};
export default connect(mapStateToProps, mapDispatchToProps)(CartPage);
