import React, { Component } from 'react';
//import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
// import { updateCart } from '../../shopify/CartApi';
//import { isGift } from '../../components/Helper';
//import { Spinner } from '../../components/Form';
// import Srcset from '../../components/SrcSet';
import { updateCart1 , addToCart } from '../../redux/cart/cartAction';
import {ctaBuyEvent} from '../../clever-tap-events/AddToCartEvent'

class GiftWrap extends Component {
    constructor(props) {
        super(props);
        this.state = {
            enabledCheckBox: false,
            myCount: 0
          };
    }

     onClick1 = () => {
         this.setState({ myCount: ++this.state.myCount  });
        // document.getElementById("adding").innerHTML = "Adding gift wrap...";
       // document.getElementById("add-input").setAttribute("checked","checked"); 
        console.log("adding function");
          if (this.state.myCount < 2){
            const form = { id: 39357298016343, quantity: 1 };
            const data = {
              "type":"cart",
              form
            }
            this.props.addToCart(data);
            //console.log(this.state.myCount);
          }
          else{
          }
       };
       onClick = () => {
        // this.setState({ enabledCheckBox: !this.state.enabledCheckBox });
        // document.getElementById("removing").innerHTML = "Removing gift wrap...";
        console.log("removing fundtion");
        document.getElementById("remove-input").removeAttribute("checked"); 
        const form = { 39357298016343: 0 };
        const data = {
          "type":"cart",
          form
        }
        this.props.updateCart1(form);
        //window.location.reload();
        return true;
       };
      
    render() {
     const { cartItems } = this.props;
     console.log(cartItems);
     let giftWrapFound = false;
     cartItems.items.map((item, index) => {
      if(parseInt(item.item.id) === 39357298016343 ){
        giftWrapFound = true;
      }
    })

     return (
       <>
       {giftWrapFound ? (
        <div>
        <div className="gift-wrapper" >
           <input checked id="remove-input"
           className="enabled"
            type="checkbox"
            value={"gift wrap"}
            onChange={this.onClick}
          />
          <label for='remove-input' id="removing">
           Add gift wrap for ₹30
          </label>
       </div>
       </div>
       ) : (
        <div>
        <div className="gift-wrapper" id="gift">
          <input id="add-input"
          type="checkbox"
          value="gift wrap"
          onChange={this.onClick1}
          />
          <label for='add-input' id="adding">
            Add gift wrap for ₹30
          </label>
         </div>
        </div>
       )}
     </>
     );
   }
} 
   
   const mapStateToProps = state => {
    return {
     cart: state.cart,
    };
   };
   const mapDispatchToProps = dispatch => {
    return {
     addToCart: (data) => dispatch(addToCart(data)),
     setCartStart: () => dispatch(setCartStart()),
     updateCart: qtyArray => dispatch(updateCart(qtyArray)),
     updateCart1: qtyArray => dispatch(updateCart1(qtyArray)),
    };
   };
   export default connect(mapStateToProps, mapDispatchToProps)(GiftWrap);
   
