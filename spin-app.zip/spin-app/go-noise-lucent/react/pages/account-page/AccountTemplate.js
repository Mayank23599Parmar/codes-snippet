import React from "react";
import { connect } from "react-redux";
/* Breadcrumb */
import Breadcrumb from "./Breadcrumb";
/* Subpage tabs */
import PersonalInformation from "./modals/PersonalInformation";
import Orders from "./modals/Orders";
import OrderDetails from "./modals/OrderDetails";
import ManageAddress from "./modals/ManageAddress";
// import NoiseWallet from "./modals/NoiseWallet";
// import ReferFriend from "./ReferFriend";
import TrustBatches from "../../components/TrustBatches";
import Newsletter from "../../components/Newsletter";
import PreOrders from "./pre-orders/PreOrders";
import ContactDetails from '../../components/ContactDetails';
// import Footer from '../../components/Footer/Footer';
class AccountTemplate extends React.Component {
  setCurrentTab = (currentTab) => {
    switch (currentTab) {
      case "personalInfo":
        return <PersonalInformation />;

      case "pre-orders":
        return <PreOrders />;

      case "orders":
        return <Orders />;

      case "order-details":
        return <OrderDetails />;

      case "address":
        return <ManageAddress />;

      // case "wallet":
      //   return <NoiseWallet />;

      // case "referFriend":
      //   return <ReferFriend />;

      default:
        return <PersonalInformation />;
    }
  };

  render() {
    const { currentTab } = this.props;

    return (
      <>
        <div className="container">
          <Breadcrumb currentTab={currentTab} />
          {this.setCurrentTab(currentTab)}
        </div>
        <ContactDetails />
        <TrustBatches />
        <Newsletter />
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  currentTab: state.account.currentTab,
});

export default connect(mapStateToProps)(AccountTemplate);
