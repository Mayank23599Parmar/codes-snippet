import React from 'react';

class ReferFriend extends React.Component {
 render() {
  return <h1>Refer Friend</h1>;
 }
}

export default ReferFriend;
