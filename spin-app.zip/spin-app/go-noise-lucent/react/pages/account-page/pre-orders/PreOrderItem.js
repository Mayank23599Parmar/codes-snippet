import React, { Component } from "react";
import Icons from "../../../components/Icons";
import { setSelectedOrderData,makePreOrderPayment , preOrderDetails } from "../../../redux/account/accountActions";
import { connect } from "react-redux";
import SrcSet from "../../../components/SrcSet";
import { formatMoney, dateFormatter } from "../../../components/Helper";
class PreOrderItem extends Component {
  state = {
    selectedAddress: false,
    selectedAddressData: {},
    showAddresses: false,
    selectAddressError: false
  };
  toggleAddress = value =>{
    if(this.state.showAddresses){
      this.setState({showAddresses: false});
    }else{
      this.setState({showAddresses: true});
    }
  }
  updateAddressData = data =>{
    this.setState({showAddresses: false,selectedAddressData:data,selectedAddress:true,selectAddressError:false});
  }
  proceedToBuy = (e) =>{
    if(this.state.selectedAddress){
      const { item } = this.props;
      let {order_id_system} = item;
      let addressId = this.state.selectedAddressData.id;
      e.target.classList.add('loading');
      this.props.makePreOrderPayment({orderId:order_id_system, addressId:addressId });
    }else{
      this.setState({selectAddressError:true});
    }
  }

  handleOrderDetails = (orderId) => {
    this.props.preOrderDetails(orderId)
  }

  render() {
    const { item } = this.props;
    let {
      booking_amount,
      created_at,
      image_url,
      inventory_status,
      is_completed,
      order_id_system,
      pre_order_id,
      pre_order_status,
      prod_title,
      product_details,
      shopify_order_id,
      amount_paid
    } = item;
    let { price, title } = product_details;
    let { addresses } = this.props;
    let {selectedAddressData} = this.state;
    if(is_completed){
      order_id_system = shopify_order_id;
    }
    return (
      <>
        <div className="order-header">
          <div className="flex-view-xs space-between" style={{ width: "100%" }}>
            <h6>Order ID : {order_id_system}</h6>
          </div>
        </div>
        <div className="order-container">
          <div className="flex-view-xs middle">
            <div className="col-md-8">
              <div className="orders-list">
                <div className="order-content">
                  <div className="item-details-container">
                    <div className="flex-view-xs space">
                      <div className="col-md-9">
                        <div className="order-main-details">
                          <div className="order-img">
                            <SrcSet src={image_url} />
                          </div>
                          <div className="order-details">
                            <h3>{prod_title}</h3>
                            <div className="item-details">
                              <p className="variant-title">{title}</p>
                              <div className="item-qty">
                                <span className="item--title">Qty: </span>
                                <span>1</span>
                              </div>
                              <div className="item-price">
                                <span className="item--title">Price : </span>{" "}
                                <span>
                                  {formatMoney(parseInt(price * 100))}
                                </span>
                              </div>
                              <div className="item-price">
                                <span className="item--title">Paid : </span>{" "}
                                <span>{is_completed ?
                                 formatMoney(amount_paid * 100)
                                :
                                formatMoney(booking_amount * 100)
                                }</span>
                              </div>
                            </div>
                            {!is_completed && inventory_status && (
                                <div className="address-selector">
                                  {this.state.selectAddressError && 'Please select address'}
                                  <button className="select-address" onClick={this.toggleAddress}>
                                    {this.state.selectedAddress ? 
                                  <> {selectedAddressData.name},{selectedAddressData.address1},
                                    {selectedAddressData.address2},{selectedAddressData.city},
                                    {selectedAddressData.province},{selectedAddressData.country},
                                    {selectedAddressData.zip}</>
                                    : "Select address"}
                                  </button>
                                  {this.state.showAddresses && 
                                  <ul>
                                    {addresses.map((address) => {
                                      return (
                                        <li key={address.id}>
                                          <input onChange={() => this.updateAddressData(address)} type="checkbox" value={address.id === this.state.selectedAddressData.id}/>
                                          {address.name},{address.address1},
                                          {address.address2},{address.city},
                                          {address.province},{address.country},
                                          {address.zip}
                                        </li>
                                      );
                                    })}
                                  </ul>}
                                </div>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="col-md-3 col-xs-12">
                        <div className="order-status">
                          <div>
                            <p>Order Date</p>
                            <span>{dateFormatter(created_at)}</span>
                          </div>
                          <div>
                            <p>Order Status</p>
                            <span>{pre_order_status ? "Prebook confirmed" : "False"}</span>
                          </div>
                          {is_completed === false && 
                            <div>
                            <p>Remaining</p>
                            <span>
                              {formatMoney(
                                (parseInt(price) - booking_amount) * 100
                              )}
                            </span>
                          </div>
                          }
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4 col-xs-12">
              <div className="order-help">
                <ul className="order-links col-xs-12">
                  {is_completed ? (
                    <li className="text-center">
                      <button className="btn" onClick={() => this.handleOrderDetails(shopify_order_id)} >
                        Order details
                      </button>
                    </li>
                  ) : (
                    <li className="text-center">
                      {inventory_status ? (
                        <button className="btn" onClick={(e)=> this.proceedToBuy(e)}>Proceed to buy</button>
                      ) : (
                        <p className="text-center">We'll get back to you when your order is ready.</p>
                      )}
                    </li>
                  )}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  addresses: state.account.profile.addresses,
});
const mapDispatchToProps = (dispatch) => ({
  setSelectedOrderData: (data) => dispatch(setSelectedOrderData(data)),
  makePreOrderPayment: (data) => dispatch(makePreOrderPayment(data)),
  preOrderDetails: (data) => dispatch(preOrderDetails(data))
});

export default connect(mapStateToProps, mapDispatchToProps)(PreOrderItem);
