import React from "react";
import { connect } from "react-redux";
import { GetPreOrder } from "../../../redux/account/accountActions";
import PreOrderItem from "./PreOrderItem";
import Loader from "../../../components/loader/loader";
class PreOrders extends React.Component {
  componentDidMount() {
    if (!cn(simply.customerId)) {
      this.props.GetPreOrder(simply.customerId);
    }
  }

  render() {
    const { orders, loading } = this.props;

    if (loading) {
      return (
        <div className="account-info-loading">
          <Loader />
        </div>
      );
    }
    return (
      <div className="order-section">
        <div className="my-order-title">
          <h1>My Pre-Orders</h1>
        </div>
        {orders.length <= 0 && <div className="no-order-found">
          <h4 className="text-center">No orders found!</h4>  
        </div>}
        {orders &&
          orders.length > 0 &&
          orders.map((item, key) => <PreOrderItem item={item} key={key} />)}
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  loading: state.account.preOrder.loading,
  orders: state.account.preOrder.orderData,
});

const mapDispatchToProps = (dispatch) => ({
  GetPreOrder: (data) => dispatch(GetPreOrder(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(PreOrders);
