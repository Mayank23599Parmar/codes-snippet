import React from 'react';
import UrlSet from '../../components/UrlSet';
class Login extends React.Component {
 render() {
  return (
   <div className='login-page'>
    <h3 className='title'>Hello NoiseMaker!</h3>
    <form className='login-form'>
     <div className='clearfix'>
      <input type='email' placeholder='Email address' />
      <input type='password' placeholder='Password' />
      <div className='forgot-password'>Forgot Password ?</div>
     </div>
     <div className='text-center'>
      <button type='submit' className='btn signIn-btn'>
       Sign in
      </button>
      <div className='signup'>
       Not a Noisemaker ? <UrlSet href="/account/register">Sign up</UrlSet>
      </div>
     </div>
    </form>
    <h3 className='or'>Or</h3>
    <div>
        <div id="oxi-social-login">

        </div>
    </div>
   </div>
  );
 }
}
export default Login;
