import React, { Component } from "react";
import Icons from "../../components/Icons";
import { setAccountTab } from "../../redux/account/accountActions";
import { connect } from "react-redux";
import UrlSet from "../../components/UrlSet";
class Breadcrumb extends Component {
  setCurrentBreadcrumb = (currentTab) => {
    switch (currentTab) {
      case "personalInfo":
        return;

      case "orders":
        return (
          <>
            <Icons icon="breadcrumb" />
            <span className="breadcrumb-field">My Orders</span>
          </>
        );
      case "pre-orders":
        return (
          <>
            <Icons icon="breadcrumb" />
            <span className="breadcrumb-field">Pre Orders</span>
          </>
        );
      case "order-details":
        return (
          <>
            <Icons icon="breadcrumb" />
            <span
              className="breadcrumb-field"
              onClick={() => {
                this.props.setAccountTab("orders");
              }}
            >
              My Orders
            </span>
            <Icons icon="breadcrumb" />
            <span className="breadcrumb-field">Order Details</span>
          </>
        );

      case "address":
        return (
          <>
            <Icons icon="breadcrumb" />
            <span className="breadcrumb-field">Addresses</span>
          </>
        );

      case "wallet":
        return (
          <>
            <Icons icon="breadcrumb" />
            <span className="breadcrumb-field">Noise Wallet</span>
          </>
        );

      case "referFriend":
        return (
          <>
            <Icons icon="breadcrumb" />
            <span className="breadcrumb-field">Refer Friend</span>
          </>
        );

      default:
        return;
    }
  };

  render() {
    const { currentTab } = this.props;

    return (
      <div className="account-breadcrumbs">
        <span className="breadcrumb-field">
          <UrlSet href="/">Home</UrlSet>
        </span>
        <Icons icon="breadcrumb" />
        <span
          className="breadcrumb-field"
          onClick={() => {
            this.props.setAccountTab("personalInfo");
          }}
        >
          Account
        </span>
        {this.setCurrentBreadcrumb(currentTab)}
      </div>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  setAccountTab: (data) => dispatch(setAccountTab(data)),
});

export default connect(null, mapDispatchToProps)(Breadcrumb);
