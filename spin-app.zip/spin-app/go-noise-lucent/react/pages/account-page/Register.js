import React from "react";
// import UrlSet from "../../components/UrlSet";
import { connect } from "react-redux";
import {
  generateOTP,
  OTPVerification,
  registerCustomer,
} from "../../redux/account/accountActions";
import { emailValidate } from '../../components/Helper'
import { showToast } from "../../components/Helper";
// import { Alert } from "reactstrap";
import { signupFormEvent } from '../../clever-tap-events/SignupEvent'
class Register extends React.Component {
  state = {
    isRegisteredMsg: "",
    firstname: "",
    lastname: "",
    password: "",
    copassword: "",
    email: "",
    phoneNumber: "",
    otp: "",
    formSubmit: false,
    otpError: false,
    otpMatchedError: "",
    firstnameError: false,
    lastnameError: false,
    passwordError: false,
    copasswordError: false,
    emailError: false,
    phoneNumberError: false,
    isRegistered: false,
    resendBtnLoad: false,
    emailErrorMsg: "",
    buttonInitialValue: false,
    buttonDesable: false,
    seconds: 47,
    displayResondButton: false
  };

  handleValidation = () => {

    let isError = false;
    if (cn(this.state.firstname)) {
      isError = true;
      this.setState((prevState) => ({
        ...prevState,
        firstnameError: true,
      }));
    }
    if (cn(this.state.lastname)) {
      isError = true;
      this.setState((prevState) => ({
        ...prevState,
        lastnameError: true,
      }));
    }
    if (cn(this.state.password)) {
      isError = true;
      this.setState((prevState) => ({
        ...prevState,
        passwordError: true,
      }));
    }
    if (
      cn(this.state.copassword) ||
      this.state.password !== this.state.copassword
    ) {
      isError = true;
      this.setState((prevState) => ({
        ...prevState,
        copasswordError: true,
      }));
    }
    if (cn(this.state.email) || !emailValidate(this.state.email)) {
      isError = true;
      if (cn(this.state.email)) {
        this.setState({ emailErrorMsg: "Email address can't be blank" })
      }
      else if (!emailValidate(this.state.email)) {
        this.setState({ emailErrorMsg: "Enter valid email address" })
      }

      this.setState((prevState) => ({
        ...prevState,
        emailError: true,
      }));
    }
    let phoneError = false;
    let first_char = this.state.phoneNumber.charAt(0);
    let msg = '';
    let phoneFormatMatch = false;
    if (first_char == "6" || first_char == "7" || first_char == "8" || first_char == "9") {
      phoneFormatMatch = true;
    }
    if (!phoneFormatMatch) {
      isError = true;
      phoneError = true;
      msg = 'Enter valid phone number.';
    }
    if (cn(this.state.phoneNumber) || this.state.phoneNumber.length !== 10) {
      isError = true;
      phoneError = true;
      msg = 'Please enter your 10 digit phone number to proceed!';
    }
    if (phoneError) {
      this.setState((prevState) => ({
        ...prevState,
        phoneNumberError: true,
        phoneNumberErrorMsg: msg
      }));
    }

    return isError;
  };

  handleSubmit = (e) => {
    e.preventDefault();
    const validationError = this.handleValidation();

    if (validationError) return;

    // this.setState((prevState) => ({
    //   ...prevState,
    // }));

    /* saga generate OTP call */
    else {
      this.setState({ buttonInitialValue: true ,displayResondButton:true,seconds:46})
      this.props.generateOTP({
        number: this.state.phoneNumber,
        email: this.state.email,
        callBack: () => {
          this.setState({
            resendBtnLoad: false,
            formSubmit: true,
            buttonInitialValue: false, buttonDesable: true
          });
        },
        callbackerror:() =>{
          this.setState({
            buttonInitialValue: false,
          });
        }
      });
    }


  };

  handleVerify = (e) => {
    e.preventDefault();

    if (cn(this.state.otp)) {
      this.setState((prevState) => ({
        ...prevState,
        otpError: true,
      }));
      return;
    }

    /* Saga verify OTP call */
    const obj = {
      first_name: this.state.firstname,
      last_name: this.state.lastname,
      email: this.state.email,
      phone: this.state.phoneNumber,
      password: this.state.password,
    };
    const reqData = {
      phone: this.state.phoneNumber,
      otp: parseInt(this.state.otp),
    };
    this.props.OTPVerification({
      reqData,
      obj,
      callBack: (res) => {
        if (res.status === "200") {
          this.props.registerCustomer({
            obj,
            callBack: (registerRes) => {
              if (registerRes.status === "200") {
                let register = true,
                  msg = "Successfully registered!";
                signupFormEvent(obj)
                window.location.href =registerRes.url;
                this.setIsRegistered(register, msg);
              } else if (registerRes.status === "409") {
                let register = true,
                  msg = "The account is already registered";
                this.setIsRegistered(register, msg);
              } else {
                let register = false;
                let msg = "something went wrong";
                showToast("Something went wrong please try again later", "top");
                this.setIsRegistered(register, msg);
              }
            },
          });
        } else {
          this.setState({ otpMatchedError: res.message });
        }
      },
    });
  };

  /* If User successfully registers */
  setIsRegistered = (register, msg) => {
    this.setState((prevState) => ({
      ...prevState,
      isRegistered: register,
      isRegisteredMsg: msg,
      formSubmit: false,
      firstname: "",
      lastname: "",
      password: "",
      copassword: "",
      email: "",
      phoneNumber: "",
      otp: ""
    }));
  };

  onChangeHandler = (e) => {
    this.setState({ buttonDesable: false, buttonInitialValue: false });
    const { name, value } = e.target;
    const nameError = name + "Error";
    if (name === "phoneNumber") {
      let withoutSpaces = value.substring(0, 10);
      let withoutSpaces1 = withoutSpaces.replace(/\s+/g, "");
      let withoutSpaces2 = withoutSpaces1.replace(/[^0-9]/g, "");
      this.setState((prevState) => ({
        ...prevState,
        [name]: withoutSpaces2,
        [nameError]: false,
      }));
    } else {
      this.setState((prevState) => ({
        ...prevState,
        [name]: value,
        [nameError]: false,
        otpMatchedError: "",
      }));
    }
  };

  componentDidUpdate(prevProps, prevState) {
    if (prevState.formSubmit !== this.state.formSubmit) {
      window.scrollTo(0, 0);
    }
    let time;
    if (prevState.seconds !== this.state.seconds) {
      if (this.state.seconds > 0) {
        this.time = setTimeout(() => this.setState({ seconds: this.state.seconds - 1 }), 1000);
        return () => clearTimeout(this.time);
      }
      if (this.state.seconds === 0) {
        this.setState({ displayResondButton: false })
      }
    }


  }
  render() {
    let formFields = (
      <div className="text-center ">
        <div className="col-sm-6">
          <input
            type="text"
            name="firstname"
            placeholder="First Name"
            onChange={this.onChangeHandler}
            value={this.state.firstname}
          />
          {this.state.firstnameError && (
            <p className="error">First name is required!</p>
          )}
        </div>
        <div className="col-sm-6">
          <input
            type="text"
            name="lastname"
            placeholder="Last Name"
            onChange={this.onChangeHandler}
            value={this.state.lastname}
          />
          {this.state.lastnameError && (
            <p className="error">Last name is required!</p>
          )}
        </div>
        <div className="col-sm-6">
          <input
            type="password"
            name="password"
            placeholder="Password"
            onChange={this.onChangeHandler}
            value={this.state.password}
          />
          {this.state.passwordError && (
            <p className="error">Please enter password!</p>
          )}
        </div>
        <div className="col-sm-6">
          <input
            type="password"
            name="copassword"
            placeholder="Confirm Password"
            onChange={this.onChangeHandler}
            value={this.state.copassword}
          />
          {this.state.copasswordError && (
            <p className="error">Passwords do not match!</p>
          )}
        </div>
        <div className="col-sm-12">
          <input
            type="email"
            name="email"
            placeholder="E-mail address"
            onChange={this.onChangeHandler}
            value={this.state.email}
          />
          {this.state.emailError && (
            <p className="error">{this.state.emailErrorMsg}</p>
          )}
        </div>
        <div className="col-sm-12">
          <input
            type="number"
            name="phoneNumber"
            placeholder="Phone number"
            onChange={this.onChangeHandler}
            onPaste={this.onChangeHandler}
            value={this.state.phoneNumber}
          />
          {this.state.phoneNumberError && (
            <p className="error">{this.state.phoneNumberErrorMsg}</p>
          )}
        </div>
        <button
          type="submit"
          className="btn signUp-btn"
          onClick={this.handleSubmit}
          disabled={this.state.buttonDesable}
        >
          {this.state.buttonInitialValue ? "Loading..." : "Sign up"}
        </button>
      </div>
    );

    let OTPform = (
      <div>
        <p>Verify {this.state.phoneNumber}</p>
        <div>
          <p>
            Please enter the verification code sent to {this.state.phoneNumber}.
            <span
              className="wrong-number"
              onClick={() => {
                clearTimeout(this.time);
                this.setState({ formSubmit: false, otp: "", displayResondButton: false });
              }}
            >
              Wrong number?
            </span>
          </p>
        </div>
        <div className="otp-input">
          <input
            type="text"
            placeholder="Enter OTP"
            name="otp"
            onChange={this.onChangeHandler}
            value={this.state.otp}
          />
          
            {this.state.displayResondButton ? <span   className={`resend-otp-time`}>Resend OTP in {this.state.seconds}s</span> :<button
            className={`resend-otp-btn`}
            onClick={(e) => {
              e.preventDefault();
              this.setState({ seconds: 45, displayResondButton: true });

              this.handleSubmit(e)
            }}
          > Resend OTP
          </button>
  }
        </div>
        {this.state.otpError && <p className="error">OTP cannot be empty!</p>}
        {this.state.otpMatchedError && (
          <p className="error">{this.state.otpMatchedError}</p>
        )}
        <button className="btn signUp-btn" onClick={this.handleVerify}>
          Verify
        </button>
      </div>
    );

    let successRegister = (
      <div className="success-alert">
        {this.state.isRegisteredMsg} <a href="/account/login">Login here</a>
      </div>
    );
    return (
      <div className="account-template">
        <div className="container">
          <div className="register-page">
            {this.state.isRegistered && successRegister}
            <h3 className="title">Hello NoiseMaker!</h3>
            <form className="register-form">
              {this.state.formSubmit ? OTPform : formFields}
              <div className="sign-in-text">
                Already a Noisemaker ? <a href="/account/login">Sign in</a>
              </div>
            </form>
            <h3 className="or">Or</h3>
            <div>
              <div id="oxi-social-login"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  generateOTP: (data) => dispatch(generateOTP(data)),
  OTPVerification: (data) => dispatch(OTPVerification(data)),
  registerCustomer: (data) => dispatch(registerCustomer(data)),
});

const mapStateToProps = (state) => ({
  isRegistered: state.account.isRegistered,
});

export default connect(mapStateToProps, mapDispatchToProps)(Register);
