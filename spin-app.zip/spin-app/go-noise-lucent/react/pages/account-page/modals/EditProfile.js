import React, { Component } from 'react';
import { connect } from 'react-redux';
import Icons from '../../../components/Icons';
import CustomInput from './CustomInput';
import { updateProfileInfo } from '../../../redux/account/accountActions';

class EditProfile extends Component {
 state = {
  btnLoading: false,   
  first_name: this.props.accountInfo.first_name
   ? this.props.accountInfo.first_name
   : '',
  last_name: this.props.accountInfo.last_name
   ? this.props.accountInfo.last_name
   : '',
  phone: this.props.accountInfo.phone
   ? this.props.accountInfo.phone.replace('+91', '')
   : '',
  email: this.props.accountInfo.email ? this.props.accountInfo.email : '',
  first_nameError: false,
  last_nameError: false,
  phoneErrorMessage: '',
  emailError: false,
 };

 constructor(props) {
  super(props);
  this.handleChange = this.handleChange.bind(this);
 }

 handleChange(element) {
  const { name, value } = element.target;
  const nameError = name + 'Error';
  if (name === 'phone') {
    if (value.length <= 10) {
      this.setState({ [name]: value,[nameError]: false,});
    }
  }
 else{
  this.setState(prevState => ({
    ...prevState,
    [name]: value,
    [nameError]: false,
   }));
 }
 }

 handleSave = () => {
  const validationError = this.handleValidation();

  if (validationError) return;
  else {
   const reqObj = {
    first_name: this.state.first_name,
    last_name: this.state.last_name,
    phone: this.state.phone,
    email: this.state.email,
   };
   this.setState({btnLoading:true},() =>{
    this.props.updateProfileInfo({data:reqObj,callBack:()=>{
        this.setState({btnLoading:false},() =>{
            this.props.handleEditProfileModal(false);
        })
    }});
   })
   /* Saga Async action call */
  }
 };

 handleValidation = () => {
  let isError = false;

  if (cn(this.state.first_name)) {
   isError = true;
   this.setState(prevState => ({
    ...prevState,
    first_nameError: true,
   }));
  }
  if (cn(this.state.last_name)) {
   isError = true;
   this.setState(prevState => ({
    ...prevState,
    last_nameError: true,
   }));
  }


    let phoneErrorCheck = false;
    let first_char = this.state.phone.charAt(0);
    let msg = '';
    let phoneFormatMatch = false;
    if (first_char == "6" || first_char == "7" || first_char == "8" || first_char == "9") {
      phoneFormatMatch = true;
    }
    if (!phoneFormatMatch) {

        phoneErrorCheck = true;
      msg = 'Please enter correct phone number starting from 6/7/8/9';
    }
    if (cn(this.state.phone) || this.state.phone.length !== 10) {

        phoneErrorCheck = true;
      msg = 'Please enter your 10 digit phone number to proceed!';
    }
    if (phoneErrorCheck) {
        isError = true;
      this.setState((prevState) => ({
        ...prevState,
        phoneErrorMessage: msg
      }));
    }
  if (cn(this.state.email)) {
   isError = true;
   this.setState(prevState => ({
    ...prevState,
    emailError: true,
   }));
  }
  return isError;
 };

 render() {
  return (
   <div className='edit-profile-popup'>
    <div className='modal-body'>
     <div className='modal-header'>
      <h4 className='text-center'>Edit Profile Information
      <div className='close-modal' onClick={() => { this.props.handleEditProfileModal(false); }}>
       <Icons icon='close' />
      </div>
      </h4>
     </div>
     <div className='modal-content'>
      <div className='flex-view-xs space'>
       <CustomInput type='text' placeholder='First Name' name='first_name' value={this.state.first_name} onChange={this.handleChange} className='col-xs-12 col-sm-6' error={this.state.first_nameError} />
       <CustomInput type='text' placeholder='Last Name' name='last_name' value={this.state.last_name} onChange={this.handleChange} className='col-xs-12 col-sm-6' error={this.state.last_nameError} />
       <CustomInput type='email' placeholder='Email address' name='email' value={this.state.email} onChange={this.handleChange} className='col-xs-12 hide' error={this.state.emailError} />
       <CustomInput type='number' placeholder='Phone Number' name='phone' value={parseInt(this.state.phone)} onChange={this.handleChange} className='col-xs-12' error={this.state.phoneError} />
       {
           this.state.phoneErrorMessage?  <p className="error">{this.state.phoneErrorMessage}</p>:""
       }
     
       <div className='col-xs-12 text-center'>
        <button className={`btn${this.state.btnLoading ? ' loading' :''}`} onClick={() => {this.handleSave();}}>Save</button>
       </div>
      </div>
     </div>
    </div>
   </div>
  );
 }
}

const mapStateToProps = state => ({
 accountInfo: state.account.profile,
});

const mapDispatchToProps = dispatch => ({
 updateProfileInfo: data => dispatch(updateProfileInfo(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(EditProfile);
