import React, { Component } from 'react';
import { connect } from 'react-redux';
import Icons from '../../../../components/Icons';
import CustomInput from './CustomInput';
import { updateProfileInfo } from '../../../../redux/account/accountActions';

class ChangePassword extends Component {
 state = {
  btnLoading: false,   
  first_name: this.props.accountInfo.first_name
   ? this.props.accountInfo.first_name
   : '',
  last_name: this.props.accountInfo.last_name
   ? this.props.accountInfo.last_name
   : '',
  phone: this.props.accountInfo.phone
   ? this.props.accountInfo.phone.replace('+91', '')
   : '',
  email: this.props.accountInfo.email ? this.props.accountInfo.email : '',
  first_nameError: false,
  last_nameError: false,
  phoneError: false,
  emailError: false,
 };

 constructor(props) {
  super(props);
  this.handleChange = this.handleChange.bind(this);
 }

 handleChange(element) {
  const { name, value } = element.target;
  const nameError = name + 'Error';
  this.setState(prevState => ({
   ...prevState,
   [name]: value,
   [nameError]: false,
  }));
 }

 handleSave = () => {
  const validationError = this.handleValidation();

  if (validationError) return;
  else {
   const reqObj = {
    first_name: this.state.first_name,
    last_name: this.state.last_name,
    phone: this.state.phone,
    email: this.state.email,
   };
   this.setState({btnLoading:true},() =>{
    this.props.updateProfileInfo({data:reqObj,callBack:()=>{
        this.setState({btnLoading:false},() =>{
            this.props.handleEditProfileModal(false);
        })
    }});
   })
   /* Saga Async action call */
  }
 };

 handleValidation = () => {
  let isError = false;

  if (cn(this.state.first_name)) {
   isError = true;
   this.setState(prevState => ({
    ...prevState,
    first_nameError: true,
   }));
  }
  if (cn(this.state.last_name)) {
   isError = true;
   this.setState(prevState => ({
    ...prevState,
    last_nameError: true,
   }));
  }
  if (cn(this.state.phone)) {
   isError = true;
   this.setState(prevState => ({
    ...prevState,
    phoneError: true,
   }));
  }

  if (cn(this.state.email)) {
   isError = true;
   this.setState(prevState => ({
    ...prevState,
    emailError: true,
   }));
  }
  return isError;
 };

 render() {
  return (
   <div className='edit-profile-popup'>
    <div className='modal-body'>
     <div className='modal-header'>
      <h4 className='text-center'>Edit Profile Information
      <div className='close-modal' onClick={() => { this.props.handleEditProfileModal(false); }}>
       <Icons icon='close' />
      </div>
      </h4>
     </div>
     <div className='modal-content'>
      <div className='flex-view-xs space'>
       <CustomInput type='text' placeholder='First Name' name='first_name' value={this.state.first_name} onChange={this.handleChange} className='col-xs-12 col-sm-6' error={this.state.first_nameError} />
       <CustomInput type='text' placeholder='Last Name' name='last_name' value={this.state.last_name} onChange={this.handleChange} className='col-xs-12 col-sm-6' error={this.state.last_nameError} />
       <CustomInput type='email' placeholder='Email address' name='email' value={this.state.email} onChange={this.handleChange} className='col-xs-12 hide' error={this.state.emailError} />
       <CustomInput type='number' placeholder='Phone Number' name='phone' value={parseInt(this.state.phone)} onChange={this.handleChange} className='col-xs-12' error={this.state.phoneError} />
       <div className='col-xs-12 text-center'>
        <button className={`btn${this.state.btnLoading ? ' loading' :''}`} onClick={() => {this.handleSave();}}>Save</button>
       </div>
      </div>
     </div>
    </div>
   </div>
  );
 }
}

const mapStateToProps = state => ({
 accountInfo: state.account.account,
});

const mapDispatchToProps = dispatch => ({
 updateProfileInfo: data => dispatch(updateProfileInfo(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ChangePassword);
