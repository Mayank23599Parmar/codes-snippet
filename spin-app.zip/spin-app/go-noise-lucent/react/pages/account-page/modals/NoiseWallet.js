import React from 'react';

class NoiseWallet extends React.Component {
 render() {
  return <h1>Noise Wallet</h1>;
 }
}

export default NoiseWallet;
