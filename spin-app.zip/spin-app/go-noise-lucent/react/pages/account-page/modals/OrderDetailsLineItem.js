import React, { Component } from "react";
import SrcSet from "../../../components/SrcSet";
import {fetchProductTitle,formatMoney} from '../../../components/Helper';
class OrderDetailsLineItem extends Component {
  findImage = () =>{
    let image = '';
    const {product_data,variant_id} = this.props.item;
    if(product_data.error){
      return '';
    }
    let img = product_data.images.find((image)=>image.variant_ids.includes(variant_id));
    if(cn(img)){
      // image = product_data.image.src;
      if(!cn(product_data.image)){
        image = product_data.image.src;
      }
    }else{
      image = img.src;
    }
    return image;
  }
  render() {
    const { order, item } = this.props;
    const {product_data,quantity } = item;
    let tags = product_data.tags;
    let title = item.title;
    if(!cn(tags)){
      tags = tags.split(',');
      let newTitle = fetchProductTitle(tags);
      if(!cn(newTitle)){
        title = newTitle;
      }
    }
    let image = this.findImage();
    if(cn(image)){
      image = pwa.noImage;
    }
    return (
        <div className="orders-list">
          <div className="order-content">
            <div className="item-details-container">
              <div className="flex-view-xs space">
                <div className="col-sm-9">
                  <div className="order-main-details">
                    <div className="order-img">
                      <SrcSet src={image} />
                    </div>
                    <div className="order-details">
                      <h3>{title}</h3>
                      <div className="item-details">
                        <p>{item.variant_title}</p>
                        <div className="item-qty">
                          <span className="item--title">Qty: </span>{" "}
                          <span>{quantity}</span>
                        </div>
                        <div className="item-price">
                          <span className="item--title">Price : </span>{" "}
                          <span>{formatMoney(item.price)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-3 col-xs-12">
                  <div className="order-status text-right">
                    <h6>Tracking Details</h6>
                    <div >
                      <p>Tracking id</p>
                      <span>
                        {order.id}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    );
  }
}

export default OrderDetailsLineItem;
