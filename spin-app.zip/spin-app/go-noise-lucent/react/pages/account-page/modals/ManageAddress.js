import React from "react";
import { connect } from "react-redux";
import AddAddress from "./AddAddress";
import Loader from "../../../components/loader/loader";
import {
  deleteAddress,
  defaultAddress,
} from "../../../redux/account/accountActions";

class ManageAddress extends React.Component {
  state = {
    openAddressModal: false,
    openEditAddressModal: false,
    editAddress: {},
  };

  handleAddressModal = (bool) => {
    this.setState((prevState) => ({
      ...prevState,
      openAddressModal: bool,
    }));
  };

  handleEditAddressModal = (bool) => {
    this.setState((prevState) => ({
      ...prevState,
      openEditAddressModal: bool,
    }));
  };

  handleEditAddress = (address) => {
    this.setState((prevState) => ({
      ...prevState,
      editAddress: address,
      openEditAddressModal: true,
    }));
  };

  handleDeleteAddress = (Id) => {
    /* Saga Async Call */
    this.props.deleteAddress(Id);
  };

  handleDefaultAddress = (Id) => {
    /* Saga Async Call */
    this.props.defaultAddress(Id);
  };

  render() {
    const { addressArray, addressLoading } = this.props;

    if (addressLoading) {
      return (
        <div className="account-info-loading">
          <Loader />
        </div>
      );
    }
    let addressElement = addressArray.map((address, idx) => {
      return (
          <div className="address-section col-sm-6 col-xs-12">
            <div className="address-section-wrap">
            <div className="address-title clearfix"> 
              <h4>{address.name}</h4>
              <div className="address-update-links">
                <span className="edit-link" onClick={() =>this.handleEditAddress(address)} >
                  Edit
                </span>
                {!address.default && (
                  <span className="remove-link" onClick={() => this.handleDeleteAddress(address.id)}>
                    Remove
                  </span>
                )}
              </div>
            </div>
            <div className="address-body">
              <p>{address.address1}</p>
              <p>{address.address2}</p>
              <p>
                {address.city}, {address.province}
              </p>
              <p>
                {address.country}, {address.zip}
              </p>
            </div>
            <div className="address-footer">
              <p>Phone: {address.phone}</p>
              {address.default ? (
                <span className="default-address">Default</span>
              ) : (
                <span className="set-default-address" onClick={() => this.handleDefaultAddress(address.id) }>
                  Set as default
                </span>
              )}
            </div>
            </div>
          </div>
      );
    });
    return (
      <>
        {this.state.openAddressModal && (
          <AddAddress handleAddressModal={this.handleAddressModal} />
        )}
        {this.state.openEditAddressModal && (
          <AddAddress handleAddressModal={this.handleEditAddressModal} address={this.state.editAddress} />
        )}
        <div className="manage-address">
          <div className="manage-address-title">
            <h1>Manage Addresses</h1>
            <span className="add-address" onClick={() => this.handleAddressModal(true)}>
              Add a new address <span>+</span>
            </span>
          </div>
          <div className="flex-view-xs">
            {addressArray.length > 0 && addressElement}
          </div>
        </div>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  addressLoading: state.account.addressLoading,
  addressArray: state.account.profile.addresses,
});

const mapDispatchToProps = (dispatch) => ({
  deleteAddress: (data) => dispatch(deleteAddress(data)),
  defaultAddress: (data) => dispatch(defaultAddress(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageAddress);
