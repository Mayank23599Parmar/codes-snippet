import React, { Component } from 'react';

class CustomInput extends Component {
 render() {
  const {
   type,
   placeholder,
   name,
   value,
   onChange,
   className,
   error,
   errorMessageForPhone
  } = this.props;

  return (
   <div className={className}>
    <input
     type={type}
     placeholder={placeholder}
     name={name}
     value={value}
     onChange={onChange}
    />
    {error && <p className='error'>{placeholder} cannot be empty!</p>}
    {errorMessageForPhone && <p className='error'>{errorMessageForPhone}</p>}
   </div>
  );
 }
}

export default CustomInput;
