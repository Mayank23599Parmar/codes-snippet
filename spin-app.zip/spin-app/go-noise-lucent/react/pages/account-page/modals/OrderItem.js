import React, { Component } from 'react';
import LineItem from './LineItem';
import Icons from '../../../components/Icons';
import { setSelectedOrderData } from '../../../redux/account/accountActions';
import { connect } from 'react-redux';

class OrderItem extends Component {

 render() {
  const { item } = this.props;
  let {name,line_items,id} = item;
  return (
   <>
    <div className='order-header'>
     <div className='flex-view-xs space-between' style={{ width: '100%' }}>
      <h6>Order ID : {name}</h6>
      <span onClick={() => this.props.setSelectedOrderData(item)}>
       Order details <Icons icon='rightArrow' />
      </span>
     </div>
    </div>
    <div className='order-container'>
     <div className='flex-view-xs middle'>
     <div className='col-sm-8 col-md-8 col-xs-12'>
      {line_items.map((line_item, key) => (
       <LineItem item={line_item} order={item} key={key} />
      ))}
      </div>
      <div className='col-sm-8 col-md-4 col-xs-12'>
       <div className='order-help'>
        <ul className='order-links flex-view'>
         {
          <>
           <li className='col-xs-6 col-md-12'>
            <a href={`https://gonoise.clickpost.in/?order_id=${id}`}>
             Track Order
             <Icons icon='rightArrow' />
            </a>
           </li>
           <li className='col-xs-6 col-md-12'>
            <a target="_blank" href="https://support.gonoise.in/complaintregistration">
             Raise Complaint
             <Icons icon='rightArrow' />
            </a>
           </li>
          </>
         }
        </ul>
       </div>
      </div>
     </div>
    </div>
   </>
  );
 }
}

const mapDispatchToProps = dispatch => ({
    setSelectedOrderData: data => dispatch(setSelectedOrderData(data)),
});

export default connect(null, mapDispatchToProps)(OrderItem);
