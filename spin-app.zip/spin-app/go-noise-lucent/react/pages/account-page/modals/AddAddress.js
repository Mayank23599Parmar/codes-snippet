import React, { Component } from "react";
import { connect } from "react-redux";
import Icons from "../../../components/Icons";
import CustomInput from "./CustomInput";
import {
  addAddress,
  setLoader,
  editAddress,
} from "../../../redux/account/accountActions";
class AddAddress extends Component {
  state = {
    first_name:
      this.props.address && this.props.address.first_name !== null
        ? this.props.address.first_name
        : "",
    last_name:
      this.props.address && this.props.address.last_name !== null
        ? this.props.address.last_name
        : "",
    phone:
      this.props.address && this.props.address.phone !== null
        ? this.props.address.phone.replace(" ", "")
        : "",
    address1:
      this.props.address && this.props.address.address1 !== null
        ? this.props.address.address1
        : "",
    address2:
      this.props.address && this.props.address.address2 !== null
        ? this.props.address.address2
        : "",
    city:
      this.props.address && this.props.address.city !== null
        ? this.props.address.city
        : "",
    state:
      this.props.address && this.props.address.province !== null
        ? this.props.address.province
        : "",
    country:
      this.props.address && this.props.address.country !== null
        ? this.props.address.country
        : "",
    pincode:
      this.props.address && this.props.address.zip !== null
        ? this.props.address.zip
        : "",
    first_nameError: false,
    last_nameError: false,
    phoneError: false,
    address1Error: false,
    cityError: false,
    stateError: false,
    countryError: false,
    pincodeError: false,
  };

  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(element) {
    const { name, value } = element.target;
    const nameError = name + "Error";
    if (name === 'phone') {
      if (value.length <= 10) {
        this.setState({ [name]: value, phoneErrorMessage: '' });
      }
    }else{
      if (name !== "address2") {
        this.setState((prevState) => ({
          ...prevState,
          [name]: value,
          [nameError]: false,
        }));
      } else {
        this.setState((prevState) => ({
          ...prevState,
          address2: value,
        }));
      }
    }
   
  }

  handleSave = () => {
    const validationError = this.handleValidation();

    if (validationError) return;
    else {
      const reqObj = {
        first_name: this.state.first_name,
        last_name: this.state.last_name,
        phone: this.state.phone,
        address1: this.state.address1,
        address2: this.state.address2,
        city: this.state.city,
        state: this.state.state,
        country: this.state.country,
        pincode: this.state.pincode,
        phoneErrorMessage:""
      };

      /* Saga Async action call */
      /* If Edit Address modal is called then we dispatch editAddress action  */
      this.props.address
        ? this.props.editAddress({ data: reqObj, id: this.props.address.id })
        : this.props.addAddress(reqObj);
      this.props.handleAddressModal(false);
    }
  };

  handleValidation = () => {
    let isError = false;

    if (cn(this.state.first_name)) {
      isError = true;
      this.setState((prevState) => ({
        ...prevState,
        first_nameError: true,
      }));
    }
    if (cn(this.state.last_name)) {
      isError = true;
      this.setState((prevState) => ({
        ...prevState,
        last_nameError: true,
      }));
    }
    let phoneErrorCheck = false;
    let first_char = this.state.phone.charAt(0);
    let msg = '';
    let phoneFormatMatch = false;
    if (first_char == "6" || first_char == "7" || first_char == "8" || first_char == "9") {
      phoneFormatMatch = true;
    }
    if (!phoneFormatMatch) {

        phoneErrorCheck = true;
      msg = 'Please enter correct phone number starting from 6/7/8/9';
    }
    if (cn(this.state.phone) || this.state.phone.length !== 10) {

        phoneErrorCheck = true;
      msg = 'Please enter your 10 digit phone number to proceed!';
    }
    if (phoneErrorCheck) {
        isError = true;
      this.setState((prevState) => ({
        ...prevState,
        phoneErrorMessage: msg
      }));
    }
    if (cn(this.state.address1)) {
      isError = true;
      this.setState((prevState) => ({
        ...prevState,
        address1Error: true,
      }));
    }
    if (cn(this.state.city)) {
      isError = true;
      this.setState((prevState) => ({
        ...prevState,
        cityError: true,
      }));
    }
    if (cn(this.state.state)) {
      isError = true;
      this.setState((prevState) => ({
        ...prevState,
        stateError: true,
      }));
    }
    if (cn(this.state.country)) {
      isError = true;
      this.setState((prevState) => ({
        ...prevState,
        countryError: true,
      }));
    }
    if (cn(this.state.pincode)) {
      isError = true;
      this.setState((prevState) => ({
        ...prevState,
        pincodeError: true,
      }));
    }

    return isError;
  };

  render() {
    return (
      <div className="add-address-popup">
        <div className="modal-body">
          <div className="modal-header">
            <h3 className="text-center">
              {this.props.address ? "Edit Address" : "Add New Address"}
                <div className="close-modal"onClick={() => {this.props.handleAddressModal(false);}}>
                <Icons icon="close" />
              </div>
            </h3>
          </div>
          <div className="modal-content">
            <div className="flex-view-xs space">
              <CustomInput
                type="text"
                placeholder="First Name"
                name="first_name"
                value={this.state.first_name}
                onChange={this.handleChange}
                className="col-xs-6"
                error={this.state.first_nameError}
              />
              <CustomInput
                type="text"
                placeholder="Last Name"
                name="last_name"
                value={this.state.last_name}
                onChange={this.handleChange}
                className="col-xs-6"
                error={this.state.last_nameError}
               
              />
              <CustomInput
                type="number"
                placeholder="Phone Number"
                name="phone"
                value={this.state.phone}
                onChange={this.handleChange}
                className="col-xs-6"
                error={this.state.phoneError}
                errorMessageForPhone={this.state.phoneErrorMessage}
              />
              
            
              
              <CustomInput
                type="text"
                placeholder="Address line 1"
                name="address1"
                value={this.state.address1}
                onChange={this.handleChange}
                className="col-xs-6"
                error={this.state.address1Error}
              />
              <CustomInput
                type="text"
                placeholder="Address line 2"
                name="address2"
                value={this.state.address2}
                onChange={this.handleChange}
                className="col-xs-12"
                error={false}
              />
              <CustomInput
                type="text"
                placeholder="City"
                name="city"
                value={this.state.city}
                onChange={this.handleChange}
                className="col-xs-6"
                error={this.state.cityError}
              />
              <CustomInput
                type="text"
                placeholder="State / Province"
                name="state"
                value={this.state.state}
                onChange={this.handleChange}
                className="col-xs-6"
                error={this.state.stateError}
              />
              <CustomInput
                type="text"
                placeholder="Country"
                name="country"
                value={this.state.country}
                onChange={this.handleChange}
                className="col-xs-6"
                error={this.state.countryError}
              />
              <CustomInput
                type="text"
                placeholder="ZIP Code"
                name="pincode"
                value={this.state.pincode}
                onChange={this.handleChange}
                className="col-xs-6"
                error={this.state.pincodeError}
              />
              <div className="col-xs-12 text-center">
                <button className="btn" onClick={() => this.handleSave()}> Save </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  addAddress: (data) => dispatch(addAddress(data)),
  editAddress: (data) => dispatch(editAddress(data)),
  setLoader: (data) => dispatch(setLoader(data)),
});

export default connect(null, mapDispatchToProps)(AddAddress);
