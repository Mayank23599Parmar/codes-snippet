import React from 'react';
import { connect } from 'react-redux';
import { getOrders } from '../../../redux/account/accountActions';
import OrderItem from './OrderItem';
import Loader from '../../../components/loader/loader';
class Orders extends React.Component {
 componentDidMount() {
  if (!cn(simply.customerId)) {
   this.props.getOrders(simply.customerId);
  }
 }

 dateFormatter(createdAt) {
  const monthNames = [
   'January',
   'February',
   'March',
   'April',
   'May',
   'June',
   'July',
   'August',
   'September',
   'October',
   'November',
   'December',
  ];

  let date = new Date(createdAt);
  let orderDate = date.getDate();
  let orderMonth = monthNames[date.getMonth()];
  let orderYear = date.getFullYear();

  return `${orderMonth} ${orderDate}, ${orderYear}`;
 }

 render() {
  const { orderArray, loading } = this.props;

    if(loading){
        return (<div className='account-info-loading'>
        <Loader />
        </div>)
    }
  return (
   <div className='order-section'>
    <div className='my-order-title'>
     <h1>My Orders</h1>
     <div className='filter'>
      <span>Filter :</span>
      <select>
       <option defaultValue>All Orders</option>
      </select>
     </div>
    </div>
     {orderArray && orderArray.length > 0 && orderArray.map((item, key) => <OrderItem item={item} key={key} />)}
   </div>
  );
 }
}

const mapStateToProps = state => ({
 loading: state.account.orders.loading,
 orderArray: state.account.orders.orderData,
});

const mapDispatchToProps = dispatch => ({
 getOrders: data => dispatch(getOrders(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Orders);
