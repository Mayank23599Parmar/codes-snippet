import React, { Component } from "react";
import SrcSet from "../../../components/SrcSet";
import {fetchProductTitle,formatMoney} from '../../../components/Helper';
class LineItem extends Component {
  dateFormatter(createdAt) {
    const monthNames = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];

    let date = new Date(createdAt);
    let orderDate = date.getDate();
    let orderMonth = monthNames[date.getMonth()];
    let orderYear = date.getFullYear();

    return `${orderMonth} ${orderDate}, ${orderYear}`;
  }
  findImage = () =>{
    let image = '';
    const {product_data,variant_id} = this.props.item;
    if(product_data.error){
      return '';
    }
    let img = product_data.images.find((image)=>image.variant_ids.includes(variant_id));
    if(cn(img)){
      if(!cn(product_data.image)){
        image = product_data.image.src;
      }
    }else{
      image = img.src;
    }
    return image;
  }
  render() {
    const { order, item } = this.props;
    const {product_data,quantity } = item;
    let tags = product_data.tags;
    let title = item.title;
    let variant_title = "";
    if(item.variant_title){
      variant_title = item.variant_title;
    }
    if(!cn(tags)){
      tags = tags.split(',');
      let newTitle = fetchProductTitle(tags);
      if(!cn(newTitle)){
        title = newTitle;
      }
    }
    let image = this.findImage();
    if(cn(image)){
      image = pwa.noImage;
    }
    return (
      <div className="">
        <div className="orders-list">
          <div className="order-content">
            <div className="item-details-container">
              <div className="flex-view-xs space">
                <div className="col-sm-9">
                  <div className="order-main-details">
                    <div className="order-img">
                      <SrcSet src={image} />
                    </div>
                    <div className="order-details">
                      <h3>{title}</h3>
                      <div className="item-details">
                        {variant_title && <p>{variant_title}</p>}
                        <div className="item-qty">
                          <span className="item--title">Qty: </span>{" "}
                          <span>{quantity}</span>
                        </div>
                        <div className="item-price">
                          <span className="item--title">Price : </span>{" "}
                          <span>{formatMoney(item.price)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-3 col-xs-12">
                  <div className="order-status">
                    <div>
                      <p>Order Date</p>
                      <span>
                        {this.dateFormatter(order.created_at)}
                      </span>
                    </div>
                    <div>
                      <p>Order Status</p>
                      <span>{"status"}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default LineItem;
