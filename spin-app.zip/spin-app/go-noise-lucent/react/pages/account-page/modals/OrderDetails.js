import React, { Component } from "react";
import Icons from "../../../components/Icons";
import { connect } from "react-redux";
import { formatMoney } from "../../../components/Helper";
import OrderDetailsLineItem from "./OrderDetailsLineItem";
class OrderDetails extends Component {
  componentDidMount() {
    /* Saga Async Call */
  }
  dateFormatter(createdAt) {
    const monthNames = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];

    let date = new Date(createdAt);
    let orderDate = date.getDate();
    let orderMonth = monthNames[date.getMonth()];
    let orderYear = date.getFullYear();

    return `${orderMonth} ${orderDate}, ${orderYear}`;
  }
  render() {
    const { order } = this.props;
    const {
      name,
      id,
      created_at,
      gateway,
      confirmed,
      shipping_address,
      total_price,
      total_tax,
      subtotal_price,
      line_items,
    } = order;
    let subtotal = parseInt(total_price) * 100 - parseInt(total_tax) * 100;
    return (
      <div className="order-details-section">
        <div className="order-details-title">
          <h1>Order Details</h1>
          <a className="hide">
            Download Invoice <Icons icon="rightArrow" />
          </a>
        </div>
        <div className="flex-view-xs">
          <div className="col-md-4 col-sm-12">
            <div className="order-info">
              <h5>Order ID : {name}</h5>
              <p>Order Date : {this.dateFormatter(created_at)}</p>
              <p>Mode of Payment : {gateway}</p>
              <p>Delivery Option :</p>
            </div>
          </div>
          <div className="col-md-4 col-sm-12">
            <div className="shipping-info">
              <div className="shipping-info--address">
                <h6>Shipping Address</h6>
                <h5>{shipping_address.name}</h5>
                <p>
                  {shipping_address.address1} {shipping_address.address2}
                </p>
                <p>
                  {shipping_address.city},{shipping_address.state}
                </p>
                <p>
                  {" "}
                  {shipping_address.country}, {shipping_address.zip}
                </p>
              </div>
              <p>Phone : {shipping_address.phone}</p>
            </div>
          </div>
          <div className="col-md-4 col-sm-12">
            <div className="summary-info">
              <div className="summary-info-wrapper">
                <h6>Shipping Address</h6>
                <div className="flex-view-xs space-between">
                  <span className="label">Subtotal</span>
                  <span className="value">{formatMoney(subtotal)}</span>
                </div>
                <div className="flex-view-xs space-between">
                  <span className="label">Shipping</span>
                  <span className="value">Free</span>
                </div>
                <div className="flex-view-xs space-between">
                  <span className="label">Estimated Tax</span>
                  <span className="value">
                    {formatMoney(parseInt(total_tax) * 100)}
                  </span>
                </div>
                <div className="main-total">
                  <div className="flex-view-xs space-between">
                    <span className="label">Estimated Tax</span>
                    <span className="value">
                      {formatMoney(parseInt(total_price) * 100)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="line-items">
            {line_items.map((item)=> <div className="flex-view-xs line-item"><OrderDetailsLineItem item={item} order={order} /></div>)}
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  order: state.account.orders.setSelectedOrderData,
});
export default connect(mapStateToProps, null)(OrderDetails);
