import React from "react";
import Icons from "../../../components/Icons";
import Srcset from "../../../components/SrcSet";
import { connect } from "react-redux";
import Loader from "../../../components/loader/loader";
import {
  fetchAccountInfo,
  setAccountTab,
} from "../../../redux/account/accountActions";
import EditProfile from "./EditProfile";
class PersonalInformation extends React.Component {
  state = {
    openEditProfileUpdateModal: false,
  };

  componentDidMount() {
    if (!cn(simply.customerId)) {
      this.props.fetchAccountInfo(simply.customerId);
    }
  }

  handleEditProfileModal = (bool) => {
    this.setState((prevState) => ({
      ...prevState,
      openEditProfileUpdateModal: bool,
    }));
  };

  render() {
    const { loading, accountInfo, setAccountTab } = this.props;

    if (!simply.customerLoggedin) {
      window.location.href = "/login";
    } else if (loading) {
      return (
        <div className="account-info-loading">
          <Loader />
        </div>
      );
    }

    return (
      <>
        {this.state.openEditProfileUpdateModal && (
          <EditProfile handleEditProfileModal={this.handleEditProfileModal} />
        )}
        <div className="personal-information">
          <h1>Account</h1>
          <div className="row">
            <div className="col-sm-6">
              <div className="personal-info-wrapper">
                <div className="personal-info-title">
                  <h5>Personal Information</h5>
                  <span
                    className="edit-info"
                    onClick={() => this.handleEditProfileModal(true)}
                  >
                    Edit Info
                  </span>
                </div>
                {accountInfo.first_name && accountInfo.last_name && (
                  <input disabled value={accountInfo.first_name + " " + accountInfo.last_name} />
                )}
                {accountInfo.phone && (
                  <input disabled value={accountInfo.phone} />
                )}
                {accountInfo.email && (
                  <input disabled value={accountInfo.email} />
                )}
                <div className="flex-view space-between">
                  <a href="/account/logout" className="change-password">
                    Sign out
                  </a>
                  {/* <a className="hide change-password">Change password</a> */}
                </div>
              </div>
            </div>
            <div className="col-sm-6">
              <div className="sub-pages-section ">
                <div className="tabs hide">
                  <div className="title" onClick={() => setAccountTab("pre-orders")}>
                    <h5> My Pre-Orders <Icons icon="rightArrow" /> </h5>
                    <span className="icon-img">
                      <Srcset src={pwa.icons.accountIcons.accountOrders} />
                    </span>
                  </div>
                  <span className="subtitle">
                    View, track and manage pre-orders
                  </span>
                </div>
                <div className="tabs">
                  <div className="title" onClick={() => setAccountTab("orders")}>
                    <h5> My Orders <Icons icon="rightArrow" /> </h5>
                    <span className="icon-img">
                      <Srcset src={pwa.icons.accountIcons.accountOrders} />
                    </span>
                  </div>
                  <span className="subtitle">
                    View, track and manage orders
                  </span>
                </div>
                <div className="tabs">
                  <div className="title" onClick={() => setAccountTab("address")}>
                    <h5>
                      Manage Addresses <Icons icon="rightArrow" />
                    </h5>
                    <span className="icon-img">
                      <Srcset src={pwa.icons.accountIcons.accountAddress} />
                    </span>
                  </div>
                  <span className="subtitle">
                    Edit, add or remove your delivery addresses
                  </span>
                </div>
                <div className="tabs hide">
                  <div className="title" onClick={() => { setAccountTab("wallet");}} >
                    <h5>
                      Noise Wallet <Icons icon="rightArrow" />
                    </h5>
                    <span className="icon-img">
                      <Srcset src={pwa.icons.accountIcons.accountOrders} />
                    </span>
                  </div>
                  <span className="subtitle">
                    Track, earn and spend your loyalty points
                  </span>
                </div>
                <div className="tabs hide">
                  <div className="title" onClick={() => setAccountTab("referFriend")}>
                    <h5>
                      Refer Friend <Icons icon="rightArrow" />
                    </h5>
                    <span className="icon-img">
                      <Srcset src={pwa.icons.accountIcons.accountOrders} />
                    </span>
                  </div>
                  <span className="subtitle">
                    Get your friend to sign up for a chance to earn loyalty
                    points
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  loading: state.loading,
  accountInfo: state.account.profile,
});

const mapDispatchToProps = (dispatch) => ({
  fetchAccountInfo: (data) => dispatch(fetchAccountInfo(data)),
  setAccountTab: (data) => dispatch(setAccountTab(data)),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(PersonalInformation);
