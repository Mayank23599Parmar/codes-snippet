import React from 'react';
/* Plugins */
import { Switch, Route } from 'react-router-dom';
import { connect } from 'react-redux';

// action
import { setCartStart } from './redux/cart/cartAction';
import { setSearchToggle, searchStart } from './redux/search/searchAction';

/* Components imports */
import Topbar from './components/topbar/Topbar';
import Header from './components/header/Header';
// import SideCart from './components/SideCart/SideCart';
import CartPage from './pages/Cart/CartPage';
import Footer from './components/Footer/Footer';

/* Pages */
import HomePage from './pages/home-page/Homepage';
import CollectionPage from './pages/collection-page/CollectionPage';
import ProductPage from './pages/product-page/ProductPage';
import SupportPage from './pages/support-page/SupportPage';
import Register from './pages/account-page/Register';
import SearchPage from './pages/search-page/SearchPage';
import BlogPage from './pages/blog-page/BlogPage';
import ArticlePage from './pages/article-page/ArticlePage'
import ErrorPage from "./pages/errorpage/ErrorPage";;

// Helper
import { closeAllDrawer } from './components/Helper';

/* Account Subpage Tab */
import AccountTemplate from './pages/account-page/AccountTemplate';
class App extends React.Component {
 componentDidMount() {
  this.props.setCartStart();
 }
 closeSearch = () => {
  const { toggleSearch, setSearchStart, showSearch } = this.props;
  if (showSearch) {
   toggleSearch(false);
   setSearchStart('');
  }
 };
 render() {
  const { showSideCart } = this.props;
  return (
   <>
    <Topbar />
    <Header />
    {/* {showSideCart ? (
     <>
      <div className='black-bg' onClick={closeAllDrawer}>
      </div>
      <SideCart />
     </>
    ) : null} */}
    <main className='main-content' onClick={this.closeSearch}>
     <Switch>
     <Route
       render={props => <ProductPage key={window.location.href} {...props} />}
       path='*/products/:productHandle'
      />
      <Route exact component={HomePage} path='/' />
      <Route component={CartPage} path='/cart' />
      <Route component={SearchPage} path='/search' />
      <Route
       render={props => (
        <CollectionPage key={window.location.href} {...props} />
       )}
       path='*/collections/:collectionHandle'
      />
      <Route path='*/pages/:pageHandle' component={SupportPage} />
      <Route path='*/account' exact component={AccountTemplate} />
      <Route path='*/account/register' component={Register} />
      <Route path='*/blogs/:blogHandle' exact component={BlogPage}/>
      <Route path='*/blogs/:blogHandle/:articleHandle' component={ArticlePage}/>
      <Route path='*/gift_cards' component=""/>
      <Route render={props => <ErrorPage show={true} {...props} />} />
     </Switch>
    </main>
    <Footer />
   </>
  );
 }
}

const mapDispatchToProps = dispatch => {
 return {
  setCartStart: () => dispatch(setCartStart()),
  toggleSearch: toggle => dispatch(setSearchToggle(toggle)),
  setSearchStart: term => dispatch(searchStart(term)),
 };
};
const mapStateToProps = state => ({
 showSideCart: state.cart.show,
 showSearch: state.search.searchToggle,
});
export default connect(mapStateToProps, mapDispatchToProps)(App);
