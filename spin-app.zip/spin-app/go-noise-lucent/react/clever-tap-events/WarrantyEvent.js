let RegisterEvent = (data)=>{
    try {
        clevertap.event.push("W-Warranty Registration", {
            "name":data.name,
            "phone":data.phone,
            "email":data.email,
            "distributor":data.supplier,
            "poroduct":data.title,
            "order id": data.orderId,
            "serial number": data.sno
          });
    } catch (error) {
        
    }
    
}

export {
    RegisterEvent
}