let ctaEvent = (data)=>{

  try {
      clevertap.event.push("W-Add to cart", {
          "Customer Add Cart":'Customer Product Add To Cart',
          //"Product Name" : data.name,
          "Product Id": data.sku,
          "Product Variant": data.title,
          //"Category" : "",
          "quantity":1,
          "Selling Prince": parseInt(data.price),
          "Stock Availability":data.available,
      });
      //Add to cart currently disabled
      // clevertap.profile.push({
      //   "Site": {
      //     "W-Cart_Product Name": fadaName,
      //     "W-Cart_Product SMS Name": fadaSmsNAme,
      //     "W-Cart_Product Image URL": fadaImage,
      //     "W-Cart_Product Strike Price": fadaPrice,
      //     "W-Cart_Product Price": fadaCompare,
      //     "W-Cart_Product Type": productType,
      //   }
      //  });

      //GTM Container layer
      dataLayer.push({
          "event": "Add to cart",
         // "product url":`https://www.gonoise.com/products/${state.product.handle}?variant=${object.id}`,
          "product sku": data.sku, 
          //"product category":data.product.type, 
          //"product name": data.name, 
          "product variant color":data.title, 
          "product price":parseInt(data.price), 
          "product compare at price":parseInt(data.compare_at_price), 
          "variant id": data.id, 
          "source":localStorage.getItem('utm_source')
          //"variant group id":""
        })

  } catch (error) {
      
  }
}



let ctaBuyEvent = (data)=>{
  try {
      clevertap.event.push("W-Buy Now", {
          "Customer Buy Now":'Customer Product Buy Now',
          "Product Name" : data.variant.name,
          "Product Id": data.variant.sku,
          "Product Variant": data.variant.title,
          "Category" : data.product.type,
          "quantity":1,
          "Selling Prince": parseInt(data.variant.price)/100,
          "Stock Availability":data.variant.available,
        });
       
        clevertap.event.push("W-Cart_addition", {
          "Customer Cart Addition":'Customer Product Cart Items',
          "Product line item name" : data.variant.name,
          "Product Line Item type": data.product.type,
          "Product Line Item Variant": data.variant.title,
          "Products Line Item quantity":1,
          "Product Price": parseInt(data.variant.price)/100
      });

        //GTM Container layer
      dataLayer.push({
          "event": "Buy Now",
          //"product url":`https://www.gonoise.com/products/${state.product.handle}?variant=${object.id}`,
          "product sku": data.variant.sku, 
          "product category":data.product.type, 
          "product name":data.variant.name,
          "product variant color":data.variant.title, 
          "product price":parseInt(data.variant.price)/100, 
          "product compare at price":parseInt(data.variant.compare_at_price)/100, 
          "variant id": data.variant.id, 
          "source":localStorage.getItem('utm_source')
          //"variant group id":""
        })

        clevertap.profile.push({
          "Site": {
            "W-Cart_Product Name": data.variant.name,
            //"W-Cart_Product SMS Name": simply.clevertap.product.tag.split("_sms-ct-")[1].split("_,")[0].split('-').join(' '),
            "W-Cart_Product Type": data.product.type,
            "W-Cart_Product Image URL": data.product.featured_image,
            "W-Cart_Product Strike Price": parseInt(data.variant.price)/100, //product price
            "W-Cart_Product Price": parseInt(data.variant.compare_at_price)/100, //product compare price

          }
         });

      //hspixel('track', 'AddToCart', {"product_id":data.variant.id, "value":parseInt(data.variant.price)/100})

      var data = {
          "product sku": data.variant.sku, 
          "product category":data.product.type, 
          "product name":data.variant.name,
          "product variant color":data.variant.title, 
          "product price":parseInt(data.variant.price)/100, 
          "product compare at price":parseInt(data.variant.compare_at_price)/100, 
          "variant id": data.variant.id, 
          //"variant group id":""
        }

      // Encrypt
      //simply.productData = data
      // var ciphertext = CryptoJS.AES.encrypt(JSON.stringify(data), 'my-secret-key@123').toString();
      // //log encrypted data
      // console.log('Encrypt Data -')
      // console.log(ciphertext);
      // localStorage.setItem("product-details",ciphertext);

  } catch (error) {
      
  }
  

}


let AddToCartCTA = (data)=>{
  try {
      clevertap.event.push("W-Buy Now", {
          "Customer Add Cart":'Customer Product Add To Cart',
          "Product Name" : data.title,
          "Product Id": data.selectedVariant.sku,
          "Product Variant": data.selectedVariant.title,
          "Category" : data.type,
          "quantity":1,
          "Selling Prince": parseInt(data.selectedVariant.price),
          "Stock Availability":data.selectedVariant.available,
      });
      //Add to cart currently disabled
      clevertap.profile.push({
        "Site": {
          "W-Cart_Product Name": data.title,
         // "W-Cart_Product SMS Name": fadaSmsNAme,
          "W-Cart_Product Image URL": data.selectedVariant.image.src,
          "W-Cart_Product Strike Price":  parseInt(data.selectedVariant.price),
          "W-Cart_Product Price":  parseInt(data.selectedVariant.compare_at_price),
          "W-Cart_Product Type": data.type,
        }
       });

      //GTM Container layer
      dataLayer.push({
          "event": "Add to cart",
         // "product url":`https://www.gonoise.com/products/${state.product.handle}?variant=${object.id}`,
          "product sku": data.selectedVariant.sku, 
          "product category":data.type, 
          "product name": data.title, 
          "product variant color":data.selectedVariant.title, 
          "product price":parseInt(data.selectedVariant.price), 
          "product compare at price":parseInt(data.selectedVariant.compare_at_price), 
          "variant id": data.selectedVariant.id, 
          "source":localStorage.getItem('utm_source')
          //"variant group id":""
        })

  } catch (error) {
      
  }
}

let AddToBag = (data)=>{
  try{
    clevertap.event.push("W-Add to bag", {
      "Customer Add Cart":'Customer Product Add To Bag',
      "Product Name" : data.product.title,
      "Product Id": data.variant.sku,
      "Product Variant": data.variant.title,
      "Category" : data.product.product_type,
      "quantity":data.quantity,
      "Selling Prince": parseInt(data.variant.price)/100,
      "Stock Availability":data.variant.available,
  });

  clevertap.event.push("W-Cart_addition", {
    "Customer Cart Addition":'Product Add to Bag Cart Items',
    "Product line item name" : data.product.title,
    "Product Line Item type": data.product.product_type,
    "Product Line Item Variant": data.variant.title,
    "Products Line Item quantity":data.quantity,
    "Product Price": parseInt(data.variant.price)/100
});

  clevertap.profile.push({
    "Site": {
      "W-Cart_Product Name": data.product.title,
     // "W-Cart_Product SMS Name": fadaSmsNAme,
      "W-Cart_Product Image URL": data.variant.image.src,
      "W-Cart_Product Strike Price":  parseInt(data.variant.price)/100,
      "W-Cart_Product Price":  parseInt(data.variant.compare_at_price)/100,
      "W-Cart_Product Type": data.product.product_type
    }
   });

  }
  catch(error){

  }
}

let AddToBagCollectionCT = (data)=>{
  try{
    clevertap.event.push("W-Add to bag", {
      "Customer Add Cart":'Collection Product Add To Bag',
      "Product Name" : data.name,
      "Product Id": data.sku,
      "Product Variant": data.public_title,
      //"Category" : data.product.product_type,
      "quantity":1,
      "Selling Prince": parseInt(data.price)/100,
      "Stock Availability":data.available,
  });

  clevertap.event.push("W-Cart_addition", {
    "Customer Cart Addition":'Collection Product Cart Items',
    "Product line item name" : data.name,
    //"Product Line Item type": data.product.product_type,
    "Product Line Item Variant": data.public_title,
    "Products Line Item quantity":1,
    "Product Price": parseInt(data.price)/100
});

  clevertap.profile.push({
    "Site": {
      "W-Cart_Product Name": data.name,
     // "W-Cart_Product SMS Name": fadaSmsNAme,
      "W-Cart_Product Image URL": data.featured_image.src,
      "W-Cart_Product Strike Price":  parseInt(data.price)/100,
      "W-Cart_Product Price":  parseInt(data.compare_at_price)/100,
      //"W-Cart_Product Type": data.product.product_type
    }
   });

  }
  catch(error){

  }
}

let BuyNowCT = (data)=>{
  try{
    clevertap.event.push("W-Product Buy Now", {
      "Customer Buy Now":'Customer Product Buy Now',
      "Product Name" : data.product.title,
      "Product Id": data.variant.sku,
      "Product Variant": data.variant.title,
      "Category" : data.product.product_type,
      "quantity":data.quantity,
      "Selling Prince": parseInt(data.variant.price)/100,
      "Stock Availability":data.variant.available,


  });

  clevertap.event.push("W-Cart_addition", {
    "Customer Cart Addition":'Customer Product Cart Items',
    "Product line item name" : data.product.title,
    "Product Line Item type": data.product.product_type,
    "Product Line Item Variant": data.variant.title,
    "Products Line Item quantity":data.quantity,
    "Product Price": parseInt(data.variant.price)/100
});

  //GTM Container layer
dataLayer.push({
    "event": "Buy Now",
    //"product url":`https://www.gonoise.com/products/${state.product.handle}?variant=${object.id}`,
    "product sku": data.variant.sku, 
    "product category":data.product.type, 
    "product name":data.variant.name,
    "product variant color":data.variant.title, 
    "product price":parseInt(data.variant.price)/100, 
    "product compare at price":parseInt(data.variant.compare_at_price)/100, 
    "variant id": data.variant.id, 
    "source":localStorage.getItem('utm_source')
    //"variant group id":""
  })


  clevertap.profile.push({
    "Site": {
      "W-Cart_Product Name": data.product.title,
     // "W-Cart_Product SMS Name": fadaSmsNAme,
      "W-Cart_Product Image URL": data.variant.image.src,
      "W-Cart_Product Strike Price":  parseInt(data.variant.price)/100,
      "W-Cart_Product Price":  parseInt(data.variant.compare_at_price)/100,
      "W-Cart_Product Type": data.product.product_type
    }
   });

  }
  catch(error){

  }
}

let BuyNowCTCollection = (data)=>{
  try{
    clevertap.event.push("W-Buy Now", {
      "Customer Buy Now":'Customer Product Buy Now',
      "Product Name" : data.name,
      "Product Id": data.sku,
      "Product Variant": data.public_title,
      //"Category" : data.product.product_type,
      "quantity":1,
      "Selling Prince": parseInt(data.price)/100,
      "Stock Availability":data.available,
  });

  clevertap.profile.push({
    "Site": {
      "W-Cart_Product Name": data.name,
     // "W-Cart_Product SMS Name": fadaSmsNAme,
      "W-Cart_Product Image URL": data.featured_image.src,
      "W-Cart_Product Strike Price":  parseInt(data.price)/100,
      "W-Cart_Product Price":  parseInt(data.compare_at_price)/100,
      //"W-Cart_Product Type": data.product.product_type
    }
   });

  clevertap.event.push("W-Cart_addition", {
    "Customer Cart Addition":'Customer Product Cart Items',
    "Product line item name" : data.name,
    //"Product Line Item type": data.product.product_type,
    "Product Line Item Variant": data.public_title,
    "Products Line Item quantity":1,
    "Product Price": parseInt(data.price)/100
});

  //GTM Container layer
dataLayer.push({
    "event": "Buy Now",
    //"product url":`https://www.gonoise.com/products/${state.product.handle}?variant=${object.id}`,
    "product sku": data.sku, 
    //"product category":data.product.type, 
    "product name":data.name,
    "product variant color":data.public_title, 
    "product price":parseInt(data.price)/100, 
    "product compare at price":parseInt(data.compare_at_price)/100, 
    "variant id": data.id, 
    "source":localStorage.getItem('utm_source')
    //"variant group id":""
  })

  }
  catch(error){

  }
}

export {
  ctaEvent,
  ctaBuyEvent,
  AddToCartCTA,
  AddToBag,
  AddToBagCollectionCT,
  BuyNowCT,
  BuyNowCTCollection
}
