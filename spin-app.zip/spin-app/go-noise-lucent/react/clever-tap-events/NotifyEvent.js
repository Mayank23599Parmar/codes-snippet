let notifyMeEvent = (object)=>{
    try {
        clevertap.event.push("W-Notify Me", {
            "Notify Me Click":'Notify Me Clicked',
            "Notify Item Name":object.title,
            "Notify Item URL":object.handle,
            "Notify Item Type":object.type,
          });
    } catch (error) {
        console.log(error);
    }  
}

let notifyMeProductEvent = (object)=>{
    try {
        clevertap.event.push("W-Notify Me", {
            "Notify Me Click":'Notify Me Clicked',
            "Notify Item Name":object.product.title,
            "Notify Item URL":object.product.handle,
            "Notify Item Type":object.product.type,
          });
    } catch (error) {
        console.log(error);
    }  
}

export {
    notifyMeEvent,
    notifyMeProductEvent
}
