let searchbarEvent = (query)=>{
    try {
        clevertap.event.push("W-Product searched", {
            "Searchbar Key":'Product Search from searchbar',
            "search value":query
          });
          
          //shotstar pixel 
          //hspixel('track', 'Search', {"search_text":query})
          dataLayer.push({
            'event': 'Search',
            'Search Query': query,
            "source":localStorage.getItem('utm_source')
        })


    } catch (error) {
        
    }
    
}

export {
    searchbarEvent
}