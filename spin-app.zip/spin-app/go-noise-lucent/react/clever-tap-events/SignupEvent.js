let signupFormEvent = (data)=>{
    try {
        clevertap.event.push("W-Signup Form", {
            "first name":data.first_name,
            "last_name":data.last_name,
            "phone":data.phone,
            "email":data.email
          });

          clevertap.profile.push({
            "Site": {
              "Identity": guest_identity,  // String or number
              "Name": data.first_name + ''+ data.last_name, //full name
              "Email": data.email, // Email address of the user
              "Phone": '+91'+ data.phone, // Email address of the user
                
            }
           });

    } catch (error) {
        
    }
    
}

export {
    signupFormEvent
}