let profileEvent = (name, phone, address)=>{
    clevertap.event.push("W-Customer Address", {
        "Customer Profile Viewed":'Customer Profile Data',
        
      });
}

export {
    profileEvent
}