let cart_addition = (data)=>{

    try {
        // data.items.forEach(element => {
        //     element.item.price = parseInt(element.item.price)/100;
        //     element.item.original_price = parseInt(element.item.original_price)/100;
        //     element.item.discounted_price = parseInt(element.item.discounted_price)/100;
        //     clevertap.event.push("W-Cart_addition", {
        //         "Customer Cart Addition":'Customer Product Cart Items',
        //         "Product Line Item Name" : element.item.product_title,
        //         "Product Line Item type": element.item.product_type,
        //         "Product Line Item Variant": element.item.variant_title,
        //         "Product Line Item quantity":element.item.quantity,
        //         "Product Price": element.item.price
        //     });
            
        //     return;
        // });
        
        clevertap.event.push("W-Cart Value", {
            "Customer Cart Addition":'Customer Product Cart Value',
            "Cart Value" : parseInt(data.original_total_price)/100,
        });
        
        //GTM container data layer
        dataLayer.push({
            "event":"Cart Page",
            "line item":data.items,
            "total cart vale":  parseInt(data.original_total_price)/100,
            "source":localStorage.getItem('utm_source')
        })
        
    } catch (error) {
        
    }
}

export{
    cart_addition
}
