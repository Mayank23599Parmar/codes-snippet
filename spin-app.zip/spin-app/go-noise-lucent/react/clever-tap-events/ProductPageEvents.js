let productClickEvent = (title, url)=>{
    try {
        clevertap.event.push("W-Header Menu Clicked", {                 //after w- mention event name accordingly
            "Header Menu Clicked":'Header Menu Item Clicked',
            "Header Menu Item Name":title,
            "Header Menu Item URL":url,
        });
    } catch (error) {
        
    }
    
}

export {
    productClickEvent
}