let HomeBanner = (link)=>{
    try {
        clevertap.event.push("W-Banner", {
            "Homapage Banner":'Homepage Banner Clicked',
            "Banner Url": link
        });
    } catch (error) {
        
    }    
}


export {
    HomeBanner
}
