let footerFollowClickEvent = (social_link)=>{
    try {
        clevertap.event.push("W-Footer Menu Clicked", {
            "Footer Menu Clicked":'Footer Menu Follow Item Clicked',
            "Footer Menu Follow URL":social_link,
          });
    } catch (error) {
        
    }
    
}

export {
    footerFollowClickEvent
}
