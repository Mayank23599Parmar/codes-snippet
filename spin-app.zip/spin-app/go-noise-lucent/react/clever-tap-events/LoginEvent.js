let loginFormEvent = (email)=>{
    clevertap.event.push("W-Login Form", {
        "Customer Login":'Customer Login Form Data',
        
      });
}

export {
    loginFormEvent
}