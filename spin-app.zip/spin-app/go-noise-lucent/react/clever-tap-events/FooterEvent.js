let footerClickEvent = (title, url)=>{
    try {
        clevertap.event.push("W-Footer Menu Clicked", {
            "Footer Menu Clicked":'Footer Menu Item Clicked',
            "Footer Menu Item Name":title,
            "Footer Menu Item URL":url,
          });
    } catch (error) {
        
    }
    
}

export {
    footerClickEvent
}