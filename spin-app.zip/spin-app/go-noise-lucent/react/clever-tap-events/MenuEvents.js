let menuClickEvent = (title, url)=>{
    try {
        clevertap.event.push("W-Header Menu", {
            "Header Menu Viewed":'Header Menu Item Clicked',
            "Header Menu Item Name":title,
            "Header Menu Item URL":url,
          });
    } catch (error) {
        
    }
   
}

export {
    menuClickEvent
}