let defaultProductViewEvent = (object, state)=>{
    console.log(object, "defaultProductViewEvent----");
    try{
        let p_name = object.name.split('-')
        clevertap.event.push("W-Product Viewed", {                 //after w- mention event name accordingly
            "Product Name":object.title,
            "Product ID":object.sku,
            "Product Variant":object.title,
            "Category":object.type || state.product.type,
            "Selling Price": parseInt(object.price)/100,
            "Stock Availability":object.inventory_quantity,
            "Compare Price":parseInt(object.compare_at_price)/100,
            "Image":object.featured_image.src
          });

             //GTM Container layer
             dataLayer.push({
                "event": "Product Page View",
                "product url":`https://www.gonoise.com/products/${state.product.handle}?variant=${object.id}`,
                "product sku": object.sku, 
                "product category":state.product.type, 
                "product name":p_name[0], 
                "product variant color":object.title, 
                "product price":parseInt(object.price)/100, 
                "product compare at price":parseInt(object.compare_at_price)/100, 
                "variant id": object.id, 
                "source":localStorage.getItem('utm_source')
                //"variant group id":""
              })
    }catch(e){
    }
}


let productViewEvent = (object, state)=>{
    console.log(object, "productViewEvent----->");
    try{
        let p_name = object.name.split('-')
        clevertap.event.push("W-Product Viewed", {                 //after w- mention event name accordingly
            "Product Name":p_name[0],
            "Product ID":object.sku,
            "Product Variant":object.title,
            "Category":object.type || state.product.type,
            "Selling Price": parseInt(object.price)/100,
            "Stock Availability":object.inventory_quantity,
            "Compare Price":parseInt(object.compare_at_price)/100,
            "Image":object.featured_image.src
          });

             //GTM Container layer
             dataLayer.push({
                "event": "Product Page View",
                "product url":`https://www.gonoise.com/products/${state.product.handle}?variant=${object.id}`,
                "product sku": object.sku, 
                "product category":state.product.type, 
                "product name":p_name[0], 
                "product variant color":object.title, 
                "product price":parseInt(object.price)/100, 
                "product compare at price":parseInt(object.compare_at_price)/100, 
                "variant id": object.id, 
                "source":localStorage.getItem('utm_source')
                //"variant group id":""
              })
    }catch(e){
    }
}

export {
    productViewEvent, 
    defaultProductViewEvent
}
