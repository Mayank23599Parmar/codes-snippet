let SubMenuEvent = (data)=>{
    try {
        clevertap.event.push("W-Header Menu Clicked", {                 //after w- mention event name accordingly
            "Header Menu Clicked":'Header Menu Item Clicked',
            "Header Menu Item Name":data.title,
            "Header Menu Item URL":data.url,
          });

        
    } catch (error) {
        
    }
    
}

let SubMenuViewAllEvent = (data)=>{
    try {
        clevertap.event.push("W-Header Menu collection Clicked", {                 //after w- mention event name accordingly
            "Header Menu collection Clicked":'Header Menu Collection Clicked',
            "Header Menu collection Name":data.title,
            "Header Menu collection URL":data.url,
          });
        
    } catch (error) {
        
    }
    
}

let SubMenuProductEvent = (data)=>{
    try {
        clevertap.event.push("W-Header Menu Product Clicked", {                 //after w- mention event name accordingly
            "Header Menu Product Clicked":'Header Menu Product Clicked',
            "Header Menu Product Name":data.title,
            "Header Menu Product handle":data.url,
            "Header Menu Product Image":data.image
          });

        
    } catch (error) {
        
    }
    
}

export {
    SubMenuEvent,
    SubMenuViewAllEvent,
    SubMenuProductEvent
}
