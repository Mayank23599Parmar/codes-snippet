let knowMore = (object)=>{
    try {
        clevertap.event.push("W-Know More Clicked", {
            "Know More Button":"Know More Button Clicked",
            "name":object.title,
            "price":parseInt(object.price)/100,
            "strike price":parseInt(object.compare_at_price)/100,
            "product_type":object.type
        })
    } catch (error) {
        console.log(error);
    }
}

let knowMoreHome = (object)=>{
    try{
        clevertap.event.push("W-Know More Home Clicked", {
            "Know More Home Button":"Know More Home Button Clicked",
            "title":object.title,
            "url":object.btn_url,
            "image":object.image
        })

    }
    catch(error){
        console.log(error)
    }
}

let knowMoreImageHome = (object)=>{
    try{
        clevertap.event.push("W-Category Viewed", {
            "Know More Category Viewed":"Know More Category Image clicked",
            "name":object.title,
            "url":object.btn_url,
            "image":object.image
        })
    }
    catch(error){
        console.log(error)
    }
}

export{
    knowMore,
    knowMoreHome,
    knowMoreImageHome
}
