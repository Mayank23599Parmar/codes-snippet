import addToCart from '../axios/AxiosAddToCart';
import { store } from '../redux/store';
import { setCartData, createJsCheckout } from './CartApi';
// import { FacebookPixels } from '../pixels/FacebookPixels' // facebook pixel
// import { googlePixels } from '../pixels/GooglePixels';
import { getCookie } from '../components/Helper';

const buyJsAddTocart = async(vid, qty = 1, properties) => {
  debugger;
  let checkoutId = getCookie('tmccheckoutId');
  let client = store.getState().shop;
  client = client.shop;
  if (!checkoutId) {
    const newCheckout = createJsCheckout(client);
    if (newCheckout) {
      checkoutId = newCheckout.id;
    }
  }
  const lineItemsToAdd = [
    {
      variantId: vid,
      quantity: parseInt(qty),
      properties:properties
    }
  ];
   const checkout = await client.checkout.addLineItems(checkoutId, lineItemsToAdd);
    // debugger;
      await setCartData();
      return checkout;
}
const singleAddToCart = async (settings) => {
  
  let { variant,properties, qty, product } = settings;
  
  let vid = variant.id;
  let vidCheck = parseInt(vid);
  if (isNaN(vidCheck)) {
    vid = atob(vid).split("/").reverse();
    vid = vid[0];
  }

  if (settings.callback.name === "goToCheckout") {
    product.toCheckout = true;
  }

  // const gp = new googlePixels();
  // gp.addToCart(vid, product);

  // const fbp = new FacebookPixels();
  // fbp.addToCart(vid, product);

  if (process.env.NODE_ENV === 'development') {
    vid = variant.id;
    let res =   await buyJsAddTocart(vid, qty);
    return { status: 0, message: `success`, data: res };
  }

  try {
  
    const data = {
      quantity: qty,
      id: parseInt(vid),
      properties:properties
    }

    let res = await addToCart.post('', data);
      await setCartData();
    return { status: 0, message: `success`, data: res.data };
  }
  catch (e) {
    return { status: 1, message: `Error:${e.message}`, data: null };
  }

}
export {
  singleAddToCart
}
