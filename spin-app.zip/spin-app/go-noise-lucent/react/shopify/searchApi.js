// import React from 'react'
// import { Redirect } from "react-router-dom";

const searchApi = async (term) => {
  let searchResponse, url;
  let searchTerm = term;
    url = `/search/suggest.json?q=${searchTerm}&resources[type]=product`

  try {
    searchResponse = await fetch(url)
      .then(res => {
        if (res.ok) {
          return res.json();
        }
        throw new Error('Network response was not ok.');
      })
  } catch (e) {
    searchResponse = null;
    console.error('There was an error.', e)
  }
  return searchResponse
}

export default searchApi;
