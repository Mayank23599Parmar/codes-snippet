import { store } from '../redux/store';
import ajaxUpdateCart from '../axios/AxiosUpdateCart';


const updateCart = async (index, qty) => {
  // debugger;
  let cartData = store.getState().cart;
  if (!cartData.cart) {
    console.error("Cart data not set");
  }
  let items = cartData.cart.items;
  let qtyArray = items.map((item, item_index) => {
    if (item_index === index) {
      return qty
    }
    return item.quantity;
  })
  try {
    const respo = await ajaxUpdateCart.post("", { updates: qtyArray });
    
  }
  catch (e) {
    alert(`Error:${e.message}`);
  }

}
export {
  updateCart
}