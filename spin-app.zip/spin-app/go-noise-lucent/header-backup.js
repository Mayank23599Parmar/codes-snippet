import React, { Component } from "react";
import SiteNav from "./SiteNav";
import UrlSet from "../UrlSet";
import SearchContainer from "./SearchContainer";
import MediaQuery from "../MediaQuery";
import MobileNav from "../MobileNav/MobileNav";
import { connect } from "react-redux";
import { setMobileNavToggle } from "../../redux/mobile-nav-reducer/MobileNavAction";
import { setSideCartToggle, setCartStart } from "../../redux/cart/cartAction";
import { setSearchToggle } from "../../redux/search/searchAction";
import { formatMoney, openSideCart } from "../Helper";
class LargeHeader extends Component {
  componentDidMount(){
    const { toggleSearch } = this.props;
    toggleSearch(false);
  }
  checkMenuType = () =>{
    let lapsScreenShow = false;
    if(window.innerWidth >= 1200 ){
      let firstLink = document.querySelector('.large-header .main-menu .first-level-li');
      let parentMenu = document.querySelector('.large-header .main-menu ul.nav');
      if(!cn(firstLink) && !cn(parentMenu)){
        if(parentMenu.offsetHeight > firstLink.offsetHeight){
          lapsScreenShow = true
        }
      }
    }
    if(window.innerWidth < 1200 &&  window.innerWidth > 767 ){
      lapsScreenShow = true;
    }
    return lapsScreenShow;
  }
  render() {
    const { toggleSearch, cart } = this.props;
    let showSearch = this.props.showSearch;
    if(this.props.history.location.pathname === "/search"){
      showSearch = false;
    }
    let {
      container,
      headerSettings,
      setMobileNavToggle,
      showMobileNav,
      setSideCartToggle,
      startCartFetch,
    } = this.props;
    let cartItems = 0;
    if (cart.cart) {
      let cartItems = cart.cart.item_count;
    }
    return (
      <div className="large-header" ref={this.headerRef}>
        <div className={container}>
          <div className="flex-view-xs middle">
            {lapsScreenShow &&<>
              <div className="mobile_menu_btn">
                {showMobileNav ? (
                  <span title="Menu" className="menu fake_anchor_tag close-menu" onClick={() => setMobileNavToggle(false)} >
                    <img src={`${pwa.icons.closeWhite}`} alt="Menu-close-icon" />
                  </span>
                ) : (
                  <span
                    title="Menu"
                    className="menu fake_anchor_tag"
                    onClick={() => setMobileNavToggle(true)}
                  >
                    <img src={`${pwa.icons.monileMenu}`} alt="Menu-icon" />
                  </span>
                )}
              </div>
              {showMobileNav ? (
                <MobileNav headerSettings={headerSettings} />
              ) : null}</>
            }
            <div className="logo-side side">
              <div className="site-logo">
                <UrlSet href="/" itemProp="url">
                  {headerSettings.site_logo ? (
                    <img itemProp="logo" src={headerSettings.site_logo} alt={window.shopObj.name} ></img>
                  ) : (
                    <h6>{window.shopObj.name}</h6>
                  )}
                </UrlSet>
              </div>
            </div>
            <MediaQuery query="tablet-and-up">
              <div className="menu-side side">
                <MediaQuery query="desk-and-up">
                  <nav className="main-menu text-center">
                    <SiteNav />
                  </nav>
                </MediaQuery>
                {showSearch && <SearchContainer />}
              </div>
            </MediaQuery>
            <div className="icon-side side">
              <ul className="flex-view-xs middle right">
                <MediaQuery query="tablet-and-up">
                  <li>
                    <div className="search-button">
                      {this.props.showSearch ? null : (
                        <img
                          onClick={() => {
                            if (window.location.pathname.includes("/search")) {
                              toggleSearch(false);
                            } else {
                              toggleSearch(true);
                            }
                          }}
                          className="showInput icon-img"
                          src={`${pwa.icons.search}`}
                        />
                      )}
                    </div>
                  </li>
                </MediaQuery>
                <li >
                  <span title="Cart" className="side-cart cart">
                    <img className="icon-img" src={pwa.icons.cart} alt="cart" />
                    {cartItems > 0 && (
                      <span className="count">{cartItems}</span>
                    )}
                  </span>
                </li>
                <li>
                  <div className="accounts">
                      {simply.customerLoggedin ?
                      <UrlSet href="/account">
                         <img
                            className="icon-img"
                            src={pwa.icons.account}
                            alt="account"
                          />
                      </UrlSet>
                      : 
                        <a href="/account/login">
                          <img
                            className="icon-img"
                            src={pwa.icons.account}
                            alt="account"
                          />
                        </a>
                      }
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  showMobileNav: state.mobileNav.showNav,
  showSearch: state.search.searchToggle,
  cart: state.cart,
});
const mapDispatchToProps = (dispatch) => ({
  setMobileNavToggle: (item) => dispatch(setMobileNavToggle(item)),
  setSideCartToggle: (side_cart) => dispatch(setSideCartToggle(side_cart)),
  startCartFetch: (value) => dispatch(setCartStart(value)),
  toggleSearch: (toggle) => dispatch(setSearchToggle(toggle)),
});
export default connect(mapStateToProps, mapDispatchToProps)(LargeHeader);
