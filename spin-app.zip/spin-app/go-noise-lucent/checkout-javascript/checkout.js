import pinCodeUpdate from "./pin-code-update";
import skipShipping from "./skip-shipping";
import phoneVerification from "./phone-verification";
import paymentMethod from "./payment-method";
import {cartJson, addItem} from './checkout-helper';

//var CryptoJS = require("crypto-js");

import checkoutProductProperties from "./checkout-product-properties";
class checkout {
  constructor() {
    // this.paymentPropertiesObj = new checkoutProductProperties;
    this.init();
    this.codID='37800451';
    this.cartJson = {};
  }
  
  announcementBar = () => {
    $("body").prepend(
      `<div class='announcement-bar'><p>${simply.header_text}<p></div>`
    );
  };
  paymentMode = () => {

    let p_data = {
      //"product sku": data.variant.sku, 
      "product category":simply.clevertap.checkout.line_item_product_type, 
      "product name":simply.clevertap.checkout.line_item_product_type,
      "product variant color":simply.clevertap.checkout.line_items_product_variants, 
      "product price":simply.clevertap.checkout.sale_amount_integer_value, 
      "product compare at price":simply.clevertap.checkout.line_items_product_compare_at_price, 
      //"variant id": simply.clevertap.checkout.line_item_product_type, 
      //"variant group id":""
    }
    

    if(Shopify.Checkout.step == 'contact_information'){
        
      $(document).on("click", "#continue_button", (e)=> {    
        let payEmail    = $('#checkout_email').val();
        let payPhone    = $('#checkout_shipping_address_phone_clone').val();
        let payAddress  = $('#checkout_shipping_address_address1').val();
        let payState    = $('#checkout_shipping_address_province').val();
        let payFirstName    = $('#checkout_shipping_address_first_name').val();
        let payLastName = $('#checkout_shipping_address_last_name').val();
        let payPincode = $('#zipcode').val();
        let payCity = $('#checkout_shipping_address_city').val();
        let payCountry = $('#checkout_shipping_address_country').val();
        let couponString = $('.reduction-code__text').map(function() { return $(this).text(); }).get()
        localStorage.setItem("Payment_Email",payEmail);
        localStorage.setItem("Payment_Phone",payPhone);
  
        let data = {
                    "email":payEmail, 
                    "phone":payPhone, 
                    "address":payAddress, 
                    "state":payState, 
                    "first_name":payFirstName, 
                    "last_name":payLastName, 
                    "pincode":payPincode, 
                    "city":payCity, 
                    "country":payCountry
                }
        
        localStorage.setItem('customer', JSON.stringify(data));
        
        clevertap.profile.push({
          "Site": {
            //"Identity": guest_identity,  // String or number
            "Name": payFirstName + ' '+payLastName,
            "Email": payEmail, // Email address of the user
            "Phone": '+91'+payPhone, // Email address of the user
            
          }
         });

        dataLayer.push({
            "event":"Customer Info",
            "email":payEmail, 
            "phone":payPhone, 
            "address":payAddress, 
            "state":payState, 
            "first_name":payFirstName, 
            "last_name":payLastName, 
            "pincode":payPincode, 
            "city":payCity, 
            "country":payCountry,
            "coupon":couponString[0],
            ...p_data
            
        })
      });

  }

  if(Shopify.Checkout.step == 'payment_method'){
    
    let c_data = localStorage.getItem('customer')
    c_data = JSON.parse(c_data)

    $(document).on("click", "#continue_button", (e)=> {
      
        let paymodeEmail = localStorage.getItem('Payment_Email');
        let paymodePhone = localStorage.getItem('Payment_Phone');
        let paymentGatewaymode = $(`input[name="checkout[payment_gateway]"]:checked`).val();
        let paymentGatewayId = 'checkout_payment_gateway_'+paymentGatewaymode ;
        let paymentGatewayName = $(`label[for="${paymentGatewayId}"] span.visually-hidden`).text();

        let couponString = $('.reduction-code__text').map(function() { return $(this).text(); }).get()
        let discountValue = $('.order-summary__emphasis').map(function() { return $(this).attr('data-checkout-discount-amount-target'); }).get()
        let cartSubtotal = $('.order-summary__emphasis').map(function() { return $(this).attr('data-checkout-subtotal-price-target'); }).get()
        let cartTotal = $('.order-summary__emphasis').map(function() { return $(this).attr('data-checkout-payment-due-target'); }).get()
        
        if(paymentGatewaymode === "37800451"){
          paymentGatewayName = "Cash on Delivery (COD)";
        }
        console.log('payment------>',paymentGatewayName);
        clevertap.event.push("W-Checkout Payment Mode Captured", {
            "Checkout Payment Mode Email":paymodeEmail,
            "Checkout Payment Mode Phone":paymodePhone,
            "Checkout Payment Mode Shopify Value":paymentGatewaymode,
            "Checkout Payment Mode Shopify Id":paymentGatewayId,
            "Checkout Payment Mode Name":paymentGatewayName
        });
        dataLayer.push({
            "event":"Initiate Checkout",
            "Coupon Code": couponString[0],
            "Coupon Value":parseFloat(discountValue[0])/100,
            "Checkout Amount": parseFloat(cartSubtotal[0]/100),
            "Total Amount":parseFloat(cartTotal[0])/100,
                      ...c_data,
                       ...p_data
        })
    
    });

  }
  }
  clickEvent = () => {};
  changeEvent = () => {
    // payment gateway change event
  };
  convertButtonType =()=>{
    if(Shopify.Checkout.step == "contact_information"){
      $('div[data-step="contact_information"] form.edit_checkout #continue_button').attr("type","button");
    }
  }
  pageLoadEvent = () => {
    this.convertButtonType();
    $(document).on(
      "change",
      '.step[data-step="contact_information"] #checkout_shipping_address_id',
      (e) => {
        // new pinCodeUpdate();
      }
    );
    $(document).on("page:load page:change", (e) => {
      //this.noOffer1();
      // zip code and phone number
      new pinCodeUpdate();
      // hide shipping breadcrumb and ship shipping
      new skipShipping();
      new paymentMethod();
      this.discountChange();
      this.paymentMode();
      $("#msg_error").html("");
      $(".step__footer__continue-btn.btn").attr(
        "old-bg-color",
        $(".step__footer__continue-btn.btn").css("background-color", "#505AF0")
      );
      // add properties based on payment method
      // this.paymentPropertiesObj.init();
      // this.paymentPropertiesObj.checkProductProperties();
    });
  };

  discountChange = () => {
    this.convertButtonType();
    if (
      $(".order-summary__section--discount .reduction-code").length > 0 &&
      $(".discount-code-text-wrap").length > 0
    ) {
      let settingCode = simply.discount_code_setting.toLowerCase();
      let successText = $(".discount-code-text-wrap").html();
      let discountCardAttr = parseInt(
        $(
          ".total-line--reduction .total-line__price .order-summary__emphasis"
        ).attr("data-checkout-discount-amount-target")
      );
      let discountPrice = 0;
      if (!isNaN(discountCardAttr)) {
        discountPrice = Math.floor(discountCardAttr / 100);
      }

      let giftCardAmount = 0;
      let giftCardAttrValue = parseInt(
        $("[data-checkout-applied-gift-card-amount-target]").attr(
          "data-checkout-applied-gift-card-amount-target"
        )
      );
      if (!isNaN(giftCardAttrValue)) {
        giftCardAmount = Math.floor(giftCardAttrValue / 100);
      }
      let discountPriceHtml = "₹" + (discountPrice + giftCardAmount);

      if (discountPrice > 0 || giftCardAmount > 0) {
        let parent = $("#order-summary .order-summary__section--discount");
        successText = successText.replace("###", discountPriceHtml);
        let htmlContent = `<div class='discount-text-wrap'>${successText}</div>`;
        $(htmlContent).insertAfter($(".tags-list", parent));
        if (window.innerWidth < 768) {
          $(htmlContent).insertAfter(
            $(".step[data-step=payment_method] .tags-list")
          );
        }
      }
    }
  };
  
  submitEvent = () => {
    $(document).on('click','div[data-step="contact_information"] form.edit_checkout #continue_button',function(e) {
        $("#error-for-phone").remove();
        let checkout_shipping_address_phone = $( "#checkout_shipping_address_phone_clone").val();
        let format_match = false;
        let f_name = $('#checkout_shipping_address_first_name').val();
        let l_name = $('#checkout_shipping_address_last_name').val();
        let address = $('#checkout_shipping_address_address1').val();
        let pincode = $('#zipcode').val();
        let city = $('#checkout_shipping_address_city').val();
        let email = $('#checkout_email').val();
        const expression = /(?!.*\.{2})^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i
        let validEmail = expression.test(String(email).toLowerCase());

        let allcondittionsPass = true;
        if(cn(email)){
          e.preventDefault();
          $("#checkout_email").closest(".field").addClass("field--error");
          $("#email_error").remove();
          $("#checkout_email").closest(".field").append('<p class="field__message field__message--error" id="email_error">Please enter your email.</p>');
          allcondittionsPass = false;
          setTimeout(function () {
            $("#continue_button").removeAttr("disabled");
            $("#continue_button").removeClass("btn--loading");
          }, 3000);
        }
        else if(!validEmail){
          $("#checkout_email").closest(".field").addClass("field--error");
          $("#email_error").remove();
          $("#checkout_email").closest(".field").append('<p class="field__message field__message--error" id="email_error">Please enter valid email.</p>');
          allcondittionsPass = false;

          setTimeout(function () {
            $("#continue_button").removeAttr("disabled");
            $("#continue_button").removeClass("btn--loading");
          }, 3000);
        }
        if (!cn(checkout_shipping_address_phone)) {
          var first_char = $("#checkout_shipping_address_phone_clone").val().charAt(0);
          if (first_char == "6" || first_char == "7" || first_char == "8" || first_char == "9" ) {
            format_match = true;
          }
        }

        let phoneHasErrors = false;
        if ( cn(checkout_shipping_address_phone) || checkout_shipping_address_phone.length != 10 || !format_match) {
          e.preventDefault();
          var submit_btn = $("#continue_button");
          submit_btn.removeAttr("disabled");
          submit_btn.removeClass("btn--loading");
          $("#checkout_shipping_address_phone_clone").closest(".field").addClass("field--error");
          if (cn(checkout_shipping_address_phone)) {
            $("#checkout_shipping_address_phone_clone").closest(".field").append('<p class="field__message field__message--error" id="error-for-phone">Please enter your 10 digit phone number to proceed.</p>');
            phoneHasErrors = true;
          } else if (checkout_shipping_address_phone.length < 10) {
            $("#checkout_shipping_address_phone_clone").closest(".field").append('<p class="field__message field__message--error" id="error-for-phone">Please enter your 10 digit phone number to proceed.</p>');
            phoneHasErrors = true;
          } else if (!format_match) {
            $("#checkout_shipping_address_phone_clone").closest(".field").append('<p class="incorrect_phn_number field__message field__message--error" id="error-for-phone">Please enter correct phone number starting from 6/7/8/9</p>');
            phoneHasErrors = true;
          } else {
            $("#error-for-phone").show();
            phoneHasErrors = true;
          }
          allcondittionsPass = false;

          setTimeout(function () {
            $("#continue_button").removeAttr("disabled");
            $("#continue_button").removeClass("btn--loading");
          }, 3000);
        } 
        if(cn(f_name)){
          e.preventDefault();
          $("#checkout_shipping_address_first_name").closest(".field").addClass("field--error");
          $('#f_name_error').remove();
          $("#checkout_shipping_address_first_name").closest(".field").append('<p class="field__message field__message--error" id="f_name_error">Please enter your first name.</p>');
          allcondittionsPass = false;

          setTimeout(function () {
            $("#continue_button").removeAttr("disabled");
            $("#continue_button").removeClass("btn--loading");
          }, 3000);
        }
        if(cn(l_name)){
          e.preventDefault();
          $("#checkout_shipping_address_last_name").closest(".field").addClass("field--error");
          $('#l_name_error').remove();

          $("#checkout_shipping_address_last_name").closest(".field").append('<p class="field__message field__message--error" id="l_name_error">Please enter your last name.</p>');
          allcondittionsPass = false;

          setTimeout(function () {
            $("#continue_button").removeAttr("disabled");
            $("#continue_button").removeClass("btn--loading");
          }, 3000);
        }
        address = address.trim();
        if(cn(address)){
          e.preventDefault();
          $("#checkout_shipping_address_address1").closest(".field").addClass("field--error");
          $('#address_error').remove();
          $("#checkout_shipping_address_address1").closest(".field").append('<p class="field__message field__message--error" id="address_error">Please enter your address.</p>');
          allcondittionsPass = false;
          
          setTimeout(function () {
            $("#continue_button").removeAttr("disabled");
            $("#continue_button").removeClass("btn--loading");
          }, 3000);
        }
        else if(address.length<15){
          e.preventDefault();
          $("#checkout_shipping_address_address1").closest(".field").addClass("field--error");
          $('#address_error').remove();
          allcondittionsPass = false;

          $("#checkout_shipping_address_address1").closest(".field").append('<p class="field__message field__message--error" id="address_error">Address cannot be less than 15 characters.</p>');         
          setTimeout(function () {
            $("#continue_button").removeAttr("disabled");
            $("#continue_button").removeClass("btn--loading");
          }, 3000);
        }
        if(cn(city)){
          e.preventDefault();
          $("#checkout_shipping_address_city").closest(".field").addClass("field--error");
          $('#city_error').remove();

          $("#checkout_shipping_address_city").closest(".field").append('<p class="field__message field__message--error" id="city_error">Please enter your city.</p>');
          allcondittionsPass = false;
          
          setTimeout(function () {
            $("#continue_button").removeAttr("disabled");
            $("#continue_button").removeClass("btn--loading");
          }, 3000);
        }
        if(cn(pincode)){
          e.preventDefault();
          $('#msg_error').html('')
          $("#zipcode").closest(".field").addClass("field--error");
          $('#msg_error').html(`Please enter your zipcode.`)          
          allcondittionsPass = false;
          
          setTimeout(function () {
            $("#continue_button").removeAttr("disabled");
            $("#continue_button").removeClass("btn--loading");
          }, 3000);
        }
        if(allcondittionsPass){
          e.preventDefault();
          var oldPhone = localStorage.getItem('phone-number');
          if(checkout_shipping_address_phone != oldPhone){
            localStorage.setItem('phone-number',checkout_shipping_address_phone);
            localStorage.setItem('otp-verified',null);
          }
          
          let pincodeServiceableUrl = 'https://pre-order.gonoise.in/dashboard/service/'+pincode ;
            var settings = {
                "async": true,
                "crossDomain": true,
                "headers": {
                    "Access-Control-Allow-Origin" : "*",
                    "Content-Type": "application/json",
                    "X-Shopify-Access-Token":"0329b8ad3bce0bcfdda8ca65c37143c3ccc1e8ae0545da19898ca08bba8ed1a5"
                },
                "url": pincodeServiceableUrl,
                "method": "GET",
                "cache": false
            }
            // if(localStorage.getItem("cod-pin-code-status") !== '200'){

            // }
            // $.ajax(settings).done( (response)=>{
              e.preventDefault();
              localStorage.setItem("pincode",pincode);
              // simply.pincode = pincode;  
                // if(!simply.codPincodes.includes(parseInt(pincode))){
                //   $('#msg_error').html('')
                //   $("#zipcode").closest(".field").addClass("field--error");
                //   $('#pincode_error').remove();
        
                //   // $("#zipcode").closest(".field").append(`<p class="field__message field__message--error" id="pincode_error">${response.message}</p>`);
                //   $('#msg_error').html(`COD service is not available in this area`)
                //   allcondittionsPass = false;
                  
                //   setTimeout(function () {
                //     $("#continue_button").removeAttr("disabled");
                //     $("#continue_button").removeClass("btn--loading");
                //   }, 3000);
                // }
                // else{
                  // if(!localStorage.getItem("cod-pin-code-status")){
                    // localStorage.setItem("cod-pin-code-status","200");
                    // localStorage.setItem("cod-pin-code-msg","COD available");
                    $('div[data-step="contact_information"] form.edit_checkout').submit();
                  // }
                // }
            // });
        }
      }
    );
  };
  fetchPincodes = async () =>{
    let pincodeFileUrl = simply.pincodeFile;
    await fetch(pincodeFileUrl)
    .then(response => response.json())
    .then(data => { 
      localStorage.setItem("codPincodes",data)
      this.pinCodeServiceability();
    });
  }
  pinCodeServiceability = () => {
    if(Shopify.Checkout.step == 'payment_method'){
        let pincode = localStorage.getItem("pincode")
        let codNotAvailableMsg = '<div class="cod-unserviceable-wrapper"><span class="">Cash on delivery is suspended temporarily to ensure social distancing.</span></div>'
        let codAvailable = localStorage.getItem('cod-pin-code-status');
        let codPincodes = localStorage.getItem('codPincodes');
        if(!codPincodes.includes(parseInt(pincode))){
            $('div.radio-wrapper[data-select-gateway="'+ this.codID +'"]').remove();
            $('div.section--payment-method .section__content').append(codNotAvailableMsg);
        }
    }
  }

  noOfferTag = () => {
    let noOffer = simply.no_offers;
    if(noOffer){
     //console.log("exist");
     $('#checkout_reduction_code').attr({
      disabled:"disabled", 
      placeholder:"The product is already at its best price"
     });
     $('#checkout_reduction_code').css('background-color','#f2f2f2');
    }
    else{
      //console.log(noOffer);
    }
  };

  showGiftWrap = async () =>{ 
    let respo = await cartJson();
    // let foundCodItem = false;
    var myCount = 0;
    let giftWrapFound = false;
     let item = respo.items;
     if(item.length > 0){
       for(let i = 0; i < item.length; i ++){
        let el =item[i].id;
          if (el === 39357298016343){
            giftWrapFound = true;
            break;
          }
        }
      }
      if (giftWrapFound){
          $(".order-summary__section--discount").prepend(
            `
            <div class="gift-wrapper" id="onclick"> 
               <input checked id="gift-input-remove"
               class="enabled"
                type="checkbox"
                value="gift wrap"
              />
              <label for='gift_wrap' id="gift-label-remove">
               Add gift wrap for ₹30
              </label>
           </div>
          `
          );       
        $("#onclick").click(function() {
          $("#gift-label-remove").html("Removing gift wrap...");
          $("#gift-input-remove").removeAttr("checked");
          jQuery.post('/cart/update.js', {updates: {39357298016343: 0}});
          setTimeout(function(){  location.reload(); }, 1000);
        });
      }
      else{
        $(".order-summary__section--discount").prepend(
          `<div class="gift-wrapper" id="onclick1">
          <input id="gift-input"
          type="checkbox"
          value="gift wrap"
          />
          <label for='gift_wrap' id="gift-label">
           Add gift wrap for ₹30
         </label>
       </div>`
      );
      $("#onclick1").click(function() {
        myCount++;
        $("#gift-label").html("Adding gift wrap...");
        $("#gift-input").attr("checked","checked");
        if (myCount < 2){
          let formData = {
            'items': [{
             'id': 39357298016343,
             'quantity': 1
             }]
           };
          fetch('/cart/add.js', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-Requested-With': 'XMLHttpRequest' // This is needed as currently there is a bug in Shopify that assumes this header
            },
            body: JSON.stringify(formData)  
          })
          .then(response => {
           // return response.json();
           location.reload();
          })
          .catch((error) => {
            alert("Sorry! We are out of gift wraps!");
          });
        }
        else{
        }
        
      });
    }
};

  init = () => {
    this.announcementBar();
    this.clickEvent();
    this.changeEvent();
    this.pageLoadEvent();
    this.submitEvent();
    // new pinCodeUpdate();
    new skipShipping();
    // otp verification
    new phoneVerification();
    new paymentMethod();
    // add properties based on payment method
    // this.paymentPropertiesObj.init()
    this.fetchPincodes();
    this.noOfferTag();
    // if( Shopify.Checkout.step == 'contact_information' ){
    //   $(document).on("page:load page:change", (e) => {
    //   this.showGiftWrap();
    //   });
    // }
  };
}

new checkout();
