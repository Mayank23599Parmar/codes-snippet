import {setCookie,getCookie,cartJson,addItem,clearCart} from './checkout-helper';
class checkoutProductProperties{
    constructor(){
        this.init();
        this.mainParent = $('[data-payment-method]');
        this.nonCodId = [63750570071,37800451];
        this.cartJson = {};
    }
    checkPaymentGatewayAndCodProperties = async () => {
        let prevID = getCookie("payment_gateway");
        // debugger
        let currentId = parseInt($('input[name="checkout[payment_gateway]"]:checked').val());
        let respo = await cartJson();
        let foundCodItem = false;
        let item = respo.items;
        if(item.length > 0){
            for(let i = 0; i < item.length; i ++){
                let el =item[i];
                if(el.properties && el.properties.cod){
                    foundCodItem = true;
                    break;
                }
            }
        }
        if(!prevID){
            if(this.nonCodId.includes(currentId)){
                if(foundCodItem){
                    return false;
                }else{
                    this.addCodProperties();
                }
            }else{
                if(foundCodItem){
                    this.removeCodProperties();
                }else{
                    return false;
                }
            }
        }
    }
    setPaymentMethodId = () => {
        // debugger
        let prevID = getCookie("payment_gateway");
        let selectedId = $("input[name='checkout[payment_gateway]']:checked").val();
        let firstSelect = $("input[type='radio']:first",this.mainParent);
        let gateway = $(firstSelect).val();
        if(cn(prevID)){
            setCookie("payment_gateway", gateway, 1);
        }else if(prevID !== selectedId){
            $(`input[type='radio'][value="${prevID}"]`).prop('checked',true).trigger('change');
        }
    }

    checkProductProperties = (that) => {
        let prevID = parseInt(getCookie("payment_gateway"));
        let currentID = parseInt($(that).val());
        setCookie("payment_gateway", currentID, 1)
        if(prevID == currentID){
            return false;
        }else if(this.nonCodId.includes(currentID)){
            if(this.nonCodId.includes(prevID)){
                return false;
            }else{
                // add cod on properties
                this.addCodProperties();
            }
        }else{
            // remove cod on properties
            this.removeCodProperties();
        }
    }

    addCodProperties = async () => {
        // $('.loading-gif').show();
        let respo = await cartJson();
        let data = [];
        respo.items.map((item,index)=>{
            let prop = item.properties;
            prop['cod'] = 'cod';
            data.push({id:item.id,quantity:item.quantity,properties:prop});
        })
        this.updateItems(data);
    }
    removeCodProperties = async () => {
        // $('.loading-gif').show();
        let respo = await cartJson();
        let data = [];
        respo.items.map((item,index)=>{
            let prop = item.properties;
            let customProp = {};
            Object.keys(prop).map(item=>{
                let key  = item;
                let value = prop[item];
                if(key != 'cod'){
                    customProp[key]=value;
                }
            });
            data.push({id:item.id,quantity:item.quantity,properties:customProp});
        })
        this.updateItems(data);
    }

    updateItems = async (data) => {
        let res =  await clearCart();
        let resp = await addItem({items:data});
        // OrderSummaryUpdater.prototype.refresh();
        window.location.reload();
        // $('.loading-gif').hide();
    }
    init = () =>{
        if(Shopify.Checkout.step == 'payment_method'){
            this.checkPaymentGatewayAndCodProperties();
            this.setPaymentMethodId();
        }
    }
}
export default checkoutProductProperties;