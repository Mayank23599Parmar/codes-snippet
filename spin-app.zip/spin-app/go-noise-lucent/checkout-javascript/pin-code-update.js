import { blackBgOpen, blackBgClose, setCookie } from './checkout-helper';
class pinCodeUpdate {
  constructor() {
    this.pinCodeData = null;
    this.init();
  }
  clickEvent = () => {};
  changeEvent = () => {
    $(document).bind("change paste", "#zipcode", async () => {
      if ($("#zipcode").val()) {
        var new_zip = $("#zipcode").val();
        $("#checkout_shipping_address_zip").val(new_zip);
        $(".zone_msg").remove();
        $(".zone_msg_xs").remove();
        if(cn(this.pinCodeData)){
          await this.fetchPinCodeData();
        }
        await this.verifyZipCode();
      }
    });
    $(".phone_wrapper #checkout_shipping_address_phone_clone").keyup((e) => {
      if (!cn($("#checkout_shipping_address_phone_clone").val())) {
        let withoutSpaces = $("#checkout_shipping_address_phone_clone").val().substring(0, 10);
        let withoutSpaces1 = withoutSpaces.replace(/\s+/g, "");
        let withoutSpaces2 = withoutSpaces1.replace(/[^0-9]/g, "");
        $("#checkout_shipping_address_phone_clone").val(withoutSpaces2);
        $("#checkout_shipping_address_phone").val(withoutSpaces2);
      }
    });
    $(document).on("change",".phone_wrapper #checkout_shipping_address_phone_clone",(e) => {
        $("#error-for-phone").remove();
        if (!cn($("#checkout_shipping_address_phone_clone").val())) {
          let withoutSpaces = $("#checkout_shipping_address_phone_clone").val().substring(0, 10);
          var withoutSpaces1 = withoutSpaces.replace(/\s+/g, "");
          var withoutSpaces2 = withoutSpaces1.replace(/[^0-9]/g, "");
          $("#checkout_shipping_address_phone_clone").val(withoutSpaces2);
          $("#checkout_shipping_address_phone").val(withoutSpaces2);
          // this.setMobileNumber();
        }
      }
    );
  };
  addZoneMsg = function (msg) {
    $(".zone_msg").remove();
    $(".zone_msg_xs").remove();
    $('<p class="zone_msg field">' + msg + "</p>").insertAfter('[data-address-field="city"]');
    $('<p class="zone_msg_xs">' + msg + "</p>").insertAfter("#zipcode");
  };
  verifyZipCode = async () => {
    let new_zip = $("#zipcode").val();
    if (cn(this.pinCodeData[new_zip])) {
      $("#checkout_shipping_address_city").val("");
      $("#checkout_shipping_address_province").val("");
      $("#msg_error").html("Sorry! Incorrect PIN");
    } else {
      let zipObj = this.pinCodeData[new_zip];
      $("#msg_error").html("");
      $("#checkout_shipping_address_city").val(zipObj.City)
      $('[data-address-field="city"]').removeClass('field--error');
      $("#checkout_shipping_address_province option").each(function () {
        var st = $(this).html().toLowerCase();
        var st1 = zipObj.State.toLowerCase();
        if (st == st1) {
          $("#checkout_shipping_address_province").val($(this).attr("value"));
        }
      });
      $(".step__footer__continue-btn.btn").first().removeAttr("disabled");
      // $(".step__footer__continue-btn.btn").css("background-color", "#000");
    }
  };
  initPhoneClone = () => {
    $(".phone_wrapper #checkout_shipping_address_phone_clone").keyup(function (
      e
    ) {
      if (!cn($("#checkout_shipping_address_phone_clone").val())) {
        let withoutSpaces = $("#checkout_shipping_address_phone_clone")
          .val()
          .substring(0, 10);
        let withoutSpaces1 = withoutSpaces.replace(/\s+/g, "");
        let withoutSpaces2 = withoutSpaces1.replace(/[^0-9]/g, "");
        $("#checkout_shipping_address_phone_clone").val(withoutSpaces2);
        $("#checkout_shipping_address_phone").val(withoutSpaces2);
      }
    });
  };
  phoneFieldInsert = () => {
    $('#checkout_shipping_address_phone_clone').closest('.phone_wrapper').remove();
    $('[data-address-field="phone"]').hide();
    $('[data-address-field="phone"]').closest(".field").addClass("main_phone_wrapper");
    let phone_field = $(".phone_wrapper").clone();
    $(phone_field).find("input").attr("id", "checkout_shipping_address_phone_clone");
    let str = $("#checkout_shipping_address_phone").val();
    if (!cn(str)) {
      str = str.replace(/ /g, "");
    }
    $(phone_field).find("input").val(str);
    phone_field.insertBefore($(".field[data-address-field=address1]"));
    $("#checkout_shipping_address_phone_clone").parent().find("label").css("padding-left", "12%");
    this.initPhoneClone();
  };
  insertPinCode = () => {
    $('[data-address-field="country"]')
      .removeClass("field--third")
      .addClass("field--half");
    $('[data-address-field="province"]')
      .removeClass("field--third")
      .addClass("field--half");
    $('[data-address-field="city"]')
      .removeClass("field--third")
      .addClass("field--half");

    //$("#checkout_reduction_code").removeAttr("disabled");
    $(".new-pincode-section").remove();
    $(
      '<div class="new-pincode-section field field--required field--show-floating-label field--half"><div class="new-pincode_div field__input-wrapper"><label class="field__label field__label--visible" id="title">Pincode</label><input type="text" class="new-pincode_input field__input" placeholder="Pincode" id="zipcode"></div><label id="msg_error"></label></div>'
    ).insertAfter('[data-address-field="address1"]');
    $("#zipcode").val($("#checkout_shipping_address_zip").val());
    $('[data-address-field="zip"]').hide();
  };
  setMobileNumber = () => {
    let mobile1 = $("#checkout_shipping_address_phone_clone").val();
    if (typeof mobile1 != "undefined") {
      var mobString = mobile1.replace(/\s+/g, "");
      var finalMob = mobString.substr(mobString.length - 10);
      localStorage.setItem("otp-mobile", finalMob);
    }
  };
  fetchPinCodeData = async () => {
    if (!cn(simply.service_zip_json_file)) {
      let data = await fetch(simply.service_zip_json_file);
      let jsonData = await data.json();
      let finalData = {};
      $.each(jsonData, (i, zip) => {
        finalData[zip.Pincode] = zip;
      });
      this.pinCodeData = finalData;
    }
  };
  updateContinueButton = () => {
    $("#continue_button .btn__content").text("Continue to payment method");
  };
  
  init = () => {
    if (Shopify.Checkout.step == "contact_information") {
      this.clickEvent();
      this.changeEvent();
      this.fetchPinCodeData();
      this.insertPinCode();
      this.phoneFieldInsert();
      this.updateContinueButton();
    }
  };
}
export default pinCodeUpdate;
