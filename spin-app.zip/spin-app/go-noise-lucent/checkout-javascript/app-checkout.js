window.$ = window.jQuery = $;
require('./checkout');
require('./scss/checkout.scss');