class paymentMethod{
    constructor(){
        this.init();
    }
   
    changeOfferText = () =>{
        let noOffer = simply.no_offers;
        if(noOffer){
         console.log("exist");
         $('.payment-offer-text').remove();
        }
        else{
          //console.log(noOffer);
          let targetDiv = $(`div[data-payment-subform="required"]`);
        let selectedPaymentGateway = $(`input[name="checkout[payment_gateway]"]:checked`);
        let savedPayment = simply.total_item_discount.slice(0, -2);
        let offerText = '';
        $('.payment-offer-text').remove();
        $('.small-payment-offer').remove();
        if(selectedPaymentGateway.val() === '37800451'){
            $('.small-payment-offer').remove();
            let paymentSmallText = $(`label[for="checkout_payment_gateway_37800451"]`);
            //paymentSmallText.append(`<span class="small-payment-offer">GET EXTRA 5% OFF ONLINE PAYMENT MODE, USE CODE: <b style="font-weight:bold;color:#000">GOSMART</b></span>`);
            offerText = $(`<span class="payment-offer-text">SAVE <span style="font-weight:bold;font-size: 20px;">₹${savedPayment}.</span> USE CODE: <b style="font-weight:bold;font-size:20px;">GOSMART</b><br /></span>`) 
        }else if(selectedPaymentGateway.val() === '63750570071'){
            $('.small-payment-offer').remove();
            let paymentSmallText = $(`label[for="checkout_payment_gateway_37800451"]`);
            offerText = $(`<span class="payment-offer-text"> Pay in 4 payments of ${simply.checkoutRazorPayEMIPrice}. NO interest
            </span>`) 
        }else{
            offerText = $(`<span class="payment-offer-text">SAVE <span style="font-weight:bold;font-size: 20px;">₹${savedPayment}.</span> USE CODE: <b style="font-weight:bold;font-size:20px;">GOSMART</b><br /></span>`) 
        }
        targetDiv.prepend(offerText)
        
        if ($(".tags-list").length > 0) {
        }
        }
        
    }
    changeRazorPayText = () =>{
        let razorPayItem = $('#checkout_payment_gateway_113885766');
        if(razorPayItem.length > 0){
            //$('label[for="checkout_payment_gateway_113885766"]').text(`No Cost EMI Starts ${simply.checkoutRazorPayEMIPrice}`);
        }
        $('.loading-gif').hide();
    }
   
    init = () =>{
        
        if(Shopify.Checkout.step == 'payment_method'){
            if($('.order-summary__section--discount .reduction-code').length <= 0){
                this.changeOfferText();
            }
            this.changeRazorPayText();
            // $('#continue_button').removeAttr('disabled');
            // $('.otp-verified-sec').remove();
        }
    }
}
export default paymentMethod;