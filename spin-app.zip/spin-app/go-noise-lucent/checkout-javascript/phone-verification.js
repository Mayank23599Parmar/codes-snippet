import { blackBgOpen, blackBgClose, setCookie } from './checkout-helper';
import paymentMethod from "./payment-method";
class phoneVerification {
    constructor() {
        this.codID='37800451';
        this.timerCounterStart = false;
        this.counter = 60;
        this.timer;
        this.otpIntervalTime = 60 * 3;
        this.otpMainSentCounter = this.otpIntervalTime;
        this.otpMainSent;
        this.init();
    }
    clearMainOTPSet = () =>{
        localStorage.setItem("otp","");
        this.otpMainSentCounter = this.otpIntervalTime;
        clearInterval(this.otpMainSent);
        return
    }
    mainOTPSet = () =>{
        this.otpMainSent = setInterval(()=> {
            this.otpMainSentCounter -= 1;
            console.log("Main=>",this.otpMainSentCounter);
            if(this.otpMainSentCounter <= 0 ){
                this.clearMainOTPSet();
            }
        }, 1000);
    }
    clickEvent = () => {
        //edit mobile number
        $(document).on('click', '.edit_mobile_link', (e) => {
            e.preventDefault();
            window.location.href = `${window.location.pathname}?step=contact_information`;
            // document.getElementById('count-timer').innerHTML = '';
            // $("#continue_button").removeAttr("disabled");
            // $("#continue_button").removeClass("btn--loading");
            // this.closeOTPBox();
        });
        $(document).on('click', '#otp_back', (e) => {
            e.preventDefault();
            setCookie('payment_gateway', '', 1);
            window.location.href = `${window.location.pathname}?step=contact_information`;
        });
        // resend otp 
        $(document).on('click', '.resend-btn', (e) => {
            e.preventDefault();
            $('#resend-otp').hide();
            $('#count-timer-wrap').show();
            clearInterval(this.timer);
            this.counter = 60;
            this.timerCount();
            this.checkPhoneVerificationModal(true);
        });
      
        $(document).on("change", "input[name='checkout[payment_gateway]']", (e) => {
            if(simply.checkoutEnable){
                if(e.target.value===this.codID){
                  if(localStorage.getItem('otp-verified')!=='true'){
                    let otpShouldSent = this.otpMainSegtntCounter == 0 ? true : false;
                    this.checkPhoneVerificationModal(true);
                  }
                }
                new paymentMethod();
            }
        });
    }
    sendOTPNumber = (mobileNumber) => {
        var otp = localStorage.getItem("otp");
        // if(cn(otp)){
        //     otp=Math.floor(Math.random() * 899999 + 100000);
        //     localStorage.setItem("otp",otp);
        // }
        otp=Math.floor(Math.random() * 899999 + 100000);
        localStorage.setItem("otp",otp);
        var message=`Your OTP is ${otp} for order confirmation. OTP is confidential. Please do not share it with anyone. -Team Noise`;
        message = encodeURIComponent(`Your authentication code is ${otp}. @www.gonoise.com #${otp}`);
        var settings = {
            "async": true,
            "crossDomain": true,
            "url": `https://alerts.solutionsinfini.com/api/v4/?api_key=Ab33c2d72f2228a81c2438fba0727f23f&method=sms&message=${message}&to=${mobileNumber}&sender=GNOISE`,
            "method": "POST",
            cache: false,
        }
        $.ajax(settings).done( (response)=>{
            // console.log(response);
        });
    }

    
    timerCount = () => {
        console.log('Started=>',this.counter);
        this.timer = setInterval(()=> {
            console.log("Inner=>",this.counter);
            this.counter -= 1;
            // Display 'counter' wherever you want to display it.
            if (this.counter <= 0) {
                this.counter = 60;
                clearInterval(this.timer);
                $('#resend-otp').show();
                $('#count-timer-wrap').hide();
                document.getElementById('count-timer').innerHTML = '01:00';
                return;
            }else{
                var m = Math.floor(this.counter / 60);
                var s = this.counter % 60;
                m = m < 10 ? '0' + m : m;
                s = s < 10 ? '0' + s : s;
                document.getElementById('count-timer').innerHTML = m + ':' + s;
            }
        }, 1000);
    }
    showError = msg => {
        let error = $('.checkout-otp-popup .phone-verify-error');
        $('p', error).text(msg);
        $(error).show();
    }
    hideError = () => {
        let error = $('.checkout-otp-popup .phone-verify-error');
        $(error).hide();
    }
    verifyOTPNumber = otp => {
        var storedOTP = localStorage.getItem('otp');
        let checkout_shipping_address_phone = $( "#checkout_shipping_address_phone_clone").val();
        if (otp == '') {
            this.showError('Please Enter received OTP')
            return false;
        }
        if(storedOTP == otp ){
            localStorage.setItem('otp-verified',"true");
            document.getElementById('count-timer').innerHTML = '';
            this.closeOTPBox();
            clearInterval(this.timer);
            this.counter = 60;
            this.clearMainOTPSet();
        }else{
            this.showError('Please enter correct OTP or try regenerating the OTP')
        }
    }
    showOTPBox = (mobileNumber) => {
        if(!this.timerCounterStart){
            this.timerCount();
            this.timerCounterStart = true;
        }
        let otpBox = $('.checkout-otp-popup');
        let mobileNumberDiv = $('#mobile-otp');
        let mobileNumberStr = mobileNumber.toString();
        mobileNumberDiv.text(mobileNumberStr);
        blackBgOpen();
        otpBox.show();
        let input = document.querySelector('input[autocomplete="one-time-code"]');
        $(input).focus();
    }
    closeOTPBox = () => {
        let otpBox = $('.checkout-otp-popup');
        blackBgClose();
        otpBox.hide();
    }
    checkPhoneVerificationModal = async (sendOTP) => {
        if(this.otpMainSentCounter === this.otpIntervalTime){
            this.mainOTPSet();
        }
        // set old otp empty if exits
        $("#votp").val("");
        // fetch mobile No
        let mobile = localStorage.getItem('phone-number');
        mobile = mobile.replaceAll(' ', '');
        let mobileNumber = parseInt(mobile);
        if(sendOTP){
            this.sendOTPNumber(mobileNumber);
        }
        this.showOTPBox(mobileNumber);
    }
    changeEvent = () => {
          // verify otp
          $(document).on('keyup change paste blur', '#votp', (e) => {
            e.preventDefault();
            this.hideError();
            let otp = $("#votp").val();
            if (otp.length === 6) {
                this.verifyOTPNumber(otp);
            }
        });
    }
    blurEvent = () =>{
        $(document).on('blur', ".phone_wrapper #checkout_shipping_address_phone_clone", (e)=> {
            // if(simply.checkoutEnable){
                let checkout_shipping_address_phone = $( "#checkout_shipping_address_phone_clone").val();
                let format_match = false;
                if (!cn(checkout_shipping_address_phone)) {
                    var first_char = $("#checkout_shipping_address_phone_clone").val().charAt(0);
                    if ( first_char == "6" || first_char == "7" || first_char == "8" || first_char == "9" ) {
                    format_match = true;
                    }
                }
                if (!cn(checkout_shipping_address_phone) && checkout_shipping_address_phone.length == 10 && format_match ) {
                    if(localStorage.getItem('phone-number') !== checkout_shipping_address_phone ){
                        localStorage.setItem('phone-number',checkout_shipping_address_phone)
                        localStorage.setItem('otp-verified',null);
                        this.clearMainOTPSet();
                        clearInterval(this.timer);
                        this.counter = 60;
                        this.timerCounterStart = true;
                    }
                }
            // }
        });
    }
    autoReadOTP = () =>{
        // if ('OTPCredential' in window) {
        //     window.addEventListener('DOMContentLoaded', e => {
        //       const input = document.querySelector('input[autocomplete="one-time-code"]');
        //       if (!input) return;
        //       // Cancel the WebOTP API if the form is submitted manually.
        //       const ac = new AbortController();
        //       const form = input.closest('form');
        //       // Invoke the WebOTP API
        //       navigator.credentials.get({
        //         otp: { transport:['sms'] },
        //         signal: ac.signal
        //       }).then(otp => {
        //           input.value = otp.code;
        //           $(input).blur();
        //           $(input).change();
        //         //   Cancel the WebOTP API.
        //           ac.abort();
        //       }).catch(err => {
        //         console.log(err);
        //       });
        //     });
        // }
    }
    // pinCodeServiceability = () => {
    //     if(Shopify.Checkout.step == 'payment_method'){
    //         let codNotAvailableMsg = '<div class="cod-unserviceable-wrapper"><span class="">Cash on delivery is suspended temporarily to ensure social distancing.</span></div>'
    //         let codAvailable = localStorage.getItem('cod-pin-code-status');
    //         if(codAvailable !== "200"){
    //             $('div.radio-wrapper[data-select-gateway="'+ this.codID +'"]').remove();
    //             $('div.section--payment-method .section__content').append(codNotAvailableMsg);
    //         }
    //     }
    //   }
    closeOPTWrapper=()=>{
        $(document).on('click', "#close-otp-wrapper", (e)=> {
            window.location.href = `${window.location.pathname}?step=contact_information`;
            e.preventDefault()
        })
    }
    init = () => {
        // this.autoReadOTP();
        this.clickEvent();
        this.changeEvent();
        this.blurEvent();
        this.closeOPTWrapper()
    }
}
export default phoneVerification;