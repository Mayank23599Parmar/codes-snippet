// import {cartJson} from './checkout-helper';
// class giftWrap{
//     constructor(){
//         this.init();
//         this.cartJson = {};
//     }
//     showGiftWrap = () =>{
//         $(".order-summary__section--discount").prepend(
//             `<div class='test'><p>Test test<p></div>`
//         );
//     }
//     init = () =>{
//         const { cartData } = this.props;
//         console.log(cartItems);
//         if( Shopify.Checkout.step == 'contact_information' ){
//             this.showGiftWrap()
//         }
//     }
// }

// export default giftWrap;