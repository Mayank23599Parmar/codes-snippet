class skipShipping{
    constructor(){
        this.init();
    }
    hideShippingBreadcrumb = () =>{
        $('.main__header .breadcrumb .breadcrumb__item .breadcrumb__link').each(function() {
            if($( this ).text() == 'Shipping'){
                $(this).parent().hide();
            }
        });
        $('.main__header .breadcrumb .breadcrumb__item .breadcrumb__text').each(function() {
            if($( this ).text() == 'Shipping'){
                $(this).parent().hide();
            }
        });
    }
    init = () =>{
        this.hideShippingBreadcrumb()
        if( Shopify.Checkout.step == 'shipping_method' ){
            $('[data-shipping-method] input[type="radio"]:first').trigger('click');
            $('.step__footer__continue-btn.btn').trigger('click');
        }
        if( Shopify.Checkout.step == 'payment_method' ){
            $(".step__footer__previous-link-content").html('Return to Cart');
            $(".step__footer__previous-link").attr("href","/cart");
        }
    }
}

export default skipShipping;