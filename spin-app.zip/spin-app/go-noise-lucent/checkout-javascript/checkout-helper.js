/* to show/hide black black background */
export const blackBgOpen = () => {
    $(".black-bg").fadeIn();
    $("html").addClass("overflow-hidden");
    $("body").addClass("overflow-hidden");
  }
  export const blackBgClose = () => {
    $(".black-bg").fadeOut();
    $("html").removeClass("overflow-hidden");
    $("body").removeClass("overflow-hidden");
  }
  export const getCookie = function(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  };
  export const setCookie = function(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  };
export const cartJson = async function(){
  let respo = await fetch("/cart.js", {
    method: "GET",
  });
  respo = await respo.json();
  return respo;
}
export const ProductJson = async function(){
  let respo2 = await fetch("/products.json", {
    method: "GET",
  });
  respo2 = await respo2.json();
  return respo2;
}

export const clearCart = async function(){
  let respo = await fetch("/cart/clear.js", {
    method: "GET"
  });
  respo = await respo.json();
  return respo;
}

export const addItem = async(data) =>{
  const res = await  fetch('/cart/add.js',{
      credentials: 'same-origin',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest' // This is needed as currently there is a bug in Shopify that assumes this header
      },
      body: JSON.stringify(data)
  });
  const resJson = await res.json();
  return resJson;
};