require('./account');
require('./product-page');
require('./footer');
require('../scss/app.scss');