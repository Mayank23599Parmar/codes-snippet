$( document ).ready(()=>{

    $('.footer-liquid').on('click',function(){
        let menu = $(this).parent('.menu');
        let submenu = $(this).siblings('.submenu');
        if(window.innerWidth < 426){
            if(menu.hasClass('active')){
                menu.removeClass('active');
            }
            else{
                menu.addClass('active');
            }
        }
    })
})