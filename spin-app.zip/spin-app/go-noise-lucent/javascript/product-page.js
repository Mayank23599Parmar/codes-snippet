class ProductPage {
  constructor(){
  }
  init = ()=>{
  }
}
new ProductPage;