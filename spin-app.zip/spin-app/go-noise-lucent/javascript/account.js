class AccountPage {
    constructor(){
        this.init();
    }

    toggleRecoverPasswordForm = () => {
        
        const parent = document.querySelectorAll('#login-page').length;
        if( parent > 0 ){
            const showHide = () => {
                RecoverPasswordForm.classList.toggle("hide");
                CustomerLogin.classList.toggle("hide");
            }
            const RecoverPasswordForm = document.querySelector('#RecoverPasswordForm');
            const CustomerLogin = document.querySelector('#CustomerLoginForm');
            const HideRecover = document.querySelector('#HideRecoverPasswordLink');
            const RecoverPassword = document.querySelector('#RecoverPassword');
            const resetPasswordSuccess = document.querySelector('.reset-password-success')
            if(window.location.href.includes('#recover')){
                showHide();
            }
            RecoverPassword.addEventListener("click", () => {
                showHide();
            });
            HideRecover.addEventListener("click", () => {
                showHide();
            });
        }
    }
    resetPassword = function () {
        if ($("#login-page").length > 0) {
          if ($(".reset-password-success").length > 0) {
            $("#ResetSuccess").removeClass("hide");
          }
        }
    };
    getHash = () => {
        return window.location.hash;
    };
    checkUrlHash = () => {
        var hash = this.getHash(); // Allow deep linking to recover password form
      
        if (hash == '#recover') {
          this.showRecoverPasswordForm();
        }
    };
    showRecoverPasswordForm =  () => {
        $('#RecoverPasswordForm').removeClass('hide');
        $('#CustomerLoginForm').addClass('hide');
    };

    hideGuestLogin = () =>{
        const urlParams = new URLSearchParams(window.location.search);
        if(urlParams.get('checkout_url') && urlParams.get('checkout_url').includes('products')){
            $('#guest-login').hide();
        }
    }

    init = ()=>{
        this.toggleRecoverPasswordForm();
        this.resetPassword();
        this.checkUrlHash();
        this.hideGuestLogin();
    }
}
new AccountPage;


$( document ).ready(function() {

    var $newAddressForm = document.querySelector('.address-add');
    if ($newAddressForm == null) {
		return;
	}
    
    const showAdress = document.querySelector('.address-new-toggle');
    showAdress.addEventListener("click", () => {
        $newAddressForm.classList.toggle("hide");
    });
    new Shopify.CountryProvinceSelector('AddressCountryNew', 'AddressProvinceNew', {
        hideElement: 'AddressProvinceContainerNew'
    });
    $('.address-country-option').each(function() {
        var formId = $(this).data('form-id');
        var countrySelector = 'AddressCountry_' + formId;
        var provinceSelector = 'AddressProvince_' + formId;
        var containerSelector = 'AddressProvinceContainer_' + formId;

        new Shopify.CountryProvinceSelector(countrySelector, provinceSelector, {
            hideElement: containerSelector
        });
    });
    $('.address-edit-toggle').on('click', function () {
        var id = $(this).attr("data-form-id");
        var check = $(this).attr("data-toggle");
        $("#address_page .edit_forms").hide();
        $('.address-edit-toggle').not(this).attr("data-toggle","0");
        if(check == '0'){
            $("#EditAddress_"+id).show();
            $(this).attr("data-toggle","1");
        }
        else{
            $("#EditAddress_"+id).hide();
            $(this).attr("data-toggle","0");
        }
    });
    $('.address-delete').on('click', function() {
        var $el = $(this);
        var formId = $el.data('form-id');
        var confirmMessage = $el.data('confirm-message');
        if (confirm(confirmMessage || "Are you sure you wish to delete this address?")) {
            Shopify.postLink('/account/addresses/' + formId, {'parameters': { '_method': 'delete' }});
        }
    });
});